"""Password hashing, tokens, sessions, roles and the permission pipeline.

Rules enforced here (spec 3, 23, 24):
  * passwords are only ever stored as PBKDF2-HMAC-SHA256 hashes with a per-user salt
  * the first account may become OWNER only while no OWNER exists
  * OWNER-ness is decided server side and can never be requested by a client
  * device tokens and pairing codes are stored hashed, never in plaintext
"""
from __future__ import annotations

import hashlib
import hmac
import os
import re
import secrets
import time
import uuid
from typing import Optional

from . import config, db

ROLE_OWNER = "OWNER"
ROLE_TRUSTED = "TRUSTED_USER"
ROLE_LIMITED = "LIMITED_USER"
ROLES = (ROLE_OWNER, ROLE_TRUSTED, ROLE_LIMITED)

# Permissions a paired device may hold. The owner grants these explicitly.
ALL_PERMISSIONS = (
    "chat",
    "system.read",
    "browser.control",
    "windows.control",
    "files.read",
    "files.write",
    "voice",
    "gmail",
    "calendar",
    "devices.manage",
)
DEFAULT_DEVICE_PERMISSIONS = ["chat", "system.read"]
HOST_PERMISSIONS = list(ALL_PERMISSIONS)


# --------------------------------------------------------------------------- #
# passwords
# --------------------------------------------------------------------------- #
def hash_password(password: str) -> str:
    if not isinstance(password, str) or len(password) < 6:
        raise ValueError("Password must be at least 6 characters.")
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, config.PBKDF2_ITERATIONS)
    return f"pbkdf2_sha256${config.PBKDF2_ITERATIONS}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        algo, iters, salt_hex, hash_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        dk = hashlib.pbkdf2_hmac(
            "sha256", (password or "").encode("utf-8"), bytes.fromhex(salt_hex), int(iters)
        )
        return hmac.compare_digest(dk.hex(), hash_hex)
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# tokens
# --------------------------------------------------------------------------- #
def new_token(prefix: str = "jtk") -> str:
    return f"{prefix}_{secrets.token_urlsafe(32)}"


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


_PAIR_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no look-alikes


def new_pairing_code() -> str:
    a = "".join(secrets.choice(_PAIR_ALPHABET) for _ in range(4))
    b = "".join(secrets.choice(_PAIR_ALPHABET) for _ in range(4))
    return f"PAIR-{a}-{b}"


def normalize_pairing_code(code: str) -> str:
    c = (code or "").strip().upper().replace(" ", "")
    if not c.startswith("PAIR-"):
        c = "PAIR-" + c.lstrip("-")
    return c


# --------------------------------------------------------------------------- #
# users
# --------------------------------------------------------------------------- #
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{3,32}$")


def owner_exists() -> bool:
    return db.one("SELECT 1 FROM users WHERE role=? LIMIT 1", (ROLE_OWNER,)) is not None


def create_user(username: str, password: str) -> dict:
    username = (username or "").strip()
    if not USERNAME_RE.match(username):
        raise ValueError("Username must be 3-32 chars: letters, digits, dot, dash, underscore.")
    if db.one("SELECT 1 FROM users WHERE username=?", (username,)):
        raise ValueError("That username is already taken.")

    pw_hash = hash_password(password)          # raises on short passwords
    # OWNER only if none exists yet - decided here, never accepted from the client.
    role = ROLE_OWNER if not owner_exists() else ROLE_LIMITED
    user_id = f"usr_{uuid.uuid4().hex[:16]}"
    db.execute(
        "INSERT INTO users(user_id,username,password_hash,role,created_at) VALUES (?,?,?,?,?)",
        (user_id, username, pw_hash, role, time.time()),
    )
    return {"user_id": user_id, "username": username, "role": role}


def authenticate(username: str, password: str) -> Optional[dict]:
    row = db.one("SELECT * FROM users WHERE username=?", ((username or "").strip(),))
    if not row or row["disabled"]:
        # still burn time so timing does not leak whether the user exists
        hash_password("dummy-password-check")
        return None
    if not verify_password(password, row["password_hash"]):
        return None
    return {"user_id": row["user_id"], "username": row["username"], "role": row["role"]}


def create_session(user_id: str, device_id: str | None = None) -> str:
    token = new_token("jsess")
    now = time.time()
    db.execute(
        "INSERT INTO sessions(session_id,user_id,created_at,expires_at,device_id) VALUES (?,?,?,?,?)",
        (token_hash(token), user_id, now, now + config.SESSION_TTL_SECONDS, device_id),
    )
    return token


def resolve_session(token: str) -> Optional[dict]:
    if not token:
        return None
    row = db.one(
        "SELECT s.*, u.username, u.role, u.disabled FROM sessions s "
        "JOIN users u ON u.user_id = s.user_id WHERE s.session_id=?",
        (token_hash(token),),
    )
    if not row or row["disabled"]:
        return None
    if row["expires_at"] < time.time():
        db.execute("DELETE FROM sessions WHERE session_id=?", (row["session_id"],))
        return None
    return {
        "user_id": row["user_id"],
        "username": row["username"],
        "role": row["role"],
        "device_id": row["device_id"],
        "via": "session",
    }


def destroy_session(token: str) -> None:
    db.execute("DELETE FROM sessions WHERE session_id=?", (token_hash(token),))


def resolve_device_token(token: str) -> Optional[dict]:
    if not token:
        return None
    row = db.one(
        "SELECT d.*, u.username, u.role, u.disabled FROM devices d "
        "JOIN users u ON u.user_id = d.user_id WHERE d.token_hash=?",
        (token_hash(token),),
    )
    if not row or row["state"] != "ACTIVE" or row["disabled"]:
        return None
    return {
        "user_id": row["user_id"],
        "username": row["username"],
        "role": row["role"],
        "device_id": row["device_id"],
        "permissions": row["permissions"],
        "via": "device",
    }


# --------------------------------------------------------------------------- #
# authorisation
# --------------------------------------------------------------------------- #
def role_rank(role: str) -> int:
    return {ROLE_LIMITED: 1, ROLE_TRUSTED: 2, ROLE_OWNER: 3}.get(role, 0)


def require_role(principal: dict, minimum: str) -> None:
    if role_rank(principal.get("role", "")) < role_rank(minimum):
        raise PermissionError(f"This action requires role {minimum} or higher.")


def device_has_permission(device_row, permission: str) -> bool:
    import json

    if device_row is None:
        return False
    if device_row["state"] != "ACTIVE":
        return False
    try:
        perms = json.loads(device_row["permissions"] or "[]")
    except Exception:
        perms = []
    return permission in perms
