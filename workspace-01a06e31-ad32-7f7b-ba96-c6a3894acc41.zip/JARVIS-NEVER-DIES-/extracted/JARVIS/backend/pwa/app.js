/* J.A.R.V.I.S. — Android Companion PWA.
 * Another authenticated JARVIS device. Uses the existing backend, auth, device
 * registry, protocol v1 and AI routing. No second backend, no separate chatbot.
 *
 * Storage is guarded (probes the backing store once) so a storage-denied webview
 * still works — exactly the same fix as the desktop HUD. */
"use strict";

/* ---------------------------- guarded storage ---------------------------- */
const __probe = { ok: null };
function storage() {
  if (__probe.ok !== null) return __probe.ok;
  try {
    const k = "__jarvis_probe__";
    window.localStorage.setItem(k, "1");
    window.localStorage.removeItem(k);
    __probe.ok = window.localStorage;
  } catch (e) {
    const m = {};
    __probe.ok = {
      getItem: (k) => (k in m ? m[k] : null),
      setItem: (k, v) => { m[k] = String(v); },
      removeItem: (k) => { delete m[k]; },
    };
  }
  return __probe.ok;
}
const store = {
  get: (k) => storage().getItem(k),
  set: (k, v) => { try { storage().setItem(k, v); } catch (e) {} },
  remove: (k) => { try { storage().removeItem(k); } catch (e) {} },
};

/* ------------------------------ session store ---------------------------- */
const SESSION = {
  token: store.get("jarvis.sessionToken") || "",
  deviceToken: store.get("jarvis.deviceToken") || "",
  user: null,
  deviceId: null,
  ws: null,
  busBackoff: 1000,
};

/* -------------------------------- api ----------------------------------- */
async function api(path, opts = {}) {
  const headers = Object.assign({}, opts.headers || {});
  if (SESSION.token) headers["Authorization"] = "Bearer " + SESSION.token;
  if (SESSION.deviceToken && !opts.useSession) headers["X-Device-Token"] = SESSION.deviceToken;
  if (typeof opts.body === "string") headers["Content-Type"] = "application/json";
  const resp = await fetch("/api" + path, Object.assign({}, opts, { headers }));
  let data = null;
  try { data = await resp.json(); } catch (e) {}
  if (resp.status === 401 && path !== "/auth/me") { /* token invalid */ }
  if (!resp.ok) {
    const err = new Error((data && data.detail) || resp.statusText || ("HTTP " + resp.status));
    err.status = resp.status;
    throw err;
  }
  return data;
}

const $ = (id) => document.getElementById(id);
const el = (tag, cls, text) => {
  const n = document.createElement(tag);
  if (cls) n.className = cls;
  if (text != null) n.textContent = text;
  return n;
};

/* --------------------------- Made by Lucky Kumar -------------------------
 * Appears exactly once per real application session; the marker persists via
 * guarded storage so refresh / reconnect / remount never repeats it. */
function greetOnce() {
  if (store.get("jarvis.greeted")) return;
  store.set("jarvis.greeted", "1");
  const box = el("div", "msg jarvis");
  box.innerHTML = "Good to see you. JARVIS is online.\n<span class=\"rt\">Made by Lucky Kumar. — Android Companion</span>";
  const chat = $("chat-log");
  if (chat) chat.appendChild(box);
}

/* ------------------------------ boot ------------------------------------ */
let offline = false;
async function refreshHealth() {
  try {
    const h = await api("/health");
    setConn(true);
    SESSION.health = h;
  } catch (e) {
    setConn(false);
  }
}
function setConn(online) {
  offline = !online;
  const chip = $("conn-chip");
  if (chip) { chip.textContent = online ? "ONLINE" : "OFFLINE";
    chip.className = "chip " + (online ? "online" : "offline"); }
  const banner = $("offline-banner");
  if (banner) banner.hidden = online;
}

async function refreshMe() {
  if (!SESSION.token) return false;
  try {
    const me = await api("/auth/me");
    SESSION.user = me;
    return true;
  } catch (e) {
    SESSION.token = "";
    return false;
  }
}

async function boot() {
  const ok = await refreshMe();
  if (ok) enterApp();
  else showAuth();
}

/* ------------------------------ views ----------------------------------- */
function showScreen(id) {
  ["auth", "pair", "app"].forEach((s) => {
    $("app") && s !== "app" ? 0 : 0;
  });
  $("auth").hidden = id !== "auth";
  $("pair").hidden = id !== "pair";
  $("app").hidden = id !== "app";
}

function showAuth() {
  showScreen("auth");
  $("auth-user").focus();
}

/* ----------------------------- routing views ---------------------------- */
const VIEWS = {};

VIEWS.home = () => {
  const h = SESSION.health || {};
  const c = h.components || {};
  return `
  <div class="core"><div class="orb"></div></div>
  <div class="card">
    <h3>SYSTEM STATUS</h3>
    <div class="row"><span class="k">JARVIS</span><span class="v ${c.backend ? "green" : "red"}">${c.backend ? c.backend.status : "OFFLINE"}</span></div>
    <div class="row"><span class="k">AI ROUTING</span><span class="v amber" id="home-mode">${SESSION.routingMode || "—"}</span></div>
    <div class="row"><span class="k">DEVICES ONLINE</span><span class="v green" id="home-dev-count">${SESSION.devCount ?? "—"}</span></div>
    <div class="row"><span class="k">ME</span><span class="v">${SESSION.user ? SESSION.user.username + " · " + SESSION.user.role : ""}</span></div>
  </div>
  <div class="card"><h3>QUICK COMMANDS</h3>
    <div class="status-line">
      <button class="ghost amber" data-quick="show system status">SYSTEM</button>
      <button class="ghost amber" data-quick="what time is it">TIME</button>
      <button class="ghost amber" data-quick="what's my cpu">CPU</button>
      <button class="ghost amber" data-quick="show connected devices">DEVICES</button>
    </div>
  </div>`;
};

VIEWS.chat = () => `
  <div class="chat" id="chat-log"><div class="msg jarvis">Ask JARVIS, or control your PC.</div></div>
  <div class="composer">
    <button class="mic" id="mic-btn" title="Speak">🎤</button>
    <input id="chat-in" placeholder="Open Chrome on my PC…" autocomplete="off" />
    <button id="chat-send">SEND</button>
  </div>`;

VIEWS.devices = () => `
  <div class="card"><h3>DEVICES</h3><div id="dev-list">Loading…</div></div>
  <div class="card"><h3>THIS DEVICE (PWA)</h3>
    <div class="row"><span class="k">ID</span><span class="v">${SESSION.deviceId || "(not paired)"}</span></div>
    <div class="row"><span class="k">CAPABILITIES</span><span class="v">WEB_PWA · MICROPHONE · NOTIFICATIONS · BROWSER</span></div>
    <div class="status-line"><button class="ghost amber" id="pair-again">PAIR AS DEVICE</button></div>
  </div>`;

VIEWS.memory = () => `
  <div class="status-line">
    <button class="ghost" id="mem-refresh">REFRESH</button>
    <button class="ghost amber" id="mem-enabled">…</button>
    <button class="ghost" id="mem-export">EXPORT</button>
    <button class="ghost" id="mem-import">IMPORT</button>
    <button class="ghost danger" id="mem-clear">CLEAR</button>
    <button class="ghost danger" id="mem-clear-ctx">CLEAR CONVERSATION</button>
  </div>
  <div class="card"><h3>SEARCH MEMORY</h3>
    <input id="mem-search" class="search-in" placeholder="search…" autocomplete="off" />
  </div>
  <div class="card"><h3>LONG-TERM MEMORY</h3><div id="mem-list">Loading…</div></div>
  <div class="card"><h3>LEARNED WORKFLOWS</h3><div id="wf-list">Loading…</div></div>
  <input type="file" id="mem-file" accept="application/json" hidden />
  <div id="mem-msg" class="dim small"></div>`;

VIEWS.ai = () => `
  <div class="card"><h3>AI ROUTING</h3><div id="ai-route">Loading…</div></div>
  <div class="card"><h3>COMBO SELECTION</h3><div id="ai-combo">Loading…</div></div>
  <div class="card"><h3>CLOUD USAGE (TODAY)</h3><div id="ai-usage">Loading…</div></div>
  <div class="card"><h3>DIAGNOSTICS</h3><div id="ai-diag">Loading…</div></div>
  <div class="status-line">
    <button class="ghost amber" id="notify-test">ENABLE NOTIFICATIONS</button>
    <button class="ghost amber" id="tts-test">TEST VOICE (TTS)</button>
  </div>`;

VIEWS.settings = () => `
  <div class="card"><h3>SETTINGS</h3>
    <div class="row"><span class="k">USER</span><span class="v">${SESSION.user ? SESSION.user.username + " · " + SESSION.user.role : ""}</span></div>
    <div class="row"><span class="k">MODE</span><span class="v amber" id="set-mode">Loading…</span></div>
    <div class="row"><span class="k">LOCAL MODEL</span><span class="v">qwen3:8b</span></div>
    <div class="row"><span class="k">CLOUD</span><span class="v">OmniRoute</span></div>
  </div>
  <div class="card"><h3>NOTES</h3>
    <p class="dim small">Windows automation stays on the Windows device. This PWA only issues commands through the authenticated backend — it never claims a PC action succeeded unless the backend verifies it.</p>
  </div>`;

function renderView(name) {
  const views = $("views");
  views.innerHTML = "";
  const wrap = el("div");
  wrap.innerHTML = VIEWS[name]();
  views.appendChild(wrap);
  bindView(name);
  loadView(name);
}

function bindView(name) {
  const v = { home: bindHome, chat: bindChat, devices: bindDevices,
              memory: bindMemory, ai: bindAi, settings: bindSettings };
  if (v[name]) v[name]();
}

function loadView(name) {
  const l = { devices: loadDevices, memory: loadMemory, ai: loadAi, settings: loadSettings };
  if (l[name]) l[name]();
}

/* ----------------------------- view bindings ---------------------------- */
function bindHome() {
  document.querySelectorAll("[data-quick]").forEach((b) =>
    b.addEventListener("click", () => {
      const t = b.getAttribute("data-quick");
      goChat(); setTimeout(() => sendChat(t), 120);
    }));
}
function goChat() { setTab("chat"); }

function bindChat() {
  const send = () => {
    const box = $("chat-in");
    const text = (box.value || "").trim();
    if (!text) return;
    box.value = "";
    sendChat(text);
  };
  $("chat-send").onclick = send;
  $("chat-in").addEventListener("keydown", (e) => { if (e.key === "Enter") send(); });
  const mic = $("mic-btn");
  if (mic) {
    mic.onclick = () => {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SR) { alert("Speech recognition is not supported by this browser."); return; }
      const r = new SR();
      r.lang = "en-US";
      r.onresult = (ev) => { const box = $("chat-in"); box.value = ev.results[0][0].transcript; send(); };
      r.onerror = (ev) => { alert("Speech recognition error: " + ev.error); };
      r.start();
    };
  }
  const log = $("chat-log");
  log.scrollTop = log.scrollHeight;
}

async function sendChat(text) {
  const log = $("chat-log") || document.createElement("div");
  log.appendChild(el("div", "msg user", text));
  const thinking = el("div", "msg jarvis", "RUNNING");
  log.appendChild(thinking);
  try {
    thinking.textContent = "RUNNING";
    const res = await api("/chat", { method: "POST", body: JSON.stringify({ text }) });
    thinking.textContent = "VERIFYING";
    const finalText = res.message || res.error || "(no response)";
    thinking.textContent = finalText;
    const rt = [];
    if (res.route) rt.push("ROUTE " + res.route);
    if (res.tool) rt.push("TOOL " + res.tool);
    if (res.ai) rt.push("AI " + res.ai);
    if (res.cloud_used !== undefined) rt.push("CLOUD " + (res.cloud_used ? "YES" : "NO"));
    if (res.fallback) rt.push("FALLBACK");
    if (res.tokens) rt.push("TOKENS " + res.tokens);
    if (res.verification) rt.push("STATUS " + res.verification);
    // honest STATUS: only COMPLETED when the backend verified it
    rt.push("STATUS " + (res.status === "COMPLETED" && res.verified !== false ? "COMPLETED" : res.status));
    const meta = el("span", "rt", rt.join(" · "));
    thinking.appendChild(meta);
    // browser TTS for spoken replies, only when supported
    const Speak = el("button", "ghost amber", "SPEAK");
    Speak.onclick = () => { try { if ("speechSynthesis" in window) speechSynthesis.speak(new SpeechSynthesisUtterance(finalText)); } catch (e) {} };
    thinking.appendChild(Speak);
    if (res.status === "WAITING_CONFIRMATION" && res.confirm_id) {
      appendConfirm(res);
    }
  } catch (e) {
    thinking.textContent = "FAILED: " + (e.message || String(e));
  }
  log.scrollTop = log.scrollHeight;
  refreshHealth();
}

function appendConfirm(res) {
  const log = $("chat-log");
  const row = el("div", "status-line");
  const appr = el("button", "ghost amber", "AUTHORIZE");
  const den = el("button", "ghost danger", "DENY");
  row.appendChild(appr); row.appendChild(den);
  log.appendChild(row);
  appr.onclick = async () => {
    await api("/tools/confirm", { method: "POST", body: JSON.stringify({ confirm_id: res.confirm_id, approve: true }) });
    log.appendChild(el("div", "msg jarvis", "Authorized."));
  };
  den.onclick = async () => {
    await api("/tools/confirm", { method: "POST", body: JSON.stringify({ confirm_id: res.confirm_id, approve: false }) });
    log.appendChild(el("div", "msg jarvis", "Cancelled."));
  };
}

function bindDevices() {
  $("pair-again").onclick = () => { showScreen("pair"); };
}
async function loadDevices() {
  try {
    const d = await api("/devices");
    const list = $("dev-list");
    list.innerHTML = "";
    SESSION.devCount = d.online_count;
    d.devices.forEach((dev) => {
      const row = el("div", "row");
      row.appendChild(el("span", "k", dev.name + (dev.is_host ? " (HOST)" : "")));
      const s = el("span", "v " + (dev.online ? "green" : "red"), dev.online ? "ONLINE" : "OFFLINE");
      row.appendChild(s); list.appendChild(row);
    });
  } catch (e) {
    $("dev-list").textContent = e.message || "unavailable";
  }
}

function memMsg(t) { const m = $("mem-msg"); if (m) m.textContent = t || ""; }
function bindMemory() {
  $("mem-refresh").onclick = loadMemory;
  $("mem-search").addEventListener("keydown", (e) => { if (e.key === "Enter") loadMemory($("mem-search").value.trim()); });
  $("mem-clear").onclick = async () => {
    if (!confirm("Clear ALL long-term memory?")) return;
    await api("/memory", { method: "DELETE" }); loadMemory(); memMsg("Long-term memory cleared.");
  };
  $("mem-clear-ctx").onclick = async () => {
    await api("/memory/context", { method: "DELETE" }); memMsg("Conversation memory cleared.");
  };
  $("mem-export").onclick = async () => {
    const d = await api("/memory/export");
    const blob = new Blob([JSON.stringify(d, null, 2)], { type: "application/json" });
    const a = el("a"); a.href = URL.createObjectURL(blob);
    a.download = "jarvis_memory.json";
    a.click(); URL.revokeObjectURL(a.href);
  };
  $("mem-import").onclick = () => $("mem-file").click();
  $("mem-file").onchange = async () => {
    const f = $("mem-file").files[0]; if (!f) return;
    const d = JSON.parse(await f.text());
    const res = await api("/memory/import", { method: "POST", body: JSON.stringify({ memories: d.memories || d }) });
    memMsg(`Imported ${res.imported}, skipped ${res.skipped}`.replace("Imported undefined", ""));
    loadMemory();
  };
  // enable/disable memory toggle button label
  let enabled = true;
  $("mem-enabled").onclick = async () => {
    enabled = !enabled;
    await api("/memory/enabled", { method: "POST", body: JSON.stringify({ enabled }) });
    memMsg("Memory " + (enabled ? "enabled" : "disabled"));
    loadMemory();
  };
}
async function loadMemory(q) {
  try {
    const mem = await api("/memory" + (q ? "?q=" + encodeURIComponent(q) : ""));
    $("mem-enabled").textContent = mem.enabled ? "MEMORY: ON" : "MEMORY: OFF";
    $("mem-enabled").className = "ghost " + (mem.enabled ? "amber" : "");
    const list = $("mem-list");
    list.innerHTML = "";
    if (!mem.memories.length) list.textContent = "(empty)";
    mem.memories.slice(0, 40).forEach((m) => {
      const row = el("div", "row");
      row.appendChild(el("span", "k", (m.category || "fact") + " · " + m.key));
      const val = el("span", "v", m.value);
      row.appendChild(val); list.appendChild(row);
      const edit = el("button", "ghost", "EDIT");
      const del = el("button", "ghost danger", "X");
      const act = el("div", "status-line");
      edit.onclick = async () => {
        const nv = prompt("Edit value for '" + m.key + "'", m.value);
        if (nv !== null) { await api("/memory/" + m.id, { method: "PATCH", body: JSON.stringify({ value: nv }) }); loadMemory(q); }
      };
      del.onclick = async () => { await api("/memory/" + m.id, { method: "DELETE" }); loadMemory(q); };
      act.append(edit, del);
      const wrap = el("div"); wrap.appendChild(row); wrap.appendChild(act); list.appendChild(wrap);
    });
    const wf = await api("/workflows");
    const wfl = $("wf-list");
    wfl.innerHTML = "";
    if (!wf.workflows.length) { wfl.appendChild(el("div", "dim small", "(none learned)")); }
    wf.workflows.forEach((w) => {
      const row = el("div", "row");
      row.appendChild(el("span", "k", w.trigger + (w.enabled === false ? " (OFF)" : "")));
      row.appendChild(el("span", "v", w.tool + " ×" + w.times_used));
      const wrap = el("div"); wrap.appendChild(row);
      const act = el("div", "status-line");
      const tog = el("button", "ghost amber", w.enabled === false ? "ENABLE" : "DISABLE");
      tog.onclick = async () => { await api("/workflows/" + w.id, { method: "PATCH", body: JSON.stringify({ enabled: w.enabled === false }) }); loadMemory(q); };
      const del = el("button", "ghost danger", "DELETE");
      del.onclick = async () => { await api("/workflows/" + w.id, { method: "DELETE" }); loadMemory(q); };
      act.append(tog, del); wrap.appendChild(act); wfl.appendChild(wrap);
    });
  } catch (e) {
    $("mem-list").textContent = e.message || "unavailable";
  }
}

async function loadAi() {
  try {
    const r = await api("/ai/routing");
    $("ai-route").innerHTML = `
      <div class="row"><span class="k">MODE</span><span class="v amber">${r.mode}</span></div>
      <div class="row"><span class="k">COMBO</span><span class="v">${r.combo || "(auto)"}</span></div>
      <div class="row"><span class="k">LOCAL MODEL</span><span class="v">${r.ollama_model}</span></div>
      <div class="row"><span class="k">RECOMMENDED</span><span class="v">${r.recommended}</span></div>`;
    SESSION.routingMode = r.mode;
    // Combo selection (OWNER may set any; others only their granted Combos)
    const comboBox = $("ai-combo");
    try {
      const mine = await api("/combos/mine");
      const opts = [["", "(auto)"], ...(mine.combos || []).map((c) => [c.omniroute_identifier, c.omniroute_identifier])];
      comboBox.innerHTML = "<select class=\"combo-sel\" id=\"combo-sel\">" +
        opts.map(([v, t]) => `<option value="${v}" ${v === r.combo ? "selected" : ""}>${t}</option>`).join("") +
        "</select>";
      $("combo-sel").onchange = async (e) => {
        await api("/settings", { method: "POST", body: JSON.stringify({ ai: { combo: e.target.value } }) });
        loadAi();
      };
    } catch (e) { comboBox.textContent = "Combo selection unavailable (" + (e.message || e) + ")"; }
    // notifications + TTS
    $("notify-test").onclick = notifTest;
    $("tts-test").onclick = ttsTest;
    const u = await api("/ai/usage");
    const t = u.summary.today;
    $("ai-usage").innerHTML = `
      <div class="row"><span class="k">CLOUD</span><span class="v">${t.cloud} req</span></div>
      <div class="row"><span class="k">LOCAL</span><span class="v">${t.local} req</span></div>
      <div class="row"><span class="k">EST CLOUD TOKENS</span><span class="v">${(t.estimated_cloud_tokens/1000).toFixed(1)}K</span></div>
      <div class="row"><span class="k">FALLBACKS</span><span class="v">${t.fallbacks}</span></div>`;
    const diag = $("ai-diag");
    diag.innerHTML = "";
    if (!r.diagnostics.length) diag.textContent = "(none yet)";
    r.diagnostics.slice(0, 15).forEach((d) => {
      diag.appendChild(el("div", "row", ""));
      const row = diag.lastChild;
      row.appendChild(el("span", "k", (d.route || "—") + " · " + (d.cloud_used ? "CLOUD" : "LOCAL")));
      row.appendChild(el("span", "v " + (d.success ? "green" : "red"),
        (d.model || d.tool || d.provider || "") + (d.fallback ? " [FB]" : "")));
    });
  } catch (e) {
    $("ai-route").textContent = e.message || "unavailable";
  }
}

async function loadSettings() {
  try {
    const s = await api("/settings");
    const mode = $("set-mode");
    if (mode) mode.textContent = s.ai.routing || s.ai.mode;
  } catch (e) {}
}

/* ------------------- notifications + browser TTS (honest) ----------------- */
function notifTest() {
  if (!("Notification" in window)) { alert("Notifications are not supported by this browser."); return; }
  Notification.requestPermission().then((p) => {
    if (p === "granted") new Notification("J.A.R.V.I.S.", { body: "Notifications enabled on this device." });
    else alert("Notification permission " + p + ".");
  }).catch(() => alert("Notifications unavailable."));
}
function ttsTest() {
  if (!("speechSynthesis" in window)) { alert("Speech synthesis is not supported by this browser."); return; }
  const u = new SpeechSynthesisUtterance("Good to see you. JARVIS is online.");
  speechSynthesis.speak(u);
}

 /* ------------------------------ tab router ------------------------------ */
const TABS = ["home", "chat", "devices", "memory", "ai", "settings"];
function setTab(name) {
  document.querySelectorAll(".tab").forEach((t) =>
    t.classList.toggle("active", t.getAttribute("data-tab") === name));
  renderView(name);
}

function enterApp() {
  showScreen("app");
  setTab("home");
  greetOnce();
  connectBus();
  refreshHealth();
  setInterval(refreshHealth, 15000);
}

/* ------------------------- device bus (protocol v1) ---------------------- */
/* heartbeat + exponential-backoff reconnect + capability negotiation.
 * The PWA uses the SAME /api/bus/ws endpoint and protocol v1 as every other
 * JARVIS device - it never invents its own protocol. */
const PWA_CAPS = ["WEB_PWA", "BROWSER", "MICROPHONE", "NOTIFICATIONS", "CLIPBOARD", "FILE_PICKER"];
function connectBus() {
  if (!SESSION.deviceToken || SESSION.ws || SESSION.busOpen) return;
  const proto = location.protocol === "https:" ? "wss://" : "ws://";
  const url = proto + location.host + "/api/bus/ws?token=" + encodeURIComponent(SESSION.deviceToken);
  const ws = new WebSocket(url);
  SESSION.ws = ws;
  ws.onopen = () => {
    SESSION.busOpen = true;
    SESSION.busBackoff = 1000;                       // reset on success
    ws.send(JSON.stringify({ type: "heartbeat", ts: Date.now(), seq: 1 }));
    // announce real browser capability (never Windows automation)
    ws.send(JSON.stringify({ message_type: "DEVICE_CAPABILITIES", payload: { capabilities: PWA_CAPS }, request_id: "cap-" + Date.now() }));
  };
  ws.onmessage = (ev) => {
    try {
      const f = JSON.parse(ev.data);
      if (f.message_type === "HELLO") {
        SESSION.deviceId = f.target_device_id || (f.payload && f.payload.device_id);
      }
    } catch (e) {}
  };
  ws.onclose = () => {
    SESSION.busOpen = false; SESSION.ws = null;
    // exponential backoff with jitter, capped
    const delay = Math.min(SESSION.busBackoff, 30000);
    setTimeout(connectBus, delay + Math.floor(Math.random() * 600));
    SESSION.busBackoff = Math.min(SESSION.busBackoff * 2, 30000);
  };
  ws.onerror = () => {};
  // heartbeat every 20s (protocol v1)
  SESSION.busHeart = setInterval(() => {
    if (SESSION.busOpen) ws.send(JSON.stringify({ type: "heartbeat", ts: Date.now() }));
  }, 20000);
}

/* ------------------------------ auth ------------------------------------ */
function showScreenRaw(id) { showScreen(id); }

function bindAuth() {
  $("auth-btn").onclick = async () => {
    const user = $("auth-user").value.trim();
    const pass = $("auth-pass").value;
    const err = $("auth-error");
    if (!user || !pass) { err.hidden = false; err.textContent = "Username and password required."; return; }
    err.hidden = true;
    try {
      const d = await api("/auth/login", { method: "POST", useSession: true, body: JSON.stringify({ username: user, password: pass }) });
      SESSION.token = d.token || "";
      store.set("jarvis.sessionToken", SESSION.token);
      const me = await refreshMe();
      if (me) enterApp();
    } catch (e) {
      err.hidden = false; err.textContent = e.message || "Sign in failed.";
    }
  };
  $("show-pair").onclick = () => showScreen("pair");
}

function bindPair() {
  $("back-login").onclick = () => showScreen("auth");
  $("pair-btn").onclick = async () => {
    const name = ($("pair-name").value || "My Phone").trim();
    $("pair-status").textContent = "";
    try {
      const d = await api("/devices/pairing", { method: "POST", useSession: true,
        body: JSON.stringify({ device_name: name, device_type: "web", capabilities: ["WEB_PWA","BROWSER","NOTIFICATIONS"] }) });
      $("pair-result").hidden = false;
      $("pair-code").textContent = d.code;
      SESSION.pairingId = d.pairing_id;
      pollPairing();
    } catch (e) {
      $("pair-status").textContent = e.message || "Pairing failed.";
    }
  };
}

let pairTimer = null;
function pollPairing() {
  clearInterval(pairTimer);
  pairTimer = setInterval(async () => {
    try {
      const st = await api("/devices/pairing/" + SESSION.pairingId, { useSession: true });
      $("pair-status").textContent = st.status;
      if (st.status === "APPROVED") {
        clearInterval(pairTimer);
        const c = await api("/devices/pairing/claim", { useSession: true,
          method: "POST", body: JSON.stringify({ code: $("pair-code").textContent }) });
        SESSION.deviceToken = c.device_token;
        store.set("jarvis.deviceToken", c.device_token);
        $("pair-status").textContent = "Paired as " + c.device_name + " (" + c.device_id + ")";
        connectBus();
      }
    } catch (e) {
      $("pair-status").textContent = e.message || "";
    }
  }, 3000);
}

function bindLogout() {
  $("logout-btn").onclick = async () => {
    try { await api("/auth/logout", { method: "POST" }); } catch (e) {}
    SESSION.token = "";
    store.remove("jarvis.sessionToken");
    store.remove("jarvis.greeted");
    if (SESSION.ws) SESSION.ws.close();
    showScreen("auth");
  };
}

/* ------------------------------ init ------------------------------------ */
function init() {
  document.querySelectorAll(".tab").forEach((t) =>
    t.addEventListener("click", () => setTab(t.getAttribute("data-tab"))));
  bindAuth(); bindPair(); bindLogout();
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("/pwa/sw.js").catch(() => {});
  }
  boot();
}
document.addEventListener("DOMContentLoaded", init);
