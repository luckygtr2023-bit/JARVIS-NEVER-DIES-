/* JARVIS PWA service worker.
 *
 * Caches the offline shell (app HTML/CSS/JS + icons) so the UI stays usable and
 * shows an honest "JARVIS OFFLINE" state when the backend is unreachable. It
 * NEVER caches or pretends API responses succeeded - /api/* is always network-only,
 * so no Windows action is ever reported complete from a stale cache.
 *
 * Auth scope: the token is kept in JS memory / localStorage, never here.
 */
// bump on every release so stale/corrupt caches from a previous build are purged
const CACHE = "jarvis-pwa-v2";
const SHELL = [
  "/pwa/",
  "/pwa/index.html",
  "/pwa/styles.css",
  "/pwa/app.js",
  "/pwa/manifest.json",
  "/pwa/icons/icon-192.png",
  "/pwa/icons/icon-512.png",
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  // API + auth + sockets: never serviced from cache. Network only.
  if (url.pathname.startsWith("/api/")) {
    e.respondWith(fetch(e.request));
    return;
  }
  // PWA shell: NETWORK-first so the newest build always wins (a stale cached
  // copy never masks a fix), with the cache as an offline fallback.
  if (url.pathname.startsWith("/pwa/")) {
    e.respondWith(
      fetch(e.request).then((resp) => {
        if (resp && resp.ok) {
          const clone = resp.clone();
          caches.open(CACHE).then((c) => c.put(e.request, clone));
        }
        return resp;
      }).catch(() => caches.match(e.request))
    );
    return;
  }
  // everything else: network, fall back to cached shell for navigation
  e.respondWith(
    fetch(e.request).catch(() => caches.match("/pwa/index.html"))
  );
});
