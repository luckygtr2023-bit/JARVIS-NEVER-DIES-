# J.A.R.V.I.S. PWA — Android Companion

This is the complete source of the JARVIS **WebApp / PWA** for Android.

**It is not a separate app and has no backend of its own.** It is another
**authenticated JARVIS device** that talks to the JARVIS **Windows PC backend**
over the network using the same:

* Authentication (username/password)
* Database (the PC backend's SQLite)
* Memory (long-term + bounded conversation)
* AI workload routing (Ollama / OmniRoute / deterministic)
* Device protocol v1 WebSocket bus

There is deliberately **no APK** — this is a browser-installable PWA.

---

## What's in here

| File | Purpose |
|---|---|
| `index.html` | App shell (login / pairing / app views) |
| `styles.css` | Mobile amber-HUD theme (responsive, safe-area aware) |
| `app.js` | All logic: auth, pairing, chat, devices, memory, AI routing, device bus |
| `manifest.json` | PWA install metadata (icons, standalone, scope `/pwa/`) |
| `sw.js` | Service worker (**network-first** shell so updates always win; cached copy only as offline fallback; `/api/*` never cached) |
| `icons/icon-192.png`, `icon-512.png` | Install icons |

---

## Option A — served by the JARVIS PC backend (recommended, canonical)

The PC backend already serves this PWA at `/pwa/`. You don't need to deploy it
separately: just run the PC JARVIS and open the URL below on your Android phone.

```
1. On the PC, start JARVIS:           start_jarvis.bat        (or: python -m backend.main)
2. Find the PC's LAN address, e.g.    http://192.168.1.10:8420/pwa/
   (the backend binds 0.0.0.0 by default so devices on the LAN can reach it)
3. On the phone, open that URL in Chrome.
4. Chrome → menu → "Add to Home screen" (install the PWA).
```

The phone and PC can be on the same Wi-Fi, different Wi-Fi, or phone data — as long
as the phone can reach `http://<PC-ip>:8420`. For cross-network (mobile data)
access, put JARVIS behind an HTTPS reverse proxy and open the `https://...` URL
(HTTPS/WSS is preferred; the device bus needs a reachable WebSocket endpoint).

### Pair the phone as a JARVIS device

```
In the PWA:  open the pairing screen → "REQUEST CODE"
             → the app shows a code like  PAIR-7K4M-92PX
On the PC:   open the JARVIS HUD → DEVICES → approve that pairing
Back in PWA: it polls, detects APPROVED, and claims the device token
             (the app then authenticates with its own token — never your password)
```

After pairing, the PWA registers as a real device in the same registry as the PC,
with browser-only capabilities (WEB_PWA, BROWSER, MICROPHONE, NOTIFICATIONS,
CLIPBOARD, FILE_PICKER — it does **not** claim Windows automation).

---

## Option B — serve the PWA source separately

If you want to host the PWA frontend on its own static server while still using the
JARVIS backend, put these files at the `/pwa/` path of a static host and proxy
`/api` (and the `/api/bus/ws` WebSocket) to the JARVIS backend. Example with nginx:

```nginx
location /pwa/ { root /var/www/jarvis-pwa; }          # these files
location /api  { proxy_pass http://127.0.0.1:8420;    # the JARVIS backend
                 proxy_http_version 1.1;
                 proxy_set_header Upgrade $http_upgrade;
                 proxy_set_header Connection "upgrade"; }   # needed for the WS bus
```

Change nothing in the PWA — it uses relative `/api/...` and `/pwa/...` URLs, so it
works as long as it is served under `/pwa/` and `/api` reaches the backend.

---

## Troubleshooting — blank / dark page at `/pwa/`

If you ever open `/pwa/` and see an empty dark page (no login screen), the cause
was **not** the PWA code — it was the backend returning a wrong `Content-Type`.

* The PC backend serves every PWA file with an **explicit** content type
  (`text/html`, `text/css`, `text/javascript`, `application/manifest+json`,
  `image/png`). It no longer relies on the operating system's MIME registry, which
  on some Windows hosts returned `application/json` for `styles.css` and `app.js`.
  A browser refuses to apply a stylesheet/script served as JSON, so the page
  rendered as an empty dark screen.
* `index.html` carries a **critical inline `<style>` fallback** so even if the
  external stylesheet is ever unavailable, the J.A.R.V.I.S. login text and controls
  still render (never an empty void).
* The service worker is now **network-first**, so a stale cached copy from an old
  build can never mask a fixed version. Clearing the PWA's storage, or uninstalling
  and reinstalling the app, re-fetches the latest files on the next open.

Fast check on the PC: from a terminal run
`curl -sI http://127.0.0.1:8420/pwa/styles.css | findstr Content-Type` — it should
report `text/css`.

---

## Using the PWA

* **HOME** — system status, AI routing mode, online devices, quick commands.
* **CHAT** — send text (or use browser voice where supported). The reply shows the
  route/tool/AI/cloud/tokens/status. Tasks display `RUNNING → VERIFYING →
  COMPLETED`, or `FAILED` — never `COMPLETED` unless the backend verified it.
* **DEVICES** — list the user's devices (PC + this PWA) and online/offline state;
  pair as a new device.
* **MEMORY** — search, edit, delete, clear long-term, clear conversation,
  enable/disable, export JSON, import with per-record credential guard, and
  manage learned workflows (disable / delete).
* **AI** — current routing mode, Combo selection (for authorized users), cloud
  usage (today), and diagnostics (request/route/reason/model/combo/cloud/tokens/
  latency/fallback/status). Only real status; no provider secrets.
* **SETTINGS** — user/role, model, cloud backend, and honest notes on capability.

## Offline behaviour

If the backend/device is unreachable the PWA shows a **JARVIS OFFLINE** banner and
reconnects with exponential backoff + heartbeat. The service worker never serves
`/api/*` from cache, so a Windows action is **never** reported complete from a
stale cache. A command routed to an offline PC returns `FAILED … is offline`
(or `QUEUED`), never `COMPLETED`.

## Browser capability honesty

* Microphone uses the browser's `SpeechRecognition` **only where supported**;
  otherwise the PWA shows a clear "not supported" state.
* TTS uses browser `SpeechSynthesis` where supported; otherwise it is unavailable.
* Notifications use the browser `Notification` API where permitted.
* None of this fakes Windows STT/TTS (Windows keeps faster-whisper + SAPI5).

---

## The one backend rule

```
Android PWA ──/pwa/ (this repo)──▶ JARVIS PC backend ──▶ DB / memory / AI routing ──▶ device bus
```

One backend. One database. One authentication system. One memory system. One AI
routing system. One device protocol v1. Same as the Windows client.

**Made by Lucky Kumar.**
