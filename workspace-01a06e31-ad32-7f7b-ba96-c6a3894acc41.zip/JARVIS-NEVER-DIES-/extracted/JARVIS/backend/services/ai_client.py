"""AI transport for OmniRoute (cloud router) and Ollama (local), spec 8.

Hard requirements implemented here:
  * the configured OmniRoute Combo name is sent EXACTLY as typed - never prefixed,
    never rewritten, never validated against a whitelist
  * Ollama models are discovered dynamically from /api/tags
  * NO response is assumed to be JSON. Text, HTML, empty bodies, malformed JSON,
    timeouts and connection errors all become clean, human-readable messages,
    so "Expecting value: line 1 column 1" can never reach the user
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import AsyncIterator, Optional

import httpx

from .. import config, db, quota, routing

MODE_OMNIROUTE = "omniroute"
MODE_OLLAMA = "ollama"
MODE_AUTO = "auto"
# New routing modes (superset of the legacy modes above).
ROUTING_MODES = tuple(routing.MODES)


class AIError(Exception):
    """A user-presentable AI failure. Always carries a readable message."""

    def __init__(self, message: str, *, provider: str = "", status: int | None = None):
        super().__init__(message)
        self.message = message
        self.provider = provider
        self.status = status


def _derive_routing(mode: str) -> str:
    """Map a legacy mode to a routing mode."""
    if mode == MODE_OLLAMA:
        return "local_only"
    if mode == MODE_OMNIROUTE:
        return "cloud_only"
    return routing.default_mode()   # auto -> local_first (quota-sparing default)


@dataclass
class AIConfig:
    mode: str = MODE_AUTO               # legacy: auto | omniroute | ollama
    routing: str = "local_first"        # new routing mode (see routing.MODES)
    combo: str = ""              # OmniRoute Combo name, sent verbatim
    ollama_model: str = ""       # discovered dynamically
    temperature: float = 0.4
    max_tokens: int = 1024

    @classmethod
    def load(cls) -> "AIConfig":
        raw = db.get_setting("ai", {}) or {}
        mode = raw.get("mode", MODE_AUTO)
        routing_mode = raw.get("routing") or _derive_routing(mode)
        return cls(
            mode=mode,
            routing=routing.normalize_mode(routing_mode),
            combo=raw.get("combo", ""),
            ollama_model=raw.get("ollama_model", ""),
            temperature=float(raw.get("temperature", 0.4)),
            max_tokens=int(raw.get("max_tokens", 1024)),
        )

    @classmethod
    def for_principal(cls, principal: dict | None) -> "AIConfig":
        """Config with the Combo this principal is actually allowed to use.

        Resolved server side from Combo Management, so a client cannot smuggle an
        unauthorized identifier in by any route (spec 7).
        """
        cfg = cls.load()
        if not principal:
            return cfg
        from .. import combos as combo_store

        identifier = combo_store.selected_for(principal["user_id"], principal.get("role", ""))
        if identifier:
            combo_store.assert_may_use(principal["user_id"], principal.get("role", ""), identifier)
            cfg.combo = identifier
        else:
            cfg.combo = ""
        return cfg

    def save(self) -> None:
        db.set_setting("ai", {
            "mode": self.mode, "routing": self.routing, "combo": self.combo,
            "ollama_model": self.ollama_model,
            "temperature": self.temperature, "max_tokens": self.max_tokens,
        })


# --------------------------------------------------------------------------- #
# defensive response handling
# --------------------------------------------------------------------------- #
def describe_http_failure(resp: httpx.Response, provider: str) -> str:
    """Turn ANY error body (json / text / html / empty) into one clear sentence."""
    body = (resp.text or "").strip()
    detail = ""
    if body:
        ctype = resp.headers.get("content-type", "")
        if "json" in ctype or body[:1] in "{[":
            try:
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    err = parsed.get("error", parsed)
                    if isinstance(err, dict):
                        detail = str(err.get("message") or err.get("detail") or err)
                    else:
                        detail = str(err)
                else:
                    detail = str(parsed)
            except json.JSONDecodeError:
                detail = body[:300]
        elif "html" in ctype or body[:1] == "<":
            detail = "the endpoint returned an HTML page instead of an API response"
        else:
            detail = body[:300]
    else:
        detail = "empty response body"
    hint = ""
    if resp.status_code in (401, 403):
        hint = " Check the API key / Combo configuration."
    elif resp.status_code == 404:
        hint = " Check that the model or Combo name exists."
    elif resp.status_code == 429:
        hint = " The provider is rate-limiting or out of quota."
    return f"{provider} returned HTTP {resp.status_code}: {detail}.{hint}"


def parse_chat_payload(resp: httpx.Response, provider: str) -> str:
    """Extract assistant text from an OpenAI-compatible reply, defensively."""
    body = (resp.text or "").strip()
    if not body:
        raise AIError(f"{provider} returned an empty response body.", provider=provider)
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        snippet = body[:200].replace("\n", " ")
        raise AIError(
            f"{provider} sent a non-JSON response ({snippet!r}). "
            f"The endpoint may be wrong or a proxy/login page is in the way.",
            provider=provider,
        )
    if not isinstance(data, dict):
        raise AIError(f"{provider} sent an unexpected response shape.", provider=provider)
    if "error" in data and data.get("error"):
        err = data["error"]
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise AIError(f"{provider} error: {msg}", provider=provider)
    choices = data.get("choices") or []
    if choices:
        msg = choices[0].get("message") or {}
        content = msg.get("content")
        if isinstance(content, list):  # some providers return content parts
            content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
        if content:
            return content
    # Ollama native shape
    if isinstance(data.get("message"), dict) and data["message"].get("content"):
        return data["message"]["content"]
    if data.get("response"):
        return str(data["response"])
    raise AIError(f"{provider} returned no assistant content.", provider=provider)


# --------------------------------------------------------------------------- #
# probes
# --------------------------------------------------------------------------- #
async def probe_omniroute(timeout: float = 3.0) -> dict:
    url = config.OMNIROUTE_BASE.rstrip("/") + "/models"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url)
        if resp.status_code >= 400:
            return {"available": False, "endpoint": config.OMNIROUTE_BASE,
                    "error": describe_http_failure(resp, "OmniRoute")}
        combos = []
        try:
            data = resp.json()
            combos = [m.get("id") for m in data.get("data", []) if isinstance(m, dict) and m.get("id")]
        except Exception:
            pass
        return {"available": True, "endpoint": config.OMNIROUTE_BASE, "combos": combos}
    except httpx.ConnectError:
        return {"available": False, "endpoint": config.OMNIROUTE_BASE,
                "error": "OmniRoute is not reachable at 127.0.0.1:20128 - is the gateway running?"}
    except Exception as exc:
        return {"available": False, "endpoint": config.OMNIROUTE_BASE, "error": str(exc)}


async def probe_ollama(timeout: float = 3.0) -> dict:
    url = config.OLLAMA_NATIVE.rstrip("/") + "/api/tags"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url)
        if resp.status_code >= 400:
            return {"available": False, "endpoint": config.OLLAMA_NATIVE,
                    "error": describe_http_failure(resp, "Ollama")}
        models: list[str] = []
        try:
            models = [m["name"] for m in resp.json().get("models", []) if m.get("name")]
        except Exception:
            models = []
        return {"available": True, "endpoint": config.OLLAMA_NATIVE, "models": models}
    except httpx.ConnectError:
        return {"available": False, "endpoint": config.OLLAMA_NATIVE,
                "error": "Ollama is not reachable at 127.0.0.1:11434 - is `ollama serve` running?"}
    except Exception as exc:
        return {"available": False, "endpoint": config.OLLAMA_NATIVE, "error": str(exc)}


async def resolve_mode(cfg: AIConfig) -> tuple[str, str]:
    """Pick the AI provider honouring the routing mode. Returns (mode, reason).

    Local-first by default: cloud (OmniRoute) is used only when the routing rule
    asks for it - never merely because it happens to be the first responder.
    """
    avail = await _availability()
    dec = routing.decide("", mode=cfg.routing, availability=avail, combo=cfg.combo)
    if dec.provider == routing.PROVIDER_CLOUD:
        if not cfg.combo:
            raise AIError("No OmniRoute Combo is configured. Set it in SETTINGS -> AI.",
                          provider="OmniRoute")
        return MODE_OMNIROUTE, dec.reason
    if dec.provider == routing.PROVIDER_LOCAL:
        return MODE_OLLAMA, dec.reason
    raise AIError(
        dec.reason or
        "No AI backend is reachable. Start Ollama (127.0.0.1:11434) or OmniRoute "
        "(127.0.0.1:20128), then try again."
    )


async def pick_ollama_model(cfg: AIConfig) -> str:
    if cfg.ollama_model:
        return cfg.ollama_model
    info = await probe_ollama()
    models = info.get("models") or []
    if not models:
        raise AIError("Ollama has no models installed. Run e.g. `ollama pull qwen3:8b`.",
                      provider="Ollama")
    for preferred in ("qwen3:8b", "qwen3", "llama3.1", "llama3"):
        for m in models:
            if m.startswith(preferred):
                return m
    return models[0]


# --------------------------------------------------------------------------- #
# chat
# --------------------------------------------------------------------------- #
async def _availability() -> dict:
    """Probe both backends once per call. Never claims one is up without touching it."""
    omni = await probe_omniroute(timeout=1.5)
    olla = await probe_ollama(timeout=1.5)
    return {"omniroute": bool(omni.get("available")),
            "ollama": bool(olla.get("available"))}


async def _route_for(text: str, cfg: AIConfig,
                     availability: Optional[dict] = None) -> routing.SplitDecision:
    """Pick ollama / omniroute / none for a language task, honouring routing mode."""
    avail = availability or await _availability()
    dec = routing.decide(text, mode=cfg.routing, availability=avail,
                         combo=cfg.combo)
    return dec


async def chat(messages: list[dict], *, cfg: Optional[AIConfig] = None,
               timeout: float = 90.0, text: str = "",
               user_id: str | None = None, device_id: str | None = None,
               route_ctx: Optional[dict] = None, _used_route: Optional[routing.SplitDecision] = None) -> dict:
    """Route and run one AI language turn.

    text               the user's request (used for complexity routing)
    user_id/device_id  scoping for cloud quota + usage telemetry
    route_ctx          an optional precomputed decision (from the agent loop)
    _used_route        internal: forces the provider to route (used by fallback)
    """
    cfg = cfg or AIConfig.load()

    # ---- routing decision -------------------------------------------------- #
    dec = route_ctx or await _route_for(text or _first_user_text(messages), cfg)
    provider_name = "OmniRoute" if dec.provider == routing.PROVIDER_CLOUD else "Ollama"

    # ---- honest failure if nothing is reachable ---------------------------- #
    if dec.provider != routing.PROVIDER_CLOUD and dec.provider != routing.PROVIDER_LOCAL:
        raise AIError(dec.reason or "No AI backend is reachable.",
                      provider="All")

    # ---- quota: cloud only, checked BEFORE the request --------------------- #
    if dec.provider == routing.PROVIDER_CLOUD:
        try:
            quota.check_cloud_limit(user_id=user_id, device_id=device_id)
        except quota.QuotaError as exc:
            # Quota exhausted -> try local (Ollama) if reachable, else honest fail.
            avail = await _availability()
            if avail.get("ollama") and cfg.routing not in ("cloud_only",):
                dec2 = routing.decide(text or _first_user_text(messages), mode=cfg.routing,
                                      availability=avail, combo=cfg.combo)
                if dec2.provider == routing.PROVIDER_LOCAL:
                    dec2.fallback = True
                    return await chat(messages, cfg=cfg, timeout=timeout, text=text,
                                      user_id=user_id, device_id=device_id,
                                      route_ctx=dec2)
            # honest failure
            ai_error = AIError(exc.message, provider="Quota")
            ai_error.quota = True
            raise ai_error

    if dec.provider == routing.PROVIDER_CLOUD:
        if not cfg.combo:
            raise AIError("No OmniRoute Combo is configured. Set it in SETTINGS -> AI.",
                          provider="OmniRoute")
        base, model, provider = config.OMNIROUTE_BASE, str(dec.combo or cfg.combo), "OmniRoute"
    else:
        base, model, provider = config.OLLAMA_BASE, await pick_ollama_model(cfg), "Ollama"

    payload = {
        "model": model,                       # EXACT combo / model id, never modified
        "messages": messages,
        "temperature": cfg.temperature,
        "max_tokens": cfg.max_tokens,
        "stream": False,
    }
    url = base.rstrip("/") + "/chat/completions"
    started = time.time()
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, json=payload)
    except httpx.ConnectError:
        _record_usage(cfg, dec, user_id, device_id, success=False,
                      provider=provider, detail="connect error", request=text)
        raise AIError(f"{provider} is not reachable at {base}.", provider=provider)
    except httpx.ReadTimeout:
        _record_usage(cfg, dec, user_id, device_id, success=False,
                      provider=provider, detail="timeout", request=text)
        raise AIError(f"{provider} timed out after {int(timeout)}s.", provider=provider)
    except Exception as exc:
        _record_usage(cfg, dec, user_id, device_id, success=False,
                      provider=provider, detail=str(exc), request=text)
        raise AIError(f"{provider} request failed: {exc}", provider=provider)

    latency_ms = int((time.time() - started) * 1000)
    if resp.status_code >= 400:
        _record_usage(cfg, dec, user_id, device_id, success=False,
                      provider=provider, detail=f"HTTP {resp.status_code}", request=text)
        raise AIError(describe_http_failure(resp, provider), provider=provider,
                      status=resp.status_code)
    content = parse_chat_payload(resp, provider)

    # ---- token accounting: exact when available, estimated otherwise -------- #
    prompt_tokens = int(_tokens_from(resp, "prompt_tokens")) or quota.estimate_tokens(
        " ".join(m.get("content", "") for m in messages))
    completion_tokens = int(_tokens_from(resp, "completion_tokens")) or \
        quota.estimate_tokens(content)
    _record_usage(cfg, dec, user_id, device_id, success=True, provider=provider,
                  prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
                  latency_ms=latency_ms, model=model, request=text)

    return {"content": content, "provider": provider, "model": model,
            "reason": dec.reason, "route": dec.provider,
            "cloud_used": dec.provider == routing.PROVIDER_CLOUD,
            "fallback": bool(dec.fallback), "tokens": prompt_tokens + completion_tokens}


def _first_user_text(messages: list[dict]) -> str:
    for m in messages or []:
        if m.get("role") == "user":
            return str(m.get("content", ""))
    return " ".join(str(m.get("content", "")) for m in (messages or []))


def _tokens_from(resp: httpx.Response, key: str) -> int:
    try:
        data = resp.json()
        usage = data.get("usage") or {}
        return int(usage.get(key, 0) or 0)
    except Exception:
        return 0


def _record_usage(cfg, dec, user_id, device_id, *, success, provider="",
                  prompt_tokens=0, completion_tokens=0, latency_ms=None, detail=None,
                  request=""):
    meta = dict(detail or {})
    meta.setdefault("reason", dec.reason or "")
    if request:
        meta.setdefault("request", str(request)[:160])
    quota.record(
        user_id=user_id, device_id=device_id, combo=str(dec.combo or cfg.combo or ""),
        provider=(routing.PROVIDER_CLOUD if dec.provider == routing.PROVIDER_CLOUD
                  else routing.PROVIDER_LOCAL),
        route=dec.provider, cloud=(dec.provider == routing.PROVIDER_CLOUD),
        success=success, fallback=bool(dec.fallback),
        prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
        latency_ms=latency_ms, model=provider or "", detail=meta)


async def chat_stream(messages: list[dict], *, cfg: Optional[AIConfig] = None,
                      timeout: float = 120.0) -> AsyncIterator[str]:
    """Yield assistant text deltas. Falls back to a single chunk if the provider
    cannot stream - the caller never has to care."""
    cfg = cfg or AIConfig.load()
    mode, _ = await resolve_mode(cfg)
    if mode == MODE_OMNIROUTE:
        if not cfg.combo:
            raise AIError("No OmniRoute Combo is configured. Set it in SETTINGS -> AI.",
                          provider="OmniRoute")
        base, model, provider = config.OMNIROUTE_BASE, cfg.combo, "OmniRoute"
    else:
        base, model, provider = config.OLLAMA_BASE, await pick_ollama_model(cfg), "Ollama"

    payload = {"model": model, "messages": messages, "temperature": cfg.temperature,
               "max_tokens": cfg.max_tokens, "stream": True}
    url = base.rstrip("/") + "/chat/completions"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, json=payload) as resp:
                if resp.status_code >= 400:
                    await resp.aread()
                    raise AIError(describe_http_failure(resp, provider), provider=provider,
                                  status=resp.status_code)
                got_any = False
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue          # never explode on a malformed SSE frame
                    for choice in chunk.get("choices", []):
                        delta = (choice.get("delta") or {}).get("content")
                        if delta:
                            got_any = True
                            yield delta
                if not got_any:
                    result = await chat(messages, cfg=cfg, timeout=timeout)
                    yield result["content"]
    except AIError:
        raise
    except httpx.ConnectError:
        raise AIError(f"{provider} is not reachable at {base}.", provider=provider)
    except httpx.ReadTimeout:
        raise AIError(f"{provider} timed out after {int(timeout)}s.", provider=provider)
