"""Real browser automation via Playwright (spec 11).

If Playwright (or its Chromium download) is missing, every call returns a clear
BLOCKED message. Nothing is ever reported as clicked/opened without reading the
resulting page back.
"""
from __future__ import annotations

import asyncio
import re
from typing import Any, Optional
from urllib.parse import quote_plus, urlparse

from .. import db
from .tools_registry import CapabilityError, SAFE, ToolError, tool

_playwright = None
_browser = None
_page = None
_lock = asyncio.Lock()

# short-term context: the last result list, so "open the second one" works (spec 10)
LAST_RESULTS: list[dict] = []


def playwright_status() -> dict:
    try:
        import playwright  # noqa: F401
    except ImportError:
        return {"installed": False,
                "reason": "playwright is not installed. Run: pip install playwright && playwright install chromium"}
    try:
        from playwright.async_api import async_playwright  # noqa: F401
        return {"installed": True}
    except Exception as exc:
        return {"installed": False, "reason": str(exc)}


async def _ensure_page(headless: bool = True):
    global _playwright, _browser, _page
    status = playwright_status()
    if not status.get("installed"):
        raise CapabilityError(status.get("reason", "Playwright unavailable."))
    from playwright.async_api import async_playwright

    async with _lock:
        if _page is not None and not _page.is_closed():
            return _page
        if _playwright is None:
            _playwright = await async_playwright().start()
        try:
            _browser = await _playwright.chromium.launch(headless=headless)
        except Exception as exc:
            raise CapabilityError(
                f"Chromium could not start ({exc}). Run `playwright install chromium`.")
        ctx = await _browser.new_context(viewport={"width": 1440, "height": 900})
        _page = await ctx.new_page()
        return _page


async def close_browser() -> None:
    global _playwright, _browser, _page
    try:
        if _browser:
            await _browser.close()
        if _playwright:
            await _playwright.stop()
    except Exception:
        pass
    _playwright = _browser = _page = None


def resolve_destination(name: str) -> Optional[str]:
    """Named destinations only - JARVIS never invents a private URL (spec 11)."""
    row = db.one("SELECT url FROM destinations WHERE name=?", (name.strip(),))
    if row:
        return row["url"]
    rows = db.query("SELECT name, url FROM destinations")
    n = name.strip().lower()
    for r in rows:
        if r["name"].lower() in n or n in r["name"].lower():
            return r["url"]
    return None


def validate_url(url: str) -> str:
    u = url.strip()
    if not re.match(r"^https?://", u, re.I):
        if "." in u.split("/")[0]:
            u = "https://" + u
        else:
            raise ToolError(f"'{url}' is not a valid URL and is not a known named destination.")
    parsed = urlparse(u)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ToolError(f"Refusing to open unsafe URL: {url}")
    return u


@tool("browser_open", "browser", SAFE, "Open a URL or a named destination in the real browser.")
async def browser_open(target: str):
    url = resolve_destination(target) or validate_url(target)
    page = await _ensure_page()
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
    except Exception as exc:
        raise ToolError(f"Navigation to {url} failed: {exc}")
    return {"requested": target, "url": page.url, "title": await page.title(),
            "verified": page.url.rstrip("/") != "about:blank"}


@tool("browser_search", "browser", SAFE,
      "Search on a site (youtube/google) and return the real result list.")
async def browser_search(query: str, site: str = "google"):
    global LAST_RESULTS
    site = (site or "google").lower()
    if "youtube" in site:
        attempts = [(f"https://www.youtube.com/results?search_query={quote_plus(query)}",
                     "a#video-title")]
    else:
        # Ordered fallbacks: engines differ in how they treat automated browsers.
        attempts = [
            (f"https://www.bing.com/search?q={quote_plus(query)}", "h2 a"),
            (f"https://duckduckgo.com/?q={quote_plus(query)}",
             "a[data-testid='result-title-a'], a.result__a"),
        ]

    page = await _ensure_page()
    results: list[dict] = []
    used_url = ""
    for url, selector in attempts:
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        except Exception:
            continue
        try:
            await page.wait_for_selector(selector, timeout=10000)
        except Exception:
            pass
        handles = await page.query_selector_all(selector)
        for idx, h in enumerate(handles[:12], start=1):
            try:
                title = (await h.inner_text()).strip()
                href = await h.get_attribute("href")
                if not title or not href or href.startswith("#"):
                    continue
                if href.startswith("/"):
                    base = "https://www.youtube.com" if "youtube" in site else url.split("/search")[0]
                    href = base + href
                results.append({"index": len(results) + 1, "title": title[:160], "url": href})
            except Exception:
                continue
        used_url = page.url
        if results:
            break

    LAST_RESULTS = results
    if not results:
        # Honest failure - no invented results (spec 11).
        raise ToolError(
            f"The search page loaded ({used_url or 'no page'}) but returned no readable results. "
            f"The engine may be serving an anti-automation page.")
    return {"query": query, "site": site, "count": len(results), "results": results,
            "page_url": used_url, "verified": True}


@tool("browser_open_result", "browser", SAFE,
      "Open the Nth result from the last search ('open the second one').")
async def browser_open_result(index: int = 1):
    if not LAST_RESULTS:
        raise ToolError("There are no search results in context yet. Search first.")
    if index < 1 or index > len(LAST_RESULTS):
        raise ToolError(f"There are only {len(LAST_RESULTS)} results; cannot open #{index}.")
    target = LAST_RESULTS[index - 1]
    page = await _ensure_page()
    await page.goto(target["url"], wait_until="domcontentloaded", timeout=30000)
    return {"opened_index": index, "title": await page.title(), "url": page.url,
            "expected": target["title"], "verified": page.url.startswith("http")}


@tool("browser_state", "browser", SAFE, "Report the current page URL, title and visible links.")
async def browser_state(max_links: int = 25):
    page = await _ensure_page()
    links = []
    for h in (await page.query_selector_all("a"))[:max_links]:
        try:
            text = (await h.inner_text()).strip()
            href = await h.get_attribute("href")
            if text and href:
                links.append({"text": text[:80], "href": href})
        except Exception:
            continue
    return {"url": page.url, "title": await page.title(), "links": links}


@tool("browser_click", "browser", SAFE, "Click an element by its visible text or CSS selector.")
async def browser_click(target: str):
    page = await _ensure_page()
    before = page.url
    try:
        try:
            await page.click(target, timeout=6000)
        except Exception:
            await page.get_by_text(target, exact=False).first.click(timeout=8000)
    except Exception as exc:
        raise ToolError(f"Could not click '{target}': {exc}")
    await page.wait_for_timeout(800)
    after = page.url
    return {"clicked": target, "url_before": before, "url_after": after,
            "navigated": before != after, "title": await page.title(), "verified": True}


@tool("browser_fill", "browser", SAFE, "Type into an input identified by a CSS selector.")
async def browser_fill(selector: str, text: str, submit: bool = False):
    page = await _ensure_page()
    await page.fill(selector, text, timeout=8000)
    value = await page.input_value(selector)
    if submit:
        await page.keyboard.press("Enter")
        await page.wait_for_timeout(1200)
    return {"selector": selector, "value": value, "verified": value == text, "url": page.url}


@tool("browser_back", "browser", SAFE, "Go back in browser history.")
async def browser_back():
    page = await _ensure_page()
    await page.go_back(timeout=15000)
    return {"url": page.url, "title": await page.title()}
