"""Voice subsystem (spec 13, 14).

Windows STT  : faster-whisper, model tiny.en (lazy-loaded - never at startup)
Windows TTS  : pyttsx3 over SAPI5
Global hotkey: a real OS-level hook via pynput, so V works while minimized.

Every piece degrades honestly: if an engine is not installed the status endpoint
says UNAVAILABLE and the HUD falls back to the browser's own speech APIs.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Optional

from .. import config, db

# ---- voice state machine (spec 14) ---------------------------------------- #
READY = "READY"
LISTENING = "LISTENING"
THINKING = "THINKING"
TOOL = "TOOL"
VERIFYING = "VERIFYING"
SPEAKING = "SPEAKING"
WAITING_CONFIRMATION = "WAITING_CONFIRMATION"
ERROR = "ERROR"
OFFLINE = "OFFLINE"

STATES = (READY, LISTENING, THINKING, TOOL, VERIFYING, SPEAKING, WAITING_CONFIRMATION, ERROR, OFFLINE)

_state = {"state": READY, "detail": "", "since": time.time()}
_lock = threading.Lock()

_model = None
_model_lock = threading.Lock()


def get_state() -> dict:
    with _lock:
        return {**_state, "for_seconds": round(time.time() - _state["since"], 1)}


def set_state(state: str, detail: str = "") -> dict:
    if state not in STATES:
        raise ValueError(f"Unknown voice state: {state}")
    with _lock:
        _state.update({"state": state, "detail": detail, "since": time.time()})
    return get_state()


# ---- STT ------------------------------------------------------------------ #
def stt_status() -> dict:
    try:
        import faster_whisper  # noqa: F401
    except ImportError:
        return {"available": False, "engine": "faster-whisper",
                "detail": "faster-whisper is not installed (pip install faster-whisper)."}
    return {"available": True, "engine": "faster-whisper", "model": "tiny.en",
            "loaded": _model is not None,
            "detail": "ready (model loads on first use)"}


def load_model(model_size: str = "tiny.en"):
    """Lazy: the ~75 MB model is only fetched/loaded on the first real transcription."""
    global _model
    with _model_lock:
        if _model is not None:
            return _model
        try:
            from faster_whisper import WhisperModel
        except ImportError as exc:
            raise RuntimeError("faster-whisper is not installed.") from exc
        _model = WhisperModel(model_size, device="cpu", compute_type="int8")
        return _model


def transcribe(audio_path: str) -> dict:
    model = load_model()
    segments, info = model.transcribe(audio_path, beam_size=1, vad_filter=True)
    text = "".join(seg.text for seg in segments).strip()
    return {"text": text, "language": getattr(info, "language", "en"),
            "duration": getattr(info, "duration", None)}


# ---- TTS ------------------------------------------------------------------ #
def tts_status() -> dict:
    try:
        import pyttsx3  # noqa: F401
    except ImportError:
        return {"available": False, "engine": "pyttsx3",
                "detail": "pyttsx3 not installed - the HUD uses the browser speech API instead."}
    if not config.IS_WINDOWS:
        return {"available": False, "engine": "pyttsx3",
                "detail": "SAPI5 voices are Windows-only; browser speech is used here."}
    return {"available": True, "engine": "pyttsx3", "backend": "SAPI5", "detail": "ready"}


def speak(text: str) -> dict:
    status = tts_status()
    if not status.get("available"):
        return {"spoken": False, "reason": status.get("detail")}
    import pyttsx3

    engine = pyttsx3.init(driverName="sapi5" if config.IS_WINDOWS else None)
    engine.say(text)
    engine.runAndWait()
    return {"spoken": True, "chars": len(text)}


# ---- global hotkey (spec 13) ---------------------------------------------- #
class HotkeyManager:
    """Real OS-level V hotkey via pynput.

    Press V  -> LISTENING (recording continues through natural pauses)
    Press V  -> stop and transcribe
    Press ESC-> cancel
    Key auto-repeat is suppressed with a debounce so one physical press is one toggle.
    """

    DEBOUNCE_SECONDS = 0.35

    def __init__(self) -> None:
        self.enabled = False
        self.key = "v"
        self.listening = False
        self._listener = None
        self._last_toggle = 0.0
        self._on_start = None
        self._on_stop = None
        self._on_cancel = None
        self.last_error: Optional[str] = None

    def status(self) -> dict:
        return {"enabled": self.enabled, "key": self.key, "listening": self.listening,
                "os_level": self._listener is not None,
                "mechanism": "pynput global hook" if self._listener else "not started",
                "error": self.last_error,
                "fallback": "the HUD also binds V while the window is focused"}

    def configure(self, key: str | None = None, enabled: bool | None = None) -> dict:
        if key:
            self.key = key.strip().lower()[:1] or "v"
        if enabled is not None:
            self.stop() if not enabled else self.start()
        db.set_setting("voice_hotkey", {"key": self.key, "enabled": self.enabled})
        return self.status()

    def bind(self, on_start=None, on_stop=None, on_cancel=None) -> None:
        self._on_start, self._on_stop, self._on_cancel = on_start, on_stop, on_cancel

    def start(self) -> dict:
        if self._listener is not None:
            self.enabled = True
            return self.status()
        try:
            from pynput import keyboard
        except ImportError:
            self.last_error = "pynput is not installed; global hotkey unavailable."
            self.enabled = False
            return self.status()

        def on_press(k):
            try:
                char = getattr(k, "char", None)
                if char and char.lower() == self.key:
                    self.toggle()
                elif k == keyboard.Key.esc:
                    self.cancel()
            except Exception:
                pass

        try:
            self._listener = keyboard.Listener(on_press=on_press)
            self._listener.daemon = True
            self._listener.start()
            self.enabled = True
            self.last_error = None
        except Exception as exc:      # no X display / no permission
            self.last_error = f"Global hook could not start: {exc}"
            self.enabled = False
            self._listener = None
        return self.status()

    def stop(self) -> dict:
        if self._listener is not None:
            try:
                self._listener.stop()
            except Exception:
                pass
            self._listener = None
        self.enabled = False
        self.listening = False
        return self.status()

    def toggle(self) -> dict:
        now = time.time()
        if now - self._last_toggle < self.DEBOUNCE_SECONDS:   # key-repeat guard
            return self.status()
        self._last_toggle = now
        self.listening = not self.listening
        if self.listening:
            set_state(LISTENING, "listening (press V again to send)")
            if self._on_start:
                self._on_start()
        else:
            set_state(THINKING, "transcribing")
            if self._on_stop:
                self._on_stop()
        return self.status()

    def cancel(self) -> dict:
        if self.listening:
            self.listening = False
            set_state(READY, "cancelled")
            if self._on_cancel:
                self._on_cancel()
        return self.status()


hotkeys = HotkeyManager()
