"""SQLite persistence layer. The backend is authoritative for all security state."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from typing import Any, Iterable, Optional

from . import config

_lock = threading.RLock()
_conn: Optional[sqlite3.Connection] = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id       TEXT PRIMARY KEY,
    username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL,
    created_at    REAL NOT NULL,
    disabled      INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS sessions (
    session_id  TEXT PRIMARY KEY,       -- sha256 of the bearer token
    user_id     TEXT NOT NULL,
    created_at  REAL NOT NULL,
    expires_at  REAL NOT NULL,
    device_id   TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS devices (
    device_id    TEXT PRIMARY KEY,
    user_id      TEXT NOT NULL,
    name         TEXT NOT NULL,
    device_type  TEXT NOT NULL,          -- windows | android | linux | other
    os           TEXT,
    os_version   TEXT,
    app_version  TEXT,
    token_hash   TEXT,                   -- sha256 of device token
    capabilities TEXT NOT NULL DEFAULT '[]',
    permissions  TEXT NOT NULL DEFAULT '[]',
    state        TEXT NOT NULL DEFAULT 'ACTIVE',   -- ACTIVE | REVOKED
    is_host      INTEGER NOT NULL DEFAULT 0,
    last_seen    REAL,
    created_at   REAL NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE TABLE IF NOT EXISTS pairings (
    pairing_id   TEXT PRIMARY KEY,
    code_hash    TEXT NOT NULL,
    code_display TEXT NOT NULL,          -- shown to the owner for visual match
    user_id      TEXT,
    device_name  TEXT NOT NULL,
    device_type  TEXT NOT NULL,
    os           TEXT,
    app_version  TEXT,
    capabilities TEXT NOT NULL DEFAULT '[]',
    status       TEXT NOT NULL,          -- PENDING | APPROVED | REJECTED | CLAIMED | EXPIRED
    created_at   REAL NOT NULL,
    expires_at   REAL NOT NULL,
    used_at      REAL,
    device_id    TEXT,
    token_hash   TEXT                    -- one-time token issued on approval
);

CREATE TABLE IF NOT EXISTS tasks (
    task_id           TEXT PRIMARY KEY,
    user_id           TEXT NOT NULL,
    source_device_id  TEXT,
    target_device_id  TEXT,
    kind              TEXT NOT NULL,
    payload           TEXT NOT NULL DEFAULT '{}',
    status            TEXT NOT NULL,     -- QUEUED|RUNNING|WAITING_CONFIRMATION|COMPLETED|FAILED|CANCELLED
    steps             TEXT NOT NULL DEFAULT '[]',
    result            TEXT,
    error             TEXT,
    verification      TEXT NOT NULL DEFAULT 'NOT_VERIFIED',
    request_id        TEXT,
    created_at        REAL NOT NULL,
    updated_at        REAL NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_tasks_request ON tasks(request_id) WHERE request_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS memories (
    id         TEXT PRIMARY KEY,
    user_id    TEXT NOT NULL,
    key        TEXT NOT NULL,
    value      TEXT NOT NULL,
    category   TEXT NOT NULL DEFAULT 'fact',
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL,
    UNIQUE(user_id, key)
);

CREATE TABLE IF NOT EXISTS audit (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    ts            REAL NOT NULL,
    user_id       TEXT,
    source_device TEXT,
    target_device TEXT,
    action        TEXT NOT NULL,
    result        TEXT NOT NULL,
    verification  TEXT,
    task_id       TEXT,
    detail        TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS destinations (
    name       TEXT PRIMARY KEY COLLATE NOCASE,
    url        TEXT NOT NULL,
    user_id    TEXT,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS activity (
    id     INTEGER PRIMARY KEY AUTOINCREMENT,
    ts     REAL NOT NULL,
    kind   TEXT NOT NULL,
    title  TEXT NOT NULL,
    detail TEXT
);

-- OWNER-managed OmniRoute Combos. There is deliberately no cap on row count:
-- the OWNER adds future identifiers from the HUD, no code change, no rebuild.
CREATE TABLE IF NOT EXISTS combos (
    combo_id             TEXT PRIMARY KEY,
    display_name         TEXT NOT NULL,
    omniroute_identifier TEXT NOT NULL UNIQUE,   -- stored EXACTLY as typed
    description          TEXT NOT NULL DEFAULT '',
    enabled              INTEGER NOT NULL DEFAULT 1,
    is_default           INTEGER NOT NULL DEFAULT 0,
    created_by           TEXT NOT NULL,
    created_at           REAL NOT NULL,
    updated_at           REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS combo_assignments (
    combo_id     TEXT NOT NULL,
    subject_type TEXT NOT NULL,          -- 'user' | 'role'
    subject_id   TEXT NOT NULL,          -- user_id | role name
    granted_by   TEXT NOT NULL,
    created_at   REAL NOT NULL,
    PRIMARY KEY (combo_id, subject_type, subject_id),
    FOREIGN KEY (combo_id) REFERENCES combos(combo_id) ON DELETE CASCADE
);

-- AI usage / quota telemetry (spec: cloud quota protection). One row per AI
-- call or per deterministic bypass, so OWNER diagnostics can show real numbers.
-- Never stores provider secrets or API keys, only counts + estimated tokens.
CREATE TABLE IF NOT EXISTS ai_usage (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    ts                REAL NOT NULL,
    user_id           TEXT,
    device_id         TEXT,
    combo             TEXT,
    provider          TEXT,               -- ollama | omniroute | none
    route             TEXT,               -- LOCAL|CLOUD|DETERMINISTIC|MEMORY|WORKFLOW|NO_AI
    cloud             INTEGER NOT NULL DEFAULT 0,
    success           INTEGER NOT NULL DEFAULT 1,
    fallback          INTEGER NOT NULL DEFAULT 0,
    prompt_tokens     INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens      INTEGER NOT NULL DEFAULT 0,
    latency_ms        INTEGER,
    model             TEXT,
    detail            TEXT
);
CREATE INDEX IF NOT EXISTS idx_ai_usage_ts ON ai_usage(ts);
CREATE INDEX IF NOT EXISTS idx_ai_usage_user ON ai_usage(user_id, ts);

-- Bounded short-term conversation memory (spec 2). Kept per user+session so the
-- WHOLE conversation is never sent to cloud AI; old turns are summarised locally.
CREATE TABLE IF NOT EXISTS conversation (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    TEXT NOT NULL,
    session_id TEXT NOT NULL,
    role       TEXT NOT NULL,            -- user | assistant | summary
    content    TEXT NOT NULL,
    is_summary INTEGER NOT NULL DEFAULT 0,
    created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_conversation_sess ON conversation(user_id, session_id, id);

-- Learned safe workflows (spec 2). Repeated deterministic commands are cached so
-- they bypass AI planning entirely. Only SAFE-risk tools are ever learned.
CREATE TABLE IF NOT EXISTS workflows (
    id         TEXT PRIMARY KEY,
    user_id    TEXT NOT NULL,
    trigger    TEXT NOT NULL,            -- normalised command phrase
    tool       TEXT NOT NULL,
    args       TEXT NOT NULL DEFAULT '{}',
    times_used INTEGER NOT NULL DEFAULT 0,
    enabled    INTEGER NOT NULL DEFAULT 1,
    created_at REAL NOT NULL,
    updated_at REAL NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_workflows_trigger ON workflows(user_id, trigger);
"""

DEFAULT_DESTINATIONS = {
    "youtube": "https://www.youtube.com/",
    "google": "https://www.google.com/",
    "gmail": "https://mail.google.com/",
    "github": "https://github.com/",
    "aternos": "https://aternos.org/",
    "chatgpt": "https://chat.openai.com/",
    "whatsapp": "https://web.whatsapp.com/",
    "maps": "https://maps.google.com/",
    "drive": "https://drive.google.com/",
    "calendar": "https://calendar.google.com/",
}


def connect() -> sqlite3.Connection:
    global _conn
    with _lock:
        if _conn is None:
            config.DB_PATH.parent.mkdir(parents=True, exist_ok=True)
            _conn = sqlite3.connect(str(config.DB_PATH), check_same_thread=False)
            _conn.row_factory = sqlite3.Row
            _conn.execute("PRAGMA journal_mode=WAL")
            _conn.execute("PRAGMA foreign_keys=ON")
            _conn.executescript(SCHEMA)
            _migrate(_conn)
            _seed(_conn)
            _conn.commit()
        return _conn


def _migrate(conn: sqlite3.Connection) -> None:
    """Additive migrations for older databases (never drops or rewrites data)."""
    # workflows gained an `enabled` column after first release.
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(workflows)")}
    if cols and "enabled" not in cols:
        conn.execute("ALTER TABLE workflows ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1")


def _seed(conn: sqlite3.Connection) -> None:
    now = time.time()
    for name, url in DEFAULT_DESTINATIONS.items():
        conn.execute(
            "INSERT OR IGNORE INTO destinations(name, url, user_id, created_at) VALUES (?,?,?,?)",
            (name, url, None, now),
        )


def reset_for_tests(path: str) -> None:
    """Point the DB at a fresh file (used by the test-suite only)."""
    global _conn
    with _lock:
        if _conn is not None:
            _conn.close()
            _conn = None
        config.DB_PATH = __import__("pathlib").Path(path)
    connect()


def query(sql: str, args: Iterable[Any] = ()) -> list[sqlite3.Row]:
    with _lock:
        return list(connect().execute(sql, tuple(args)).fetchall())


def one(sql: str, args: Iterable[Any] = ()) -> Optional[sqlite3.Row]:
    rows = query(sql, args)
    return rows[0] if rows else None


def execute(sql: str, args: Iterable[Any] = ()) -> sqlite3.Cursor:
    with _lock:
        conn = connect()
        cur = conn.execute(sql, tuple(args))
        conn.commit()
        return cur


def get_setting(key: str, default: Any = None) -> Any:
    row = one("SELECT value FROM settings WHERE key=?", (key,))
    if not row:
        return default
    try:
        return json.loads(row["value"])
    except Exception:
        return row["value"]


def set_setting(key: str, value: Any) -> None:
    execute(
        "INSERT INTO settings(key,value) VALUES (?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, json.dumps(value)),
    )


def log_activity(kind: str, title: str, detail: str | None = None) -> None:
    execute(
        "INSERT INTO activity(ts,kind,title,detail) VALUES (?,?,?,?)",
        (time.time(), kind, title, detail),
    )
    # keep the feed bounded
    execute("DELETE FROM activity WHERE id NOT IN (SELECT id FROM activity ORDER BY id DESC LIMIT 500)")
