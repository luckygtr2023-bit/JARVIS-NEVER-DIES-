"""Learned safe workflows + tool-routing cache (spec: LEARNED WORKFLOWS).

When the same safe deterministic command is used repeatedly, JARVIS caches the
command-phrase -> tool mapping so later uses bypass AI planning entirely
(command -> workflow lookup -> deterministic execution).

Safety rules:
  * only SAFE-risk tools are ever learned (`requires_confirmation` ones never are)
  * a workflow is only learned from an actual successful execution, never created
    speculatively by the AI
  * every workflow is user-scoped, inspectable and deletable by that user
  * never silently create a dangerous / privileged workflow

The same table also serves as the deterministic tool-routing cache for
single-word commands (open chrome -> launch_app("Chrome")).
"""
from __future__ import annotations

import json
import re
import time
import uuid

from . import db
from .services.tools_registry import REGISTRY, requires_confirmation

SAFE_ONLY = True


def _norm(text: str) -> str:
    """Normalised lookup key: lowercased, trimmed, single-spaced."""
    return re.sub(r"\s+", " ", (text or "").strip().lower().rstrip(".!?"))


def lookup(user_id: str, text: str) -> dict | None:
    """Return the cached workflow for a command, or None. Only enabled ones are
    used, so a user can disable a workflow without deleting it."""
    key = _norm(text)
    if not key:
        return None
    row = db.one("SELECT * FROM workflows WHERE user_id=? AND trigger=? AND enabled=1",
                 (user_id, key))
    if not row:
        # also allow a cache hit on the trimmed first clause
        short = " ".join(key.split()[:4])
        row = db.one("SELECT * FROM workflows WHERE user_id=? AND trigger=? AND enabled=1",
                     (user_id, short))
    if not row:
        return None
    return {"id": row["id"], "trigger": row["trigger"], "tool": row["tool"],
            "args": json.loads(row["args"] or "{}"), "times_used": row["times_used"],
            "enabled": bool(row["enabled"]), "created_at": row["created_at"],
            "updated_at": row["updated_at"]}


def learn(user_id: str, text: str, tool: str, args: dict) -> dict | None:
    """Record a workflow after a successful deterministic execution.

    Returns None if the tool is unsafe (CONFIRM risk) or unknown - we never learn
    dangerous mappings. Idempotent: repeats bump `times_used` instead of duplicating.
    """
    t = REGISTRY.get(tool)
    if not t or t.risk != "SAFE":
        return None
    key = _norm(text)
    if not key or len(key) < 3:
        return None
    now = time.time()
    existing = db.one("SELECT * FROM workflows WHERE user_id=? AND trigger=?",
                      (user_id, key))
    if existing:
        db.execute("UPDATE workflows SET times_used=times_used+1, updated_at=? WHERE id=?",
                   (now, existing["id"]))
        wf_id = existing["id"]
    else:
        wf_id = f"wf_{uuid.uuid4().hex[:12]}"
        db.execute(
            "INSERT INTO workflows(id,user_id,trigger,tool,args,times_used,created_at,updated_at)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (wf_id, user_id, key, tool, json.dumps(args), 1, now, now))
    return {"id": wf_id, "trigger": key, "tool": tool, "args": args}


def list_for(user_id: str) -> list[dict]:
    rows = db.query("SELECT * FROM workflows WHERE user_id=? ORDER BY updated_at DESC",
                    (user_id,))
    return [{"id": r["id"], "trigger": r["trigger"], "tool": r["tool"],
             "args": json.loads(r["args"] or "{}"), "times_used": r["times_used"],
             "enabled": bool(r["enabled"]), "created_at": r["created_at"],
             "updated_at": r["updated_at"]} for r in rows]


def set_enabled(user_id: str, wf_id: str, enabled: bool) -> dict | None:
    """Disable/re-enable a learned workflow (kept, so it can be re-enabled)."""
    row = db.one("SELECT * FROM workflows WHERE user_id=? AND id=?", (user_id, wf_id))
    if not row:
        return None
    db.execute("UPDATE workflows SET enabled=? WHERE id=?", (1 if enabled else 0, wf_id))
    return {"id": wf_id, "trigger": row["trigger"], "tool": row["tool"],
            "enabled": bool(enabled)}


def delete(user_id: str, wf_id: str) -> bool:
    cur = db.execute("DELETE FROM workflows WHERE user_id=? AND id=?", (user_id, wf_id))
    return cur.rowcount > 0


def clear(user_id: str) -> int:
    cur = db.execute("DELETE FROM workflows WHERE user_id=?", (user_id,))
    return cur.rowcount
