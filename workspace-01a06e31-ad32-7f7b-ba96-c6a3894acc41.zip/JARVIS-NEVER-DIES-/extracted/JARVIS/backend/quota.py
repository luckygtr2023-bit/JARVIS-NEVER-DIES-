"""Cloud quota protection + AI usage telemetry (spec: CLOUD QUOTA PROTECTION).

JARVIS must never blindly burn cloud quota. This module:
  * records every AI call (cloud or local) as one row in `ai_usage`
  * estimates token usage when the provider returns none (exact when available)
  * enforces daily / session / per-user / per-device cloud request limits
  * exposes OWNER diagnostics that never leak provider secrets

The limits themselves are configurable settings (see config defaults); an OWNER
can raise or lower them from the HUD. Rules enforced here are always checked
BEFORE a cloud request is made, so quota is never overspent by a race.
"""
from __future__ import annotations

import json
import time
from typing import Optional

from . import db


class QuotaError(PermissionError):
    """Raised when the cloud quota is exhausted. Always user-presentable."""

    def __init__(self, message: str, *, window: str = ""):
        super().__init__(message)
        self.message = message
        self.window = window


# --------------------------------------------------------------------------- #
# limits (stored in settings, defaulted here)
# --------------------------------------------------------------------------- #
DEFAULT_LIMITS = {
    "session_cloud_limit": 100,   # cloud calls per backend session (process start)
    "daily_cloud_limit": 500,     # cloud calls per rolling 24h (per user)
    "user_cloud_limit": 500,      # per user (per rolling 24h)
    "device_cloud_limit": 300,    # per device (per rolling 24h)
    "enforce_cloud_limits": True,
}

# The backend session identity. Roughly "since this server process started".
_SESSION_START = time.time()


def limits() -> dict:
    raw = db.get_setting("quota_limits", None)
    out = dict(DEFAULT_LIMITS)
    if isinstance(raw, dict):
        out.update({k: v for k, v in raw.items() if k in DEFAULT_LIMITS})
    return out


def save_limits(new: dict) -> dict:
    cur = limits()
    for k in ("session_cloud_limit", "daily_cloud_limit", "user_cloud_limit",
              "device_cloud_limit"):
        if k in new and new[k] is not None:
            try:
                cur[k] = max(1, int(new[k]))
            except (TypeError, ValueError):
                pass
    if "enforce_cloud_limits" in new and new["enforce_cloud_limits"] is not None:
        cur["enforce_cloud_limits"] = bool(new["enforce_cloud_limits"])
    db.set_setting("quota_limits", cur)
    return cur


# --------------------------------------------------------------------------- #
# counting helpers
# --------------------------------------------------------------------------- #
def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~1.3 tokens per word (OpenAI-style heuristic)."""
    if not text:
        return 0
    return int(len(text.split()) * 1.3) + 1


def _count(where: str, args: tuple) -> int:
    row = db.one(f"SELECT COUNT(*) AS n FROM ai_usage WHERE {where}", args)
    return int(row["n"]) if row else 0


def cloud_count(where: str, args: tuple) -> int:
    return _count(f"cloud=1 AND {where}", args) if not where.startswith("cloud") \
        else _count(where, args)


def _window_start(seconds: int) -> float:
    return time.time() - seconds


def usage_today() -> int:
    return _count("ts >= ?", (_window_start(86400),))


def cloud_today() -> int:
    return _count("cloud=1 AND ts >= ?", (_window_start(86400),))


def local_today() -> int:
    return _count("cloud=0 AND ts >= ?", (_window_start(86400),))


def session_cloud() -> int:
    return _count("cloud=1 AND ts >= ?", (_SESSION_START,))


# --------------------------------------------------------------------------- #
# enforcement
# --------------------------------------------------------------------------- #
def check_cloud_limit(*, user_id: Optional[str] = None,
                      device_id: Optional[str] = None) -> None:
    """Raise QuotaError if any cloud limit is exhausted. Called BEFORE a cloud
    request so quota is never overspent."""
    lim = limits()
    if not lim.get("enforce_cloud_limits", True):
        return
    now = time.time()
    day_start = now - 86400

    session = _count("cloud=1 AND ts >= ?", (_SESSION_START,))
    if session >= lim["session_cloud_limit"]:
        raise QuotaError(
            f"Cloud quota exhausted for this session ({session}/{lim['session_cloud_limit']}). "
            "I switched to local reasoning. Start a fresh session to reset it.",
            window="session")

    if user_id:
        user_day = _count("cloud=1 AND user_id=? AND ts >= ?", (user_id, day_start))
        if user_day >= lim["daily_cloud_limit"]:
            raise QuotaError(
                f"Your daily cloud quota is exhausted ({user_day}/{lim['daily_cloud_limit']}). "
                "I will use local reasoning instead.", window="daily")
        if user_day >= lim["user_cloud_limit"]:
            raise QuotaError(
                f"Cloud quota for this account is exhausted.", window="user")

    if device_id:
        dev_day = _count("cloud=1 AND device_id=? AND ts >= ?", (device_id, day_start))
        if dev_day >= lim["device_cloud_limit"]:
            raise QuotaError(
                f"This device's cloud quota is exhausted ({dev_day}/{lim['device_cloud_limit']}). "
                "I will use local reasoning instead.", window="device")


# --------------------------------------------------------------------------- #
# recording
# --------------------------------------------------------------------------- #
def record(*, user_id=None, device_id=None, combo=None, provider=None, route=None,
           cloud=False, success=True, fallback=False, prompt_tokens=0,
           completion_tokens=0, model=None, latency_ms=None,
           detail: Optional[dict] = None) -> int:
    """Record one AI execution. Never raises; bookkeeping must not block the loop."""
    try:
        total = int(prompt_tokens or 0) + int(completion_tokens or 0)
        db.execute(
            "INSERT INTO ai_usage(ts,user_id,device_id,combo,provider,route,cloud,success,"
            "fallback,prompt_tokens,completion_tokens,total_tokens,latency_ms,model,detail)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (time.time(), user_id, device_id, combo, provider, route, int(bool(cloud)),
             int(bool(success)), int(bool(fallback)), int(prompt_tokens or 0),
             int(completion_tokens or 0), total, latency_ms, model,
             json.dumps(detail, default=str) if detail else None))
        db.execute("DELETE FROM ai_usage WHERE id NOT IN "
                   "(SELECT id FROM ai_usage ORDER BY id DESC LIMIT 50000)")
        return total
    except Exception:
        return 0


# --------------------------------------------------------------------------- #
# diagnostics (OWNER view; never leaks secrets)
# --------------------------------------------------------------------------- #
def summary(user_id: Optional[str] = None) -> dict:
    """Usage summary shown in OWNER diagnostics 'AI USAGE'."""
    now = time.time()
    day_start = now - 86400
    base = []
    args = []
    if user_id:
        base.append("user_id=?")
        args.append(user_id)

    def one(extra, extra_args):
        where = " AND ".join(base + [extra])
        return _count(where, tuple(args + list(extra_args)))

    cloud = one("cloud=1 AND ts >= ?", [day_start])
    local = one("cloud=0 AND ts >= ?", [day_start])
    failures = one("success=0 AND ts >= ?", [day_start])
    fallbacks = one("fallback=1 AND ts >= ?", [day_start])
    tokens = _sum_tokens(base, args, day_start)
    by_mode = _group_by("route", base, args, day_start)
    by_provider = _group_by("provider", base, args, day_start)
    lim = limits()

    return {
        "window": "rolling 24h",
        "today": {"cloud": cloud, "local": local, "total": cloud + local,
                  "failures": failures, "fallbacks": fallbacks,
                  "estimated_cloud_tokens": tokens["cloud"],
                  "estimated_local_tokens": tokens["local"],
                  "estimated_total_tokens": tokens["cloud"] + tokens["local"]},
        "session": {"cloud": session_cloud()},
        "by_route": by_mode,
        "by_provider": by_provider,
        "limits": {
            "session_cloud_limit": lim["session_cloud_limit"],
            "daily_cloud_limit": lim["daily_cloud_limit"],
            "user_cloud_limit": lim["user_cloud_limit"],
            "device_cloud_limit": lim["device_cloud_limit"],
            "enforce_cloud_limits": lim["enforce_cloud_limits"],
        },
    }


def _sum_tokens(base, args, day_start) -> dict:
    where = " AND ".join(base + ["ts >= ?"])
    row = db.one(
        f"SELECT COALESCE(SUM(CASE WHEN cloud=1 THEN total_tokens ELSE 0 END),0) AS c, "
        f"COALESCE(SUM(CASE WHEN cloud=0 THEN total_tokens ELSE 0 END),0) AS l "
        f"FROM ai_usage WHERE {where}", tuple(args + [day_start]))
    return {"cloud": int(row["c"]) if row else 0, "local": int(row["l"]) if row else 0}


def _group_by(column, base, args, day_start):
    if not base:
        where = "ts >= ?"
    else:
        where = " AND ".join(base + ["ts >= ?"])
    rows = db.query(
        f"SELECT {column} AS k, COUNT(*) AS n FROM ai_usage WHERE {where} "
        f"GROUP BY {column}", tuple(args + [day_start]))
    return {r["k"] or "unknown": r["n"] for r in rows}


def recent(limit: int = 50, user_id: Optional[str] = None) -> list[dict]:
    if user_id:
        rows = db.query(
            "SELECT ts,provider,route,cloud,success,fallback,prompt_tokens,"
            "completion_tokens,total_tokens,latency_ms,model,combo,user_id,device_id,detail "
            "FROM ai_usage WHERE user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit))
    else:
        rows = db.query(
            "SELECT ts,provider,route,cloud,success,fallback,prompt_tokens,"
            "completion_tokens,total_tokens,latency_ms,model,combo,user_id,device_id,detail "
            "FROM ai_usage ORDER BY id DESC LIMIT ?", (limit,))
    return [dict(r) for r in rows]
