"""Device capability registry (spec 8).

A capability is a promise a device makes about what it can physically do. It is
NOT a permission: `windows.automation` says a device *can* drive Windows,
`windows.control` (in security.ALL_PERMISSIONS) says it is *allowed* to. Both
must hold before a task is routed.

Two rules keep this honest:
  1. Capabilities are advertised by the device and stored per device_id. The
     application/package name is never treated as proof - an APK claiming to be
     JARVIS still has to pair and still only gets what the OWNER grants.
  2. JARVIS checks the capability BEFORE dispatching, so the user is told
     "your phone cannot do that" instead of watching a task time out.
"""
from __future__ import annotations

import json
from typing import Dict, Iterable, List, Optional

from . import db

# --------------------------------------------------------------------------- #
# catalogue
# --------------------------------------------------------------------------- #
#: capability -> (human description, platforms that can plausibly offer it)
CATALOG: Dict[str, tuple] = {
    # --- shared ---
    "chat":                 ("Accept natural-language commands", ("windows", "android", "linux")),
    "device.info":          ("Report OS, model and app version", ("windows", "android", "linux")),
    "notifications":        ("Show a notification to the user", ("windows", "android")),
    "browser":              ("Open URLs / drive a browser", ("windows", "android", "linux")),
    "media.control":        ("Play / pause / skip media", ("windows", "android")),
    "voice.microphone":     ("Capture microphone audio", ("windows", "android")),
    "voice.stt":            ("Transcribe speech to text", ("windows", "android")),
    "voice.tts":            ("Speak text aloud", ("windows", "android")),
    # --- android leaning ---
    "app.launch":           ("Launch an installed application", ("windows", "android")),
    "android.intent":       ("Fire an Android intent", ("android",)),
    "android.accessibility": ("Use the accessibility service (explicit opt-in only)", ("android",)),
    "files.scoped":         ("Read/write inside a permitted folder only", ("android",)),
    "location":             ("Report device location (explicit opt-in only)", ("android",)),
    # --- windows leaning ---
    "windows.automation":   ("Drive Windows: windows, processes, shell", ("windows",)),
    "input.keyboard_mouse": ("Synthesise keyboard and mouse input", ("windows",)),
    "screen.capture":       ("Take a screenshot", ("windows", "android")),
    "files.full":           ("Read/write inside the configured file root", ("windows", "linux")),
    "system.info":          ("CPU, RAM, battery, process telemetry", ("windows", "android", "linux")),
    "ai.local":             ("Run a local model (Ollama) on this device", ("windows", "linux")),
}

ALL_CAPABILITIES = tuple(CATALOG)

#: What a fresh install of each client advertises before the user grants extras.
DEFAULT_CAPABILITIES: Dict[str, tuple] = {
    "windows": (
        "chat", "device.info", "notifications", "browser", "media.control",
        "voice.microphone", "voice.stt", "voice.tts", "app.launch",
        "windows.automation", "input.keyboard_mouse", "screen.capture",
        "files.full", "system.info", "ai.local",
    ),
    "android": (
        "chat", "device.info", "notifications", "browser", "media.control",
        "voice.microphone", "voice.stt", "voice.tts", "app.launch",
        "android.intent", "files.scoped", "system.info",
    ),
    "linux": ("chat", "device.info", "browser", "files.full", "system.info", "ai.local"),
    "other": ("chat", "device.info"),
}

#: Capability required to carry out a routed intent. Checked before dispatch.
INTENT_CAPABILITY: Dict[str, str] = {
    "open_url": "browser",
    "browser_search": "browser",
    "open_app": "app.launch",
    "close_app": "app.launch",
    "screenshot": "screen.capture",
    "system_status": "system.info",
    "media": "media.control",
    "speak": "voice.tts",
    "listen": "voice.microphone",
    "notify": "notifications",
    "keyboard": "input.keyboard_mouse",
    "mouse": "input.keyboard_mouse",
    "windows_control": "windows.automation",
    "read_file": "files.full",
    "write_file": "files.full",
    "delete_file": "files.full",
    "chat": "chat",
}

#: Phrases that imply an intent, used when routing free text to another device.
_TEXT_HINTS = (
    ("screenshot", "screenshot"),
    ("screen shot", "screenshot"),
    ("take a picture of the screen", "screenshot"),
    ("open ", "open_url"),
    ("launch ", "open_app"),
    ("play ", "media"),
    ("pause", "media"),
    ("next track", "media"),
    ("volume", "media"),
    ("say ", "speak"),
    ("speak ", "speak"),
    ("notify", "notify"),
    ("notification", "notify"),
    ("delete ", "delete_file"),
    ("read file", "read_file"),
    ("cpu", "system_status"),
    ("battery", "system_status"),
    ("ram", "system_status"),
    ("memory usage", "system_status"),
    ("type ", "keyboard"),
    ("press ", "keyboard"),
    ("click ", "mouse"),
)


class CapabilityMismatch(Exception):
    """Raised when a target device cannot physically perform the request."""

    def __init__(self, device_name: str, capability: str, message: str = ""):
        self.device_name = device_name
        self.capability = capability
        super().__init__(message or (
            f"{device_name} does not support '{capability}' "
            f"({CATALOG.get(capability, ('an unsupported action',))[0]}), so I did not send it."))


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def normalize(caps: Iterable[str]) -> List[str]:
    """Trim, de-duplicate and order capabilities. Unknown strings are KEPT -
    a future Android build may advertise something this server has not heard of
    yet, and silently dropping it would be a lie about what the device can do."""
    seen, out = set(), []
    for cap in caps or []:
        cap = str(cap).strip()
        if not cap or cap in seen:
            continue
        seen.add(cap)
        out.append(cap)
    return out


def unknown(caps: Iterable[str]) -> List[str]:
    return [c for c in normalize(caps) if c not in CATALOG]


def defaults_for(device_type: str) -> List[str]:
    return list(DEFAULT_CAPABILITIES.get((device_type or "other").lower(),
                                         DEFAULT_CAPABILITIES["other"]))


def device_capabilities(device_id: str) -> List[str]:
    row = db.one("SELECT capabilities FROM devices WHERE device_id=?", (device_id,))
    if not row:
        return []
    try:
        return normalize(json.loads(row["capabilities"] or "[]"))
    except json.JSONDecodeError:
        return []


def set_capabilities(device_id: str, caps: Iterable[str]) -> List[str]:
    caps = normalize(caps)
    db.execute("UPDATE devices SET capabilities=? WHERE device_id=?",
               (json.dumps(caps), device_id))
    return caps


def supports(device_id: str, capability: str) -> bool:
    return capability in device_capabilities(device_id)


def capability_for_intent(intent: str) -> Optional[str]:
    return INTENT_CAPABILITY.get(intent)


def capability_for_text(text: str) -> Optional[str]:
    """Best-effort mapping of a free-text command to the capability it needs.

    Deliberately conservative: if nothing matches we return None and the task is
    routed, because refusing on a guess would be worse than letting the target
    device answer 'I cannot do that'.
    """
    low = (text or "").lower()
    for needle, intent in _TEXT_HINTS:
        if needle in low:
            return INTENT_CAPABILITY.get(intent)
    return None


def assert_capable(device_id: str, capability: Optional[str], device_name: str = "") -> None:
    if not capability:
        return
    caps = device_capabilities(device_id)
    if capability in caps:
        return
    name = device_name or (db.one("SELECT name FROM devices WHERE device_id=?", (device_id,))
                           or {"name": device_id})["name"]
    raise CapabilityMismatch(name, capability)


def describe(caps: Iterable[str]) -> List[dict]:
    out = []
    for cap in normalize(caps):
        desc, platforms = CATALOG.get(cap, ("Device-specific capability", ()))
        out.append({"capability": cap, "description": desc,
                    "platforms": list(platforms), "known": cap in CATALOG})
    return out


def catalog_public() -> dict:
    return {
        "capabilities": [
            {"capability": c, "description": d, "platforms": list(p)}
            for c, (d, p) in sorted(CATALOG.items())
        ],
        "defaults": {k: list(v) for k, v in DEFAULT_CAPABILITIES.items()},
        "intent_map": dict(sorted(INTENT_CAPABILITY.items())),
        "note": "Capabilities describe what a device CAN do. Permissions decide "
                "what it MAY do. Both are checked before a task is routed.",
    }
