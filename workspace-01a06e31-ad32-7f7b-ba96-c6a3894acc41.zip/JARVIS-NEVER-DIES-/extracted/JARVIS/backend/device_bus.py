"""Cross-device control plane (spec 6).

A device (this Windows host today, an Android client tomorrow) authenticates with
its device token, opens a WebSocket to /api/bus/ws and then:

    <- {"type":"hello", "seq":n}                     server greets
    -> {"type":"heartbeat"}                          client keeps presence alive
    <- {"type":"task", "task_id":..., "payload":...} server routes work
    -> {"type":"result", "task_id":..., "ok":bool, "result":..., "verified":bool}

Everything is authenticated, ordered (monotonic seq per connection), idempotent
(request_id) and duplicate-protected (a task result is only accepted once).
Nothing is ever reported as done unless the target device actually answered.
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Any, Dict, Optional

from . import audit, config, db


class Connection:
    """One authenticated device socket.

    `dialect` starts as "legacy" (the 1.0.0 short frames) and is promoted to
    "v1" the first time the client sends a frame carrying protocol_version or
    message_type. That way a JARVIS 1.0.0 client and a new Android client can be
    connected to the same server at the same time, each spoken to correctly.
    """

    def __init__(self, device_id: str, user_id: str, ws: Any, role: str = "",
                 capabilities: list | None = None):
        self.device_id = device_id
        self.user_id = user_id
        self.ws = ws
        self.role = role
        self.capabilities = capabilities or []
        self.seq = 0
        self.connected_at = time.time()
        self.last_seen = time.time()
        self.dialect = "legacy"
        self.client_protocol_version = 0

    def note_dialect(self, frame: dict) -> None:
        """Promote to v1 only on an explicitly v1 frame.

        parse_frame normalises protocol_version even for legacy frames, so the
        ONLY reliable signal is the _legacy flag it sets.
        """
        if frame.get("_legacy") is False:
            self.dialect = "v1"
            self.client_protocol_version = int(frame.get("protocol_version") or 1)

    async def send(self, message: dict) -> None:
        """Send a v1 envelope, downgrading it for a 1.0.0 client."""
        from . import protocol
        self.seq += 1
        if self.dialect == "legacy" and message.get("message_type"):
            wire = protocol.downgrade(message)
            wire["seq"] = self.seq
            wire["ts"] = time.time()
        else:
            wire = {**message, "seq": self.seq, "ts": time.time()}
        await self.ws.send_text(json.dumps(wire, default=str))


class DeviceBus:
    def __init__(self) -> None:
        self._conns: Dict[str, Connection] = {}
        self._waiters: Dict[str, asyncio.Future] = {}
        self._seen_results: set[str] = set()
        self._lock = asyncio.Lock()

    # ---------------- presence ----------------
    async def register(self, conn: Connection) -> None:
        async with self._lock:
            old = self._conns.get(conn.device_id)
            self._conns[conn.device_id] = conn
        if old is not None:
            try:
                await old.ws.close()
            except Exception:
                pass
        self.touch(conn.device_id)
        db.log_activity("device", f"Device connected: {self.device_name(conn.device_id)}")
        audit.record("device.connect", "OK", user_id=conn.user_id, source_device=conn.device_id)

    async def unregister(self, device_id: str) -> None:
        async with self._lock:
            self._conns.pop(device_id, None)
        db.log_activity("device", f"Device disconnected: {self.device_name(device_id)}")
        audit.record("device.disconnect", "OK", source_device=device_id)

    def touch(self, device_id: str) -> None:
        db.execute("UPDATE devices SET last_seen=? WHERE device_id=?", (time.time(), device_id))
        conn = self._conns.get(device_id)
        if conn:
            conn.last_seen = time.time()

    def is_online(self, device_id: str) -> bool:
        """Honest presence: a live socket OR a heartbeat inside the grace window."""
        conn = self._conns.get(device_id)
        if conn is not None and (time.time() - conn.last_seen) < config.DEVICE_OFFLINE_AFTER:
            return True
        row = db.one("SELECT last_seen, state FROM devices WHERE device_id=?", (device_id,))
        if not row or row["state"] != "ACTIVE" or not row["last_seen"]:
            return False
        return (time.time() - row["last_seen"]) < config.DEVICE_OFFLINE_AFTER

    def online_ids(self) -> list[str]:
        return [d for d in self._conns if self.is_online(d)]

    @staticmethod
    def device_name(device_id: str) -> str:
        row = db.one("SELECT name FROM devices WHERE device_id=?", (device_id,))
        return row["name"] if row else device_id

    async def disconnect(self, device_id: str, reason: str = "revoked") -> None:
        conn = self._conns.get(device_id)
        if conn:
            try:
                from . import protocol
                await conn.send(protocol.envelope(
                    protocol.MessageType.DISCONNECT, target_device_id=device_id,
                    payload={"reason": reason}))
                await conn.ws.close()
            except Exception:
                pass
            await self.unregister(device_id)

    # ---------------- task routing ----------------
    async def dispatch(self, task_id: str, target_device_id: str, payload: dict,
                       timeout: float = 60.0) -> dict:
        """Send a task to a target device and wait for its verified result.

        Returns a dict with ok/result/error. If the device is not online this
        reports offline - it never pretends the work happened.
        """
        if not self.is_online(target_device_id):
            return {"ok": False, "offline": True,
                    "error": f"{self.device_name(target_device_id)} is offline."}
        conn = self._conns.get(target_device_id)
        if conn is None:
            return {"ok": False, "offline": True,
                    "error": f"{self.device_name(target_device_id)} has no active control channel."}

        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()
        self._waiters[task_id] = fut
        try:
            from . import protocol
            await conn.send(protocol.envelope(
                protocol.MessageType.TASK_ASSIGN, task_id=task_id,
                user_id=conn.user_id, target_device_id=target_device_id,
                payload=payload, status=protocol.Status.ASSIGNED))
        except Exception as exc:
            self._waiters.pop(task_id, None)
            return {"ok": False, "error": f"Could not reach the target device: {exc}"}

        try:
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            return {"ok": False, "timeout": True,
                    "error": f"{self.device_name(target_device_id)} did not answer in {int(timeout)}s."}
        finally:
            self._waiters.pop(task_id, None)

    def deliver_result(self, task_id: str, message: dict) -> bool:
        """Duplicate-protected result delivery. Returns False for a replay.

        A result is accepted the FIRST time it is seen even when nobody is
        awaiting it. That case is normal on a mobile network: the phone finishes
        the task, loses connectivity before it can answer, reconnects and
        reports afterwards - by then the original dispatch has already timed
        out and its waiter is gone. Dropping that result would lose real work.
        Every later copy of the same task_id is rejected as a duplicate.
        """
        if not task_id or task_id in self._seen_results:
            return False
        fut = self._waiters.get(task_id)
        self._seen_results.add(task_id)
        if len(self._seen_results) > 5000:
            self._seen_results = set(list(self._seen_results)[-2000:])
        if fut and not fut.done():
            fut.set_result({
                "ok": bool(message.get("ok")),
                "result": message.get("result"),
                "error": message.get("error"),
                "verified": bool(message.get("verified")),
            })
        return True


bus = DeviceBus()


# --------------------------------------------------------------------------- #
# task records
# --------------------------------------------------------------------------- #
def create_task(user_id: str, kind: str, payload: dict, *, source_device_id: str | None = None,
                target_device_id: str | None = None, request_id: str | None = None,
                status: str = "QUEUED") -> dict:
    """Create a task. request_id makes creation idempotent (spec 6)."""
    if request_id:
        existing = db.one("SELECT * FROM tasks WHERE request_id=?", (request_id,))
        if existing:
            return dict(existing)
    now = time.time()
    task_id = f"tsk_{uuid.uuid4().hex[:16]}"
    db.execute(
        "INSERT INTO tasks(task_id,user_id,source_device_id,target_device_id,kind,payload,status,"
        "steps,result,error,verification,request_id,created_at,updated_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (task_id, user_id, source_device_id, target_device_id, kind, json.dumps(payload), status,
         "[]", None, None, "NOT_VERIFIED", request_id, now, now),
    )
    audit.record("task.create", "OK", user_id=user_id, source_device=source_device_id,
                 target_device=target_device_id, task_id=task_id, detail={"kind": kind})
    return dict(db.one("SELECT * FROM tasks WHERE task_id=?", (task_id,)))


def update_task(task_id: str, **fields) -> Optional[dict]:
    allowed = {"status", "result", "error", "verification", "steps", "target_device_id"}
    sets, args = [], []
    for key, value in fields.items():
        if key not in allowed:
            continue
        if key in ("steps", "result") and not isinstance(value, (str, type(None))):
            value = json.dumps(value)
        sets.append(f"{key}=?")
        args.append(value)
    if not sets:
        return get_task(task_id)
    sets.append("updated_at=?")
    args.append(time.time())
    args.append(task_id)
    db.execute(f"UPDATE tasks SET {', '.join(sets)} WHERE task_id=?", args)
    return get_task(task_id)


def append_step(task_id: str, step: dict) -> None:
    row = db.one("SELECT steps FROM tasks WHERE task_id=?", (task_id,))
    steps = json.loads(row["steps"]) if row and row["steps"] else []
    steps.append({**step, "ts": time.time()})
    db.execute("UPDATE tasks SET steps=?, updated_at=? WHERE task_id=?",
               (json.dumps(steps[-50:]), time.time(), task_id))


def get_task(task_id: str) -> Optional[dict]:
    row = db.one("SELECT * FROM tasks WHERE task_id=?", (task_id,))
    return dict(row) if row else None


def list_tasks(user_id: str, limit: int = 100) -> list[dict]:
    rows = db.query("SELECT * FROM tasks WHERE user_id=? ORDER BY created_at DESC LIMIT ?",
                    (user_id, limit))
    return [dict(r) for r in rows]
