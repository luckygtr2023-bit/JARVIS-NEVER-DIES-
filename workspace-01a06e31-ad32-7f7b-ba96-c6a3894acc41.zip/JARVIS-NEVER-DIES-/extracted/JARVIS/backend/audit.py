"""Append-only audit log. Never records secrets (spec 25)."""
from __future__ import annotations

import json
import re
import time
from typing import Any

from . import db

_SECRET_KEYS = re.compile(
    r"(pass|passwd|password|secret|token|api[_-]?key|authorization|cookie|private[_-]?key|refresh)",
    re.I,
)
_SECRET_VALUE = re.compile(r"(jtk_[A-Za-z0-9_-]+|jsess_[A-Za-z0-9_-]+|sk-[A-Za-z0-9]{8,}|Bearer\s+\S+)")


def scrub(value: Any) -> Any:
    """Recursively remove anything that looks like a credential."""
    if isinstance(value, dict):
        return {
            k: ("[REDACTED]" if _SECRET_KEYS.search(str(k)) else scrub(v)) for k, v in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [scrub(v) for v in value]
    if isinstance(value, str):
        return _SECRET_VALUE.sub("[REDACTED]", value)
    return value


def record(
    action: str,
    result: str,
    *,
    user_id: str | None = None,
    source_device: str | None = None,
    target_device: str | None = None,
    verification: str | None = None,
    task_id: str | None = None,
    detail: Any = None,
) -> None:
    payload = None
    if detail is not None:
        try:
            payload = json.dumps(scrub(detail))[:4000]
        except Exception:
            payload = str(detail)[:4000]
    db.execute(
        "INSERT INTO audit(ts,user_id,source_device,target_device,action,result,verification,task_id,detail)"
        " VALUES (?,?,?,?,?,?,?,?,?)",
        (time.time(), user_id, source_device, target_device, action, result, verification, task_id, payload),
    )


def recent(limit: int = 200) -> list[dict]:
    rows = db.query("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))
    return [dict(r) for r in rows]
