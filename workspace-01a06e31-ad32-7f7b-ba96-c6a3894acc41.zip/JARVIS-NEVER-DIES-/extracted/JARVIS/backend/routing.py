"""Intelligent AI workload routing (spec: PART 1).

Priorities (default LOCAL_FIRST):
    1. DETERMINISTIC  - local, no AI (open chrome, take a screenshot, what time ...)
    2. MEMORY         - local retrieval, no cloud (already in memory_store)
    3. WORKFLOW       - cached safe workflow, no AI
    4. LOCAL          - Ollama
    5. CLOUD          - OmniRoute, ONLY when a local method can't reliably finish
    6. EXPLICIT FAILURE

This module decides which AI provider (if any) should handle the *language*
portion of a command. The deterministic / memory / workflow gates live in the
agent loop; routing.py only answers "ollama vs omniroute vs none" and records
the reason so OWNER diagnostics can show it.

Modes:
    auto         - simple -> local, complex -> cloud-if-available (frugal default)
    local_first  - always prefer Ollama; cloud only when Ollama is unavailable
    cloud_first  - prefer OmniRoute; fall back to Ollama
    local_only   - Ollama only; never cloud
    cloud_only   - OmniRoute only; never local
    hybrid       - multi-stage: local first, escalate to cloud on complex/needed

The engine is pure (no network, no DB) so every branch is unit-testable.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict
from typing import Optional

MODES = ("auto", "local_first", "cloud_first", "local_only", "cloud_only", "hybrid")

ROUTE_DETERMINISTIC = "DETERMINISTIC"
ROUTE_MEMORY = "MEMORY"
ROUTE_WORKFLOW = "WORKFLOW"
ROUTE_LOCAL = "LOCAL"          # Ollama
ROUTE_CLOUD = "CLOUD"          # OmniRoute
ROUTE_NONE = "NO_AI"           # nothing local AND nothing cloud (or explicit)
ROUTE_NO_AI = "NO_AI"

PROVIDER_LOCAL = "ollama"
PROVIDER_CLOUD = "omniroute"

# Difficulty classes (heuristic, conservative: we'd rather ask more than spill).
SIMPLE = "SIMPLE"
MODERATE = "MODERATE"
COMPLEX = "COMPLEX"


# --------------------------------------------------------------------------- #
# complexity heuristic
# --------------------------------------------------------------------------- #
_COMPLEX_SIGNALS = re.compile(
    r"\b(explain(?: in detail| deeply)?|compare|contrast|analy[sz]e|synthesi[sz]e|"
    r"refactor|debug|diagram|algorithm|architecture|design(?: a| the)?|write (?:a |the )?"
    r"(?:program|code|app|function|class)|implement|optim[iz]e|optimise|complex|"
    r"difficult|hard problem|derive|prove|reason(?: ing)?|summarize the .*pdf|"
    r"summarise the .*pdf|newest three|troubleshoot|diagnose|overview|review(?: this)?|"
    r"essay|report|csv|dataset|database schema|largest|deep research)\b", re.I)

_MODE_SIGNAL = re.compile(r"\b(?:use|with|switch to|set|using)\s+([\w.\-]{3,})\b", re.I)


def classify(text: str) -> str:
    t = (text or "").strip()
    words = len(t.split())
    if _COMPLEX_SIGNALS.search(t) or words >= 18:
        return COMPLEX
    if _MODE_SIGNAL.search(t) and words >= 3:
        return MODERATE
    if words >= 9:
        return MODERATE
    return SIMPLE


def explicit_combo(text: str) -> Optional[str]:
    """If the user says 'use JARVIS-copy-13', return that EXACT identifier.

    Returns None when no explicit Combo is requested. The identifier is returned
    byte-for-byte - never lowercased, never prefixed, never co-opted into
    existence-only if it already exists (matching must stay exact per spec).
    """
    t = (text or "").strip()
    low = t.lower()
    # 'use X' / 'with X' / 'switch to X' / 'using X'
    m = re.search(r"(?:\buse\b|\bwith\b|\bswitch to\b|\busing\b|^use)\s+"
                  r"([A-Za-z0-9][\w.\-]{2,50})", low)
    if not m:
        return None
    candidate = m.group(1)
    # Guard against grabbing a generic word ("use google" -> google is a site).
    if candidate.lower() in _COMMON_WORDS:
        return None
    # Recover original casing from the source text (match case-insensitively).
    for token in re.findall(r"[A-Za-z0-9][\w.\-]{2,50}", t):
        if token.lower() == candidate.lower():
            return token
    return candidate


_COMMON_WORDS = {
    "google", "chrome", "youtube", "the", "my", "a", "an", "me", "it", "that",
    "browser", "app", "tool", "local", "cloud", "auto", "voice", "this",
}


def _route_reason(mode: str, complexity: str, local_ok: bool, cloud_ok: bool,
                  has_combo: bool, forced_combo: bool) -> tuple[str, str]:
    """Return (provider, reason) for the given mode and availability.

    provider is 'ollama' | 'omniroute' | '' (none available).
    """
    # forced explicit Combo always means cloud (a Combo IS an OmniRoute id).
    if forced_combo:
        return (PROVIDER_CLOUD, "explicit Combo requested")

    if mode == "local_only":
        if local_ok:
            return (PROVIDER_LOCAL, "local_only: Ollama required")
        return ("", "local_only: Ollama is unavailable")

    if mode == "cloud_only":
        if cloud_ok:
            return (PROVIDER_CLOUD, "cloud_only: OmniRoute required")
        return ("", "cloud_only: OmniRoute is unavailable")

    if mode == "cloud_first":
        if cloud_ok:
            return (PROVIDER_CLOUD, "cloud_first: OmniRoute preferred")
        if local_ok:
            return (PROVIDER_LOCAL, "cloud_first: OmniRoute down, Ollama fallback")
        return ("", "cloud_first: no AI backend reachable")

    if mode == "local_first":
        if local_ok:
            return (PROVIDER_LOCAL, "local_first: Ollama preferred")
        if cloud_ok:
            return (PROVIDER_CLOUD, "local_first: Ollama down, OmniRoute fallback")
        return ("", "local_first: no AI backend reachable")

    # auto / hybrid - frugal: local for everything unless it genuinely needs cloud
    if mode == "auto":
        if complexity == COMPLEX:
            if cloud_ok and has_combo:
                return (PROVIDER_CLOUD, "auto: complex reasoning -> OmniRoute")
            if local_ok:
                return (PROVIDER_LOCAL, "auto: complex but OmniRoute unavailable -> Ollama")
            return ("", "auto: no AI backend reachable")
        # SIMPLE / MODERATE
        if local_ok:
            return (PROVIDER_LOCAL, "auto: simple task -> Ollama (quota-sparing)")
        if cloud_ok:
            return (PROVIDER_CLOUD, "auto: Ollama down -> OmniRoute")
        return ("", "auto: no AI backend reachable")

    # hybrid: multi-stage - local first, escalate to cloud for complex/moderate
    if local_ok:
        return (PROVIDER_LOCAL, "hybrid: local stage first")
    if complexity in (COMPLEX, MODERATE) and cloud_ok and has_combo:
        return (PROVIDER_CLOUD, "hybrid: escalate to OmniRoute")
    if cloud_ok:
        return (PROVIDER_CLOUD, "hybrid: OmniRoute fallback")
    return ("", "hybrid: no AI backend reachable")


@dataclass
class SplitDecision:
    """The transport decision (leave split = keep them separate for storage)."""
    mode: str
    complexity: str
    forced_combo: bool
    provider: str                 # ollama | omniroute | "" (none)
    model: str = ""
    combo: str = ""
    local_available: bool = False
    cloud_available: bool = False
    cloud_used: bool = False
    fallback: bool = False
    reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def decide(text: str, *, mode: str, availability: dict,
           combo: str = "", forced_combo: Optional[str] = None) -> SplitDecision:
    """Pure decision function. Fully unit-testable without a network.

    availability: {"ollama": bool, "omniroute": bool}
    """
    if mode not in MODES:
        mode = "local_first"
    complexity = classify(text)
    fc = forced_combo or explicit_combo(text)

    local_ok = bool(availability.get("ollama"))
    cloud_ok = bool(availability.get("omniroute"))

    # A Combo that is requested explicitly but does not exist / is disabled is
    # caught by combos.may_use in the caller; here we only decide transport.
    provider, reason = _route_reason(mode, complexity, local_ok, cloud_ok,
                                     bool(combo), bool(fc))
    cloud_used = provider == PROVIDER_CLOUD
    # "fallback" flag: the chosen provider differs from what the mode prefers.
    preferred = _preferred(mode, complexity)
    fallback = bool(preferred and provider and preferred != provider)

    return SplitDecision(
        mode=mode, complexity=complexity, forced_combo=bool(fc),
        provider=provider, model="",
        combo=combo or (fc or ""), local_available=local_ok,
        cloud_available=cloud_ok, cloud_used=cloud_used, fallback=fallback,
        reason=reason,
    )


def _preferred(mode: str, complexity: str) -> str:
    """The provider the mode IDEALLY wants (ignoring availability). Used for the
    honest 'fallback' flag in diagnostics."""
    if mode == "local_only":
        return PROVIDER_LOCAL
    if mode == "cloud_only":
        return PROVIDER_CLOUD
    if mode == "cloud_first":
        return PROVIDER_CLOUD
    if mode == "local_first":
        return PROVIDER_LOCAL
    if mode == "auto":
        return PROVIDER_CLOUD if complexity == COMPLEX else PROVIDER_LOCAL
    # hybrid
    return PROVIDER_LOCAL


def default_mode() -> str:
    """Recommended default. Kept here so it can change in one place."""
    return "local_first"


def normalize_mode(value) -> str:
    v = str(value or "").lower().strip()
    return v if v in MODES else default_mode()
