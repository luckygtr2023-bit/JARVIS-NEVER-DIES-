"""Persistent memory with credential guards (spec 21).

JARVIS will refuse to store anything that looks like a password, API key, token,
OAuth secret, cookie or private key - in the key OR the value.
"""
from __future__ import annotations

import re
import time
import uuid

from . import audit, db

CATEGORIES = ("fact", "preference", "device", "destination", "context")

_KEY_GUARD = re.compile(
    r"(pass(word|wd)?|secret|api[_\s-]?key|token|oauth|credential|private[_\s-]?key|"
    r"cookie|session[_\s-]?id|cvv|pin\b|seed[_\s-]?phrase)", re.I)

_VALUE_GUARD = re.compile(
    r"("
    r"sk-[A-Za-z0-9]{16,}"                       # OpenAI-style
    r"|gsk_[A-Za-z0-9]{16,}"                     # Groq
    r"|AIza[0-9A-Za-z_\-]{30,}"                  # Google
    r"|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}"
    r"|jtk_[A-Za-z0-9_\-]{20,}|jsess_[A-Za-z0-9_\-]{20,}"
    r"|xox[baprs]-[A-Za-z0-9-]{10,}"             # Slack
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----"
    r"|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\."  # JWT
    r")")


class MemoryGuardError(ValueError):
    pass


def guard(key: str, value: str) -> None:
    if _KEY_GUARD.search(key or ""):
        raise MemoryGuardError(
            "Refused: that looks like a credential. JARVIS never stores passwords, "
            "API keys, tokens or secrets in memory.")
    if _VALUE_GUARD.search(value or ""):
        raise MemoryGuardError(
            "Refused: the value looks like an API key or token. JARVIS never stores secrets.")
    if _KEY_GUARD.search(value or "") and re.search(r"[:=]\s*\S{8,}", value or ""):
        raise MemoryGuardError("Refused: that value appears to contain a credential.")


def store_memory(user_id: str, key: str, value: str, category: str = "fact") -> dict:
    key = (key or "").strip()
    value = (value or "").strip()
    if not key or not value:
        raise ValueError("Both a key and a value are required.")
    if category not in CATEGORIES:
        category = "fact"
    guard(key, value)
    now = time.time()
    existing = db.one("SELECT id FROM memories WHERE user_id=? AND key=?", (user_id, key))
    if existing:
        db.execute("UPDATE memories SET value=?, category=?, updated_at=? WHERE id=?",
                   (value, category, now, existing["id"]))
        mem_id = existing["id"]
    else:
        mem_id = f"mem_{uuid.uuid4().hex[:12]}"
        db.execute("INSERT INTO memories(id,user_id,key,value,category,created_at,updated_at)"
                   " VALUES (?,?,?,?,?,?,?)", (mem_id, user_id, key, value, category, now, now))
    audit.record("memory.store", "OK", user_id=user_id, detail={"key": key, "category": category})
    db.log_activity("memory", f"Remembered: {key}")
    return {"id": mem_id, "key": key, "value": value, "category": category, "updated_at": now}


def list_memories(user_id: str) -> list[dict]:
    rows = db.query("SELECT * FROM memories WHERE user_id=? ORDER BY updated_at DESC", (user_id,))
    return [dict(r) for r in rows]


def delete_memory(user_id: str, mem_id: str) -> bool:
    cur = db.execute("DELETE FROM memories WHERE user_id=? AND id=?", (user_id, mem_id))
    audit.record("memory.delete", "OK", user_id=user_id, detail={"id": mem_id})
    return cur.rowcount > 0


def clear_memories(user_id: str) -> int:
    cur = db.execute("DELETE FROM memories WHERE user_id=?", (user_id,))
    audit.record("memory.clear", "OK", user_id=user_id, detail={"removed": cur.rowcount})
    return cur.rowcount


def update_memory(user_id: str, mem_id: str, value: str | None = None,
                  category: str | None = None) -> dict | None:
    """Edit an existing memory (value and/or category). Guarded like creation."""
    row = db.one("SELECT * FROM memories WHERE user_id=? AND id=?", (user_id, mem_id))
    if not row:
        return None
    new_value = (value if value is not None else row["value"]).strip()
    new_cat = (category if category is not None else row["category"]).strip()
    if not new_value:
        raise ValueError("A memory value is required.")
    if new_cat not in CATEGORIES:
        new_cat = "fact"
    guard(row["key"], new_value)
    db.execute("UPDATE memories SET value=?, category=?, updated_at=? WHERE id=?",
               (new_value, new_cat, time.time(), mem_id))
    audit.record("memory.edit", "OK", user_id=user_id, detail={"id": mem_id})
    db.log_activity("memory", f"Edited: {row['key']}")
    out = dict(row)
    out.update({"value": new_value, "category": new_cat, "updated_at": time.time()})
    return out


def memory_enabled() -> bool:
    """Master switch for LONG-TERM memory retrieval (separate from the
    short-term conversation window)."""
    return bool(db.get_setting("memory_enabled", True))


def set_memory_enabled(value: bool) -> None:
    db.set_setting("memory_enabled", bool(value))


def export_memories(user_id: str) -> dict:
    """Export a user's memories as a portable JSON document (no secrets)."""
    items = list_memories(user_id)
    return {"version": 1, "exported_at": time.time(), "user": user_id,
            "memories": [{"key": m["key"], "value": m["value"], "category": m["category"]}
                         for m in items]}


def import_memories(user_id: str, records: list) -> dict:
    """Safely import memories from an exported document. Each record is re-guarded
    (a credential sneaking into the file is refused) and imports are scoped to the
    calling user. Returns a summary of imported/skipped."""
    imported, skipped = 0, 0
    seen = 0
    for rec in records or []:
        seen += 1
        if not isinstance(rec, dict):
            skipped += 1
            continue
        key = str(rec.get("key", "")).strip()
        value = str(rec.get("value", "")).strip()
        if not key or not value:
            skipped += 1
            continue
        try:
            store_memory(user_id, key, value, str(rec.get("category", "fact")))
            imported += 1
        except ValueError:
            skipped += 1
    audit.record("memory.import", "OK", user_id=user_id,
                 detail={"imported": imported, "skipped": skipped})
    return {"imported": imported, "skipped": skipped, "seen": seen}


def search_memories(user_id: str, query: str, limit: int = 50) -> list[dict]:
    """Keyword relevance filter over the user's own memories (local, no cloud)."""
    q = (query or "").strip().lower()
    if not q:
        return list_memories(user_id)[:limit]
    rows = list_memories(user_id)
    scored = []
    tokens = q.split()
    for m in rows:
        hay = f"{m['key']} {m['value']}".lower()
        score = sum(1 for tok in tokens if tok in hay)
        if score:
            scored.append((score, m))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [m for _, m in scored[:limit]]


# --------------------------------------------------------------------------- #
# SHORT-TERM CONVERSATION MEMORY (bounded context)
# --------------------------------------------------------------------------- #
MAX_TURNS = 12            # newest turns kept verbatim
MAX_CHARS = 6000          # hard char budget for the live window
SUMMARY_TRIGGER = 8       # summarise once the window exceeds this many turns


def conversation_enabled() -> bool:
    return bool(db.get_setting("conversation_memory", True))


def set_conversation_enabled(value: bool) -> None:
    db.set_setting("conversation_memory", bool(value))


def append_turn(user_id: str, session_id: str, role: str, content: str) -> int:
    """Append one conversation row. Returns the new row id (or -1 if skipped).

    Credential-like turns (passwords / API keys / tokens) are NEVER persisted,
    even in conversation memory, in line with the memory security rules.
    """
    if not conversation_enabled():
        return -1
    if _is_credential_like(content):
        return -1
    cur = db.execute(
        "INSERT INTO conversation(user_id,session_id,role,content,is_summary,created_at)"
        " VALUES (?,?,?,?,0,?)",
        (user_id, session_id or "default", role, content[:4000], time.time()))
    return cur.lastrowid if cur and cur.lastrowid else -1


def _rows(user_id: str, session_id: str) -> list:
    return db.query(
        "SELECT * FROM conversation WHERE user_id=? AND session_id=? ORDER BY id ASC",
        (user_id, session_id or "default"))


def _is_credential_like(content: str) -> bool:
    return bool(_VALUE_GUARD.search(content or ""))


def get_context(user_id: str, session_id: str) -> list[dict]:
    """Bounded, pruned conversation context as OpenAI-style messages.

    Older turns that exceed the budget are collapsed into a local summary message
    (created by `summarize_context`), and only the newest N turns are kept verbatim.
    So JARVIS never ships the WHOLE conversation to cloud AI.
    """
    if not conversation_enabled():
        return []
    rows = _rows(user_id, session_id)
    if not rows:
        return []

    summaries = [r for r in rows if r["is_summary"]]
    messages: list[dict] = []
    if summaries:
        text = " ".join(r["content"] for r in summaries[:2])
        if text:
            messages.append({"role": "system", "content": f"Earlier summary: {text[:1500]}"})

    live = [r for r in rows if not r["is_summary"]][-MAX_TURNS:]
    chars = sum(len(r["content"]) for r in live)
    while len(live) > 1 and chars > MAX_CHARS:
        chars -= len(live[0]["content"])
        live = live[1:]

    for r in live:
        messages.append({"role": r["role"], "content": r["content"]})
    return messages


def summarize_context(user_id: str, session_id: str) -> str | None:
    """Summarise the older portion of the conversation locally (via summary text
    is kept separate from the live window). Returns the summary text or None."""
    if not conversation_enabled():
        return None
    rows = [r for r in _rows(user_id, session_id) if not r["is_summary"]]
    if len(rows) <= SUMMARY_TRIGGER:
        return None
    older = rows[:-4]
    text = "\n".join(f"{r['role']}: {r['content'][:400]}" for r in older)
    # Local, compact summary (no cloud). If Ollama is available the caller may
    # ask it to enrich this; the fallback is a deterministic digest.
    digest = _digest(text)
    now = time.time()
    sid = session_id or "default"
    for r in older:
        db.execute("UPDATE conversation SET is_summary=0 WHERE id=?", (r["id"],))
    db.execute(
        "INSERT INTO conversation(user_id,session_id,role,content,is_summary,created_at)"
        " VALUES (?,?,?,?,1,?)", (user_id, sid, "assistant", digest, now))
    db.execute("DELETE FROM conversation WHERE user_id=? AND session_id=? AND is_summary=1 "
               "AND id NOT IN (SELECT id FROM conversation WHERE user_id=? AND session_id=? "
               "AND is_summary=1 ORDER BY id DESC LIMIT 1)",
               (user_id, sid, user_id, sid))
    return digest


def _digest(text: str) -> str:
    """Deterministic local digest (no cloud). Compresses the oldest turns."""
    lines = [ln for ln in text.splitlines() if ln.strip()][:60]
    compact = " ; ".join(l.strip() for l in lines)
    if len(compact) > 1200:
        compact = compact[:1200] + "..."
    return f"[Local summary of earlier turns] {compact}"


def clear_conversation(user_id: str, session_id: str | None = None) -> int:
    if session_id:
        cur = db.execute("DELETE FROM conversation WHERE user_id=? AND session_id=?",
                         (user_id, session_id))
    else:
        cur = db.execute("DELETE FROM conversation WHERE user_id=?", (user_id,))
    return cur.rowcount
