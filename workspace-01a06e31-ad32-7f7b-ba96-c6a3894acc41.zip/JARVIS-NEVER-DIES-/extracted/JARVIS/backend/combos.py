"""OWNER/OPERATOR Combo management (spec 5-10).

A "Combo" is an OmniRoute routing identifier plus the metadata the OWNER needs to
manage it from the HUD. Combos live in the database, never in source code, so the
OWNER can add JARVIS-copy-13, -14, -99 or any future identifier without anyone
editing Python/React, touching .env, or rebuilding the EXE.

Hard rules enforced here:
  * the OmniRoute identifier is stored and sent back EXACTLY as typed -
    no case folding, no provider prefix, no rewriting, no whitelist
  * there is NO cap on how many Combos may exist
  * who may use which Combo is decided server side; the frontend cannot widen it
  * only the OWNER may create/edit/delete/enable/assign; the AI never can
"""
from __future__ import annotations

import time
import uuid
from typing import Iterable, Optional

from . import audit, db, security

# The Combos the project shipped with. They are SEEDED once, never enforced as a
# limit, and never deleted by the migration.
LEGACY_COMBOS = [f"JARVIS-copy-{n}" for n in range(2, 13)]  # -2 .. -12

SUBJECT_USER = "user"
SUBJECT_ROLE = "role"
SUBJECT_TYPES = (SUBJECT_USER, SUBJECT_ROLE)


class ComboError(ValueError):
    """A user-presentable Combo problem."""


class ComboPermissionError(PermissionError):
    """The caller may not use or manage this Combo."""


# --------------------------------------------------------------------------- #
# migration / seeding
# --------------------------------------------------------------------------- #
def ensure_seeded() -> int:
    """Import the pre-existing Combos once. Idempotent; never destructive."""
    if db.get_setting("combos_seeded"):
        return 0
    created = 0
    now = time.time()
    for index, identifier in enumerate(LEGACY_COMBOS):
        if db.one("SELECT 1 FROM combos WHERE omniroute_identifier=?", (identifier,)):
            continue
        db.execute(
            "INSERT INTO combos(combo_id,display_name,omniroute_identifier,description,"
            "enabled,is_default,created_by,created_at,updated_at)"
            " VALUES (?,?,?,?,?,?,?,?,?)",
            (f"cmb_{uuid.uuid4().hex[:12]}", identifier, identifier,
             "Imported from the original JARVIS configuration.", 1,
             1 if index == 0 else 0, "system", now, now),
        )
        created += 1

    # Preserve whatever Combo was already selected in the AI settings.
    existing = (db.get_setting("ai", {}) or {}).get("combo", "")
    if existing and not db.one("SELECT 1 FROM combos WHERE omniroute_identifier=?", (existing,)):
        db.execute(
            "INSERT INTO combos(combo_id,display_name,omniroute_identifier,description,"
            "enabled,is_default,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (f"cmb_{uuid.uuid4().hex[:12]}", existing, existing,
             "Imported from the previously saved AI settings.", 1, 0, "system", now, now),
        )
        created += 1

    db.set_setting("combos_seeded", True)
    if created:
        db.log_activity("combo", f"Imported {created} existing Combo(s) into Combo Management")
    return created


# --------------------------------------------------------------------------- #
# reads
# --------------------------------------------------------------------------- #
def _assignments(combo_id: str) -> list[dict]:
    rows = db.query(
        "SELECT subject_type, subject_id, granted_by, created_at FROM combo_assignments"
        " WHERE combo_id=? ORDER BY subject_type, subject_id", (combo_id,))
    out = []
    for r in rows:
        item = dict(r)
        if item["subject_type"] == SUBJECT_USER:
            u = db.one("SELECT username FROM users WHERE user_id=?", (item["subject_id"],))
            item["label"] = u["username"] if u else item["subject_id"]
        else:
            item["label"] = item["subject_id"]
        out.append(item)
    return out


def to_public(row) -> dict:
    d = dict(row)
    d["enabled"] = bool(d["enabled"])
    d["is_default"] = bool(d["is_default"])
    d["assignments"] = _assignments(d["combo_id"])
    return d


def get_combo(combo_id: str) -> Optional[dict]:
    row = db.one("SELECT * FROM combos WHERE combo_id=?", (combo_id,))
    return to_public(row) if row else None


def get_by_identifier(identifier: str) -> Optional[dict]:
    row = db.one("SELECT * FROM combos WHERE omniroute_identifier=?", (identifier,))
    return to_public(row) if row else None


def list_all() -> list[dict]:
    ensure_seeded()
    rows = db.query("SELECT * FROM combos ORDER BY is_default DESC, created_at")
    return [to_public(r) for r in rows]


def list_permitted(user_id: str, role: str) -> list[dict]:
    """Combos this principal may actually use, decided server side."""
    ensure_seeded()
    if role == security.ROLE_OWNER:
        return [c for c in list_all() if c["enabled"]]
    rows = db.query(
        "SELECT DISTINCT c.* FROM combos c JOIN combo_assignments a ON a.combo_id = c.combo_id"
        " WHERE c.enabled=1 AND ((a.subject_type='user' AND a.subject_id=?)"
        "                     OR (a.subject_type='role' AND a.subject_id=?))"
        " ORDER BY c.is_default DESC, c.created_at",
        (user_id, role))
    return [to_public(r) for r in rows]


def may_use(user_id: str, role: str, identifier: str) -> bool:
    if not identifier:
        return False
    # Disabling a Combo takes it out of service for EVERYONE, the OWNER
    # included - otherwise "disabled" would still be reachable through the API
    # and set_default's refusal to point at a disabled Combo would be
    # inconsistent. An identifier that is not in the registry at all is left
    # alone here (legacy/imported configuration) and judged below.
    row = db.one("SELECT enabled FROM combos WHERE omniroute_identifier=?", (identifier,))
    if row is not None and not row["enabled"]:
        return False
    if role == security.ROLE_OWNER:
        return True                     # the OWNER may use any enabled Combo
    return any(c["omniroute_identifier"] == identifier
               for c in list_permitted(user_id, role))


def assert_may_use(user_id: str, role: str, identifier: str) -> None:
    if not may_use(user_id, role, identifier):
        audit.record("combo.use_denied", "DENIED", user_id=user_id,
                     detail={"identifier": identifier, "role": role})
        raise ComboPermissionError(
            f"You are not authorized to use the Combo '{identifier}'. "
            f"Ask the OWNER to assign it to you in COMBOS.")


def default_identifier() -> str:
    ensure_seeded()
    row = db.one("SELECT omniroute_identifier FROM combos WHERE enabled=1 AND is_default=1")
    if row:
        return row["omniroute_identifier"]
    row = db.one("SELECT omniroute_identifier FROM combos WHERE enabled=1 ORDER BY created_at")
    return row["omniroute_identifier"] if row else ""


def selected_for(user_id: str, role: str) -> str:
    """The Combo this user will actually send to OmniRoute.

    Per-user selection first, then the global default - but a selection the user
    is no longer allowed to use is silently dropped rather than honoured.
    """
    chosen = db.get_setting(f"ai_combo:{user_id}", "") or ""
    if chosen and may_use(user_id, role, chosen):
        return chosen
    if chosen and not may_use(user_id, role, chosen):
        chosen = ""
    if role == security.ROLE_OWNER:
        legacy = (db.get_setting("ai", {}) or {}).get("combo", "")
        if legacy:
            return legacy
        return default_identifier()
    permitted = list_permitted(user_id, role)
    if not permitted:
        return ""
    for c in permitted:
        if c["is_default"]:
            return c["omniroute_identifier"]
    return permitted[0]["omniroute_identifier"]


def select_for(user_id: str, role: str, identifier: str) -> str:
    assert_may_use(user_id, role, identifier)
    db.set_setting(f"ai_combo:{user_id}", identifier)
    audit.record("combo.select", "OK", user_id=user_id, detail={"identifier": identifier})
    return identifier


# --------------------------------------------------------------------------- #
# writes (OWNER only - the router enforces the role, this enforces the data)
# --------------------------------------------------------------------------- #
def _validate(display_name: str, identifier: str) -> tuple[str, str]:
    display_name = (display_name or "").strip()
    # NOTE: only surrounding whitespace is removed. The identifier itself keeps
    # its exact capitalisation and characters - it is sent to OmniRoute verbatim.
    identifier = (identifier or "").strip()
    if not display_name:
        raise ComboError("A display name is required.")
    if len(display_name) > 80:
        raise ComboError("Display name must be 80 characters or fewer.")
    if not identifier:
        raise ComboError("An OmniRoute identifier is required.")
    if len(identifier) > 200:
        raise ComboError("OmniRoute identifier must be 200 characters or fewer.")
    if any(ch in identifier for ch in "\n\r\t"):
        raise ComboError("The OmniRoute identifier cannot contain line breaks or tabs.")
    return display_name, identifier


def create_combo(display_name: str, identifier: str, description: str, actor: dict,
                 enabled: bool = True) -> dict:
    ensure_seeded()
    display_name, identifier = _validate(display_name, identifier)
    if db.one("SELECT 1 FROM combos WHERE omniroute_identifier=?", (identifier,)):
        raise ComboError(f"A Combo with the identifier '{identifier}' already exists.")
    now = time.time()
    combo_id = f"cmb_{uuid.uuid4().hex[:12]}"
    is_default = 0 if db.one("SELECT 1 FROM combos WHERE is_default=1") else 1
    db.execute(
        "INSERT INTO combos(combo_id,display_name,omniroute_identifier,description,enabled,"
        "is_default,created_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
        (combo_id, display_name, identifier, (description or "").strip()[:500],
         1 if enabled else 0, is_default, actor["user_id"], now, now))
    audit.record("combo.create", "OK", user_id=actor["user_id"],
                 detail={"combo_id": combo_id, "identifier": identifier})
    db.log_activity("combo", f"Combo created: {display_name} ({identifier})")
    return get_combo(combo_id)


def update_combo(combo_id: str, actor: dict, *, display_name: str | None = None,
                 identifier: str | None = None, description: str | None = None,
                 enabled: bool | None = None) -> dict:
    current = db.one("SELECT * FROM combos WHERE combo_id=?", (combo_id,))
    if not current:
        raise ComboError("No such Combo.")
    new_name = current["display_name"] if display_name is None else display_name
    new_ident = current["omniroute_identifier"] if identifier is None else identifier
    new_name, new_ident = _validate(new_name, new_ident)
    if new_ident != current["omniroute_identifier"] and \
            db.one("SELECT 1 FROM combos WHERE omniroute_identifier=? AND combo_id<>?",
                   (new_ident, combo_id)):
        raise ComboError(f"Another Combo already uses the identifier '{new_ident}'.")
    db.execute(
        "UPDATE combos SET display_name=?, omniroute_identifier=?, description=?, enabled=?,"
        " updated_at=? WHERE combo_id=?",
        (new_name, new_ident,
         current["description"] if description is None else (description or "").strip()[:500],
         current["enabled"] if enabled is None else (1 if enabled else 0),
         time.time(), combo_id))
    audit.record("combo.update", "OK", user_id=actor["user_id"],
                 detail={"combo_id": combo_id, "identifier": new_ident,
                         "enabled": enabled if enabled is not None else bool(current["enabled"])})
    db.log_activity("combo", f"Combo updated: {new_name}")
    return get_combo(combo_id)


def set_enabled(combo_id: str, enabled: bool, actor: dict) -> dict:
    return update_combo(combo_id, actor, enabled=enabled)


def delete_combo(combo_id: str, actor: dict) -> dict:
    row = db.one("SELECT * FROM combos WHERE combo_id=?", (combo_id,))
    if not row:
        raise ComboError("No such Combo.")
    db.execute("DELETE FROM combo_assignments WHERE combo_id=?", (combo_id,))
    db.execute("DELETE FROM combos WHERE combo_id=?", (combo_id,))
    # never leave the system without a default
    if row["is_default"]:
        nxt = db.one("SELECT combo_id FROM combos WHERE enabled=1 ORDER BY created_at")
        if nxt:
            db.execute("UPDATE combos SET is_default=1 WHERE combo_id=?", (nxt["combo_id"],))
    audit.record("combo.delete", "OK", user_id=actor["user_id"],
                 detail={"combo_id": combo_id, "identifier": row["omniroute_identifier"]})
    db.log_activity("combo", f"Combo deleted: {row['display_name']}")
    return {"deleted": combo_id, "identifier": row["omniroute_identifier"]}


def set_default(combo_id: str, actor: dict) -> dict:
    row = db.one("SELECT * FROM combos WHERE combo_id=?", (combo_id,))
    if not row:
        raise ComboError("No such Combo.")
    if not row["enabled"]:
        raise ComboError("A disabled Combo cannot be the default.")
    db.execute("UPDATE combos SET is_default=0")
    db.execute("UPDATE combos SET is_default=1, updated_at=? WHERE combo_id=?",
               (time.time(), combo_id))
    audit.record("combo.set_default", "OK", user_id=actor["user_id"], detail={"combo_id": combo_id})
    return get_combo(combo_id)


# --------------------------------------------------------------------------- #
# assignments
# --------------------------------------------------------------------------- #
def assign(combo_id: str, subject_type: str, subject_id: str, actor: dict) -> dict:
    if not db.one("SELECT 1 FROM combos WHERE combo_id=?", (combo_id,)):
        raise ComboError("No such Combo.")
    if subject_type not in SUBJECT_TYPES:
        raise ComboError("subject_type must be 'user' or 'role'.")
    subject_id = (subject_id or "").strip()
    if subject_type == SUBJECT_ROLE:
        if subject_id not in security.ROLES:
            raise ComboError(f"Unknown role '{subject_id}'.")
        if subject_id == security.ROLE_OWNER:
            raise ComboError("The OWNER already has access to every enabled Combo.")
    else:
        if not db.one("SELECT 1 FROM users WHERE user_id=?", (subject_id,)):
            raise ComboError("Unknown user.")
    db.execute(
        "INSERT OR IGNORE INTO combo_assignments(combo_id,subject_type,subject_id,granted_by,"
        "created_at) VALUES (?,?,?,?,?)",
        (combo_id, subject_type, subject_id, actor["user_id"], time.time()))
    audit.record("combo.assign", "OK", user_id=actor["user_id"],
                 detail={"combo_id": combo_id, "subject_type": subject_type,
                         "subject_id": subject_id})
    return get_combo(combo_id)


def unassign(combo_id: str, subject_type: str, subject_id: str, actor: dict) -> dict:
    db.execute("DELETE FROM combo_assignments WHERE combo_id=? AND subject_type=? AND subject_id=?",
               (combo_id, subject_type, subject_id))
    audit.record("combo.unassign", "OK", user_id=actor["user_id"],
                 detail={"combo_id": combo_id, "subject_type": subject_type,
                         "subject_id": subject_id})
    return get_combo(combo_id)
