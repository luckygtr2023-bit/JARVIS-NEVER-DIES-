"""JARVIS cross-device protocol, version 1.

This module is the single source of truth for every message that crosses the
device bus. It exists so that an Android client written in another environment
can be implemented against a stable contract without a backend rewrite.

An envelope always carries these fields:

    protocol_version  int    always 1 for this release
    message_type      str    one of MessageType.*
    request_id        str    caller-generated, makes retries idempotent
    task_id           str    set once a task record exists
    user_id           str    owner of both devices
    source_device_id  str    who sent it
    target_device_id  str    who it is for ("" for server-directed frames)
    timestamp         float  unix seconds, server clock on server frames
    payload           dict   message-specific body
    status            str    one of Status.*
    seq               int    monotonic per connection, for ordering

Backwards compatibility: the 1.0.0 device bus spoke a shorter dialect
(`{"type": "heartbeat"}`, `{"type": "result", ...}`). Those frames are still
accepted and are normalised into v1 envelopes by `parse_frame`, so an older
client keeps working while new clients get the full protocol. Nothing in this
module talks to the database or the network - it is pure, and therefore
testable.
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Dict, Optional

PROTOCOL_VERSION = 1
MIN_SUPPORTED_VERSION = 1


class ProtocolError(ValueError):
    """A frame that cannot be understood. Always answered with ERROR_EVENT."""


class MessageType:
    # ---- device lifecycle ----
    DEVICE_REGISTER = "DEVICE_REGISTER"
    DEVICE_AUTH = "DEVICE_AUTH"
    DEVICE_PAIR_REQUEST = "DEVICE_PAIR_REQUEST"
    DEVICE_PAIR_APPROVE = "DEVICE_PAIR_APPROVE"
    DEVICE_REVOKE = "DEVICE_REVOKE"
    DEVICE_HEARTBEAT = "DEVICE_HEARTBEAT"
    DEVICE_STATUS = "DEVICE_STATUS"
    DEVICE_CAPABILITIES = "DEVICE_CAPABILITIES"
    # ---- tasks ----
    TASK_CREATE = "TASK_CREATE"
    TASK_ASSIGN = "TASK_ASSIGN"
    TASK_UPDATE = "TASK_UPDATE"
    TASK_RESULT = "TASK_RESULT"
    TASK_CANCEL = "TASK_CANCEL"
    # ---- natural-language commands ----
    COMMAND_REQUEST = "COMMAND_REQUEST"
    COMMAND_RESULT = "COMMAND_RESULT"
    # ---- confirmation of consequential actions ----
    CONFIRMATION_REQUEST = "CONFIRMATION_REQUEST"
    CONFIRMATION_RESULT = "CONFIRMATION_RESULT"
    # ---- transport ----
    HELLO = "HELLO"
    ACK = "ACK"
    PONG = "PONG"
    DISCONNECT = "DISCONNECT"
    ERROR_EVENT = "ERROR_EVENT"


ALL_MESSAGE_TYPES = tuple(
    v for k, v in vars(MessageType).items() if not k.startswith("_") and isinstance(v, str)
)

#: Frames a client is allowed to originate. Everything else is server-to-device
#: only - a device cannot, for example, fake a DEVICE_PAIR_APPROVE.
CLIENT_ORIGINATED = frozenset({
    MessageType.DEVICE_REGISTER,
    MessageType.DEVICE_HEARTBEAT,
    MessageType.DEVICE_STATUS,
    MessageType.DEVICE_CAPABILITIES,
    MessageType.TASK_RESULT,
    MessageType.TASK_UPDATE,
    MessageType.TASK_CANCEL,
    MessageType.COMMAND_REQUEST,
    MessageType.CONFIRMATION_RESULT,
    MessageType.PONG,
    MessageType.ERROR_EVENT,
})

SERVER_ORIGINATED = frozenset({
    MessageType.HELLO,
    MessageType.ACK,
    MessageType.PONG,
    MessageType.DEVICE_PAIR_APPROVE,
    MessageType.DEVICE_REVOKE,
    MessageType.DEVICE_STATUS,
    MessageType.TASK_ASSIGN,
    MessageType.TASK_UPDATE,
    MessageType.TASK_CANCEL,
    MessageType.COMMAND_RESULT,
    MessageType.CONFIRMATION_REQUEST,
    MessageType.DISCONNECT,
    MessageType.ERROR_EVENT,
})


class Status:
    PENDING = "PENDING"
    QUEUED = "QUEUED"
    ASSIGNED = "ASSIGNED"
    RUNNING = "RUNNING"
    WAITING_CONFIRMATION = "WAITING_CONFIRMATION"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"
    OFFLINE = "OFFLINE"
    TIMEOUT = "TIMEOUT"
    REJECTED = "REJECTED"


class ErrorCode:
    """Stable codes. A client should branch on these, never on prose."""
    UNAUTHENTICATED = "UNAUTHENTICATED"
    FORBIDDEN = "FORBIDDEN"
    DEVICE_REVOKED = "DEVICE_REVOKED"
    UNSUPPORTED_VERSION = "UNSUPPORTED_VERSION"
    MALFORMED = "MALFORMED"
    UNKNOWN_MESSAGE_TYPE = "UNKNOWN_MESSAGE_TYPE"
    NOT_CLIENT_ORIGINATED = "NOT_CLIENT_ORIGINATED"
    TARGET_OFFLINE = "TARGET_OFFLINE"
    TARGET_UNKNOWN = "TARGET_UNKNOWN"
    CAPABILITY_MISSING = "CAPABILITY_MISSING"
    PERMISSION_MISSING = "PERMISSION_MISSING"
    CONFIRMATION_REQUIRED = "CONFIRMATION_REQUIRED"
    DUPLICATE = "DUPLICATE"
    TIMEOUT = "TIMEOUT"
    INTERNAL = "INTERNAL"


#: 1.0.0 dialect -> v1. Kept so already-deployed clients do not break.
LEGACY_TYPE_ALIASES = {
    "hello": MessageType.HELLO,
    "heartbeat": MessageType.DEVICE_HEARTBEAT,
    "ping": MessageType.DEVICE_HEARTBEAT,
    "pong": MessageType.PONG,
    "task": MessageType.TASK_ASSIGN,
    "result": MessageType.TASK_RESULT,
    "ack": MessageType.ACK,
    "command": MessageType.COMMAND_REQUEST,
    "command_result": MessageType.COMMAND_RESULT,
    "cancel": MessageType.TASK_CANCEL,
    "capabilities": MessageType.DEVICE_CAPABILITIES,
    "status": MessageType.DEVICE_STATUS,
    "confirm": MessageType.CONFIRMATION_RESULT,
    "disconnect": MessageType.DISCONNECT,
    "error": MessageType.ERROR_EVENT,
}

#: v1 -> 1.0.0, so we can keep answering old clients in their own dialect.
LEGACY_TYPE_FOR = {
    MessageType.HELLO: "hello",
    MessageType.DEVICE_HEARTBEAT: "heartbeat",
    MessageType.PONG: "pong",
    MessageType.TASK_ASSIGN: "task",
    MessageType.TASK_RESULT: "result",
    MessageType.ACK: "ack",
    MessageType.COMMAND_REQUEST: "command",
    MessageType.COMMAND_RESULT: "command_result",
    MessageType.DISCONNECT: "disconnect",
    MessageType.ERROR_EVENT: "error",
}


def new_request_id() -> str:
    return f"req_{uuid.uuid4().hex[:16]}"


def envelope(message_type: str, *, request_id: str = "", task_id: str = "",
             user_id: str = "", source_device_id: str = "", target_device_id: str = "",
             payload: Optional[Dict[str, Any]] = None, status: str = "",
             timestamp: Optional[float] = None, **extra) -> Dict[str, Any]:
    """Build a well-formed v1 envelope. Unknown kwargs ride along at top level
    so we never have to break the schema to add a field."""
    if message_type not in ALL_MESSAGE_TYPES:
        raise ProtocolError(f"unknown message_type: {message_type}")
    msg = {
        "protocol_version": PROTOCOL_VERSION,
        "message_type": message_type,
        "request_id": request_id or new_request_id(),
        "task_id": task_id,
        "user_id": user_id,
        "source_device_id": source_device_id,
        "target_device_id": target_device_id,
        "timestamp": time.time() if timestamp is None else timestamp,
        "payload": payload if payload is not None else {},
        "status": status,
    }
    msg.update(extra)
    return msg


def error_event(code: str, message: str, *, request_id: str = "", task_id: str = "",
                **extra) -> Dict[str, Any]:
    return envelope(MessageType.ERROR_EVENT, request_id=request_id, task_id=task_id,
                    status=Status.FAILED,
                    payload={"code": code, "message": message}, **extra)


def parse_frame(raw: Any) -> Dict[str, Any]:
    """Normalise anything a client sent into a v1 envelope.

    Raises ProtocolError for frames that cannot be salvaged. The caller answers
    those with an ERROR_EVENT rather than dropping the connection, because a
    mobile client on a flaky network should not be punished for one bad frame.
    """
    if not isinstance(raw, dict):
        raise ProtocolError("frame must be a JSON object")

    mtype = raw.get("message_type") or raw.get("type")
    if not mtype:
        raise ProtocolError("frame has no message_type")
    if not isinstance(mtype, str):
        raise ProtocolError("message_type must be a string")

    if mtype not in ALL_MESSAGE_TYPES:
        alias = LEGACY_TYPE_ALIASES.get(mtype.lower())
        if alias is None:
            raise ProtocolError(f"unknown message_type: {mtype}")
        mtype = alias
        legacy = True
    else:
        legacy = "message_type" not in raw

    version = raw.get("protocol_version", PROTOCOL_VERSION if not legacy else 0)
    try:
        version = int(version)
    except (TypeError, ValueError):
        raise ProtocolError("protocol_version must be an integer")
    if version > PROTOCOL_VERSION:
        raise ProtocolError(
            f"protocol_version {version} is newer than this server supports "
            f"({PROTOCOL_VERSION}); upgrade JARVIS or downgrade the client")

    payload = raw.get("payload")
    if payload is None:
        # legacy frames carried their body at the top level
        payload = {k: v for k, v in raw.items()
                   if k not in {"type", "message_type", "protocol_version", "request_id",
                                "task_id", "user_id", "source_device_id", "target_device_id",
                                "timestamp", "status", "seq", "ts"}}
    if not isinstance(payload, dict):
        raise ProtocolError("payload must be a JSON object")

    return {
        "protocol_version": version or PROTOCOL_VERSION,
        "message_type": mtype,
        "request_id": str(raw.get("request_id") or ""),
        "task_id": str(raw.get("task_id") or payload.get("task_id") or ""),
        "user_id": str(raw.get("user_id") or ""),
        "source_device_id": str(raw.get("source_device_id") or ""),
        "target_device_id": str(raw.get("target_device_id") or ""),
        "timestamp": float(raw.get("timestamp") or raw.get("ts") or time.time()),
        "payload": payload,
        "status": str(raw.get("status") or ""),
        "_legacy": legacy,
    }


def is_client_originated(message_type: str) -> bool:
    return message_type in CLIENT_ORIGINATED


def downgrade(msg: Dict[str, Any]) -> Dict[str, Any]:
    """Render a v1 envelope in the 1.0.0 dialect for a legacy client."""
    mtype = msg.get("message_type", "")
    legacy_type = LEGACY_TYPE_FOR.get(mtype, mtype.lower())
    out = {"type": legacy_type}
    for key in ("task_id", "request_id", "seq", "ts", "timestamp"):
        if msg.get(key):
            out[key] = msg[key]
    payload = msg.get("payload") or {}
    if isinstance(payload, dict):
        # keep the 1.0.0 shape (body under "payload") AND flatten it, because
        # different early clients read it both ways.
        out["payload"] = payload
        for k, v in payload.items():
            if k not in out:
                out[k] = v
    return out


def descriptor() -> Dict[str, Any]:
    """Machine-readable contract, served at GET /api/protocol.

    A client should fetch this at startup and refuse to run if
    `protocol_version` is outside the range it implements.
    """
    return {
        "protocol_version": PROTOCOL_VERSION,
        "min_supported_version": MIN_SUPPORTED_VERSION,
        "transport": {
            "websocket": "/api/bus/ws",
            "auth": "device token via ?token=, Authorization: Bearer, or X-Device-Token",
            "close_codes": {"4401": "unauthenticated", "4403": "revoked or forbidden"},
            "heartbeat_seconds": 20,
            "offline_after_seconds": 45,
            "reconnect": "exponential backoff 1s, 2s, 4s, 8s, 16s, 30s max, full jitter",
        },
        "envelope": {
            "protocol_version": "int",
            "message_type": "string",
            "request_id": "string, client-generated, makes retries idempotent",
            "task_id": "string",
            "user_id": "string",
            "source_device_id": "string",
            "target_device_id": "string",
            "timestamp": "float, unix seconds",
            "payload": "object",
            "status": "string",
            "seq": "int, monotonic per connection (server frames)",
        },
        "message_types": sorted(ALL_MESSAGE_TYPES),
        "client_originated": sorted(CLIENT_ORIGINATED),
        "server_originated": sorted(SERVER_ORIGINATED),
        "statuses": sorted(v for k, v in vars(Status).items() if not k.startswith("_")),
        "error_codes": sorted(v for k, v in vars(ErrorCode).items() if not k.startswith("_")),
        "legacy_aliases": LEGACY_TYPE_ALIASES,
        "guarantees": [
            "Every frame is authenticated; there is no anonymous device channel.",
            "request_id makes task creation idempotent - a retry returns the first task.",
            "A task result is accepted exactly once; replays are answered with duplicate=true.",
            "seq is monotonic per connection so a client can detect gaps and reorder.",
            "A task for an offline device is never reported as executed.",
            "Capabilities are checked before a task is routed, not after it fails.",
        ],
    }
