"""/api/devices/* - device identity, pairing, permissions, revocation (spec 4, 5)."""
from __future__ import annotations

import json
import time
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .. import audit, capabilities, config, db, protocol, security
from ..device_bus import bus
from ..deps import current_principal, require_owner

router = APIRouter(prefix="/api/devices", tags=["devices"])


def device_public(row) -> dict:
    """The full device identity (spec 3). The token hash never leaves the DB."""
    d = dict(row)
    token_hash = d.pop("token_hash", None)
    d["capabilities"] = json.loads(d.get("capabilities") or "[]")
    d["permissions"] = json.loads(d.get("permissions") or "[]")
    d["online"] = bus.is_online(d["device_id"])
    d["is_host"] = bool(d.get("is_host"))
    # explicit, machine-readable states so a client never has to guess
    d["auth_state"] = "AUTHENTICATED" if token_hash else "AWAITING_TOKEN"
    d["pairing_state"] = "PAIRED" if d.get("state") == "ACTIVE" else "REVOKED"
    d["presence"] = "ONLINE" if d["online"] else "OFFLINE"
    d["last_seen_seconds_ago"] = (
        round(time.time() - d["last_seen"], 1) if d.get("last_seen") else None)
    d["capabilities_described"] = capabilities.describe(d["capabilities"])
    return d


def ensure_host_device(user_id: str, name: str = "This PC (JARVIS host)") -> dict:
    """The machine JARVIS itself runs on is always a registered device."""
    row = db.one("SELECT * FROM devices WHERE user_id=? AND is_host=1", (user_id,))
    if row:
        db.execute("UPDATE devices SET last_seen=? WHERE device_id=?", (time.time(), row["device_id"]))
        return device_public(db.one("SELECT * FROM devices WHERE device_id=?", (row["device_id"],)))
    import platform

    dtype = "windows" if config.IS_WINDOWS else platform.system().lower()
    device_id = f"dev_{dtype}_{uuid.uuid4().hex[:8]}"
    db.execute(
        "INSERT INTO devices(device_id,user_id,name,device_type,os,os_version,app_version,"
        "token_hash,capabilities,permissions,state,is_host,last_seen,created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (device_id, user_id, name, dtype, platform.system(), platform.release(),
         config.APP_VERSION, None, json.dumps(_host_capabilities()),
         json.dumps(security.HOST_PERMISSIONS), "ACTIVE", 1, time.time(), time.time()),
    )
    audit.record("device.register_host", "OK", user_id=user_id, target_device=device_id)
    return device_public(db.one("SELECT * FROM devices WHERE device_id=?", (device_id,)))


def _host_capabilities() -> list[str]:
    caps = ["chat", "memory", "files", "browser", "system.metrics"]
    if config.IS_WINDOWS:
        caps += ["windows.automation", "voice.stt", "voice.tts", "hotkey.global", "notifications"]
    return caps


# --------------------------------------------------------------------------- #
# listing / management
# --------------------------------------------------------------------------- #
@router.get("")
def list_devices(principal: dict = Depends(current_principal)):
    """Every device belonging to THIS user - a user may own many (spec 3)."""
    ensure_host_device(principal["user_id"])
    rows = db.query("SELECT * FROM devices WHERE user_id=? ORDER BY is_host DESC, created_at",
                    (principal["user_id"],))
    devices = [device_public(r) for r in rows]
    return {"devices": devices,
            "all_permissions": list(security.ALL_PERMISSIONS),
            "capability_catalog": capabilities.catalog_public(),
            "protocol_version": protocol.PROTOCOL_VERSION,
            "online_count": sum(1 for d in devices if d.get("online")),
            "total": len(devices)}


class CapabilitiesBody(BaseModel):
    capabilities: list[str]


@router.post("/{device_id}/capabilities")
def update_capabilities(device_id: str, body: CapabilitiesBody,
                        principal: dict = Depends(current_principal)):
    """A device (or its owner) refreshes what it can physically do.

    REST twin of the DEVICE_CAPABILITIES frame, for clients that want to declare
    themselves before opening the socket. Unknown capability strings are kept,
    not silently dropped, and reported back under "unknown".
    """
    _owned_device(device_id, principal)
    stored = capabilities.set_capabilities(device_id, body.capabilities)
    audit.record("device.capabilities", "OK", user_id=principal["user_id"],
                 target_device=device_id, detail={"count": len(stored)})
    return {"device_id": device_id, "capabilities": stored,
            "unknown": capabilities.unknown(stored),
            "described": capabilities.describe(stored)}


@router.get("/capabilities/catalog")
def capability_catalog(principal: dict = Depends(current_principal)):
    return capabilities.catalog_public()


class RenameBody(BaseModel):
    name: str = Field(min_length=1, max_length=64)


@router.post("/{device_id}/rename")
def rename_device(device_id: str, body: RenameBody, principal: dict = Depends(current_principal)):
    row = _owned_device(device_id, principal)
    db.execute("UPDATE devices SET name=? WHERE device_id=?", (body.name.strip(), device_id))
    audit.record("device.rename", "OK", user_id=principal["user_id"], target_device=device_id,
                 detail={"from": row["name"], "to": body.name})
    return device_public(db.one("SELECT * FROM devices WHERE device_id=?", (device_id,)))


class PermissionsBody(BaseModel):
    permissions: list[str]


@router.post("/{device_id}/permissions")
def set_permissions(device_id: str, body: PermissionsBody, principal: dict = Depends(require_owner)):
    _owned_device(device_id, principal)
    unknown = [p for p in body.permissions if p not in security.ALL_PERMISSIONS]
    if unknown:
        raise HTTPException(status_code=400, detail=f"Unknown permissions: {', '.join(unknown)}")
    db.execute("UPDATE devices SET permissions=? WHERE device_id=?",
               (json.dumps(sorted(set(body.permissions))), device_id))
    audit.record("device.permissions", "OK", user_id=principal["user_id"], target_device=device_id,
                 detail={"permissions": body.permissions})
    return device_public(db.one("SELECT * FROM devices WHERE device_id=?", (device_id,)))


@router.post("/{device_id}/revoke")
async def revoke_device(device_id: str, principal: dict = Depends(require_owner)):
    row = _owned_device(device_id, principal)
    if row["is_host"]:
        raise HTTPException(status_code=400, detail="The host device cannot revoke itself.")
    db.execute("UPDATE devices SET state='REVOKED', token_hash=NULL WHERE device_id=?", (device_id,))
    await bus.disconnect(device_id, reason="revoked")
    audit.record("device.revoke", "OK", user_id=principal["user_id"], target_device=device_id)
    db.log_activity("device", f"Device revoked: {row['name']}")
    return {"ok": True, "device_id": device_id, "state": "REVOKED"}


@router.delete("/{device_id}")
async def remove_device(device_id: str, principal: dict = Depends(require_owner)):
    row = _owned_device(device_id, principal)
    if row["is_host"]:
        raise HTTPException(status_code=400, detail="The host device cannot be removed.")
    await bus.disconnect(device_id, reason="removed")
    db.execute("DELETE FROM devices WHERE device_id=?", (device_id,))
    audit.record("device.remove", "OK", user_id=principal["user_id"], target_device=device_id)
    return {"ok": True, "removed": device_id}


def _owned_device(device_id: str, principal: dict):
    row = db.one("SELECT * FROM devices WHERE device_id=?", (device_id,))
    if not row or row["user_id"] != principal["user_id"]:
        raise HTTPException(status_code=404, detail="Unknown device.")
    return row


# --------------------------------------------------------------------------- #
# pairing (spec 5)
# --------------------------------------------------------------------------- #
class PairingRequest(BaseModel):
    device_name: str = Field(min_length=1, max_length=64)
    device_type: str = Field(default="android", max_length=32)
    os: str | None = None
    os_version: str | None = None
    app_version: str | None = None
    capabilities: list[str] = []
    username: str | None = None      # which JARVIS account the new device wants to join


@router.post("/pairing")
def request_pairing(body: PairingRequest):
    """Called by a NEW, unauthenticated device. Produces a short-lived code."""
    user_id = None
    if body.username:
        row = db.one("SELECT user_id FROM users WHERE username=?", (body.username.strip(),))
        user_id = row["user_id"] if row else None

    code = security.new_pairing_code()
    pairing_id = f"pair_{uuid.uuid4().hex[:12]}"
    now = time.time()
    # A client that advertises nothing gets the documented baseline for its
    # platform rather than an empty set, otherwise it would pair into a device
    # that JARVIS believes can do nothing at all. A real client corrects this
    # immediately with a DEVICE_CAPABILITIES frame or POST /capabilities.
    caps = capabilities.normalize(body.capabilities) or capabilities.defaults_for(body.device_type)
    db.execute(
        "INSERT INTO pairings(pairing_id,code_hash,code_display,user_id,device_name,device_type,os,"
        "app_version,capabilities,status,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (pairing_id, security.token_hash(code), code, user_id, body.device_name.strip(),
         body.device_type, body.os, body.app_version, json.dumps(caps),
         "PENDING", now, now + config.PAIRING_TTL_SECONDS),
    )
    audit.record("pairing.request", "OK",
                 detail={"device_name": body.device_name, "device_type": body.device_type,
                         "capabilities": len(caps)})
    db.log_activity("pairing", f"Pairing requested by {body.device_name}")
    return {
        "pairing_id": pairing_id,
        "code": code,                      # shown on the new device screen
        "expires_at": now + config.PAIRING_TTL_SECONDS,
        "expires_in": config.PAIRING_TTL_SECONDS,
        "status": "PENDING",
        "capabilities": caps,
        "protocol_version": protocol.PROTOCOL_VERSION,
    }


def _expire_stale() -> None:
    db.execute("UPDATE pairings SET status='EXPIRED' WHERE status='PENDING' AND expires_at < ?",
               (time.time(),))


@router.get("/pairing")
def list_pairings(principal: dict = Depends(current_principal)):
    _expire_stale()
    rows = db.query(
        "SELECT pairing_id, code_display, device_name, device_type, os, status, created_at, expires_at"
        " FROM pairings WHERE status IN ('PENDING','APPROVED') ORDER BY created_at DESC LIMIT 50")
    return {"pairings": [dict(r) for r in rows]}


@router.get("/pairing/{pairing_id}")
def pairing_status(pairing_id: str):
    """Polled by the pairing device; never leaks the token, only the state."""
    _expire_stale()
    row = db.one("SELECT status, device_name, expires_at FROM pairings WHERE pairing_id=?", (pairing_id,))
    if not row:
        raise HTTPException(status_code=404, detail="Unknown pairing request.")
    return dict(row)


@router.post("/pairing/{pairing_id}/approve")
def approve_pairing(pairing_id: str, principal: dict = Depends(require_owner)):
    _expire_stale()
    row = db.one("SELECT * FROM pairings WHERE pairing_id=?", (pairing_id,))
    if not row:
        raise HTTPException(status_code=404, detail="Unknown pairing request.")
    if row["status"] != "PENDING":
        raise HTTPException(status_code=409, detail=f"Pairing is {row['status']}, not PENDING.")
    if row["expires_at"] < time.time():
        db.execute("UPDATE pairings SET status='EXPIRED' WHERE pairing_id=?", (pairing_id,))
        raise HTTPException(status_code=410, detail="Pairing code expired. Ask the device for a new one.")

    device_id = f"dev_{row['device_type']}_{uuid.uuid4().hex[:8]}"
    now = time.time()
    # The device row exists but holds NO credential yet - the device mints its own
    # token by claiming with its code, so no plaintext token is ever stored at rest.
    db.execute(
        "INSERT INTO devices(device_id,user_id,name,device_type,os,os_version,app_version,token_hash,"
        "capabilities,permissions,state,is_host,last_seen,created_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (device_id, principal["user_id"], row["device_name"], row["device_type"], row["os"], None,
         row["app_version"], None, row["capabilities"],
         json.dumps(security.DEFAULT_DEVICE_PERMISSIONS), "ACTIVE", 0, None, now),
    )
    db.execute("UPDATE pairings SET status='APPROVED', device_id=? WHERE pairing_id=?",
               (device_id, pairing_id))
    audit.record("pairing.approve", "OK", user_id=principal["user_id"], target_device=device_id)
    db.log_activity("pairing", f"Device approved: {row['device_name']}")
    return {
        "ok": True,
        "device_id": device_id,
        "device_name": row["device_name"],
        "permissions": security.DEFAULT_DEVICE_PERMISSIONS,
        "note": "Approved. The device now exchanges its pairing code for a permanent credential.",
    }


@router.post("/{device_id}/issue-token")
def issue_token(device_id: str, principal: dict = Depends(require_owner)):
    """Owner-driven credential hand-off (type the token into the other device).

    Any previously issued token for this device stops working immediately.
    """
    row = _owned_device(device_id, principal)
    if row["state"] != "ACTIVE":
        raise HTTPException(status_code=409, detail="Device is revoked.")
    token = security.new_token("jtk")
    db.execute("UPDATE devices SET token_hash=? WHERE device_id=?",
               (security.token_hash(token), device_id))
    audit.record("device.issue_token", "OK", user_id=principal["user_id"], target_device=device_id)
    return {"device_id": device_id, "device_token": token,
            "note": "Shown once. Previous credentials for this device are now invalid."}


@router.post("/pairing/{pairing_id}/reject")
def reject_pairing(pairing_id: str, principal: dict = Depends(require_owner)):
    row = db.one("SELECT * FROM pairings WHERE pairing_id=?", (pairing_id,))
    if not row:
        raise HTTPException(status_code=404, detail="Unknown pairing request.")
    db.execute("UPDATE pairings SET status='REJECTED', used_at=? WHERE pairing_id=?",
               (time.time(), pairing_id))
    audit.record("pairing.reject", "OK", user_id=principal["user_id"],
                 detail={"device_name": row["device_name"]})
    return {"ok": True, "status": "REJECTED"}


class ClaimBody(BaseModel):
    code: str
    pairing_id: str | None = None


@router.post("/pairing/claim")
def claim_pairing(body: ClaimBody):
    """The approved device exchanges its code for a permanent device credential.

    The code is single-use: the hash is destroyed on success, so a replay of the
    same code can never authenticate again.
    """
    _expire_stale()
    code = security.normalize_pairing_code(body.code)
    row = db.one("SELECT * FROM pairings WHERE code_hash=? AND code_hash<>''",
                 (security.token_hash(code),))
    if not row:
        raise HTTPException(status_code=404, detail="Invalid, expired or already-used pairing code.")
    if row["expires_at"] < time.time():
        db.execute("UPDATE pairings SET status='EXPIRED' WHERE pairing_id=?", (row["pairing_id"],))
        raise HTTPException(status_code=410, detail="Pairing code expired.")
    if row["status"] == "PENDING":
        raise HTTPException(status_code=425, detail="Waiting for the owner to approve this device.")
    if row["status"] != "APPROVED":
        raise HTTPException(status_code=409, detail=f"Pairing is {row['status']}.")

    token = security.new_token("jtk")
    now = time.time()
    db.execute("UPDATE devices SET token_hash=?, created_at=created_at WHERE device_id=?",
               (security.token_hash(token), row["device_id"]))
    # burn the code
    db.execute("UPDATE pairings SET status='CLAIMED', used_at=?, code_hash='' WHERE pairing_id=?",
               (now, row["pairing_id"]))
    device = db.one("SELECT * FROM devices WHERE device_id=?", (row["device_id"],))
    audit.record("pairing.claim", "OK", user_id=device["user_id"], target_device=device["device_id"])
    db.log_activity("pairing", f"Device paired: {device['name']}")
    return {
        "ok": True,
        "device_id": device["device_id"],
        "device_token": token,
        "user_id": device["user_id"],
        "permissions": json.loads(device["permissions"] or "[]"),
        "ws_url": "/api/bus/ws",
    }
