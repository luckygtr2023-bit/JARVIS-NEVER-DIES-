"""/api/health, /api/system/*, /api/activity - honest component health (spec 36)."""
from __future__ import annotations

import platform
import time

from fastapi import APIRouter, Depends

from .. import config, db
from ..device_bus import bus
from ..deps import current_principal, optional_principal
from ..services import ai_client, browser_tools, voice_engine

router = APIRouter(prefix="/api", tags=["system"])
STARTED_AT = time.time()


@router.get("/health")
async def health(principal=Depends(optional_principal)):
    """Never reports a component READY unless it really is."""
    omni = await ai_client.probe_omniroute(timeout=1.2)
    olla = await ai_client.probe_ollama(timeout=1.2)
    pw = browser_tools.playwright_status()
    stt = voice_engine.stt_status()
    tts = voice_engine.tts_status()

    components = {
        "backend": {"status": "READY", "detail": f"{config.APP_NAME} {config.APP_VERSION}"},
        "database": {"status": "READY" if db.connect() else "ERROR", "detail": str(config.DB_PATH)},
        "authentication": {"status": "READY", "detail": "username + password"},
        "omniroute": {"status": "READY" if omni.get("available") else "UNAVAILABLE",
                      "detail": omni.get("error") or omni.get("endpoint")},
        "ollama": {"status": "READY" if olla.get("available") else "UNAVAILABLE",
                   "detail": olla.get("error") or f"{len(olla.get('models', []))} model(s)"},
        "browser": {"status": "READY" if pw.get("installed") else "UNAVAILABLE",
                    "detail": pw.get("reason", "playwright + chromium")},
        "voice_stt": {"status": "READY" if stt.get("available") else "UNAVAILABLE",
                      "detail": stt.get("detail")},
        "voice_tts": {"status": "READY" if tts.get("available") else "UNAVAILABLE",
                      "detail": tts.get("detail")},
        "device_bus": {"status": "READY", "detail": f"{len(bus.online_ids())} device(s) online"},
        "gmail": _google_status(),
        "calendar": _google_status(),
    }
    overall = "ok"
    return {"status": overall, "app": config.APP_NAME, "version": config.APP_VERSION,
            "platform": platform.system(), "uptime_seconds": round(time.time() - STARTED_AT),
            "authenticated": principal is not None, "components": components}


def _google_status() -> dict:
    if config.GOOGLE_CLIENT_ID and config.GOOGLE_CLIENT_SECRET:
        return {"status": "CONFIGURED", "detail": "OAuth client present; link the account to use it."}
    return {"status": "CREDENTIAL_BLOCKED",
            "detail": "GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET are not set in the environment."}


@router.get("/system/status")
def system_status(principal: dict = Depends(current_principal)):
    """Live telemetry for the HUD panel."""
    try:
        import psutil
    except ImportError:
        return {"available": False, "reason": "psutil not installed"}
    vm = psutil.virtual_memory()
    root = "C:\\" if config.IS_WINDOWS else "/"
    du = psutil.disk_usage(root)
    bat = getattr(psutil, "sensors_battery", lambda: None)()
    return {
        "available": True,
        "cpu": round(psutil.cpu_percent(interval=0.1)),
        "ram": round(vm.percent),
        "ram_used_gb": round(vm.used / 1e9, 2),
        "ram_total_gb": round(vm.total / 1e9, 2),
        "disk": round(du.percent),
        "battery": round(bat.percent) if bat else None,
        "battery_plugged": bat.power_plugged if bat else None,
        "processes": len(psutil.pids()),
        "uptime_minutes": round((time.time() - psutil.boot_time()) / 60),
        "memories": len(db.query("SELECT 1 FROM memories WHERE user_id=?", (principal["user_id"],))),
        "pending_tasks": len(db.query(
            "SELECT 1 FROM tasks WHERE user_id=? AND status IN ('QUEUED','RUNNING','WAITING_CONFIRMATION')",
            (principal["user_id"],))),
        "devices_online": len(bus.online_ids()),
    }


@router.get("/activity")
def activity(limit: int = 100, principal: dict = Depends(current_principal)):
    rows = db.query("SELECT * FROM activity ORDER BY id DESC LIMIT ?", (limit,))
    return {"events": [dict(r) for r in rows]}


@router.get("/audit")
def audit_log(limit: int = 200, principal: dict = Depends(current_principal)):
    from .. import audit as audit_mod
    return {"entries": audit_mod.recent(limit)}
