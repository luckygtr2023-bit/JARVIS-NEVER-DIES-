"""/api/chat/*, /api/tools/*, /api/tasks/* - the agent surface."""
from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .. import audit, config, db
from ..device_bus import bus, list_tasks, get_task, update_task
from ..deps import check_permission, current_principal
from ..services import agent_loop
from ..services.ai_client import AIConfig, AIError, chat_stream
from ..services.tools_registry import registry_public

router = APIRouter(prefix="/api", tags=["agent"])


class CommandBody(BaseModel):
    text: str
    request_id: str | None = None
    stream: bool = False


@router.post("/chat")
async def chat_endpoint(body: CommandBody, principal: dict = Depends(current_principal)):
    check_permission(principal, "chat")
    if not body.text.strip():
        raise HTTPException(status_code=400, detail="Empty command.")
    return await agent_loop.handle_command(
        body.text, principal,
        source_device_id=principal.get("device_id"), request_id=body.request_id)


@router.post("/chat/stream")
async def chat_stream_endpoint(body: CommandBody, principal: dict = Depends(current_principal)):
    """SSE stream. Tool intents resolve first and stream their verified summary,
    otherwise the AI answer streams token by token."""
    check_permission(principal, "chat")
    text = body.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="Empty command.")

    async def gen():
        try:
            intent = agent_loop.parse_intent(text)
            target = agent_loop.parse_target_device(text, principal["user_id"])
            if intent or target:
                result = await agent_loop.handle_command(
                    text, principal, source_device_id=principal.get("device_id"),
                    request_id=body.request_id)
                yield f"data: {json.dumps({'type': 'result', 'payload': result})}\n\n"
                yield "data: [DONE]\n\n"
                return
            messages = agent_loop.build_context(principal["user_id"], text)
            sent_any = False
            async for delta in chat_stream(messages, cfg=AIConfig.for_principal(principal)):
                sent_any = True
                yield f"data: {json.dumps({'type': 'delta', 'text': delta})}\n\n"
            if not sent_any:
                yield f"data: {json.dumps({'type': 'error', 'error': 'The AI returned nothing.'})}\n\n"
            audit.record("ai.chat_stream", "OK", user_id=principal["user_id"])
        except AIError as exc:
            yield f"data: {json.dumps({'type': 'error', 'error': exc.message})}\n\n"
        except Exception as exc:                      # never leak a raw traceback
            yield f"data: {json.dumps({'type': 'error', 'error': f'Agent failure: {exc}'})}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# --------------------------------------------------------------------------- #
# tools
# --------------------------------------------------------------------------- #
@router.get("/tools")
def tools(principal: dict = Depends(current_principal)):
    return {"tools": registry_public()}


class ToolCall(BaseModel):
    name: str
    args: dict = {}


@router.post("/tools/run")
async def run_tool_endpoint(body: ToolCall, principal: dict = Depends(current_principal)):
    from ..services.tools_registry import CapabilityError, ToolError, requires_confirmation, run_tool
    from ..device_bus import create_task

    perm = "windows.control" if body.name in ("shutdown_pc", "run_powershell", "close_application",
                                              "click_mouse", "type_text") else "chat"
    check_permission(principal, perm)

    task = create_task(principal["user_id"], "tool", {"name": body.name, "args": body.args},
                       source_device_id=principal.get("device_id"), status="RUNNING")
    if requires_confirmation(body.name):
        pc = agent_loop.create_confirmation(principal["user_id"], body.name, body.args,
                                            f"{body.name}", task["task_id"])
        return {"status": "WAITING_CONFIRMATION", "confirm_id": pc.confirm_id,
                "tool": body.name, "args": body.args, "task_id": task["task_id"]}
    try:
        result = await asyncio.wait_for(run_tool(body.name, body.args), timeout=60)
    except CapabilityError as exc:
        update_task(task["task_id"], status="FAILED", error=str(exc))
        raise HTTPException(status_code=501, detail=str(exc))
    except ToolError as exc:
        update_task(task["task_id"], status="FAILED", error=str(exc))
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        update_task(task["task_id"], status="FAILED", error=str(exc))
        raise HTTPException(status_code=500, detail=str(exc))
    update_task(task["task_id"], status="COMPLETED", result=json.dumps(result, default=str),
                verification="VERIFIED")
    return {"status": "COMPLETED", "tool": body.name, "result": result, "task_id": task["task_id"]}


class ConfirmBody(BaseModel):
    confirm_id: str
    approve: bool = True


@router.post("/tools/confirm")
async def confirm_tool(body: ConfirmBody, principal: dict = Depends(current_principal)):
    """Backend-enforced confirmation. A frontend cannot skip this step."""
    try:
        return await agent_loop.resolve_confirmation(body.confirm_id, body.approve,
                                                     principal["user_id"])
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/tools/pending")
def pending_confirmations(principal: dict = Depends(current_principal)):
    return {"pending": [
        {"confirm_id": p.confirm_id, "tool": p.tool, "args": p.args,
         "description": p.description, "created_at": p.created_at}
        for p in agent_loop.PENDING.values() if p.user_id == principal["user_id"]]}


# --------------------------------------------------------------------------- #
# tasks
# --------------------------------------------------------------------------- #
@router.get("/tasks")
def tasks(limit: int = 100, principal: dict = Depends(current_principal)):
    return {"tasks": list_tasks(principal["user_id"], limit)}


@router.get("/tasks/{task_id}")
def task_detail(task_id: str, principal: dict = Depends(current_principal)):
    task = get_task(task_id)
    if not task or task["user_id"] != principal["user_id"]:
        raise HTTPException(status_code=404, detail="Unknown task.")
    return task


@router.post("/tasks/{task_id}/cancel")
def cancel_task(task_id: str, principal: dict = Depends(current_principal)):
    task = get_task(task_id)
    if not task or task["user_id"] != principal["user_id"]:
        raise HTTPException(status_code=404, detail="Unknown task.")
    if task["status"] in ("COMPLETED", "FAILED", "CANCELLED"):
        return task
    update_task(task_id, status="CANCELLED", error="Cancelled by user.")
    audit.record("task.cancel", "CANCELLED", user_id=principal["user_id"], task_id=task_id)
    return get_task(task_id)
