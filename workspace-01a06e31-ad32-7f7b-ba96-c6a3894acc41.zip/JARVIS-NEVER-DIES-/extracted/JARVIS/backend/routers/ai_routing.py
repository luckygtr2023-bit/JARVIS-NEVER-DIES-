"""/api/ai/* routing, usage and quota diagnostics (spec: AI ROUTING DIAGNOSTICS).

OWNER sees the full picture (routes, reasons, models, tools, cloud-used, tokens,
latency, fallbacks); non-OWNERS see only their own usage. Provider secrets are
never returned - only counts, names and reasons.
"""
from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from .. import audit, memory_store, quota, routing as routing_mod
from .. import workflows as wf_store
from ..deps import current_principal, require_owner
from ..services import ai_client

router = APIRouter(prefix="/api", tags=["ai_routing"])


def _cfg_public() -> dict:
    cfg = ai_client.AIConfig.load()
    return {
        "mode": cfg.mode,
        "routing": cfg.routing,
        "combo": cfg.combo,
        "ollama_model": cfg.ollama_model or "qwen3:8b",
        "temperature": cfg.temperature,
        "max_tokens": cfg.max_tokens,
        "modes": list(routing_mod.MODES),
        "recommended": "local_first",
    }


@router.get("/ai/usage")
def ai_usage(principal: dict = Depends(current_principal)):
    """Usage summary. OWNER sees the global picture; others see their own."""
    owner_view = principal.get("role") == "OWNER"
    summary = quota.summary(None if owner_view else principal["user_id"])
    usage = {
        "summary": summary,
        "routing_mode": ai_client.AIConfig.load().routing,
        "principal_scope": "all" if owner_view else principal["user_id"],
    }
    if owner_view:
        usage["recent"] = quota.recent(50)
    else:
        usage["recent"] = quota.recent(20, principal["user_id"])
    return usage


@router.get("/ai/routing")
def ai_routing_status(principal: dict = Depends(current_principal)):
    """Current routing config + recent diagnostics (route/reason/model/tool/cloud)."""
    cfg = ai_client.AIConfig.load()
    recent = quota.recent(25, principal["user_id"] if principal.get("role") != "OWNER" else None)
    diagnostics = []
    for r in recent:
        detail = json.loads(r["detail"]) if r.get("detail") else {}
        diagnostics.append({
            "request": detail.get("request", ""), "reason": detail.get("reason", ""),
            "route": r["route"], "provider": r["provider"],
            "model": r["model"], "combo": r["combo"], "cloud_used": bool(r["cloud"]),
            "tokens": r["total_tokens"], "latency_ms": r["latency_ms"],
            "fallback": bool(r["fallback"]),
            "status": "OK" if r["success"] else ("FAILED" if r["route"] in
                        ("LOCAL", "CLOUD") else "SKIPPED"),
        })
    return {"mode": cfg.routing, "modes": list(routing_mod.MODES),
            "recommended": "local_first", "combo": cfg.combo,
            "ollama_model": cfg.ollama_model or "qwen3:8b",
            "diagnostics": diagnostics}


class RoutingBody(BaseModel):
    routing: str | None = None
    combo: str | None = None


class RoutingConfigBody(BaseModel):
    routing: str | None = None


@router.post("/ai/routing")
def set_routing(body: RoutingConfigBody, principal: dict = Depends(require_owner)):
    """OWNER sets the routing mode. Non-OWNERS cannot change it."""
    cfg = ai_client.AIConfig.load()
    if body.routing is None:
        raise HTTPException(status_code=400, detail="Provide a routing mode.")
    if body.routing not in routing_mod.MODES:
        raise HTTPException(status_code=400,
                            detail=f"routing must be one of: {', '.join(routing_mod.MODES)}")
    cfg.routing = body.routing
    # keep the legacy `mode` derived so old clients keep working
    if body.routing == "local_only":
        cfg.mode = "ollama"
    elif body.routing == "cloud_only":
        cfg.mode = "omniroute"
    else:
        cfg.mode = "auto"
    cfg.save()
    from .. import audit
    audit.record("settings.ai.routing", "OK", user_id=principal["user_id"],
                 detail={"routing": body.routing})
    return _cfg_public()


class LimitsBody(BaseModel):
    session_cloud_limit: int | None = None
    daily_cloud_limit: int | None = None
    user_cloud_limit: int | None = None
    device_cloud_limit: int | None = None
    enforce_cloud_limits: bool | None = None


@router.get("/routing/limits")
def get_limits(principal: dict = Depends(current_principal)):
    lim = quota.limits()
    # empty-values safe: never return secrets; just the numbers
    return {"limits": lim, "enforceable_by": "OWNER"}


@router.post("/routing/limits")
def set_limits(body: LimitsBody, principal: dict = Depends(require_owner)):
    from .. import audit
    new = quota.save_limits(body.model_dump(exclude_unset=True, exclude_none=True))
    audit.record("settings.quota_limits", "OK", user_id=principal["user_id"],
                 detail={k: v for k, v in new.items() if not k.startswith("enforce") or v})
    return {"limits": new}


# ------------------------------- workflows --------------------------------- #
@router.get("/workflows")
def list_workflows(principal: dict = Depends(current_principal)):
    return {"workflows": wf_store.list_for(principal["user_id"]),
            "note": "Only SAFE-risk tools are ever learned. Delete any you do not want cached."}


class WorkflowPatch(BaseModel):
    enabled: bool


@router.patch("/workflows/{wf_id}")
def set_workflow_enabled(wf_id: str, body: WorkflowPatch,
                         principal: dict = Depends(current_principal)):
    res = wf_store.set_enabled(principal["user_id"], wf_id, body.enabled)
    if not res:
        raise HTTPException(status_code=404, detail="No such learned workflow.")
    from .. import audit
    audit.record("workflows.enabled", "OK", user_id=principal["user_id"],
                 detail={"id": wf_id, "enabled": body.enabled})
    return res


@router.delete("/workflows/{wf_id}")
def delete_workflow(wf_id: str, principal: dict = Depends(current_principal)):
    if not wf_store.delete(principal["user_id"], wf_id):
        raise HTTPException(status_code=404, detail="No such learned workflow.")
    return {"ok": True}


@router.delete("/workflows")
def clear_workflows(principal: dict = Depends(current_principal)):
    from .. import audit
    removed = wf_store.clear(principal["user_id"])
    audit.record("workflows.clear", "OK", user_id=principal["user_id"], detail={"removed": removed})
    return {"ok": True, "removed": removed}


# --------------------------- conversation context -------------------------- #
@router.get("/memory/context")
def get_context(principal: dict = Depends(current_principal)):
    window = memory_store.get_context(principal["user_id"], "default")
    return {"enabled": memory_store.conversation_enabled(),
            "window": window, "max_turns": memory_store.MAX_TURNS}


@router.delete("/memory/context")
def clear_context(principal: dict = Depends(current_principal)):
    removed = memory_store.clear_conversation(principal["user_id"])
    from .. import audit
    audit.record("memory.conversation.clear", "OK", user_id=principal["user_id"],
                 detail={"removed": removed})
    return {"ok": True, "removed": removed}


class CtxBody(BaseModel):
    enabled: bool


@router.post("/memory/context/enabled")
def set_context_enabled(body: CtxBody, principal: dict = Depends(current_principal)):
    memory_store.set_conversation_enabled(body.enabled)
    return {"enabled": memory_store.conversation_enabled()}
