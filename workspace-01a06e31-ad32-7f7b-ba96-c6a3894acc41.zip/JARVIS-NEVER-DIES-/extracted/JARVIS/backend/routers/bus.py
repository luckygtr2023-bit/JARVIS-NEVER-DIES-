"""/api/bus/ws - the authenticated cross-device WebSocket control plane.

Speaks protocol v1 (see backend/protocol.py) and, for already-deployed 1.0.0
clients, the older short dialect. The dialect is detected per connection from
the first frame the client sends, so Android (v1) and an old Windows build
(legacy) can be connected simultaneously.

Security: the socket is authenticated before it is accepted. There is no
anonymous device channel, a revoked device is closed with 4403, and a device can
only originate the frame types in protocol.CLIENT_ORIGINATED - it cannot, for
example, forge a DEVICE_PAIR_APPROVE or grant itself a permission.
"""
from __future__ import annotations

import json
import time

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from .. import audit, capabilities, db, protocol, security
from ..device_bus import Connection, bus, get_task, update_task
from ..protocol import ErrorCode, MessageType, Status

router = APIRouter(prefix="/api/bus", tags=["bus"])

HEARTBEAT_SECONDS = 20


def _credentials(websocket: WebSocket, token: str) -> str:
    header_token = websocket.headers.get("x-device-token") or ""
    auth = websocket.headers.get("authorization") or ""
    if auth.lower().startswith("bearer "):
        auth = auth[7:]
    return token or header_token or auth


@router.websocket("/ws")
async def bus_ws(websocket: WebSocket, token: str = Query(default="")):
    principal = security.resolve_device_token(_credentials(websocket, token))
    if principal is None:
        # 4401 = unauthenticated. A revoked device's token no longer resolves,
        # so it lands here too; the close code is documented in the descriptor.
        await websocket.close(code=4401)
        return

    await websocket.accept()
    device_id = principal["device_id"]
    user_id = principal["user_id"]
    perms = json.loads(principal.get("permissions") or "[]")
    conn = Connection(device_id, user_id, websocket, role=principal.get("role", ""),
                      capabilities=capabilities.device_capabilities(device_id))
    await bus.register(conn)

    await conn.send(protocol.envelope(
        MessageType.HELLO, user_id=user_id, target_device_id=device_id,
        status=Status.COMPLETED,
        payload={
            "device_id": device_id,
            "user_id": user_id,
            "role": principal.get("role", ""),
            "permissions": perms,
            "capabilities": conn.capabilities,
            "protocol_version": protocol.PROTOCOL_VERSION,
            "min_supported_version": protocol.MIN_SUPPORTED_VERSION,
            "heartbeat_seconds": HEARTBEAT_SECONDS,
            "server_time": time.time(),
        }))

    async def fail(code: str, message: str, *, request_id: str = "", task_id: str = ""):
        await conn.send(protocol.error_event(code, message, request_id=request_id,
                                             task_id=task_id))

    try:
        while True:
            raw = await websocket.receive_text()
            bus.touch(device_id)

            try:
                frame = protocol.parse_frame(json.loads(raw))
            except json.JSONDecodeError:
                await fail(ErrorCode.MALFORMED, "malformed JSON frame")
                continue
            except protocol.ProtocolError as exc:
                code = (ErrorCode.UNSUPPORTED_VERSION if "protocol_version" in str(exc)
                        else ErrorCode.UNKNOWN_MESSAGE_TYPE)
                await fail(code, str(exc))
                continue

            conn.note_dialect(frame)
            mtype = frame["message_type"]
            payload = frame["payload"]
            request_id = frame["request_id"]

            if not protocol.is_client_originated(mtype):
                await fail(ErrorCode.NOT_CLIENT_ORIGINATED,
                           f"a device may not originate {mtype}", request_id=request_id)
                continue

            # ---------------- presence ---------------- #
            if mtype == MessageType.DEVICE_HEARTBEAT:
                await conn.send(protocol.envelope(
                    MessageType.PONG, request_id=request_id, user_id=user_id,
                    target_device_id=device_id, status=Status.COMPLETED,
                    payload={"server_time": time.time(),
                             "next_heartbeat_seconds": HEARTBEAT_SECONDS}))

            elif mtype == MessageType.DEVICE_STATUS:
                # the device volunteering battery / foreground app / network etc.
                db.execute("UPDATE devices SET last_seen=? WHERE device_id=?",
                           (time.time(), device_id))
                await conn.send(protocol.envelope(
                    MessageType.ACK, request_id=request_id, target_device_id=device_id,
                    status=Status.COMPLETED, payload={"accepted": True}))

            # ---------------- capabilities (spec 8) ---------------- #
            elif mtype in (MessageType.DEVICE_CAPABILITIES, MessageType.DEVICE_REGISTER):
                caps = payload.get("capabilities")
                if not isinstance(caps, list):
                    await fail(ErrorCode.MALFORMED,
                               "payload.capabilities must be a list of strings",
                               request_id=request_id)
                    continue
                stored = capabilities.set_capabilities(device_id, caps)
                conn.capabilities = stored
                # A device may also refresh its own descriptive fields. It may
                # NOT change its owner, permissions, role or state here.
                fields, args = [], []
                for column, key in (("name", "device_name"), ("os", "os"),
                                    ("os_version", "os_version"), ("app_version", "app_version")):
                    if isinstance(payload.get(key), str) and payload[key].strip():
                        fields.append(f"{column}=?")
                        args.append(payload[key].strip()[:64])
                if fields:
                    args.append(device_id)
                    db.execute(f"UPDATE devices SET {', '.join(fields)} WHERE device_id=?", args)
                audit.record("device.capabilities", "OK", user_id=user_id,
                             source_device=device_id, detail={"count": len(stored)})
                await conn.send(protocol.envelope(
                    MessageType.ACK, request_id=request_id, target_device_id=device_id,
                    status=Status.COMPLETED,
                    payload={"capabilities": stored,
                             "unknown": capabilities.unknown(stored)}))

            # ---------------- task results ---------------- #
            elif mtype == MessageType.TASK_RESULT:
                task_id = frame["task_id"] or payload.get("task_id", "")
                ok = bool(payload.get("ok"))
                accepted = bus.deliver_result(task_id, {
                    "ok": ok,
                    "result": payload.get("result"),
                    "error": payload.get("error"),
                    "verified": bool(payload.get("verified")),
                })
                if accepted:
                    update_task(task_id,
                                status=Status.COMPLETED if ok else Status.FAILED,
                                result=json.dumps(payload.get("result"), default=str),
                                error=payload.get("error"),
                                verification="VERIFIED" if payload.get("verified")
                                             else "NOT_VERIFIED")
                await conn.send(protocol.envelope(
                    MessageType.ACK, request_id=request_id, task_id=task_id,
                    target_device_id=device_id,
                    status=Status.COMPLETED if accepted else Status.REJECTED,
                    payload={"duplicate": not accepted,
                             "code": None if accepted else ErrorCode.DUPLICATE}))

            elif mtype == MessageType.TASK_UPDATE:
                task_id = frame["task_id"]
                task = get_task(task_id)
                if not task or task["user_id"] != user_id:
                    await fail(ErrorCode.FORBIDDEN, "unknown task", request_id=request_id,
                               task_id=task_id)
                    continue
                update_task(task_id, status=str(payload.get("status") or Status.RUNNING))
                await conn.send(protocol.envelope(
                    MessageType.ACK, request_id=request_id, task_id=task_id,
                    target_device_id=device_id, status=Status.COMPLETED))

            elif mtype == MessageType.TASK_CANCEL:
                task_id = frame["task_id"]
                task = get_task(task_id)
                if not task or task["user_id"] != user_id:
                    await fail(ErrorCode.FORBIDDEN, "unknown task", request_id=request_id,
                               task_id=task_id)
                    continue
                update_task(task_id, status=Status.CANCELLED,
                            error="cancelled by " + bus.device_name(device_id))
                audit.record("task.cancel", "OK", user_id=user_id, source_device=device_id,
                             task_id=task_id)
                await conn.send(protocol.envelope(
                    MessageType.ACK, request_id=request_id, task_id=task_id,
                    target_device_id=device_id, status=Status.CANCELLED))

            # ---------------- natural-language command ---------------- #
            elif mtype == MessageType.COMMAND_REQUEST:
                from ..deps import device_permissions
                from ..services import agent_loop
                text = str(payload.get("text", ""))
                if "chat" not in device_permissions(device_id):
                    await fail(ErrorCode.PERMISSION_MISSING,
                               "device lacks the 'chat' permission", request_id=request_id)
                    continue
                result = await agent_loop.handle_command(
                    text, {"user_id": user_id, "role": principal["role"],
                           "device_id": device_id, "via": "device"},
                    source_device_id=device_id, request_id=request_id or None)
                status = result.get("status", Status.COMPLETED)
                await conn.send(protocol.envelope(
                    MessageType.COMMAND_RESULT, request_id=request_id,
                    task_id=result.get("task_id", ""), user_id=user_id,
                    target_device_id=device_id, status=status, payload=result))

            # ---------------- confirmation of a consequential action ---------- #
            elif mtype == MessageType.CONFIRMATION_RESULT:
                from ..services import agent_loop
                confirmation_id = str(payload.get("confirmation_id", ""))
                approved = bool(payload.get("approved"))
                try:
                    # resolve_confirmation re-checks that the confirmation
                    # belongs to THIS user, so one device cannot authorise
                    # another user's pending destructive action.
                    outcome = await agent_loop.resolve_confirmation(
                        confirmation_id, approved, user_id)
                except Exception as exc:          # unknown / stolen / expired id
                    await fail(ErrorCode.FORBIDDEN, str(exc), request_id=request_id)
                    continue
                await conn.send(protocol.envelope(
                    MessageType.COMMAND_RESULT, request_id=request_id,
                    user_id=user_id, target_device_id=device_id,
                    status=outcome.get("status", Status.COMPLETED), payload=outcome))

            elif mtype == MessageType.ERROR_EVENT:
                # the device telling us something went wrong on its side
                audit.record("device.error", "FAILED", user_id=user_id, source_device=device_id,
                             detail={"code": payload.get("code"),
                                     "message": str(payload.get("message"))[:200]})
                await conn.send(protocol.envelope(
                    MessageType.ACK, request_id=request_id, target_device_id=device_id,
                    status=Status.COMPLETED))

            elif mtype == MessageType.PONG:
                pass      # answer to our own keepalive; presence already touched

            else:
                await fail(ErrorCode.UNKNOWN_MESSAGE_TYPE,
                           f"unhandled message_type: {mtype}", request_id=request_id)

    except WebSocketDisconnect:
        pass
    except Exception as exc:
        audit.record("device.bus_error", "FAILED", source_device=device_id,
                     detail={"error": str(exc)})
    finally:
        await bus.unregister(device_id)
