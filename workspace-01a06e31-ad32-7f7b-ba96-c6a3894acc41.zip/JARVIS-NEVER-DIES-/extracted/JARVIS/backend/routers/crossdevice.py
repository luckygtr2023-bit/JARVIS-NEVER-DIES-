"""/api/protocol and /api/devices/route - the cross-device contract surface.

Two jobs:

  * `GET /api/protocol` lets a client (Android, a second PC, anything) discover
    the exact message contract at runtime and refuse to start if it is too old.
    Deliberately unauthenticated: it contains no user data, only the schema, and
    a device needs it BEFORE it has a token in order to pair correctly.

  * `POST /api/devices/{device_id}/tasks` is the explicit, typed way to send a
    task to another device, for clients that do not want to go through natural
    language. It runs the same security pipeline as the agent path (spec 9).
"""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .. import audit, capabilities, db, protocol
from ..device_bus import bus, create_task, update_task
from ..deps import current_principal, device_permissions
from ..protocol import ErrorCode, Status

router = APIRouter(prefix="/api", tags=["protocol"])


@router.get("/protocol")
def protocol_descriptor():
    """Machine-readable protocol contract. Unauthenticated by design."""
    return protocol.descriptor()


@router.get("/capabilities")
def capability_catalog():
    """The capability vocabulary. Also unauthenticated - it is a schema, not data."""
    return capabilities.catalog_public()


class RouteBody(BaseModel):
    kind: str = Field(default="command", max_length=40)
    payload: dict = Field(default_factory=dict)
    request_id: str = ""
    required_capability: str = ""
    timeout: float = Field(default=45.0, ge=1.0, le=300.0)


@router.post("/devices/{device_id}/tasks")
async def route_task(device_id: str, body: RouteBody,
                     principal: dict = Depends(current_principal)):
    """Send a typed task to one of MY devices and wait for its verified result.

    The full pipeline runs in order, and every refusal is explicit:
    identify target -> ownership -> state -> device permission -> capability ->
    presence -> execute -> verify -> audit.
    """
    user_id = principal["user_id"]

    row = db.one("SELECT * FROM devices WHERE device_id=?", (device_id,))
    if not row or row["user_id"] != user_id:
        # Ownership is by user_id, never by application or package name.
        raise HTTPException(status_code=404, detail="Unknown device.")
    if row["state"] != "ACTIVE":
        raise HTTPException(status_code=403,
                            detail=f"{row['name']} has been revoked and cannot be reached.")
    if row["is_host"] and body.kind == "command":
        raise HTTPException(status_code=400,
                            detail="That is this machine - run it locally instead of routing it.")

    if "chat" not in device_permissions(device_id):
        audit.record("task.route", "DENIED", user_id=user_id, target_device=device_id,
                     detail={"reason": "missing 'chat' permission"})
        raise HTTPException(status_code=403,
                            detail=f"{row['name']} does not have the 'chat' permission.")

    needed = body.required_capability or capabilities.capability_for_text(
        str(body.payload.get("text", "")))
    try:
        capabilities.assert_capable(device_id, needed, row["name"])
    except capabilities.CapabilityMismatch as exc:
        audit.record("task.route", "DENIED", user_id=user_id, target_device=device_id,
                     detail={"reason": "capability", "capability": exc.capability})
        raise HTTPException(status_code=409, detail={
            "code": ErrorCode.CAPABILITY_MISSING,
            "capability": exc.capability,
            "message": str(exc),
        })

    task = create_task(user_id, body.kind, body.payload, target_device_id=device_id,
                       request_id=body.request_id or None, status=Status.QUEUED)
    task_id = task["task_id"]

    # A retry with the same request_id returns the original task instead of
    # running the work twice (idempotency, spec 5/7).
    if task["status"] in (Status.COMPLETED, Status.FAILED, Status.CANCELLED):
        return {"task_id": task_id, "status": task["status"], "duplicate": True,
                "result": task.get("result"), "error": task.get("error")}

    if not bus.is_online(device_id):
        update_task(task_id, status=Status.FAILED, error=f"{row['name']} is offline.")
        audit.record("task.route", "OFFLINE", user_id=user_id, target_device=device_id,
                     task_id=task_id)
        return {"task_id": task_id, "status": Status.FAILED, "offline": True,
                "code": ErrorCode.TARGET_OFFLINE,
                "error": f"{row['name']} is offline.",
                "message": f"{row['name']} is offline, so nothing was executed."}

    update_task(task_id, status=Status.ASSIGNED)
    routed = await bus.dispatch(task_id, device_id, body.payload, timeout=body.timeout)

    if not routed.get("ok"):
        code = (ErrorCode.TIMEOUT if routed.get("timeout")
                else ErrorCode.TARGET_OFFLINE if routed.get("offline")
                else ErrorCode.INTERNAL)
        update_task(task_id, status=Status.FAILED, error=routed.get("error"))
        audit.record("task.route", "FAILED", user_id=user_id, target_device=device_id,
                     task_id=task_id, detail={"code": code})
        return {"task_id": task_id, "status": Status.FAILED, "code": code,
                "error": routed.get("error"), "verified": False}

    audit.record("task.route", "OK", user_id=user_id, target_device=device_id, task_id=task_id)
    return {"task_id": task_id, "status": Status.COMPLETED,
            "result": routed.get("result"),
            "verified": bool(routed.get("verified")),
            "completed_at": time.time()}


@router.get("/devices/{device_id}/presence")
def device_presence(device_id: str, principal: dict = Depends(current_principal)):
    """"Is my PC online?" - answered from real socket state, never assumed."""
    row = db.one("SELECT * FROM devices WHERE device_id=?", (device_id,))
    if not row or row["user_id"] != principal["user_id"]:
        raise HTTPException(status_code=404, detail="Unknown device.")
    online = bus.is_online(device_id)
    return {
        "device_id": device_id,
        "name": row["name"],
        "device_type": row["device_type"],
        "presence": "ONLINE" if online else "OFFLINE",
        "online": online,
        "state": row["state"],
        "last_seen": row["last_seen"],
        "last_seen_seconds_ago": (round(time.time() - row["last_seen"], 1)
                                  if row["last_seen"] else None),
        "capabilities": capabilities.device_capabilities(device_id),
    }
