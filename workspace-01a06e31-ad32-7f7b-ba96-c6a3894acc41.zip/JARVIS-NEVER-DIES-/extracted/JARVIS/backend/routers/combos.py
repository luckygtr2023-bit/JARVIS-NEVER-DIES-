"""/api/combos/* - OWNER/OPERATOR Combo management (spec 10).

Authorization model, enforced here and again in the store:
  * OWNER            : create / edit / delete / enable / assign / use anything
  * TRUSTED_USER     : may use only the Combos assigned to them or their role
  * LIMITED_USER     : may use only the Combos assigned to them or their role
  * the AI           : may READ, never mutate - every mutation requires an
                       authenticated OWNER session on this router
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .. import combos, db, security
from ..deps import current_principal, require_owner

router = APIRouter(prefix="/api/combos", tags=["combos"])


def _err(exc: Exception, status: int = 400):
    return HTTPException(status_code=status, detail=str(exc))


@router.get("")
def list_combos(principal: dict = Depends(current_principal)):
    """OWNER sees every Combo; everyone else sees only what they may actually use."""
    is_owner = principal["role"] == security.ROLE_OWNER
    items = combos.list_all() if is_owner else combos.list_permitted(
        principal["user_id"], principal["role"])
    return {
        "combos": items,
        "can_manage": is_owner,
        "selected": combos.selected_for(principal["user_id"], principal["role"]),
        "default": combos.default_identifier(),
        "roles": [r for r in security.ROLES if r != security.ROLE_OWNER],
        "users": [dict(r) for r in db.query(
            "SELECT user_id, username, role FROM users ORDER BY created_at")] if is_owner else [],
        "total": len(items),
        "limit": None,          # deliberately unlimited
    }


@router.get("/mine")
def my_combos(principal: dict = Depends(current_principal)):
    return {"combos": combos.list_permitted(principal["user_id"], principal["role"]),
            "selected": combos.selected_for(principal["user_id"], principal["role"])}


class SelectBody(BaseModel):
    omniroute_identifier: str


@router.post("/select")
def select(body: SelectBody, principal: dict = Depends(current_principal)):
    """A user picks their active Combo. Rejected server-side if unauthorized -
    sending a raw identifier through the API does not bypass anything."""
    try:
        identifier = combos.select_for(principal["user_id"], principal["role"],
                                       body.omniroute_identifier.strip())
    except combos.ComboPermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    return {"ok": True, "selected": identifier}


class ComboBody(BaseModel):
    display_name: str = Field(min_length=1, max_length=80)
    omniroute_identifier: str = Field(min_length=1, max_length=200)
    description: str = ""
    enabled: bool = True


@router.post("")
def create_combo(body: ComboBody, principal: dict = Depends(require_owner)):
    try:
        return combos.create_combo(body.display_name, body.omniroute_identifier,
                                   body.description, principal, body.enabled)
    except combos.ComboError as exc:
        raise _err(exc)


class ComboPatch(BaseModel):
    display_name: str | None = None
    omniroute_identifier: str | None = None
    description: str | None = None
    enabled: bool | None = None


@router.post("/{combo_id}")
def update_combo(combo_id: str, body: ComboPatch, principal: dict = Depends(require_owner)):
    try:
        return combos.update_combo(combo_id, principal, display_name=body.display_name,
                                   identifier=body.omniroute_identifier,
                                   description=body.description, enabled=body.enabled)
    except combos.ComboError as exc:
        raise _err(exc)


class EnableBody(BaseModel):
    enabled: bool


@router.post("/{combo_id}/enabled")
def set_enabled(combo_id: str, body: EnableBody, principal: dict = Depends(require_owner)):
    try:
        return combos.set_enabled(combo_id, body.enabled, principal)
    except combos.ComboError as exc:
        raise _err(exc)


@router.post("/{combo_id}/default")
def set_default(combo_id: str, principal: dict = Depends(require_owner)):
    try:
        return combos.set_default(combo_id, principal)
    except combos.ComboError as exc:
        raise _err(exc)


class DeleteBody(BaseModel):
    confirm: bool = False


@router.post("/{combo_id}/delete")
def delete_combo(combo_id: str, body: DeleteBody, principal: dict = Depends(require_owner)):
    """Destructive: the backend refuses until confirm=true is presented (spec 8)."""
    combo = combos.get_combo(combo_id)
    if not combo:
        raise HTTPException(status_code=404, detail="No such Combo.")
    if not body.confirm:
        raise HTTPException(
            status_code=409,
            detail=f"Deleting the Combo '{combo['display_name']}' "
                   f"({combo['omniroute_identifier']}) is permanent and removes "
                   f"{len(combo['assignments'])} assignment(s). Re-send with confirm=true.")
    try:
        return combos.delete_combo(combo_id, principal)
    except combos.ComboError as exc:
        raise _err(exc)


class AssignBody(BaseModel):
    subject_type: str
    subject_id: str


@router.post("/{combo_id}/assign")
def assign(combo_id: str, body: AssignBody, principal: dict = Depends(require_owner)):
    try:
        return combos.assign(combo_id, body.subject_type, body.subject_id, principal)
    except combos.ComboError as exc:
        raise _err(exc)


@router.post("/{combo_id}/unassign")
def unassign(combo_id: str, body: AssignBody, principal: dict = Depends(require_owner)):
    try:
        return combos.unassign(combo_id, body.subject_type, body.subject_id, principal)
    except combos.ComboError as exc:
        raise _err(exc)
