"""/api/auth/* - JARVIS accounts are username + password only (spec 3)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field

from .. import audit, db, security
from ..deps import current_principal, _bearer

router = APIRouter(prefix="/api/auth", tags=["auth"])


class Credentials(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class RegisterBody(Credentials):
    device_name: str | None = None


@router.get("/state")
def auth_state():
    """Used by the HUD to decide between the LOGIN and CREATE-OWNER screen."""
    return {
        "owner_exists": security.owner_exists(),
        "user_count": len(db.query("SELECT 1 FROM users")),
    }


@router.post("/register")
def register(body: RegisterBody):
    try:
        user = security.create_user(body.username, body.password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    token = security.create_session(user["user_id"])
    audit.record("auth.register", "OK", user_id=user["user_id"], detail={"role": user["role"]})
    db.log_activity("auth", f"Account created: {user['username']} ({user['role']})")
    return {"token": token, "user": user}


@router.post("/login")
def login(body: Credentials):
    user = security.authenticate(body.username, body.password)
    if not user:
        audit.record("auth.login", "DENIED", detail={"username": body.username})
        raise HTTPException(status_code=401, detail="Invalid username or password.")
    token = security.create_session(user["user_id"])
    audit.record("auth.login", "OK", user_id=user["user_id"])
    db.log_activity("auth", f"Login: {user['username']}")
    return {"token": token, "user": user}


@router.post("/logout")
def logout(authorization: str | None = Header(default=None),
           principal: dict = Depends(current_principal)):
    security.destroy_session(_bearer(authorization))
    audit.record("auth.logout", "OK", user_id=principal["user_id"])
    return {"ok": True}


@router.get("/me")
def me(principal: dict = Depends(current_principal)):
    return principal


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


@router.post("/password")
def change_password(body: PasswordChange, principal: dict = Depends(current_principal)):
    row = db.one("SELECT * FROM users WHERE user_id=?", (principal["user_id"],))
    if not row or not security.verify_password(body.current_password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Current password is incorrect.")
    try:
        new_hash = security.hash_password(body.new_password)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    db.execute("UPDATE users SET password_hash=? WHERE user_id=?", (new_hash, principal["user_id"]))
    db.execute("DELETE FROM sessions WHERE user_id=?", (principal["user_id"],))
    audit.record("auth.password_change", "OK", user_id=principal["user_id"])
    return {"ok": True, "sessions_invalidated": True}


@router.get("/users")
def list_users(principal: dict = Depends(current_principal)):
    security.require_role(principal, security.ROLE_OWNER) if principal["role"] != security.ROLE_OWNER else None
    rows = db.query("SELECT user_id, username, role, created_at, disabled FROM users ORDER BY created_at")
    return {"users": [dict(r) for r in rows]}
