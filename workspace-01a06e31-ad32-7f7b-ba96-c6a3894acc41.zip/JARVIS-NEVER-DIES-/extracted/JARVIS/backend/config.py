"""JARVIS configuration. No secrets are hardcoded; everything comes from env or the DB."""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _app_dir() -> Path:
    """Writable data dir. Works both from source and from a PyInstaller bundle."""
    env = os.environ.get("JARVIS_HOME")
    if env:
        p = Path(env)
    elif getattr(sys, "frozen", False):
        p = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "JARVIS"
    else:
        p = Path(__file__).resolve().parent.parent / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _bundle_dir() -> Path:
    """Directory holding read-only resources (webui) - differs under PyInstaller."""
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return Path(__file__).resolve().parent


APP_NAME = "J.A.R.V.I.S."
APP_VERSION = "1.0.0"
AUTHOR_LINE = "Made by Lucky Kumar."

DATA_DIR = _app_dir()
DB_PATH = Path(os.environ.get("JARVIS_DB", DATA_DIR / "jarvis.db"))
WEBUI_DIR = Path(os.environ.get("JARVIS_WEBUI", _bundle_dir() / "webui"))
PWA_DIR = Path(os.environ.get("JARVIS_PWA", _bundle_dir() / "pwa"))

HOST = os.environ.get("JARVIS_HOST", "0.0.0.0")
PORT = int(os.environ.get("JARVIS_PORT", "8420"))

# ---- AI endpoints (spec section 8) ----
OMNIROUTE_BASE = os.environ.get("OMNIROUTE_BASE", "http://127.0.0.1:20128/v1")
OLLAMA_BASE = os.environ.get("OLLAMA_BASE", "http://127.0.0.1:11434/v1")
OLLAMA_NATIVE = os.environ.get("OLLAMA_NATIVE", "http://127.0.0.1:11434")

# ---- Security knobs ----
SESSION_TTL_SECONDS = int(os.environ.get("JARVIS_SESSION_TTL", 60 * 60 * 24 * 14))
PAIRING_TTL_SECONDS = int(os.environ.get("JARVIS_PAIRING_TTL", 600))  # 10 minutes
PBKDF2_ITERATIONS = int(os.environ.get("JARVIS_PBKDF2_ITERS", 210_000))
DEVICE_OFFLINE_AFTER = int(os.environ.get("JARVIS_OFFLINE_AFTER", 45))  # seconds

# File access root for file tools (spec section: security & permissions)
FILE_ROOT = Path(os.environ.get("JARVIS_FILE_ROOT", Path.home()))

# ---- Google OAuth (only for Gmail/Calendar; never for JARVIS login) ----
GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
GOOGLE_REDIRECT_URI = os.environ.get(
    "GOOGLE_REDIRECT_URI", f"http://localhost:{PORT}/api/integrations/google/callback"
)

IS_WINDOWS = sys.platform.startswith("win")
