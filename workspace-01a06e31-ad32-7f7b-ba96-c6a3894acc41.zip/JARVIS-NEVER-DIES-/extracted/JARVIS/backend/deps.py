"""FastAPI dependencies: the single entry point of the permission pipeline (spec 23)."""
from __future__ import annotations

import json
from typing import Optional

from fastapi import Depends, Header, HTTPException, Request

from . import audit, db, security


def _bearer(authorization: Optional[str]) -> str:
    if not authorization:
        return ""
    parts = authorization.split(None, 1)
    if len(parts) == 2 and parts[0].lower() == "bearer":
        return parts[1].strip()
    return authorization.strip()


def current_principal(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    x_device_token: Optional[str] = Header(default=None, alias="X-Device-Token"),
) -> dict:
    """AUTHENTICATE -> IDENTIFY USER -> IDENTIFY SOURCE DEVICE."""
    token = _bearer(authorization)
    principal = None
    if x_device_token:
        principal = security.resolve_device_token(x_device_token)
    if principal is None and token:
        principal = security.resolve_session(token) or security.resolve_device_token(token)
    if principal is None:
        raise HTTPException(status_code=401, detail="Not authenticated.")
    request.state.principal = principal
    return principal


def optional_principal(
    request: Request,
    authorization: Optional[str] = Header(default=None),
    x_device_token: Optional[str] = Header(default=None, alias="X-Device-Token"),
) -> Optional[dict]:
    try:
        return current_principal(request, authorization, x_device_token)
    except HTTPException:
        return None


def require_owner(principal: dict = Depends(current_principal)) -> dict:
    if principal.get("role") != security.ROLE_OWNER:
        audit.record("authz.denied", "DENIED", user_id=principal.get("user_id"),
                     detail={"required": "OWNER", "had": principal.get("role")})
        raise HTTPException(status_code=403, detail="This action requires the OWNER role.")
    return principal


def check_permission(principal: dict, permission: str) -> None:
    """CHECK ROLE -> CHECK PERMISSION.

    A session on the host machine inherits the user's role. A paired device is
    additionally limited by the explicit permission grants the owner gave it.
    """
    if principal.get("via") == "device":
        row = db.one("SELECT * FROM devices WHERE device_id=?", (principal.get("device_id"),))
        if not security.device_has_permission(row, permission):
            audit.record(
                "authz.denied", "DENIED",
                user_id=principal.get("user_id"),
                source_device=principal.get("device_id"),
                detail={"permission": permission},
            )
            raise HTTPException(
                status_code=403,
                detail=f"This device does not have the '{permission}' permission. "
                       f"The owner can grant it in the DEVICES tab.",
            )
        return
    # Session principals: LIMITED_USER cannot do control-plane things.
    if permission in ("windows.control", "files.write", "devices.manage") and \
            security.role_rank(principal.get("role", "")) < security.role_rank(security.ROLE_TRUSTED):
        raise HTTPException(status_code=403, detail=f"Your role cannot use '{permission}'.")


def device_permissions(device_id: str) -> list[str]:
    row = db.one("SELECT permissions FROM devices WHERE device_id=?", (device_id,))
    if not row:
        return []
    try:
        return json.loads(row["permissions"] or "[]")
    except Exception:
        return []
