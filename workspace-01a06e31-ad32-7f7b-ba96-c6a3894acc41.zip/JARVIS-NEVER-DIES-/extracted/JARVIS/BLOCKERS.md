# Genuine blockers

Only things that truly cannot be done from this environment. Everything else in
the spec is implemented and verified.

## 1. `JARVIS.exe` cannot be produced or launched here — **BLOCKED (environment)**

The agent workspace is Linux:

```
Linux e2b.local 6.1.158+ x86_64 · Python 3.13 · no Windows API, no display, no mic
```

PyInstaller emits a binary for the OS it runs on. What was done instead:

* the PyInstaller spec (`scripts/jarvis.spec`) was **executed** here and produced a
  working single-file frozen binary
* that frozen binary was **launched** and passed the full 34/34 live verification,
  serving the bundled HUD from inside the archive

So the packaging configuration itself is proven — hidden imports resolve, the
`webui` data bundle is found, the stdio guards work under freezing. Running the
identical spec on Windows yields `JARVIS.exe`.

**What you do:** `scripts\BUILD_EXE.bat`, then `scripts\verify_exe.bat`, and paste
the output back. Any failure gets fixed in the source and rebuilt.

## 2. Windows-only runtime features — **NOT TESTED here, implemented**

`pywin32`, `pyautogui`, SAPI5 `pyttsx3`, tray behaviour, and the OS-level global
`V` hook cannot be exercised on Linux. They are implemented and guarded: on a
non-Windows host the tools report `Windows-only tool; this host is Linux`
instead of failing silently. `scripts/verify_exe.bat` walks you through checking
them on the real machine.

## 3. `faster-whisper` — **NOT INSTALLED here**

It is in `requirements.txt` and loaded lazily (`tiny.en`, int8 CPU). The endpoint
currently answers `501` with the install hint, which is the honest behaviour.
It will work on Windows after `pip install -r requirements.txt`.

## 4. OmniRoute and Ollama — **UNREACHABLE here, code verified**

Both live on `127.0.0.1` on *your* machine; this sandbox has neither. Verified
without them: probe logic, AUTO selection, the exact-combo rule, and the whole
error-handling matrix (JSON / text / HTML / empty / malformed / timeout /
connection refused / 429). Health honestly reports both as `UNAVAILABLE` with a
reason. Start them locally and press TEST AI in SETTINGS.

## 5. Gmail / Calendar — **CREDENTIAL_BLOCKED**

No `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`. Health says `CREDENTIAL_BLOCKED`
and `/api/integrations/google/auth-url` returns `503` with instructions rather
than faking a linked account. Fill in `backend/.env` from `.env.example`.

## 6. Tauri shell — **WRITTEN, NOT COMPILED**

`src-tauri/` (config, `Cargo.toml`, `main.rs` with `tauri-plugin-global-shortcut`
registering a real OS-level `V`, tray, minimise-instead-of-quit) is complete, but
there is no Rust toolchain here and Tauri's Windows target needs MSVC. The
PyInstaller path is the primary, verified deliverable; the Tauri shell is
optional and needs `cargo tauri build` on Windows.

Note the PyInstaller path does **not** depend on Tauri for the global hotkey —
`scripts/jarvis_entry.py` starts a `pynput` OS-level hook at launch.

## 7. Android APK — **NOT BUILT (as instructed)**

Not attempted, per the spec. The backend it will talk to is finished and tested:
see `docs/ANDROID_CLIENT.md`. The live verification includes a simulated Android
client that pairs, connects over the WebSocket bus, receives a routed task and
returns a verified result.

## 8. Original Git repository — **UNREACHABLE**

`https://github.com/luckygtr2023-bit/JARVIS-001.git` returns **404** to an
unauthenticated client (private or renamed), and the agent has no credentials.
This project was therefore rebuilt from the artifacts you uploaded — the
compiled HUD bundle gave the exact API surface and the exact design tokens, and
`docs/reference/old-hud.css` is that original stylesheet, reused verbatim so the
visual identity is not an approximation.

To fold this into the original repo: make it public briefly, or push this tree as
a branch from your own machine (`git remote add … && git push`).
