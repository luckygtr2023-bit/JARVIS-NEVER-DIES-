// J.A.R.V.I.S. Windows shell.
//
// Responsibilities:
//   1. own the window that displays the HUD served by the Python backend
//   2. register a REAL OS-level global shortcut for V (works while minimized,
//      while another app is focused, and while JARVIS sits in the tray)
//   3. minimise to tray instead of quitting, and shut down cleanly
//
// The V shortcut emits "jarvis://voice-toggle" to the HUD, which drives the
// same command queue as typing - voice and text never diverge.
#![cfg_attr(all(not(debug_assertions), target_os = "windows"), windows_subsystem = "windows")]

use tauri::{Emitter, Manager};
use tauri_plugin_global_shortcut::{Code, GlobalShortcutExt, Shortcut, ShortcutState};

fn main() {
    let voice_key = Shortcut::new(None, Code::KeyV);
    let escape_key = Shortcut::new(None, Code::Escape);

    tauri::Builder::default()
        .plugin(
            tauri_plugin_global_shortcut::Builder::new()
                .with_handler(move |app, shortcut, event| {
                    // Fire on key-down only: this is what stops key auto-repeat
                    // from toggling listening several times per physical press.
                    if event.state() != ShortcutState::Pressed {
                        return;
                    }
                    if shortcut == &voice_key {
                        let _ = app.emit("jarvis://voice-toggle", ());
                    } else if shortcut == &escape_key {
                        let _ = app.emit("jarvis://voice-cancel", ());
                    }
                })
                .build(),
        )
        .setup(move |app| {
            let handle = app.handle();
            match handle.global_shortcut().register(voice_key) {
                Ok(_) => println!("Global shortcut V registered (OS level)."),
                Err(e) => eprintln!("Could not register global V: {e}. The HUD falls back to a window-focused listener."),
            }
            let _ = handle.global_shortcut().register(escape_key);
            Ok(())
        })
        .on_window_event(|window, event| {
            // Closing the window hides JARVIS to the tray; it keeps running.
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                let _ = window.hide();
                api.prevent_close();
            }
        })
        .run(tauri::generate_context!())
        .expect("error while running JARVIS");
}
