@echo off
REM ===================================================================
REM  J.A.R.V.I.S. - Windows launcher
REM  Made by Lucky Kumar.
REM
REM  Extract the project, then double-click this file (or run it from a
REM  Command Prompt in the project root):
REM
REM      start_jarvis.bat
REM
REM  First run installs everything into a local .venv folder. Later runs
REM  start in a couple of seconds.
REM ===================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"
title J.A.R.V.I.S.

set "JARVIS_PORT=%JARVIS_PORT%"
if "%JARVIS_PORT%"=="" set "JARVIS_PORT=8420"
set "VENV=.venv"
set "PYEXE=%VENV%\Scripts\python.exe"
set "STAMP=%VENV%\.jarvis_deps_installed"

echo.
echo  ============================================================
echo   J.A.R.V.I.S.   Windows launcher
echo   Project: %CD%
echo  ============================================================
echo.

REM ---------------------------------------------------------------- #
REM  0. Already running? Just open the HUD - never start a second one
REM ---------------------------------------------------------------- #
curl -s -o nul -m 2 "http://127.0.0.1:%JARVIS_PORT%/api/health" >nul 2>&1
if not errorlevel 1 (
  echo  [i] JARVIS is already running on port %JARVIS_PORT%.
  echo      Opening the HUD in your browser instead of starting a second copy.
  start "" "http://localhost:%JARVIS_PORT%/"
  timeout /t 3 >nul
  exit /b 0
)

REM ---------------------------------------------------------------- #
REM  1. Python
REM ---------------------------------------------------------------- #
where python >nul 2>&1
if errorlevel 1 (
  echo  [FAIL] Python is not on PATH.
  echo         Install Python 3.11 or newer from https://python.org
  echo         and tick "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b 1
)

REM ---------------------------------------------------------------- #
REM  2. Virtual environment + dependencies (first run only)
REM ---------------------------------------------------------------- #
if not exist "%PYEXE%" (
  echo  [1/4] Creating the virtual environment in %VENV% ...
  python -m venv "%VENV%"
  if errorlevel 1 (
    echo  [FAIL] Could not create the virtual environment.
    pause
    exit /b 1
  )
) else (
  echo  [1/4] Virtual environment found.
)

if not exist "%STAMP%" (
  echo  [2/4] Installing Python dependencies ^(first run - this takes a few minutes^)...
  "%PYEXE%" -m pip install --upgrade pip --quiet
  "%PYEXE%" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo  [FAIL] pip install failed. Check your internet connection and retry.
    pause
    exit /b 1
  )
  REM Optional local text-to-speech. JARVIS runs fine without it and reports
  REM the missing engine honestly rather than pretending to speak.
  "%PYEXE%" -m pip install pyttsx3 --quiet
  echo installed > "%STAMP%"
) else (
  echo  [2/4] Dependencies already installed.
)

REM ---------------------------------------------------------------- #
REM  3. HUD - a prebuilt bundle ships with the project
REM ---------------------------------------------------------------- #
if exist "backend\webui\index.html" (
  echo  [3/4] HUD bundle present.
) else (
  echo  [3/4] HUD bundle missing - building it from frontend\ ...
  where npm >nul 2>&1
  if errorlevel 1 (
    echo  [FAIL] backend\webui is missing and npm is not installed.
    echo         Install Node.js 20+ from https://nodejs.org and run this again.
    pause
    exit /b 1
  )
  pushd frontend
  call npm install --no-audit --no-fund
  call npm run build
  popd
  if not exist "backend\webui\index.html" (
    echo  [FAIL] The HUD did not build.
    pause
    exit /b 1
  )
)

REM ---------------------------------------------------------------- #
REM  3b. Windows Firewall: allow inbound TCP 8420 on Private networks so the
REM      Android phone can reach the PWA. Requires an elevated shell; if this
REM      is not run as Administrator it is skipped (JARVIS still starts).
REM ---------------------------------------------------------------- #
netsh advfirewall firewall show rule name="JARVIS (TCP 8420)" >nul 2>&1
if errorlevel 1 (
  echo  [FIREWALL] Adding inbound allow rule for TCP 8420 ^(Private^)...
  netsh advfirewall firewall add rule name="JARVIS (TCP 8420)" ^
    dir=in action=allow protocol=TCP localport=8420 profile=private >nul 2>&1
  if errorlevel 1 (
    echo  [WARN] Could not add the firewall rule - you may need to run this
    echo         as Administrator, or allow the Python prompt in Windows
    echo         Defender Firewall when it appears.
  ) else (
    echo  [FIREWALL] Rule "JARVIS (TCP 8420)" added for inbound TCP 8420.
  )
) else (
  echo  [FIREWALL] Inbound rule "JARVIS (TCP 8420)" already present.
)

REM ---------------------------------------------------------------- #
REM  4. Run. The backend opens the HUD exactly once per process start.
REM ---------------------------------------------------------------- #
set "JARVIS_OPEN_BROWSER=1"
REM Bind to ALL interfaces (0.0.0.0) so your Android phone and other LAN
REM devices can reach the PWA at http://<this-pc-ip>:8420/pwa/ . If you want
REM a LOCAL-ONLY server, change 0.0.0.0 to 127.0.0.1 below.
set "JARVIS_HOST=0.0.0.0"
set "PYTHONUTF8=1"

echo  [4/4] Starting JARVIS on http://localhost:%JARVIS_PORT%/
echo        (Listening on 0.0.0.0:%JARVIS_PORT% - reachable from your LAN.)
echo        Android PWA:  http://<this-PC-IP>:%JARVIS_PORT%/pwa/
echo.
echo      The HUD opens automatically. Keep this window open - closing it
echo      stops JARVIS. Press Ctrl+C for a clean shutdown.
echo.
echo      First launch: create your account in the HUD. The FIRST account
echo      becomes the OWNER.
echo.

"%PYEXE%" -m backend.main
set "EXITCODE=%ERRORLEVEL%"

echo.
if "%EXITCODE%"=="0" (
  echo  JARVIS stopped cleanly.
) else (
  echo  JARVIS exited with code %EXITCODE%.
  echo  If that was unexpected, scroll up for the error, or run:
  echo      %PYEXE% -m backend.main
)
echo.
pause
endlocal
