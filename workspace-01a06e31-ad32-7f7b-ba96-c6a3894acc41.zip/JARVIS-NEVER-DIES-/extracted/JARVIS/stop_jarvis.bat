@echo off
REM ===================================================================
REM  Stop a JARVIS backend that is still running in the background
REM  (for example if its console window was closed without Ctrl+C).
REM ===================================================================
setlocal
set "JARVIS_PORT=%JARVIS_PORT%"
if "%JARVIS_PORT%"=="" set "JARVIS_PORT=8420"

echo Looking for JARVIS on port %JARVIS_PORT% ...
set "FOUND="
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /r /c:"LISTENING" ^| findstr ":%JARVIS_PORT% "') do (
  set "FOUND=1"
  echo   stopping PID %%P
  taskkill /PID %%P /F >nul 2>&1
)

if not defined FOUND (
  echo   nothing is listening on port %JARVIS_PORT% - JARVIS is not running.
) else (
  echo JARVIS stopped.
)
echo.
pause
endlocal
