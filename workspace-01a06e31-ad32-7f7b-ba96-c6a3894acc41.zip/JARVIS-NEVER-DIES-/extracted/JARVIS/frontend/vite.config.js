import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// The built HUD is written into backend/webui so the Python backend (and the
// PyInstaller bundle) can serve it directly. 'dist' is deliberately avoided.
export default defineConfig({
  plugins: [react()],
  build: { outDir: '../backend/webui', emptyOutDir: true, assetsDir: 'assets' },
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: false,
    allowedHosts: true,
    proxy: {
      '/api': { target: 'http://127.0.0.1:8420', changeOrigin: true, ws: true },
    },
  },
})
