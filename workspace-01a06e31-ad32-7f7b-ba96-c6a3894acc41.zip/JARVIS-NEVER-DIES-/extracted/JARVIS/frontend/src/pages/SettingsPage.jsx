import React, { useEffect, useState } from 'react'
import { del, get, post } from '../api'
import { Panel } from '../components/Hud'

export default function SettingsPage({ health, user }) {
  const [settings, setSettings] = useState(null)
  const [detect, setDetect] = useState(null)
  const [destinations, setDestinations] = useState([])
  const [destName, setDestName] = useState('')
  const [destUrl, setDestUrl] = useState('')
  const [status, setStatus] = useState('')
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState(null)

  const load = async () => {
    try {
      const [s, d, dest] = await Promise.all([get('/settings'), get('/ai/detect'), get('/destinations')])
      setSettings(s)
      setDetect(d)
      setDestinations(dest.destinations || [])
    } catch (err) {
      setStatus(err.message)
    }
  }

  useEffect(() => {
    load()
  }, [])

  if (!settings) return <Panel title="SETTINGS"><p className="dim-text small pad">Loading…</p></Panel>

  const saveAi = async (patch) => {
    setStatus('')
    try {
      const next = await post('/settings', { ai: { ...patch } })
      setSettings(next)
      setStatus('Saved.')
    } catch (err) {
      setStatus(err.message)
    }
  }

  const runTest = async () => {
    setTesting(true)
    setTestResult(null)
    try {
      setTestResult(await post('/ai/test', {}))
    } catch (err) {
      setTestResult({ ok: false, error: err.message })
    } finally {
      setTesting(false)
    }
  }

  const ai = settings.ai
  const omni = detect?.omniroute
  const olla = detect?.ollama

  return (
    <div className="stack">
      <Panel title="AI CONFIGURATION" right="mode · combo · model — nothing else needed">
        <div className="mem-form">
          <div className="provider-cards">
            <div className="provider-card">
              <div className="provider-top">
                <span className="provider-name">OMNIROUTE</span>
                <span className={`tag ${omni?.available ? 'safe' : 'off'}`}>
                  {omni?.available ? 'ONLINE' : 'OFFLINE'}
                </span>
              </div>
              <div className="provider-desc">
                {omni?.endpoint}
                <br />
                {omni?.available
                  ? `${(omni.combos || []).length} combo(s) advertised`
                  : omni?.error}
              </div>
            </div>
            <div className="provider-card">
              <div className="provider-top">
                <span className="provider-name">OLLAMA</span>
                <span className={`tag ${olla?.available ? 'safe' : 'off'}`}>
                  {olla?.available ? 'ONLINE' : 'OFFLINE'}
                </span>
              </div>
              <div className="provider-desc">
                {olla?.endpoint}
                <br />
                {olla?.available ? (olla.models || []).join(', ') || 'no models installed' : olla?.error}
              </div>
            </div>
          </div>

          <div className="auth-field">
            <label>AI MODE</label>
            <select
              className="field-input"
              value={ai.mode}
              onChange={(e) => saveAi({ mode: e.target.value })}
            >
              <option value="auto">AUTO — use whichever AI is actually up</option>
              <option value="omniroute">OMNIROUTE — cloud router</option>
              <option value="ollama">OLLAMA — local / offline</option>
            </select>
          </div>

          <div className="auth-field">
            <label>OMNIROUTE COMBO</label>
            <input
              className="field-input"
              defaultValue={ai.combo}
              placeholder="e.g. JARVIS-copy-2"
              onBlur={(e) => e.target.value !== ai.combo && saveAi({ combo: e.target.value })}
            />
            <span className="dim-text small">
              Sent to OmniRoute exactly as typed — no provider prefix, no whitelist. Any future Combo
              name works.
            </span>
          </div>

          <div className="auth-field">
            <label>OLLAMA MODEL</label>
            <select
              className="field-input"
              value={ai.ollama_model}
              onChange={(e) => saveAi({ ollama_model: e.target.value })}
            >
              <option value="">auto-detect from /api/tags</option>
              {(olla?.models || []).map((m) => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
              {ai.ollama_model && !(olla?.models || []).includes(ai.ollama_model) && (
                <option value={ai.ollama_model}>{ai.ollama_model} (saved)</option>
              )}
            </select>
          </div>

          <div className="btn-row">
            <button className="btn-primary" onClick={runTest} disabled={testing}>
              {testing ? 'TESTING…' : 'TEST AI'}
            </button>
            <button className="btn-cancel" onClick={load}>
              REFRESH
            </button>
          </div>
          {status && <div className="dim-text small">{status}</div>}
          {testResult && (
            <div className={testResult.ok ? 'hint' : 'auth-err'}>
              {testResult.ok
                ? `${testResult.provider} (${testResult.model}) replied: ${testResult.content?.slice(0, 160)}`
                : testResult.error}
            </div>
          )}
        </div>
      </Panel>

      <div className="page-grid two-col">
        <Panel title="VOICE SUBSYSTEM">
          <div className="mem-form">
            <div className="check-row">
              <span>STT ENGINE</span>
              <span className={health?.components?.voice_stt?.status === 'READY' ? 'green' : 'amber'}>
                {health?.components?.voice_stt?.detail || '—'}
              </span>
            </div>
            <div className="check-row">
              <span>TTS ENGINE</span>
              <span className={health?.components?.voice_tts?.status === 'READY' ? 'green' : 'amber'}>
                {health?.components?.voice_tts?.detail || '—'}
              </span>
            </div>
            <div className="check-row">
              <span>GLOBAL HOTKEY</span>
              <span className={settings.voice?.hotkey?.os_level ? 'green' : 'amber'}>
                {settings.voice?.hotkey?.os_level
                  ? `V — OS level (${settings.voice.hotkey.mechanism})`
                  : settings.voice?.hotkey?.error || 'window-focused fallback'}
              </span>
            </div>
            <p className="dim-text small">
              Press V to start listening, V again to send, ESC to cancel. Recording continues through
              natural pauses — it does not stop after a second of silence.
            </p>
            <p className="dim-text small">
              Local engines: <code>pip install faster-whisper pyttsx3</code>. Without them the HUD uses
              your browser's speech APIs.
            </p>
          </div>
        </Panel>

        <Panel title="SECURITY &amp; PERMISSIONS">
          <div className="mem-form">
            <div className="check-row">
              <span>SIGNED IN AS</span>
              <span className="amber">{user?.username} · {user?.role}</span>
            </div>
            <div className="check-row">
              <span>FILE ACCESS ROOT</span>
              <span className="dim-text">{settings.security.file_root}</span>
            </div>
            <div className="check-row">
              <span>DESTRUCTIVE ACTIONS</span>
              <span className="amber">{settings.security.destructive_actions}</span>
            </div>
            <div className="check-row">
              <span>SHELL COMMANDS</span>
              <span className="amber">{settings.security.shell_commands}</span>
            </div>
            <div className="check-row">
              <span>EMAILS / MESSAGES</span>
              <span className="amber">{settings.security.messages}</span>
            </div>
            <p className="dim-text small">
              JARVIS never performs sensitive actions silently. Every CONFIRM-level tool pauses and shows
              the authorization dialog — and the backend enforces it, not just the HUD.
            </p>
          </div>
        </Panel>
      </div>

      <Panel title="NAMED DESTINATIONS" right={`${destinations.length} configured`}>
        <div className="mem-form">
          <p className="dim-text small">
            Named places JARVIS can open: “open my Aternos server”, “open Gmail”. JARVIS never invents a
            URL — add yours here.
          </p>
          <div className="device-row">
            <input
              className="field-input"
              placeholder="name, e.g. my aternos server"
              value={destName}
              onChange={(e) => setDestName(e.target.value)}
            />
            <input
              className="field-input"
              placeholder="https://aternos.org/server/your-id"
              value={destUrl}
              onChange={(e) => setDestUrl(e.target.value)}
            />
            <button
              className="btn-primary"
              onClick={async () => {
                try {
                  await post('/destinations', { name: destName, url: destUrl })
                  setDestName('')
                  setDestUrl('')
                  load()
                } catch (err) {
                  setStatus(err.message)
                }
              }}
            >
              SAVE
            </button>
          </div>
          {destinations.map((d) => (
            <div className="check-row" key={d.name}>
              <span>{d.name.toUpperCase()}</span>
              <span className="dim-text">
                {d.url}{' '}
                <button
                  className="mini-btn"
                  onClick={async () => {
                    await del(`/destinations/${d.name}`)
                    load()
                  }}
                >
                  ✕
                </button>
              </span>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="COMPONENT HEALTH" right="honest status — never READY unless it really is">
        <div className="mem-form">
          {Object.entries(health?.components || {}).map(([name, c]) => (
            <div className="check-row" key={name}>
              <span>{name.toUpperCase().replace('_', ' ')}</span>
              <span className={c.status === 'READY' ? 'green' : c.status === 'UNAVAILABLE' ? 'amber' : 'red'}>
                {c.status} <span className="dim-text small">{c.detail}</span>
              </span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  )
}
