import React, { useEffect, useState } from 'react'
import { del, get, post } from '../api'
import { Panel } from '../components/Hud'

const SUBTABS = ['DEVICES', 'TASKS', 'AUDIT']

function Dot({ ok }) {
  return <span className={`device-dot ${ok ? 'ok' : 'fail'}`} />
}

export default function DevicesPage({ user }) {
  const [sub, setSub] = useState('DEVICES')
  const [devices, setDevices] = useState([])
  const [allPerms, setAllPerms] = useState([])
  const [pairings, setPairings] = useState([])
  const [tasks, setTasks] = useState([])
  const [audit, setAudit] = useState([])
  const [issued, setIssued] = useState(null)
  const [error, setError] = useState('')

  const isOwner = user?.role === 'OWNER'

  const load = async () => {
    try {
      const [d, p] = await Promise.all([get('/devices'), get('/devices/pairing')])
      setDevices(d.devices || [])
      setAllPerms(d.all_permissions || [])
      setPairings((p.pairings || []).filter((x) => x.status === 'PENDING'))
      if (sub === 'TASKS') setTasks((await get('/tasks?limit=80')).tasks || [])
      if (sub === 'AUDIT') setAudit((await get('/audit?limit=120')).entries || [])
    } catch (err) {
      setError(err.message)
    }
  }

  useEffect(() => {
    load()
    const id = setInterval(load, 7000)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sub])

  const act = async (fn) => {
    setError('')
    try {
      await fn()
      await load()
    } catch (err) {
      setError(err.message)
    }
  }

  const togglePerm = (device, perm) => {
    const next = device.permissions.includes(perm)
      ? device.permissions.filter((p) => p !== perm)
      : [...device.permissions, perm]
    act(() => post(`/devices/${device.device_id}/permissions`, { permissions: next }))
  }

  return (
    <Panel
      title="DEVICE COMMAND CENTER"
      className="full"
      right={
        <span>
          {SUBTABS.map((s) => (
            <button key={s} className={`nav-chip ${sub === s ? 'active' : ''}`} onClick={() => setSub(s)}>
              {s}
            </button>
          ))}
        </span>
      }
    >
      <div className="device-body">
        {error && <div className="auth-err">{error}</div>}

        {sub === 'DEVICES' && (
          <>
            {pairings.length > 0 && (
              <section className="device-section">
                <h3 className="device-h">PAIRING REQUESTS</h3>
                {pairings.map((p) => (
                  <div className="device-card pending-card" key={p.pairing_id}>
                    <div className="device-row">
                      <strong>{p.device_name}</strong>
                      <span className="device-meta">
                        {p.device_type} · code <code>{p.code_display}</code>
                      </span>
                    </div>
                    <div className="device-meta">
                      Confirm this code matches the one on the device screen before approving.
                    </div>
                    {isOwner ? (
                      <div className="device-actions">
                        <button
                          className="btn-primary"
                          onClick={() => act(async () => {
                            const r = await post(`/devices/pairing/${p.pairing_id}/approve`)
                            setIssued({ name: p.device_name, ...r })
                          })}
                        >
                          APPROVE
                        </button>
                        <button
                          className="btn-cancel"
                          onClick={() => act(() => post(`/devices/pairing/${p.pairing_id}/reject`))}
                        >
                          REJECT
                        </button>
                      </div>
                    ) : (
                      <div className="device-meta">Only the OWNER can approve devices.</div>
                    )}
                  </div>
                ))}
              </section>
            )}

            {issued && (
              <div className="device-card token-card">
                <div className="device-row">
                  <strong>{issued.name} approved</strong>
                </div>
                <div className="device-meta">
                  The device now exchanges its pairing code for a permanent credential. If it asks for a
                  token instead, use ISSUE TOKEN on the card below.
                </div>
                <button className="mini-btn" onClick={() => setIssued(null)}>
                  DISMISS
                </button>
              </div>
            )}

            <section className="device-section">
              <h3 className="device-h">REGISTERED DEVICES</h3>
              {devices.map((d) => (
                <div className={`device-card ${d.state === 'REVOKED' ? 'revoked' : ''}`} key={d.device_id}>
                  <div className="device-row">
                    <Dot ok={d.online} />
                    <strong>{d.name}</strong>
                    <span className="device-meta">
                      {d.device_type} · {d.is_host ? 'host' : 'paired'} · {d.online ? 'online' : 'offline'}
                    </span>
                    {isOwner && !d.is_host && (
                      <button
                        className="btn-danger"
                        onClick={() => act(() => post(`/devices/${d.device_id}/revoke`))}
                      >
                        REVOKE
                      </button>
                    )}
                  </div>
                  <div className="device-meta">
                    {d.device_id} · {d.os || 'unknown OS'}{d.os_version ? ` ${d.os_version}` : ''}
                    {' · '}last seen{' '}
                    {d.last_seen ? new Date(d.last_seen * 1000).toLocaleString() : 'never'}
                  </div>
                  {(d.capabilities || []).length > 0 && (
                    <div className="cap-line">
                      <span className="device-meta">CAN DO ·</span>
                      {d.capabilities.map((c) => (
                        <span key={c} className="cap-chip" title={c}>{c}</span>
                      ))}
                    </div>
                  )}
                  {!d.is_host && (
                    <div className="perm-grid">
                      {allPerms.map((p) => (
                        <label key={p} className={`perm-chip ${d.permissions.includes(p) ? 'on' : ''}`}>
                          <input
                            type="checkbox"
                            checked={d.permissions.includes(p)}
                            disabled={!isOwner}
                            onChange={() => togglePerm(d, p)}
                          />
                          {p}
                        </label>
                      ))}
                    </div>
                  )}
                  {isOwner && !d.is_host && d.state === 'ACTIVE' && (
                    <div className="device-actions">
                      <button
                        className="mini-btn"
                        onClick={() => act(async () => {
                          const r = await post(`/devices/${d.device_id}/issue-token`)
                          window.prompt('One-time device token (copy it into the device):', r.device_token)
                        })}
                      >
                        ISSUE TOKEN
                      </button>
                      <button
                        className="mini-btn"
                        onClick={() => {
                          const name = window.prompt('New name', d.name)
                          if (name) act(() => post(`/devices/${d.device_id}/rename`, { name }))
                        }}
                      >
                        RENAME
                      </button>
                      <button className="mini-btn" onClick={() => act(() => del(`/devices/${d.device_id}`))}>
                        REMOVE
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </section>

            <p className="dim-text small">
              A new device requests pairing and shows a PAIR-XXXX-XXXX code. Codes expire in 10 minutes,
              are single-use, and are never reusable as a password.
            </p>
          </>
        )}

        {sub === 'TASKS' && (
          <section className="device-section">
            {tasks.length === 0 && <p className="dim-text small">No tasks yet.</p>}
            {tasks.map((t) => (
              <div className="device-card" key={t.task_id}>
                <div className="device-row">
                  <span className={`chip ${t.status === 'COMPLETED' ? 'chip-ok' : t.status === 'FAILED' ? 'chip-warn' : ''}`}>
                    {t.status}
                  </span>
                  <strong>{t.kind}</strong>
                  <span className="device-meta">{new Date(t.created_at * 1000).toLocaleString()}</span>
                </div>
                <div className="device-meta">{t.payload}</div>
                {t.error && <div className="error-text">{t.error}</div>}
                <div className="device-meta">verification: {t.verification}</div>
              </div>
            ))}
          </section>
        )}

        {sub === 'AUDIT' && (
          <section className="device-section">
            {audit.length === 0 && <p className="dim-text small">Audit log is empty.</p>}
            {audit.map((a) => (
              <div className="activity-row" key={a.id}>
                <span className="activity-icon">▸</span>
                <div className="activity-main">
                  <div className="activity-title">
                    {a.action} — <span className={a.result === 'OK' ? 'green' : 'amber'}>{a.result}</span>
                  </div>
                  {a.detail && <div className="activity-detail">{a.detail}</div>}
                </div>
                <span className="activity-time">
                  {new Date(a.ts * 1000).toLocaleTimeString('en-US', { hour12: false })}
                </span>
              </div>
            ))}
          </section>
        )}
      </div>
    </Panel>
  )
}
