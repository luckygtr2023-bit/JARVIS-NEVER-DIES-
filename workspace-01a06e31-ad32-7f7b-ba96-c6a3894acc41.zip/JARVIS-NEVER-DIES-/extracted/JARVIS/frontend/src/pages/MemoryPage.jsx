import React, { useEffect, useState } from 'react'
import { del, get, post } from '../api'
import { Panel } from '../components/Hud'

export default function MemoryPage() {
  const [memories, setMemories] = useState([])
  const [categories, setCategories] = useState(['fact'])
  const [key, setKey] = useState('')
  const [value, setValue] = useState('')
  const [category, setCategory] = useState('fact')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const load = async () => {
    try {
      const data = await get('/memory')
      setMemories(data.memories || [])
      setCategories(data.categories || ['fact'])
    } catch (err) {
      setError(err.message)
    }
  }

  useEffect(() => {
    load()
  }, [])

  const store = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      await post('/memory', { key: key.trim(), value: value.trim(), category })
      setKey('')
      setValue('')
      await load()
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  const remove = async (id) => {
    await del(`/memory/${id}`).catch((err) => setError(err.message))
    load()
  }

  const clearAll = async () => {
    if (!window.confirm('Clear every stored memory?')) return
    await del('/memory').catch((err) => setError(err.message))
    load()
  }

  return (
    <div className="page-grid two-col">
      <Panel title="PERSISTENT MEMORY" right={`${memories.length} items`}>
        <div className="activity-scroll">
          {memories.length === 0 && (
            <p className="dim-text small pad">No memories yet. Tell JARVIS “remember that …” or add one manually.</p>
          )}
          {memories.map((m) => (
            <div className="memory-row" key={m.id}>
              <div className="memory-main">
                <div className="memory-key">{m.key}</div>
                <div className="memory-value">{m.value}</div>
              </div>
              <span className="chip">{m.category}</span>
              <button className="mini-btn" onClick={() => remove(m.id)} title="Forget">
                ✕
              </button>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="MEMORY CONTROL">
        <form className="mem-form" onSubmit={store}>
          <div className="auth-field">
            <label>KEY</label>
            <input
              className="field-input"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="e.g. favorite_city"
            />
          </div>
          <div className="auth-field">
            <label>VALUE</label>
            <textarea
              className="field-input"
              rows={3}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="e.g. Patna"
            />
          </div>
          <div className="auth-field">
            <label>CATEGORY</label>
            <select className="field-input" value={category} onChange={(e) => setCategory(e.target.value)}>
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          {error && <div className="auth-err">{error}</div>}
          <div className="btn-row">
            <button className="btn-primary" type="submit" disabled={busy || !key || !value}>
              STORE
            </button>
            <button className="btn-cancel" type="button" onClick={clearAll}>
              CLEAR ALL
            </button>
          </div>
          <p className="dim-text small">
            Credentials (passwords, API keys, tokens) are automatically refused by the memory guard.
          </p>
        </form>
      </Panel>
    </div>
  )
}
