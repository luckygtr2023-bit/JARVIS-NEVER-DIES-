import React, { useEffect, useState } from 'react'
import { get, post, setToken } from '../api'

/** JARVIS login is username + password. Google is never used to sign in here. */
export default function AuthGate({ onAuthenticated }) {
  const [state, setState] = useState(null)
  const [mode, setMode] = useState('login')
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    let alive = true
    get('/auth/state')
      .then((s) => {
        if (!alive) return
        setState(s)
        setMode(s.owner_exists ? 'login' : 'register')
      })
      .catch(() => alive && setError('Backend unreachable — is JARVIS running?'))
    return () => {
      alive = false
    }
  }, [])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    setBusy(true)
    try {
      const data = await post(mode === 'login' ? '/auth/login' : '/auth/register', {
        username: username.trim(),
        password,
      })
      setToken(data.token)
      onAuthenticated(data.user)
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  const firstOwner = state && !state.owner_exists

  return (
    <div className="auth-shell">
      <form className="auth-card" onSubmit={submit}>
        <div className="auth-title">J.A.R.V.I.S.</div>
        <div className="auth-sub">
          {firstOwner ? 'OWNER INITIALIZATION' : mode === 'login' ? 'IDENTIFY YOURSELF' : 'CREATE ACCOUNT'}
        </div>

        <div className="auth-field">
          <label htmlFor="u">USERNAME</label>
          <input
            id="u"
            className="field-input"
            autoComplete="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="lucky"
            autoFocus
          />
        </div>
        <div className="auth-field">
          <label htmlFor="p">PASSWORD</label>
          <input
            id="p"
            className="field-input"
            type="password"
            autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="at least 6 characters"
          />
        </div>

        {error && <div className="auth-err">{error}</div>}

        <button className="btn-primary" type="submit" disabled={busy || !username || !password}>
          {busy ? 'WORKING…' : mode === 'login' ? 'LOG IN' : 'CREATE ACCOUNT'}
        </button>

        {!firstOwner && (
          <button
            type="button"
            className="auth-toggle"
            onClick={() => {
              setMode(mode === 'login' ? 'register' : 'login')
              setError('')
            }}
          >
            {mode === 'login' ? 'Create a new account' : 'I already have an account'}
          </button>
        )}

        <div className="auth-note">
          {firstOwner
            ? 'No OWNER exists yet — the first account created becomes the OWNER. Every later account is a LIMITED_USER until the owner promotes it.'
            : 'Passwords are stored only as PBKDF2-SHA256 hashes. Google sign-in is used only for Gmail and Calendar, never for the JARVIS account.'}
        </div>
      </form>
    </div>
  )
}
