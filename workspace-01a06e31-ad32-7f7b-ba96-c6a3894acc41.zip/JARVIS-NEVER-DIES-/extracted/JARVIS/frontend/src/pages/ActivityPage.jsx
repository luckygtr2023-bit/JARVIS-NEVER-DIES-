import React, { useEffect, useMemo, useState } from 'react'
import { get } from '../api'
import { Panel } from '../components/Hud'

export default function ActivityPage() {
  const [events, setEvents] = useState([])
  const [tools, setTools] = useState([])
  const [filter, setFilter] = useState('')

  useEffect(() => {
    let alive = true
    const load = async () => {
      try {
        const [a, t] = await Promise.all([get('/activity?limit=200'), get('/tools')])
        if (!alive) return
        setEvents(a.events || [])
        setTools(t.tools || [])
      } catch {
        /* surfaced by the status bar */
      }
    }
    load()
    const id = setInterval(load, 6000)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [])

  const shown = useMemo(() => {
    const q = filter.trim().toLowerCase()
    if (!q) return tools
    return tools.filter(
      (t) => t.name.includes(q) || t.category.includes(q) || t.description.toLowerCase().includes(q),
    )
  }, [tools, filter])

  return (
    <div className="page-grid two-col">
      <Panel title="FULL ACTIVITY FEED" right={`${events.length} events`}>
        <div className="activity-scroll">
          {events.length === 0 && <p className="dim-text small pad">Nothing logged yet.</p>}
          {events.map((e) => (
            <div className="activity-row" key={e.id}>
              <span className="activity-icon">◆</span>
              <div className="activity-main">
                <div className="activity-title">{e.title}</div>
                {e.detail && <div className="activity-detail">{String(e.detail).slice(0, 200)}</div>}
              </div>
              <span className="activity-time">
                {new Date(e.ts * 1000).toLocaleTimeString('en-US', { hour12: false })}
              </span>
            </div>
          ))}
        </div>
      </Panel>

      <Panel
        title="REGISTERED TOOLS"
        right={
          <input
            className="inline-filter"
            placeholder="filter…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          />
        }
      >
        <div className="activity-scroll">
          {shown.map((t) => (
            <div className="tool-row" key={t.name}>
              <div className="tool-top">
                <span className="tool-name">{t.name}</span>
                <span className={`tag ${t.risk === 'CONFIRM' ? 'confirm' : 'safe'}`}>
                  {t.risk === 'CONFIRM' ? '⚠ CONFIRM' : 'SAFE'}
                </span>
                <span className="chip">{t.category}</span>
                {!t.available && <span className="tag off">UNAVAILABLE</span>}
              </div>
              <div className="tool-desc">{t.description}</div>
              {!t.available && t.unavailable_reason && (
                <div className="tool-desc dim-text">{t.unavailable_reason}</div>
              )}
            </div>
          ))}
        </div>
      </Panel>
    </div>
  )
}
