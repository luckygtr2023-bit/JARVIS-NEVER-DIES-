import React, { useEffect, useMemo, useState } from 'react'
import { get, post } from '../api'
import { Panel } from '../components/Hud'

/**
 * COMBO CONTROL — OWNER/OPERATOR management of OmniRoute Combos (spec 10).
 *
 * Everything here is a thin skin over /api/combos. The UI never decides who may
 * use what: it renders what the backend returned for THIS principal. A
 * non-OWNER simply receives fewer Combos and no management controls, and even
 * if they forged the requests the router would refuse them.
 *
 * Combo identifiers are rendered verbatim in a monospace field and sent back
 * verbatim — no provider prefix is ever added.
 */

const EMPTY = { display_name: '', omniroute_identifier: '', description: '', enabled: true }

function Dot({ on }) {
  return <span className={`device-dot ${on ? 'ok' : 'fail'}`} />
}

export default function CombosPage({ user }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [draft, setDraft] = useState(EMPTY)
  const [editing, setEditing] = useState(null)   // combo_id being edited
  const [editDraft, setEditDraft] = useState(EMPTY)
  const [confirming, setConfirming] = useState(null) // {combo, message}
  const [assignFor, setAssignFor] = useState(null)   // combo_id

  const isOwner = user?.role === 'OWNER'

  const load = async () => {
    try {
      setData(await get('/combos'))
    } catch (err) {
      setError(err.message)
    }
  }

  useEffect(() => {
    load()
    const id = setInterval(load, 12000)
    return () => clearInterval(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const act = async (fn, ok) => {
    setError('')
    setNotice('')
    try {
      const r = await fn()
      if (ok) setNotice(typeof ok === 'function' ? ok(r) : ok)
      await load()
      return r
    } catch (err) {
      setError(err.message)
      throw err
    }
  }

  const combos = data?.combos || []
  const users = data?.users || []
  const roles = data?.roles || []
  const selected = data?.selected || ''

  const stats = useMemo(() => ({
    total: combos.length,
    enabled: combos.filter((c) => c.enabled).length,
    assigned: combos.filter((c) => (c.assignments || []).length > 0).length,
  }), [combos])

  const create = async () => {
    if (!draft.display_name.trim() || !draft.omniroute_identifier.trim()) {
      setError('A Combo needs a display name and an OmniRoute identifier.')
      return
    }
    await act(() => post('/combos', draft), (r) => `Added ${r.display_name} → ${r.omniroute_identifier}`)
    setDraft(EMPTY)
  }

  const askDelete = async (combo) => {
    // Fire the unconfirmed call so the BACKEND writes the warning text (spec 18):
    // the UI never invents its own consequence description.
    try {
      await post(`/combos/${combo.combo_id}/delete`, { confirm: false })
      await load()
    } catch (err) {
      setConfirming({ combo, message: err.message })
    }
  }

  return (
    <Panel
      title="COMBO CONTROL"
      className="full"
      right={
        <span className="combo-headline">
          {stats.total} COMBOS · {stats.enabled} ENABLED · LIMIT{' '}
          <span className="green">UNLIMITED</span>
        </span>
      }
    >
      <div className="device-body">
        {error && <div className="auth-err">{error}</div>}
        {notice && <div className="combo-notice">{notice}</div>}

        {/* ---- what this principal is actually using ---------------------- */}
        <section className="device-section">
          <h3 className="device-h">ACTIVE UPLINK</h3>
          <div className="device-card">
            <div className="device-row">
              <Dot on={!!selected} />
              <strong className="mono">{selected || 'NONE PERMITTED'}</strong>
              <span className="device-meta">
                {user?.username} · {user?.role}
              </span>
            </div>
            <div className="device-meta">
              Sent to OmniRoute exactly as written. The server re-checks your permission on every
              request, so a Combo revoked mid-session stops working immediately.
            </div>
            {combos.length > 0 && (
              <div className="combo-pick">
                {combos.filter((c) => c.enabled).map((c) => (
                  <button
                    key={c.combo_id}
                    className={`nav-chip ${c.omniroute_identifier === selected ? 'active' : ''}`}
                    onClick={() => act(
                      () => post('/combos/select', { omniroute_identifier: c.omniroute_identifier }),
                      `Active Combo: ${c.omniroute_identifier}`,
                    )}
                    title={c.omniroute_identifier}
                  >
                    {c.display_name}
                  </button>
                ))}
              </div>
            )}
            {combos.length === 0 && (
              <div className="device-meta">
                No Combos are assigned to you. Ask the OWNER to grant one.
              </div>
            )}
          </div>
        </section>

        {/* ---- the registry ---------------------------------------------- */}
        <section className="device-section">
          <h3 className="device-h">
            {isOwner ? 'COMBO REGISTRY' : 'COMBOS AVAILABLE TO YOU'}
          </h3>

          {combos.map((c) => (
            <div className={`device-card ${c.enabled ? '' : 'revoked'}`} key={c.combo_id}>
              {editing === c.combo_id ? (
                <div className="combo-edit">
                  <div className="field-row">
                    <label>DISPLAY NAME</label>
                    <input
                      value={editDraft.display_name}
                      onChange={(e) => setEditDraft({ ...editDraft, display_name: e.target.value })}
                    />
                  </div>
                  <div className="field-row">
                    <label>OMNIROUTE IDENTIFIER</label>
                    <input
                      className="mono"
                      value={editDraft.omniroute_identifier}
                      onChange={(e) =>
                        setEditDraft({ ...editDraft, omniroute_identifier: e.target.value })}
                    />
                  </div>
                  <div className="field-row">
                    <label>NOTE</label>
                    <input
                      value={editDraft.description}
                      onChange={(e) => setEditDraft({ ...editDraft, description: e.target.value })}
                    />
                  </div>
                  <div className="device-actions">
                    <button
                      className="btn-primary"
                      onClick={() => act(
                        () => post(`/combos/${c.combo_id}`, editDraft),
                        'Combo updated.',
                      ).then(() => setEditing(null)).catch(() => {})}
                    >
                      SAVE
                    </button>
                    <button className="btn-cancel" onClick={() => setEditing(null)}>CANCEL</button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="device-row">
                    <Dot on={c.enabled} />
                    <strong>{c.display_name}</strong>
                    {c.is_default && <span className="chip chip-ok">DEFAULT</span>}
                    {!c.enabled && <span className="chip chip-warn">DISABLED</span>}
                    {c.omniroute_identifier === selected && <span className="chip">IN USE</span>}
                  </div>
                  <div className="device-meta mono combo-id">{c.omniroute_identifier}</div>
                  {c.description && <div className="device-meta">{c.description}</div>}

                  {isOwner && (
                    <div className="combo-assign-line">
                      <span className="device-meta">ACCESS ·</span>
                      {(c.assignments || []).length === 0 && (
                        <span className="device-meta dim-text">OWNER only</span>
                      )}
                      {(c.assignments || []).map((a) => (
                        <button
                          key={`${a.subject_type}:${a.subject_id}`}
                          className="perm-chip on"
                          title="Click to revoke"
                          onClick={() => act(
                            () => post(`/combos/${c.combo_id}/unassign`, a),
                            `Revoked ${a.label}.`,
                          )}
                        >
                          {a.subject_type === 'role' ? '◆' : '●'} {a.label} ✕
                        </button>
                      ))}
                      <button
                        className="mini-btn"
                        onClick={() => setAssignFor(assignFor === c.combo_id ? null : c.combo_id)}
                      >
                        + GRANT
                      </button>
                    </div>
                  )}

                  {isOwner && assignFor === c.combo_id && (
                    <div className="combo-grant">
                      <div className="device-meta">GRANT TO A ROLE</div>
                      <div className="combo-pick">
                        {roles.map((r) => (
                          <button
                            key={r}
                            className="nav-chip"
                            onClick={() => act(
                              () => post(`/combos/${c.combo_id}/assign`,
                                { subject_type: 'role', subject_id: r }),
                              `Granted to every ${r}.`,
                            )}
                          >
                            {r}
                          </button>
                        ))}
                      </div>
                      <div className="device-meta">GRANT TO ONE USER</div>
                      <div className="combo-pick">
                        {users.filter((u) => u.role !== 'OWNER').map((u) => (
                          <button
                            key={u.user_id}
                            className="nav-chip"
                            onClick={() => act(
                              () => post(`/combos/${c.combo_id}/assign`,
                                { subject_type: 'user', subject_id: u.user_id }),
                              `Granted to ${u.username}.`,
                            )}
                          >
                            {u.username}
                          </button>
                        ))}
                        {users.filter((u) => u.role !== 'OWNER').length === 0 && (
                          <span className="device-meta dim-text">
                            No other accounts exist yet.
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {isOwner && (
                    <div className="device-actions">
                      <button
                        className="mini-btn"
                        onClick={() => { setEditing(c.combo_id); setEditDraft({ ...c }) }}
                      >
                        EDIT
                      </button>
                      <button
                        className="mini-btn"
                        onClick={() => act(
                          () => post(`/combos/${c.combo_id}/enabled`, { enabled: !c.enabled }),
                          c.enabled ? 'Combo disabled.' : 'Combo enabled.',
                        )}
                      >
                        {c.enabled ? 'DISABLE' : 'ENABLE'}
                      </button>
                      {!c.is_default && c.enabled && (
                        <button
                          className="mini-btn"
                          onClick={() => act(
                            () => post(`/combos/${c.combo_id}/default`),
                            `${c.display_name} is now the default.`,
                          )}
                        >
                          MAKE DEFAULT
                        </button>
                      )}
                      <button className="btn-danger" onClick={() => askDelete(c)}>DELETE</button>
                    </div>
                  )}
                </>
              )}
            </div>
          ))}

          {combos.length === 0 && (
            <p className="dim-text small">Registry is empty.</p>
          )}
        </section>

        {/* ---- add ------------------------------------------------------- */}
        {isOwner && (
          <section className="device-section">
            <h3 className="device-h">ADD COMBO</h3>
            <div className="device-card">
              <div className="field-row">
                <label>DISPLAY NAME</label>
                <input
                  placeholder="e.g. Research"
                  value={draft.display_name}
                  onChange={(e) => setDraft({ ...draft, display_name: e.target.value })}
                />
              </div>
              <div className="field-row">
                <label>OMNIROUTE IDENTIFIER</label>
                <input
                  className="mono"
                  placeholder="e.g. JARVIS-copy-13"
                  value={draft.omniroute_identifier}
                  onChange={(e) => setDraft({ ...draft, omniroute_identifier: e.target.value })}
                  onKeyDown={(e) => e.key === 'Enter' && create()}
                />
              </div>
              <div className="field-row">
                <label>NOTE</label>
                <input
                  placeholder="optional"
                  value={draft.description}
                  onChange={(e) => setDraft({ ...draft, description: e.target.value })}
                />
              </div>
              <div className="device-actions">
                <button className="btn-primary" onClick={create}>ADD COMBO</button>
              </div>
              <p className="dim-text small">
                Stored and transmitted byte-for-byte. There is no whitelist and no cap — add
                JARVIS-copy-13, JARVIS-copy-400 or any future name and it works the moment you
                save it.
              </p>
            </div>
          </section>
        )}

        <p className="dim-text small">
          OWNER may use and manage every Combo. TRUSTED_USER and LIMITED_USER may use only what is
          granted to them here, and JARVIS itself can read this registry but can never grant itself
          access — every change on this screen requires an authenticated OWNER session and is
          written to the audit log.
        </p>
      </div>

      {/* backend-worded confirmation for the destructive path */}
      {confirming && (
        <div className="modal-backdrop">
          <div className="modal">
            <div className="modal-scan" />
            <div className="modal-head">AUTHORIZATION REQUIRED</div>
            <p className="modal-desc">{confirming.message}</p>
            <div className="modal-args-title">{confirming.combo.display_name}</div>
            <pre className="modal-args">{confirming.combo.omniroute_identifier}</pre>
            <div className="modal-actions">
              <button className="btn-cancel" onClick={() => setConfirming(null)}>CANCEL</button>
              <button
                className="btn-authorize"
                onClick={() => act(
                  () => post(`/combos/${confirming.combo.combo_id}/delete`, { confirm: true }),
                  'Combo deleted.',
                ).finally(() => setConfirming(null))}
              >
                DELETE
              </button>
            </div>
          </div>
        </div>
      )}
    </Panel>
  )
}
