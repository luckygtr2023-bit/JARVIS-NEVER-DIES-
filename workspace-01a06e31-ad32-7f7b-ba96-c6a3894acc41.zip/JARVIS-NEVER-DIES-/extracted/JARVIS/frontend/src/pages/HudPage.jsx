import React, { useCallback, useEffect, useRef, useState } from 'react'
import { get, post, streamChat, getToken, sessionStore } from '../api'
import { ConfirmModal, Core, Panel, Waveform } from '../components/Hud'

const GREETED_KEY = 'jarvis.greeted'

function Telemetry({ status }) {
  const bar = (label, value) => (
    <div className="tele-row" key={label}>
      <span className="tele-label">{label}</span>
      <span className="tele-bar">
        <span className="tele-fill" style={{ width: `${Math.min(100, value ?? 0)}%` }} />
      </span>
      <span className="tele-value">{value == null ? '—' : `${value}%`}</span>
    </div>
  )
  const cell = (k, v) => (
    <div key={k}>
      <span className="tele-k">{k}</span>
      <span className="tele-v">{v}</span>
    </div>
  )
  return (
    <div className="tele-body">
      {bar('CPU', status?.cpu)}
      {bar('RAM', status?.ram)}
      {bar('DSK', status?.disk)}
      <div className="tele-grid">
        {cell('BAT', status?.battery != null ? `${status.battery}%` : 'n/a')}
        {cell('PROC', status?.processes ?? '—')}
        {cell('MEM-DB', status?.memories ?? 0)}
        {cell('PENDING', status?.pending_tasks ?? 0)}
        {cell('RAM', status ? `${status.ram_used_gb}/${status.ram_total_gb} GB` : '—')}
        {cell('UP', status ? `${status.uptime_minutes}m` : '—')}
      </div>
    </div>
  )
}

export default function HudPage({ health, onVoiceState, user }) {
  const [messages, setMessages] = useState([])
  const [draft, setDraft] = useState('')
  const [state, setState] = useState('READY')
  const [status, setStatus] = useState(null)
  const [activity, setActivity] = useState([])
  const [pending, setPending] = useState(null)
  const [confirmBusy, setConfirmBusy] = useState(false)
  const [speakReplies, setSpeakReplies] = useState(false)
  const [listening, setListening] = useState(false)

  const busyRef = useRef(false)
  const abortRef = useRef(null)
  const scrollRef = useRef(null)
  const queueRef = useRef([])
  const mediaRef = useRef(null)

  const setPhase = useCallback(
    (next) => {
      setState(next)
      onVoiceState?.(next)
    },
    [onVoiceState],
  )

  // ---- greeting: exactly once per real application session (spec 15) ----- //
  useEffect(() => {
    const already = sessionStore.get(GREETED_KEY)
    if (already) {
      setMessages((m) => (m.length ? m : [{ role: 'assistant', text: already }]))
      return
    }
    let alive = true
    get('/greeting')
      .then((g) => {
        if (!alive) return
        sessionStore.set(GREETED_KEY, g.text)
        setMessages([{ role: 'assistant', text: g.text }])
        if (speakReplies) speak(g.text)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ---- telemetry + activity polling ------------------------------------- //
  useEffect(() => {
    let alive = true
    const tick = async () => {
      try {
        const [s, a] = await Promise.all([get('/system/status'), get('/activity?limit=40')])
        if (!alive) return
        setStatus(s)
        setActivity(a.events || [])
      } catch {
        /* handled by the health indicator */
      }
    }
    tick()
    const id = setInterval(tick, 5000)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages])

  const speak = (text) => {
    try {
      if (!window.speechSynthesis) return
      window.speechSynthesis.cancel()
      const u = new SpeechSynthesisUtterance(text)
      u.rate = 1.05
      u.onstart = () => setPhase('SPEAKING')
      u.onend = () => setPhase('READY')
      window.speechSynthesis.speak(u)
    } catch {
      /* browser speech unavailable */
    }
  }

  // ---- command pipeline (voice and typing share it, spec 14) ------------- //
  const send = useCallback(
    async (text) => {
      const clean = (text ?? '').trim()
      if (!clean) return
      if (busyRef.current) {
        queueRef.current.push(clean)     // FIFO queue, never a dropped command
        return
      }
      busyRef.current = true
      setMessages((m) => [...m, { role: 'user', text: clean }])
      setDraft('')
      setPhase('THINKING')

      const controller = new AbortController()
      abortRef.current = controller
      const watchdog = setTimeout(() => controller.abort(), 120000)   // never stuck
      let acc = ''
      const index = { current: null }

      try {
        await streamChat(clean, {
          signal: controller.signal,
          requestId: `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
          onEvent: (evt) => {
            if (evt.type === 'delta') {
              acc += evt.text
              setMessages((m) => {
                const copy = [...m]
                if (index.current == null) {
                  copy.push({ role: 'assistant', text: acc, streaming: true })
                  index.current = copy.length - 1
                } else {
                  copy[index.current] = { role: 'assistant', text: acc, streaming: true }
                }
                return copy
              })
            } else if (evt.type === 'result') {
              const p = evt.payload || {}
              if (p.status === 'WAITING_CONFIRMATION') {
                setPending({ confirm_id: p.confirm_id, tool: p.tool, args: p.args })
                setPhase('WAITING_CONFIRMATION')
              }
              const body = p.message || p.error || 'Done.'
              acc = body
              setMessages((m) => [
                ...m,
                { role: 'assistant', text: body, error: p.status === 'FAILED', meta: p.status },
              ])
            } else if (evt.type === 'error') {
              acc = ''
              setMessages((m) => [...m, { role: 'assistant', text: evt.error, error: true }])
            }
          },
        })
        if (acc && index.current != null) {
          setMessages((m) => {
            const copy = [...m]
            copy[index.current] = { role: 'assistant', text: acc }
            return copy
          })
          if (speakReplies) speak(acc)
        } else if (acc && speakReplies) {
          speak(acc)
        }
      } catch (err) {
        if (err.name !== 'AbortError') {
          setMessages((m) => [...m, { role: 'assistant', text: String(err.message || err), error: true }])
        }
      } finally {
        clearTimeout(watchdog)        // ALWAYS clears - no stuck THINKING state
        abortRef.current = null
        busyRef.current = false
        setPhase((s) => (s === 'WAITING_CONFIRMATION' ? s : 'READY'))
        setState((s) => (s === 'WAITING_CONFIRMATION' ? s : 'READY'))
        const next = queueRef.current.shift()
        if (next) setTimeout(() => send(next), 60)
      }
    },
    [setPhase, speakReplies],
  )

  // ---- OS-level V hotkey coming from the Tauri shell (works while minimized) //
  useEffect(() => {
    const tauri = window.__TAURI__
    if (!tauri?.event?.listen) return
    let unlistenToggle = null
    let unlistenCancel = null
    tauri.event.listen('jarvis://voice-toggle', () => {
      listening ? stopListening(false) : startListening()
    }).then((fn) => (unlistenToggle = fn))
    tauri.event.listen('jarvis://voice-cancel', () => {
      if (listening) stopListening(true)
    }).then((fn) => (unlistenCancel = fn))
    return () => {
      unlistenToggle?.()
      unlistenCancel?.()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listening])

  // ---- V hotkey while the HUD is focused (the OS-level hook lives in the
  //      Tauri shell / backend; this is the in-window fallback) ------------- //
  useEffect(() => {
    const onKey = (e) => {
      const typing = ['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName)
      if (e.repeat) return                       // key-repeat guard (spec 13)
      if (e.key === 'Escape' && listening) {
        stopListening(true)
        return
      }
      if (typing) return
      if (e.key.toLowerCase() === 'v') {
        e.preventDefault()
        listening ? stopListening(false) : startListening()
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listening])

  const startListening = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const chunks = []
      const rec = new MediaRecorder(stream)
      rec.ondataavailable = (e) => e.data.size && chunks.push(e.data)
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop())
        if (mediaRef.current?.cancelled) return
        const blob = new Blob(chunks, { type: 'audio/webm' })
        setPhase('THINKING')
        try {
          const form = new FormData()
          form.append('audio', blob, 'clip.webm')
          const token = getToken()
          const resp = await fetch('/api/voice/stt', {
            method: 'POST',
            body: form,
            headers: token ? { Authorization: `Bearer ${token}` } : {},
          })
          const text = await resp.text()
          let data = null
          try {
            data = JSON.parse(text)
          } catch {
            data = null
          }
          if (!resp.ok) {
            setMessages((m) => [
              ...m,
              { role: 'assistant', error: true, text: (data && data.detail) || 'Speech-to-text is unavailable on this machine.' },
            ])
            setPhase('READY')
            return
          }
          if (data?.text) send(data.text)
          else setPhase('READY')
        } catch (err) {
          setMessages((m) => [...m, { role: 'assistant', error: true, text: `Voice failed: ${err.message}` }])
          setPhase('READY')
        }
      }
      mediaRef.current = { rec, cancelled: false }
      rec.start()
      setListening(true)
      setPhase('LISTENING')
    } catch (err) {
      setMessages((m) => [
        ...m,
        { role: 'assistant', error: true, text: `Microphone unavailable: ${err.message}` },
      ])
    }
  }

  const stopListening = (cancelled) => {
    const media = mediaRef.current
    setListening(false)
    if (!media) {
      setPhase('READY')
      return
    }
    media.cancelled = cancelled
    try {
      media.rec.stop()
    } catch {
      /* already stopped */
    }
    if (cancelled) setPhase('READY')
  }

  const resolveConfirmation = async (approve) => {
    if (!pending) return
    setConfirmBusy(true)
    try {
      const result = await post('/tools/confirm', { confirm_id: pending.confirm_id, approve })
      setMessages((m) => [
        ...m,
        {
          role: 'assistant',
          meta: result.status,
          error: result.status === 'FAILED',
          text:
            result.status === 'CANCELLED'
              ? `Cancelled. ${pending.tool} was not executed.`
              : result.status === 'COMPLETED'
                ? `${pending.tool} completed${result.verified ? ' and verified' : ''}.`
                : `${pending.tool} failed: ${result.error}`,
        },
      ])
    } catch (err) {
      setMessages((m) => [...m, { role: 'assistant', error: true, text: err.message }])
    } finally {
      setConfirmBusy(false)
      setPending(null)
      setPhase('READY')
    }
  }

  const provider = health?.components?.omniroute?.status === 'READY'
    ? 'OMNIROUTE'
    : health?.components?.ollama?.status === 'READY'
      ? 'OLLAMA'
      : 'NO UPLINK'

  return (
    <div className="hud-grid">
      <Panel title="COMMUNICATION LOG" right={state === 'READY' ? 'IDLE' : state} className="chat-panel">
        <div className="chat-scroll" ref={scrollRef}>
          {messages.map((m, i) => (
            <div key={i} className={`msg ${m.role} ${m.error ? 'error' : ''}`}>
              <div className="msg-meta">{m.role === 'user' ? 'YOU' : m.meta || 'JARVIS'}</div>
              <div className="msg-body">
                {m.text}
                {m.streaming && <span className="cursor">▌</span>}
              </div>
            </div>
          ))}
        </div>
        <Waveform active={listening} />
        <div className="chat-input-row">
          <button
            className={`mic-btn ${listening ? 'live' : ''}`}
            title="Press V to talk"
            onClick={() => (listening ? stopListening(false) : startListening())}
          >
            🎙
          </button>
          <input
            className="chat-input"
            value={draft}
            placeholder="Speak (V) or type a command, Sir."
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send(draft)}
          />
          <button className="send-btn" onClick={() => send(draft)}>
            SEND ⏎
          </button>
        </div>
      </Panel>

      <Core state={state} provider={provider} />

      <div className="right-column">
        <Panel
          title="SYSTEM TELEMETRY"
          right={<span className={`dot ${status?.available ? 'ok' : 'fail'}`} />}
        >
          <Telemetry status={status} />
        </Panel>

        <Panel title="VOICE INTERFACE">
          <div className="voice-panel">
            <Waveform active={listening} />
            <label className="voice-toggle-row">
              <span className="switch">
                <input
                  type="checkbox"
                  checked={speakReplies}
                  onChange={(e) => setSpeakReplies(e.target.checked)}
                />
                <span className="slider" />
              </span>
              <span className="voice-toggle-label">Speak replies aloud</span>
            </label>
            <p className="dim-text small">
              Mic is push-to-talk only — JARVIS never records without you pressing it.
            </p>
          </div>
        </Panel>

        <Panel title="TOOL ACTIVITY" className="tools-panel">
          <div className="activity-scroll">
            {activity.length === 0 && <p className="dim-text small pad">No activity yet.</p>}
            {activity.map((e) => (
              <div className="activity-row" key={e.id}>
                <span className="activity-icon">◆</span>
                <div className="activity-main">
                  <div className="activity-title">{e.title}</div>
                  {e.detail && <div className="activity-detail">{String(e.detail).slice(0, 120)}</div>}
                </div>
                <span className="activity-time">
                  {new Date(e.ts * 1000).toLocaleTimeString('en-US', { hour12: false })}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <ConfirmModal pending={pending} onResolve={resolveConfirmation} busy={confirmBusy} />
    </div>
  )
}
