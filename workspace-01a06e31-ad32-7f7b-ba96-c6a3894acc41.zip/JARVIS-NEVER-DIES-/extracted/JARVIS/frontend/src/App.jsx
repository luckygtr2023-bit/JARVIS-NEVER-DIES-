import React, { useCallback, useEffect, useRef, useState } from 'react'
import { ApiError, get, post, setToken, getToken, sessionStore } from './api'
import { Backdrop } from './components/Hud'
import HudPage from './pages/HudPage'
import ActivityPage from './pages/ActivityPage'
import MemoryPage from './pages/MemoryPage'
import DevicesPage from './pages/DevicesPage'
import SettingsPage from './pages/SettingsPage'
import CombosPage from './pages/CombosPage'
import AuthGate from './pages/AuthGate'

const TABS = ['HUD', 'ACTIVITY', 'MEMORY', 'DEVICES', 'COMBOS', 'SETTINGS']

function useClock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])
  return now
}

function StatusBar({ tab, setTab, health, voiceState, user, onLogout }) {
  const now = useClock()
  const online = !!health
  const ai = health?.components?.omniroute?.status === 'READY'
    ? 'OMNIROUTE'
    : health?.components?.ollama?.status === 'READY'
      ? 'OLLAMA'
      : 'UNLINKED'
  const aiClass = ai === 'UNLINKED' ? 'amber' : 'green'

  return (
    <header className="status-bar">
      <div className="brand">
        <span className={`brand-dot ${online ? 'on' : 'off'}`} />
        <span className="brand-name">J.A.R.V.I.S.</span>
        <span className="brand-ver">Mark I</span>
      </div>
      <div className="status-cluster">
        <div className="status-item">
          <span className="status-key">STATUS</span>
          <span className={`status-value ${online ? 'green' : 'red'}`}>
            {online ? 'ONLINE' : 'OFFLINE'}
          </span>
        </div>
        <div className="status-item">
          <span className="status-key">AI</span>
          <span className={`status-value ${aiClass}`}>{ai}</span>
        </div>
        <div className="status-item">
          <span className="status-key">VOICE</span>
          <span className="status-value">{voiceState || 'READY'}</span>
        </div>
        <div className="status-item">
          <span className="status-key">SYSTEM</span>
          <span className={`status-value ${online ? 'green' : 'red'}`}>
            {online ? 'NOMINAL' : 'DEGRADED'}
          </span>
        </div>
        <div className="status-item">
          <span className="status-value">
            {now.toLocaleTimeString('en-US', { hour12: true })}
          </span>
          <span className="status-sub">
            {now.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}
          </span>
        </div>
      </div>
      <nav className="nav">
        {TABS.map((t) => (
          <a
            key={t}
            href={`#${t.toLowerCase()}`}
            className={tab === t ? 'active' : ''}
            onClick={(e) => {
              e.preventDefault()
              setTab(t)
            }}
          >
            {t}
          </a>
        ))}
        {user && (
          <a href="#logout" onClick={(e) => { e.preventDefault(); onLogout() }} title={`${user.username} · ${user.role}`}>
            EXIT
          </a>
        )}
      </nav>
    </header>
  )
}

export default function App() {
  const [tab, setTab] = useState('HUD')
  const [user, setUser] = useState(null)
  const [checking, setChecking] = useState(true)
  const [health, setHealth] = useState(null)
  const [voiceState, setVoiceState] = useState('READY')

  // ---- session bootstrap ---------------------------------------------- //
  useEffect(() => {
    let cancelled = false
    const boot = async () => {
      if (!getToken()) {
        setChecking(false)
        return
      }
      try {
        const me = await get('/auth/me')
        if (!cancelled) setUser(me)
      } catch {
        setToken('')
      } finally {
        if (!cancelled) setChecking(false)
      }
    }
    boot()
    return () => {
      cancelled = true
    }
  }, [])

  // ---- health polling (single interval, cleaned up) --------------------- //
  useEffect(() => {
    if (!user) return
    let alive = true
    const poll = async () => {
      try {
        const h = await get('/health')
        if (alive) setHealth(h)
      } catch {
        if (alive) setHealth(null)
      }
    }
    poll()
    const id = setInterval(poll, 15000)
    return () => {
      alive = false
      clearInterval(id)
    }
  }, [user])

  const onLogout = useCallback(async () => {
    try {
      await post('/auth/logout')
    } catch {
      /* the session may already be gone */
    }
    setToken('')
    setUser(null)
    sessionStore.remove('jarvis.greeted')
  }, [])

  if (checking) {
    return (
      <div className="app-shell">
        <Backdrop />
        <div className="auth-shell">
          <div className="auth-title">J.A.R.V.I.S.</div>
        </div>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="app-shell">
        <Backdrop />
        <AuthGate onAuthenticated={setUser} />
      </div>
    )
  }

  return (
    <div className="app-shell">
      <Backdrop />
      <StatusBar
        tab={tab}
        setTab={setTab}
        health={health}
        voiceState={voiceState}
        user={user}
        onLogout={onLogout}
      />
      <main className="page-body">
        {tab === 'HUD' && <HudPage health={health} onVoiceState={setVoiceState} user={user} />}
        {tab === 'ACTIVITY' && <ActivityPage />}
        {tab === 'MEMORY' && <MemoryPage />}
        {tab === 'DEVICES' && <DevicesPage user={user} />}
        {tab === 'COMBOS' && <CombosPage user={user} />}
        {tab === 'SETTINGS' && <SettingsPage health={health} user={user} />}
      </main>
    </div>
  )
}
