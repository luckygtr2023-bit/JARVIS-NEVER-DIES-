// Thin API layer. One place that knows about the token and about error shapes.
const TOKEN_KEY = 'jarvis.token'

/**
 * Storage that cannot take the HUD down.
 *
 * Touching window.localStorage throws a SecurityError - not returns null,
 * THROWS - in a sandboxed iframe (sandbox="allow-scripts" with no
 * allow-same-origin), under "block third-party cookies", in some kiosk/embedded
 * webviews, and in Chrome when site data is blocked. An unguarded
 * localStorage.getItem() in the session bootstrap therefore blanked the whole
 * interface and the login screen never appeared. Every storage access in the
 * HUD goes through here instead, and falls back to an in-memory map so JARVIS
 * still logs in and runs normally - only "stay signed in across reloads" is
 * lost, which is the correct thing to lose when the browser forbids storage.
 */
function safeStore(pick) {
  const mem = new Map()
  const backing = () => {
    try {
      const s = pick()
      if (!s) return null
      const probe = '__jarvis_probe__'
      s.setItem(probe, '1')
      s.removeItem(probe)
      return s
    } catch {
      return null
    }
  }
  let real
  const store = () => {
    if (real === undefined) real = backing()
    return real
  }
  return {
    get(k) {
      try {
        const s = store()
        if (s) return s.getItem(k)
      } catch {
        /* fall through to memory */
      }
      return mem.has(k) ? mem.get(k) : null
    },
    set(k, v) {
      mem.set(k, String(v))
      try {
        const s = store()
        if (s) s.setItem(k, String(v))
      } catch {
        /* memory copy already written */
      }
    },
    remove(k) {
      mem.delete(k)
      try {
        const s = store()
        if (s) s.removeItem(k)
      } catch {
        /* memory copy already cleared */
      }
    },
    get persistent() {
      return !!store()
    },
  }
}

export const localStore = safeStore(() => window.localStorage)
export const sessionStore = safeStore(() => window.sessionStorage)

export function getToken() {
  return localStore.get(TOKEN_KEY) || ''
}
export function setToken(t) {
  if (t) localStore.set(TOKEN_KEY, t)
  else localStore.remove(TOKEN_KEY)
}

export class ApiError extends Error {
  constructor(message, status) {
    super(message)
    this.status = status
  }
}

export async function api(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) }
  const token = getToken()
  if (token) headers.Authorization = `Bearer ${token}`

  let resp
  try {
    resp = await fetch(`/api${path}`, { ...options, headers })
  } catch (err) {
    throw new ApiError('Backend unreachable — is JARVIS running?', 0)
  }

  const text = await resp.text()
  let data = null
  if (text) {
    try {
      data = JSON.parse(text)
    } catch {
      // Never surface a raw parse error to the user (spec 8).
      if (!resp.ok) throw new ApiError(`Server error ${resp.status}: ${text.slice(0, 160)}`, resp.status)
      throw new ApiError('The backend sent a response JARVIS could not read.', resp.status)
    }
  }
  if (!resp.ok) {
    const detail = (data && (data.detail || data.error || data.message)) || `HTTP ${resp.status}`
    throw new ApiError(typeof detail === 'string' ? detail : JSON.stringify(detail), resp.status)
  }
  return data
}

export const get = (p) => api(p)
export const post = (p, body) => api(p, { method: 'POST', body: JSON.stringify(body ?? {}) })
export const del = (p) => api(p, { method: 'DELETE' })

// Streaming chat. onEvent receives {type:'delta'|'result'|'error', ...}
export async function streamChat(text, { onEvent, signal, requestId }) {
  const headers = { 'Content-Type': 'application/json' }
  const token = getToken()
  if (token) headers.Authorization = `Bearer ${token}`

  const resp = await fetch('/api/chat/stream', {
    method: 'POST',
    headers,
    signal,
    body: JSON.stringify({ text, request_id: requestId }),
  })
  if (!resp.ok || !resp.body) {
    const body = await resp.text().catch(() => '')
    let detail = `HTTP ${resp.status}`
    try {
      detail = JSON.parse(body).detail || detail
    } catch {
      if (body) detail = body.slice(0, 200)
    }
    onEvent({ type: 'error', error: detail })
    return
  }

  const reader = resp.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  try {
    while (true) {
      const { value, done } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() || ''
      for (const line of lines) {
        if (!line.startsWith('data:')) continue
        const payload = line.slice(5).trim()
        if (payload === '[DONE]') return
        try {
          onEvent(JSON.parse(payload))
        } catch {
          /* ignore malformed frame */
        }
      }
    }
  } finally {
    try {
      reader.cancel()
    } catch {
      /* already closed */
    }
  }
}
