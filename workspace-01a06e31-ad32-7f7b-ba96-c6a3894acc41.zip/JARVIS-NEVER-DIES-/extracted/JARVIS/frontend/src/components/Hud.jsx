import React, { useEffect, useRef } from 'react'

/** Ambient background: grid, drifting particles, scanlines. Pure CSS + canvas. */
export function Backdrop() {
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    let raf = 0
    let particles = []

    const resize = () => {
      canvas.width = canvas.offsetWidth
      canvas.height = canvas.offsetHeight
      const count = Math.min(70, Math.round((canvas.width * canvas.height) / 26000))
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 1.4 + 0.3,
        vx: (Math.random() - 0.5) * 0.16,
        vy: (Math.random() - 0.5) * 0.16,
        a: Math.random() * 0.5 + 0.15,
      }))
    }
    resize()
    window.addEventListener('resize', resize)

    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy
        if (p.x < 0) p.x = canvas.width
        if (p.x > canvas.width) p.x = 0
        if (p.y < 0) p.y = canvas.height
        if (p.y > canvas.height) p.y = 0
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(245,165,36,${p.a})`
        ctx.fill()
      }
      raf = requestAnimationFrame(tick)
    }
    tick()
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', resize)
    }
  }, [])

  return (
    <>
      <div className="bg-grid" />
      <canvas ref={canvasRef} className="particle-canvas" />
      <div className="scanlines" />
    </>
  )
}

/** The holographic core: concentric rings, tick marks, sweep and the orb. */
export function Core({ state = 'READY', provider = 'NO UPLINK' }) {
  const stateClass =
    {
      LISTENING: 'state-listening',
      THINKING: 'state-thinking',
      TOOL: 'state-thinking',
      VERIFYING: 'state-thinking',
      SPEAKING: 'state-speaking',
      ERROR: 'state-alert',
      OFFLINE: 'state-alert',
      WAITING_CONFIRMATION: 'state-alert',
    }[state] || ''

  return (
    <div className="core-column">
      <div className={`core-wrap ${stateClass}`}>
        <div className="core-ticks" />
        <div className="core-ring r1" />
        <div className="core-ring r2" />
        <div className="core-ring r3" />
        <div className="core-ring r4" />
        <div className="core-sweep" />
        <div className="core-orb">
          <div className="core-orb-inner" />
        </div>
        <div className="core-readout">
          <div className="core-state">{state}</div>
          <div className="core-provider">{provider}</div>
        </div>
      </div>
    </div>
  )
}

export function Panel({ title, right, children, className = '' }) {
  return (
    <section className={`panel ${className}`}>
      <div className="panel-head">
        <span>{title}</span>
        {right != null && <span className="panel-head-right">{right}</span>}
      </div>
      {children}
    </section>
  )
}

export function Waveform({ active }) {
  return (
    <div className={`waveform ${active ? 'active' : ''}`}>
      {Array.from({ length: 24 }).map((_, i) => (
        <span key={i} style={{ animationDelay: `${(i % 8) * 0.09}s` }} />
      ))}
    </div>
  )
}

/** Backend-enforced confirmation dialog (spec 18). */
export function ConfirmModal({ pending, onResolve, busy }) {
  if (!pending) return null
  return (
    <div className="modal-backdrop">
      <div className="modal">
        <div className="modal-scan" />
        <div className="modal-head">AUTHORIZATION REQUIRED</div>
        <p className="modal-desc">
          JARVIS will not perform this action without your explicit authorization.
        </p>
        <div className="modal-args-title">{pending.tool}</div>
        <pre className="modal-args">{JSON.stringify(pending.args || {}, null, 2)}</pre>
        <div className="modal-actions">
          <button className="btn-cancel" disabled={busy} onClick={() => onResolve(false)}>
            CANCEL
          </button>
          <button className="btn-authorize" disabled={busy} onClick={() => onResolve(true)}>
            AUTHORIZE
          </button>
        </div>
      </div>
    </div>
  )
}
