import React from 'react'

/**
 * A render fault used to blank the entire interface, which is how the missing
 * login screen presented itself. JARVIS never shows an empty document again:
 * anything that escapes a component lands here and is reported inside the HUD's
 * own visual language, with the failure text visible instead of hidden in the
 * console.
 */
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { error: null }
  }

  static getDerivedStateFromError(error) {
    return { error }
  }

  componentDidCatch(error, info) {
    // Keep the real stack reachable for a developer without breaking the UI.
    console.error('[JARVIS] interface fault', error, info)
  }

  render() {
    if (!this.state.error) return this.props.children
    return (
      <div className="auth-shell">
        <div className="auth-card">
          <div className="auth-title">J.A.R.V.I.S.</div>
          <div className="auth-sub">INTERFACE FAULT</div>
          <div className="auth-err">{String(this.state.error?.message || this.state.error)}</div>
          <div className="auth-note">
            The interface stopped rendering. The backend and every device session are unaffected.
            Reload to reconnect; if this repeats, the message above is the fault to report.
          </div>
          <button className="btn-primary" type="button" onClick={() => window.location.reload()}>
            RELOAD INTERFACE
          </button>
        </div>
      </div>
    )
  }
}
