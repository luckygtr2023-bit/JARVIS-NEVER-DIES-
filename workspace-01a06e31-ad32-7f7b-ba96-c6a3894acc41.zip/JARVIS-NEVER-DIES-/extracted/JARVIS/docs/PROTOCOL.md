# JARVIS cross-device protocol — version 1

This is the contract between the JARVIS backend and every client (Windows HUD,
Android app, a second PC, anything future). The server also serves it at runtime:

```
GET /api/protocol      →  the same information, machine-readable
GET /api/capabilities  →  the capability vocabulary
```

Both are unauthenticated **on purpose**: they contain no user data, and a device
needs them *before* it has a token in order to pair correctly.

Source of truth: `backend/protocol.py`. The Android mirror is
`android-client/src/protocol.js`, and `android-client/scripts/protocol-selftest.mjs`
checks the two have not drifted apart.

---

## 1. Envelope

Every frame in either direction:

```jsonc
{
  "protocol_version": 1,
  "message_type": "TASK_ASSIGN",
  "request_id": "req_7f3a…",      // client-generated; makes retries idempotent
  "task_id": "tsk_9c21…",         // set once a task record exists
  "user_id": "usr_…",
  "source_device_id": "dev_windows_…",
  "target_device_id": "dev_android_…",
  "timestamp": 1788500000.123,     // unix seconds
  "payload": { },                  // message-specific body
  "status": "ASSIGNED",
  "seq": 14                        // server frames only: monotonic per connection
}
```

`seq` lets a client detect a gap and know it missed something. The Android
client raises a `gap` event when `seq` jumps.

## 2. Message types

| Group | Types |
|---|---|
| Device lifecycle | `DEVICE_REGISTER` `DEVICE_AUTH` `DEVICE_PAIR_REQUEST` `DEVICE_PAIR_APPROVE` `DEVICE_REVOKE` `DEVICE_HEARTBEAT` `DEVICE_STATUS` `DEVICE_CAPABILITIES` |
| Tasks | `TASK_CREATE` `TASK_ASSIGN` `TASK_UPDATE` `TASK_RESULT` `TASK_CANCEL` |
| Commands | `COMMAND_REQUEST` `COMMAND_RESULT` |
| Confirmation | `CONFIRMATION_REQUEST` `CONFIRMATION_RESULT` |
| Transport | `HELLO` `ACK` `PONG` `DISCONNECT` `ERROR_EVENT` |

**A device may only originate** `DEVICE_REGISTER`, `DEVICE_HEARTBEAT`,
`DEVICE_STATUS`, `DEVICE_CAPABILITIES`, `TASK_RESULT`, `TASK_UPDATE`,
`TASK_CANCEL`, `COMMAND_REQUEST`, `CONFIRMATION_RESULT`, `PONG`, `ERROR_EVENT`.
Anything else from a device is answered with
`ERROR_EVENT / NOT_CLIENT_ORIGINATED` — a paired phone cannot approve its own
pairing or assign itself a task. This is tested, not merely intended.

## 3. Statuses and error codes

`PENDING QUEUED ASSIGNED RUNNING WAITING_CONFIRMATION COMPLETED FAILED
CANCELLED OFFLINE TIMEOUT REJECTED`

`UNAUTHENTICATED FORBIDDEN DEVICE_REVOKED UNSUPPORTED_VERSION MALFORMED
UNKNOWN_MESSAGE_TYPE NOT_CLIENT_ORIGINATED TARGET_OFFLINE TARGET_UNKNOWN
CAPABILITY_MISSING PERMISSION_MISSING CONFIRMATION_REQUIRED DUPLICATE TIMEOUT
INTERNAL`

Branch on the code, never on the prose.

## 4. Connection lifecycle

```
GET /api/protocol                    → check version, refuse if incompatible
POST /api/devices/pairing            → PAIR-7K4M-92PX  (single use, 10 min)
   … OWNER approves in the HUD …
POST /api/devices/pairing/claim      → 425 until approved, then device_token
WS  /api/bus/ws?token=<device_token> → HELLO, then the session
```

* heartbeat every **20 s**; the server marks a device offline after **45 s**
* reconnect: exponential backoff with full jitter, 1→2→4→8→16→30 s cap
* close **4401** = unauthenticated, **4403** = revoked → stop retrying, wipe the
  token, return to the pairing screen
* the socket is not LAN-bound: point it at any HTTPS/WSS reverse proxy in front
  of the same backend and cross-network works unchanged

## 5. Guarantees the server actually keeps

1. Every frame is authenticated; there is no anonymous device channel.
2. `request_id` makes task creation idempotent — a retry returns the first task
   instead of doing the work twice.
3. A task result is accepted **exactly once**; a replay gets `duplicate: true`.
   A first result is accepted even if nobody is still awaiting it (the phone
   finished, lost signal, reconnected, then reported) — that work is not lost.
4. `seq` is monotonic per connection.
5. A task for an offline device is **never** reported as executed.
6. Capabilities are checked **before** routing, so the user is told "your phone
   cannot do that" instead of watching a task time out.

## 6. Backwards compatibility

The 1.0.0 dialect (`{"type":"heartbeat"}`, `{"type":"result",…}`) is still
accepted and is normalised into v1 internally. The server replies to each
connection in the dialect that connection used, so an old Windows build and a
new Android build can be connected at the same time. `parse_frame` /
`downgrade` in `backend/protocol.py` do the translation.

## 7. Adding to the protocol later

* new `message_type` → add to `MessageType` and to `CLIENT_ORIGINATED` or
  `SERVER_ORIGINATED`; old clients ignore what they do not know
* new field → put it in `payload`; the envelope stays stable
* breaking change → bump `PROTOCOL_VERSION` and raise `MIN_SUPPORTED_VERSION`
  only when old clients genuinely cannot work
