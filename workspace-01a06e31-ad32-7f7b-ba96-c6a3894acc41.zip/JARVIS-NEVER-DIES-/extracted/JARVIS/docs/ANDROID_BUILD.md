# Building the Android APK from this ZIP

The APK is **deliberately not built** in the environment that produced this
handoff — that machine is Linux with no Android SDK, and a fake APK would be
worse than none. Everything needed to build a real one is here.

Project: `android-client/` — Expo (React Native), JavaScript, no TypeScript
config to fight with.

---

## 1. Requirements

| Requirement | Version |
|---|---|
| Node.js | 20 LTS or newer |
| npm | 10+ (or pnpm/yarn if you prefer) |
| Java JDK | **17** (required by AGP 8.x; JDK 21 also works on recent Expo) |
| Android SDK Platform | **34** (compileSdk / targetSdk) |
| Android Build Tools | 34.0.0 |
| Android NDK | only if you add native modules; not needed as shipped |
| minSdkVersion | **24** (Android 7.0) |
| Architectures | `arm64-v8a`, `armeabi-v7a`, `x86_64` (Expo default) |
| EAS CLI | `npm i -g eas-cli` — only for cloud builds |

Application ID: **`com.jarvis.ai`** (`android-client/app.json` → `expo.android.package`).

## 2. Install

```bash
cd android-client
npm install
npx expo-doctor          # reports any SDK/dependency mismatch
npx expo install --fix   # aligns package versions with the installed Expo SDK
```

The dependency set is pinned to **Expo SDK 51**. If the receiving environment
has a newer SDK, run `npx expo upgrade` (or `npx expo install --fix`) first —
nothing in `src/` depends on SDK-51-only APIs.

## 3. Build an APK

### Option A — EAS cloud build (easiest)

```bash
eas login
eas init                 # writes your own projectId into app.json → extra.eas
eas build --platform android --profile preview     # → installable .apk
```

`eas.json` already defines three profiles: `development` (dev client),
`preview` (APK for sideloading), `production` (AAB for Play).

### Option B — Local build, no Expo account

```bash
npx expo prebuild --platform android --clean   # generates the android/ project
cd android
./gradlew assembleRelease                      # → app/build/outputs/apk/release/
```

`android/` is intentionally **not** in this ZIP: it is generated output, and
committing it would make the project harder, not easier, to build.

### Option C — Run on a device without building

```bash
npx expo start            # then open with Expo Go, or `a` for a connected device
```

Note: `expo-intent-launcher` (used to launch other apps) does not work inside
Expo Go — use a dev build or the APK for that feature.

## 4. Point the app at the backend

No credential is compiled in. The pairing screen asks for the backend address,
and it is stored in the Android Keystore after pairing. To pre-fill it:

* build-time: set `JARVIS_BACKEND_URL` (see `eas.json` → `build.*.env`, or
  `.env` locally — copy `.env.example`), or
* edit `app.json` → `expo.extra.defaultBackendUrl`.

| Scenario | Address |
|---|---|
| Phone and PC on the same Wi-Fi | `http://<pc-lan-ip>:8420` |
| Different networks | `https://<your-tunnel-or-proxy>` in front of the same backend |

Cross-network needs nothing special from the app: the control plane is a single
authenticated WebSocket, so any HTTPS reverse proxy (Caddy, nginx, Cloudflare
Tunnel, Tailscale) that forwards `/api/*` including WebSocket upgrades works.
**Bind the backend to `0.0.0.0` and put TLS in front of it before exposing it.**

## 5. Android permissions and why each is requested

| Permission | Used for | Optional? |
|---|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | reach the backend | required |
| `POST_NOTIFICATIONS` | JARVIS notifying you on the phone | yes — capability `notifications` is only advertised if granted |
| `RECORD_AUDIO` | future on-device voice capture | yes — `voice.microphone` only advertised if granted |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK` | keeping the control channel alive in the background | needed for reliable "open X on my phone" while the app is backgrounded |
| `QUERY_ALL_PACKAGES` | launching installed apps by package name | remove it if you only need URL opening; Play Store review asks about this one |
| Location | **blocked** in `app.json` — not used |

The app advertises only capabilities that are actually granted
(`src/capabilities.js`), because the backend routes work based on that list.

## 6. What the client already implements

* `src/protocol.js` — protocol v1, mirror of `backend/protocol.py`, with
  version negotiation that refuses an incompatible server
* `src/identity.js` — device identity + token in Keystore (`expo-secure-store`)
* `src/api.js` — pairing, presence, typed cross-device task routing, 401 →
  revoked handling
* `src/bus.js` — WebSocket client: heartbeat, exponential backoff with jitter,
  `seq` gap detection, per-task idempotency cache, honest `verified` flag
* `src/executor.js` — executes tasks sent *to* the phone: open URL, launch app,
  speak, notify, device info; refuses honestly when it cannot
* `App.js` — pairing screen (shows `PAIR-XXXX-XXXX`) and link screen, in the
  HUD's amber-on-black language

Verify the protocol layer without an emulator:

```bash
cd android-client && npm test      # 13/13 protocol self-tests
```

## 7. Suggested next steps for the Android agent

1. `npm install && npx expo-doctor`, then build the `preview` profile.
2. Pair against a running backend and watch the HUD → DEVICES → PAIRING REQUESTS.
3. Add a **foreground service** so the socket survives Doze (Expo:
   `expo-task-manager` + a notification, or eject and write a small service).
4. Add on-device STT (`@react-native-voice/voice`) and advertise `voice.stt`
   only once the permission is granted.
5. Optional: push notifications for `CONFIRMATION_REQUEST` so the OWNER can
   authorise a consequential action from the phone.

Do not put OAuth client secrets, API keys or the OWNER password in the app.
The device token issued at pairing is the only credential it needs.
