# JARVIS — Testing Guide (Windows PC + Android)

## What you received

| File | What it is |
|---|---|
| `JARVIS_Windows_Package.zip` | Zero-dev-setup Windows app: backend + prebuilt HUD + one-click `START_JARVIS.bat`, plus `BUILD_EXE.bat` if you want a true `JARVIS.exe` |
| `JARVIS-android.apk` | Installable Android app (arm64, signed with the debug key — fine for personal use) |

---

## 1. Start JARVIS on the PC (Windows 10/11, 64-bit)

1. Unzip `JARVIS_Windows_Package.zip` anywhere (e.g. `C:\JARVIS`).
2. Double-click **`START_JARVIS.bat`**.
   - First run downloads embedded Python + libraries once (~250 MB, internet needed). Later runs need no internet unless you use cloud AI.
   - A console stays open — that **is** JARVIS running. Your browser opens the HUD at `http://localhost:8420`.
   - The console prints `http://192.168.x.x:8420` — that's the address for your phone.
3. To make a real desktop exe later: run `BUILD_EXE.bat` (after the launcher has run once). Output: `dist\JARVIS.exe`.

**Verify on the PC:**
- HUD loads; the startup greeting appears once.
- Dev check: `http://localhost:8420/api/health` → `{"status":"ok",…}`.
- Press **V** — JARVIS starts listening (first voice run downloads the ~75 MB Whisper model once); speak; **ESC** cancels.
- Chat works with your configured provider (OpenRouter/Groq keys are already in `backend\.env`). Settings page shows provider status.

## 2. Install the Android app

1. Copy `JARVIS-android.apk` to your phone (USB / Drive / Telegram to yourself).
2. Open it on the phone → allow **"install unknown apps"** when Android asks → Install.
   - Signed with the standard debug certificate; no Play Protect reputation — that's expected for a personal build.

## 3. Pair the phone with the PC

1. Phone and PC on the **same Wi-Fi**. PC firewall: allow the incoming connection on port 8420 if Windows asks.
2. Open the JARVIS app → **Pairing** screen:
   - Server: `http://192.168.x.x:8420` (what the PC console printed)
   - Device name: e.g. `Arjun's Phone`
3. Tap **REQUEST PAIRING** → the app shows a pairing code.
4. On the PC HUD → **DEVICES** tab → your phone appears under PAIRING REQUESTS with the **same code** → **APPROVE**.
5. The PC shows a **one-time token** (`jtk_…`). Type/paste it into the phone → **CONNECT**.
6. Phone now shows CHAT + DEVICES tabs; DEVICES shows the PC and itself with honest online/offline dots.

## 4. Verify the features that exist today

| # | Check | Expect |
|---|---|---|
| 1 | Windows app launches | HUD in browser, greeting once, no console errors |
| 2 | APK installs & launches | Pairing screen; no crash |
| 3 | PC↔phone comms | After pairing: phone DEVICES shows PC *online*; PC HUD DEVICES shows phone *online* |
| 4 | Authentication | Wrong/revoked token → phone gets kicked to "ACCESS REVOKED" screen |
| 5 | Voice | PC: V → speak → transcript appears. Phone: hold 🎙, speak, release → "Heard: …" then JARVIS answers (server-side Whisper) |
| 6 | AI | Ask anything on either device → answer streams from OpenRouter/Groq/Ollama per your `.env` |
| 7 | Voice output | PC HUD speaks replies (local TTS); phone speaks replies (on-device TTS) |
| 8 | Regression | All previous features: tools page, memory page, settings, web search, destinations, Gmail/Calendar (if linked) |
| 9 | Permissions | By default the phone can chat but NOT run PC commands — try `pc_shutdown` … not exposed; owner grants perms in DEVICES tab |
| 10 | Tasks/audit | DEVICES → TASKS and AUDIT tabs show routed commands and the append-only security log |

## 5. Known limits (honest)

- **Windows exe is built by you** with `BUILD_EXE.bat` (PyInstaller) — it could not be pre-built in the Linux environment where this package was assembled, and the bat launcher itself has **not been executed on a real Windows machine here**. It's a standard launcher flow, but if anything misbehaves, run it from `cmd` and read the message — and report it.
- **The APK was compiled and structurally verified** (manifest, signature, arm64 native libs), but was **not launched on a physical phone** from this environment — there is no Android emulator/device here. First-launch behavior on your device is the real test; if it crashes, capture `adb logcat` and share.
- Whisper on the PC downloads its model on first voice use; keep the PC online for that first run.
- `pyttsx3` (Windows SAPI TTS) installs with requirements; if voice-out is silent, check Windows volume/narrator voice settings.
- Phone→PC remote actions require the owner to grant the specific permission in the DEVICES tab first — that's the security design, not a bug.

## 6. If something fails

- PC console shows Python tracebacks — copy them.
- Phone: `adb logcat *:E` while reproducing, or just screenshot the error text.
- Report back exactly what you saw; every failing area will be fixed before the next (OmniRoute combo) phase.
