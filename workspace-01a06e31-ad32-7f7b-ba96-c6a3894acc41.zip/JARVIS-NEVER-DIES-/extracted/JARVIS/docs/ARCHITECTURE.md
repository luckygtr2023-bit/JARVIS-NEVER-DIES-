# J.A.R.V.I.S. Architecture

> Diagram: [`ARCHITECTURE.svg`](./ARCHITECTURE.svg)

JARVIS is one Windows application with a FastAPI backend, an amber HUD frontend,
and a cross-device control plane. Android and any other device are **clients** of
the same backend — there is no second backend and no separate chatbot.

## Layers

| Layer | Where | Role |
|---|---|---|
| Transport | `backend/services/ai_client.py` | OmniRoute (cloud) + Ollama (local), defensive parsing |
| Routing | `backend/routing.py` | decides ollama / omniroute / none per request |
| Quota | `backend/quota.py` | usage telemetry + cloud limits |
| Memory | `backend/memory_store.py` | long-term (guarded) + bounded conversation window |
| Workflows | `backend/workflows.py` | safe command→tool cache |
| Agent | `backend/services/agent_loop.py` | UNDERSTAND→PLAN→TOOL→VERIFY→RESPOND |
| Devices | `backend/device_bus.py`, `routers/bus.py` | protocol v1 WebSocket control plane |
| Auth | `backend/security.py`, `deps.py` | PBKDF2, sessions, device tokens, pairing, roles |
| PWA | `backend/pwa/` | mobile HUD served by this backend |

## The routing pipeline

```
USER INPUT → NORMALIZE → ① WORKFLOW CACHE → ② DETERMINISTIC → ③ MEMORY
          → ④ ROUTING ENGINE → OLLAMA → OMNIROUTE only if needed
          → TOOLS → VERIFY → MEMORY UPDATE → RESPONSE(+DIAGNOSTICS)
```

* Workflow, deterministic and memory steps return before any `chat()` call, so
  cloud quota (and Ollama) are only spent on genuine language tasks.
* The routing engine is **pure** (no network / DB) so every branch is unit-tested.
* The agent loop is unchanged in shape — routing is integrated into the existing
  single loop, not a second one.

### Ollama vs OmniRoute decision logic (`backend/routing.py`)

* Complexity is heuristic: `COMPLEX` signals (explain in detail, analyse, write
  code, refactor, summarize the newest three PDFs …) or long input; `MODERATE` for
  medium tasks; otherwise `SIMPLE`.
* `local_first` (default) → always Ollama; cloud only as a fallback when Ollama is
  unreachable.
* `auto` → SIMPLE to Ollama, COMPLEX to OmniRoute *only when a Combo is set*.
* `cloud_first` / `cloud_only` / `local_only` / `hybrid` per the table in README.
* An explicit Combo ("use JARVIS-copy-13") always routes to OmniRoute and is sent
  byte-for-byte (never lowercased, prefixed or restricted to known names).

### Quota-saving mechanisms

1. Deterministic bypass (no AI).
2. Local memory recall (no AI).
3. Learned workflow cache (no AI).
4. Local-first routing (Ollama instead of OmniRoute).
5. Bounded context: only the recent window + relevant memories are sent, never the
   full history → far fewer tokens for the same answer.
6. `auto`/`local_first` keep OmniRoute for genuinely complex work only.

## Security model

* Backend is authoritative for role, user_id, device_id, permissions — frontend
  values are never trusted.
* Passwords → PBKDF2-HMAC-SHA256; sessions/device-tokens hashed at rest; pairing
  codes single-use + expiring (10 min) and destroyed on claim.
* Confirmation is backend-enforced for consequential actions (`CONFIRM` risk).
* Devised capabilities are checked before a task is dispatched.
* Memory guard refuses credentials; conversation memory refuses credential turns;
  audit scrubs secrets; usage diagnostics never expose provider secrets.
* Never trust the web claims Windows capability; the PWA advertises only
  `WEB_PWA, MICROPHONE, NOTIFICATIONS, BROWSER, CLIPBOARD, FILE_PICKER` and routes
  Windows work through the backend to the Windows device.

## Cross-network

One authenticated WebSocket per device (`/api/bus/ws`, protocol v1) works behind a
HTTPS reverse proxy — it does not assume a LAN, so the PWA works on the same Wi-Fi,
a different Wi-Fi, or mobile data.

## Offline honesty

If the Windows target is offline, a routed task returns `FAILED … is offline`
(or `QUEUED`) — it is never reported `COMPLETED`. The PWA shows `JARVIS OFFLINE`
and its shell remains usable, but `/api/*` is never served from the service-worker
cache.
