# Android client (`com.jarvis.ai`)

> **Status update.** This document was written when the Android app did not
> exist. It now does: the source lives in `android-client/` and implements
> everything below. The APK is still **not built** (no Android SDK on the build
> host) — see `docs/ANDROID_BUILD.md` for how to build it, and
> `docs/PROTOCOL.md` for the full v1 contract that supersedes the frame
> examples further down this page (the old short frames still work).


## 1. Reach the server

Same Wi-Fi: `http://<pc-ip>:8420`.
Different networks: point the app at any HTTPS reverse proxy / relay in front of
the same backend. Nothing in the protocol assumes a LAN — the control plane is a
single authenticated WebSocket, so a relay only has to forward it.

## 2. Pair (once)

```
POST /api/devices/pairing
     {"device_name": "Lucky's Phone", "device_type": "android",
      "os": "Android 14", "app_version": "1.0.0",
      "capabilities": ["chat", "voice", "notifications"]}
  -> {"pairing_id": "pair_…", "code": "PAIR-7K4M-92PX", "expires_in": 600}
```

Show the code. The OWNER sees the same code in the HUD → **DEVICES → PAIRING
REQUESTS** and taps APPROVE.

```
POST /api/devices/pairing/claim   {"code": "PAIR-7K4M-92PX"}
  -> 425  if the owner has not approved yet   (keep polling)
  -> 200  {"device_id": "dev_android_ab12cd34",
           "device_token": "jtk_…", "permissions": ["chat","system.read"],
           "ws_url": "/api/bus/ws"}
```

Store `device_token` in Android Keystore / EncryptedSharedPreferences.
The pairing code dies the moment it is claimed — it is never a password.

## 3. Authenticate every request

```
X-Device-Token: jtk_…          (header, all REST calls)
GET /api/bus/ws?token=jtk_…    (WebSocket)
```

`401` means the device was revoked → wipe the token and return to the pairing
screen.

## 4. Control plane frames

```jsonc
// server -> device, immediately after connect
{"type":"hello","device_id":"dev_android_…","permissions":[…],"seq":1}

// device -> server, every ~20 s (presence; 45 s without one = offline)
{"type":"heartbeat"}                      // server replies {"type":"pong"}

// server -> device: work routed from another device
{"type":"task","task_id":"tsk_…","payload":{"text":"Open YouTube"},"seq":7}

// device -> server: the ONLY way a task completes.
{"type":"result","task_id":"tsk_…","ok":true,"verified":true,
 "result":{"opened":"youtube","url":"https://m.youtube.com/"}}
// verified=true means the device actually checked the outcome.

// device -> server: ask JARVIS to do something (needs the 'chat' permission)
{"type":"command","request_id":"req_…","text":"Open YouTube on my PC"}
  -> {"type":"command_result","request_id":"req_…","payload":{…}}
```

Guarantees already enforced server-side:

| Property | How |
|---|---|
| ordering | monotonic `seq` per connection |
| idempotency | `request_id` — a repeat returns the original task |
| duplicate protection | a `result` for a `task_id` is accepted exactly once |
| offline honesty | routing to an absent device returns `FAILED … is offline` |
| revocation | the socket is closed with `{"type":"disconnect"}` and the token dies |

Reconnect with exponential backoff (1s, 2s, 4s … capped at 30s) plus jitter.

## 5. Permissions

A new device starts with `["chat", "system.read"]`. Everything else — `browser.control`,
`windows.control`, `files.read/write`, `voice`, `gmail`, `calendar`, `devices.manage` —
must be granted by the OWNER in the DEVICES tab. A device asking for something it
was not granted gets `403` with a readable reason. Never work around it client-side.

## 6. Endpoints the app will want

| Purpose | Call |
|---|---|
| chat (streaming SSE) | `POST /api/chat/stream` |
| chat (single shot) | `POST /api/chat` |
| speech to text | `POST /api/voice/stt` (multipart `audio`) |
| device list + presence | `GET /api/devices` |
| tasks | `GET /api/tasks` |
| memory | `GET/POST /api/memory` |
| confirmations | `GET /api/tools/pending`, `POST /api/tools/confirm` |
| health | `GET /api/health` |

## 7. Confirmations on mobile

If a reply comes back `{"status":"WAITING_CONFIRMATION","confirm_id":"cnf_…"}`,
show an authorize/cancel sheet and call
`POST /api/tools/confirm {"confirm_id":…, "approve":true|false}`.
The backend refuses to run the action until then — the app cannot skip it, and
neither can the AI.

## 8. Visual identity

Reuse the HUD language: `#f5a524` amber on `#030509`, mono labels with wide
letter-spacing, panels at `rgba(10,14,24,.62)` with amber hairline borders, the
concentric ring core as the listening indicator. `frontend/src/styles.css`
already carries a `@media (max-width: 860px)` breakpoint that reflows the HUD
into a single column — that is the phone layout.
