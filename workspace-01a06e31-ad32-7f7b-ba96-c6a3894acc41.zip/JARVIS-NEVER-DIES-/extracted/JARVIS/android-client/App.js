/**
 * J.A.R.V.I.S. Android client.
 *
 * Two screens: PAIRING (until this installation is approved by the OWNER) and
 * LINK (status, my devices, send a command to the PC). Visual language matches
 * the desktop HUD - amber #f5a524 on near-black #030509, mono type, thin
 * borders - without copying any screenshot or OS chrome.
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator, Pressable, ScrollView, StatusBar, StyleSheet, Text, TextInput, View,
} from 'react-native';
import Constants from 'expo-constants';
import * as Notifications from 'expo-notifications';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

import * as api from './src/api';
import { DeviceBus } from './src/bus';
import { advertise } from './src/capabilities';
import { executeTask } from './src/executor';
import {
  clearCredentials, describeThisDevice, loadCredentials, saveCredentials,
} from './src/identity';

const AMBER = '#f5a524';
const BG = '#030509';
const DIM = 'rgba(245,165,36,0.55)';

const DEFAULT_URL =
  process.env.JARVIS_BACKEND_URL ||
  Constants.expoConfig?.extra?.defaultBackendUrl ||
  '';

export default function App() {
  const [phase, setPhase] = useState('BOOT');      // BOOT | PAIR | WAITING | LINKED
  const [backendUrl, setBackendUrl] = useState(DEFAULT_URL);
  const [username, setUsername] = useState('');
  const [pairing, setPairing] = useState(null);
  const [creds, setCreds] = useState(null);
  const [status, setStatus] = useState('starting');
  const [error, setError] = useState('');
  const [log, setLog] = useState([]);
  const [devices, setDevices] = useState([]);
  const [command, setCommand] = useState('');
  const busRef = useRef(null);
  const pollRef = useRef(null);

  const note = useCallback((line) => {
    setLog((prev) => [`${new Date().toLocaleTimeString()}  ${line}`, ...prev].slice(0, 60));
  }, []);

  // ---- boot: do we already have credentials? ----------------------------- //
  useEffect(() => {
    (async () => {
      const stored = await loadCredentials();
      if (stored.deviceToken && stored.backendUrl) {
        setBackendUrl(stored.backendUrl);
        setCreds(stored);
        setPhase('LINKED');
      } else {
        setPhase('PAIR');
      }
    })();
    return () => {
      busRef.current?.stop();
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  // ---- the control channel ----------------------------------------------- //
  useEffect(() => {
    if (phase !== 'LINKED' || !creds?.deviceToken) return undefined;

    const bus = new DeviceBus({
      baseUrl: creds.backendUrl,
      token: creds.deviceToken,
      execute: (payload) => executeTask(payload),
      onEvent: ({ type, data }) => {
        if (type === 'connected') {
          setStatus('linked');
          note('control channel open');
          Notifications.getPermissionsAsync().then(({ granted }) => {
            bus.sendCapabilities(advertise({ notifications: granted, tts: true }),
              describeThisDevice());
          });
        } else if (type === 'connecting') {
          setStatus('connecting');
        } else if (type === 'disconnected') {
          setStatus('reconnecting');
          note(`disconnected (${data.reason}); retry in ${Math.round(data.retryInMs / 1000)}s`);
        } else if (type === 'revoked') {
          setStatus('revoked');
          note('this device was revoked by the owner');
          clearCredentials().then(() => {
            setCreds(null);
            setPhase('PAIR');
          });
        } else if (type === 'task') {
          note(`task in: ${JSON.stringify(data.payload).slice(0, 90)}`);
        } else if (type === 'task_done') {
          note(`task ${data.result.ok ? 'done' : 'failed'}: ${data.result.error || 'ok'}`);
        } else if (type === 'command_result') {
          note(`JARVIS: ${data.payload?.message || data.status}`);
        } else if (type === 'gap') {
          note(`frame gap detected (expected ${data.expected}, got ${data.got})`);
        } else if (type === 'error_event') {
          note(`server error: ${data.code} ${data.message}`);
        }
      },
    });
    busRef.current = bus;
    bus.connect();

    api.getDevices(creds.backendUrl, creds.deviceToken)
      .then((d) => setDevices(d.devices || []))
      .catch((err) => note(err.message));

    return () => bus.stop();
  }, [phase, creds, note]);

  // ---- pairing ------------------------------------------------------------ //
  const startPairing = async () => {
    setError('');
    const url = backendUrl.trim();
    if (!url) return setError('Enter the JARVIS backend address first.');
    try {
      await api.handshake(url);                       // version check before anything else
      const device = describeThisDevice();
      const { granted } = await Notifications.requestPermissionsAsync();
      const caps = advertise({ notifications: granted, tts: true });
      const req = await api.requestPairing(url, device, caps, username.trim());
      setPairing(req);
      setPhase('WAITING');
      note(`pairing code ${req.code} — approve it in the HUD`);

      pollRef.current = setInterval(async () => {
        try {
          const claim = await api.claimPairing(url, req.code);
          if (!claim) return;                          // 425: not approved yet
          clearInterval(pollRef.current);
          await saveCredentials({
            deviceId: claim.device_id,
            deviceToken: claim.device_token,
            backendUrl: url,
            userId: claim.user_id,
          });
          setCreds({ ...claim, backendUrl: url, deviceToken: claim.device_token });
          setPhase('LINKED');
          note('paired and authenticated');
        } catch (err) {
          clearInterval(pollRef.current);
          setError(err.message);
          setPhase('PAIR');
        }
      }, 2500);
    } catch (err) {
      setError(err.message);
    }
  };

  const sendToPc = async () => {
    const pc = devices.find((d) => d.device_type === 'windows' || d.is_host);
    if (!pc) return note('no Windows device registered on this account');
    if (!command.trim()) return undefined;
    try {
      const r = await api.routeTask(creds.backendUrl, creds.deviceToken, pc.device_id,
        { text: command.trim() });
      note(r.status === 'COMPLETED'
        ? `PC: ${JSON.stringify(r.result).slice(0, 120)}`
        : `PC: ${r.error || r.status}`);
      setCommand('');
    } catch (err) {
      note(err.message);
    }
    return undefined;
  };

  // ------------------------------------------------------------------------ //
  if (phase === 'BOOT') {
    return (
      <View style={[styles.screen, styles.center]}>
        <ActivityIndicator color={AMBER} />
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.screen}>
        <StatusBar barStyle="light-content" backgroundColor={BG} />
        <View style={styles.header}>
          <Text style={styles.brand}>J.A.R.V.I.S.</Text>
          <Text style={styles.badge}>{status.toUpperCase()}</Text>
        </View>

        {phase !== 'LINKED' ? (
          <ScrollView contentContainerStyle={styles.body}>
            <Text style={styles.h}>LINK THIS DEVICE</Text>
            <Text style={styles.label}>BACKEND ADDRESS</Text>
            <TextInput
              style={styles.input}
              autoCapitalize="none"
              autoCorrect={false}
              placeholder="http://192.168.1.50:8420"
              placeholderTextColor={DIM}
              value={backendUrl}
              onChangeText={setBackendUrl}
            />
            <Text style={styles.label}>JARVIS USERNAME (OPTIONAL)</Text>
            <TextInput
              style={styles.input}
              autoCapitalize="none"
              placeholder="lucky"
              placeholderTextColor={DIM}
              value={username}
              onChangeText={setUsername}
            />

            {phase === 'WAITING' && pairing ? (
              <View style={styles.codeBox}>
                <Text style={styles.codeLabel}>SHOW THIS CODE TO THE OWNER</Text>
                <Text style={styles.code}>{pairing.code}</Text>
                <Text style={styles.hint}>
                  Approve it in the HUD under DEVICES → PAIRING REQUESTS. The code is
                  single-use and expires in {Math.round((pairing.expires_in || 600) / 60)} minutes.
                </Text>
                <ActivityIndicator color={AMBER} style={{ marginTop: 12 }} />
              </View>
            ) : (
              <Pressable style={styles.button} onPress={startPairing}>
                <Text style={styles.buttonText}>REQUEST PAIRING</Text>
              </Pressable>
            )}

            {!!error && <Text style={styles.error}>{error}</Text>}
            <Text style={styles.footnote}>
              The pairing code is not a password. It dies the moment it is used, and this
              device is only trusted after the OWNER approves it.
            </Text>
          </ScrollView>
        ) : (
          <ScrollView contentContainerStyle={styles.body}>
            <Text style={styles.h}>MY DEVICES</Text>
            {devices.map((d) => (
              <View key={d.device_id} style={styles.card}>
                <View style={styles.row}>
                  <View style={[styles.dot, { backgroundColor: d.online ? '#7CFFB2' : '#ff6b6b' }]} />
                  <Text style={styles.cardTitle}>{d.name}</Text>
                  <Text style={styles.meta}>{d.device_type}</Text>
                </View>
                <Text style={styles.meta}>
                  {d.presence} · {d.capabilities?.length || 0} capabilities
                </Text>
              </View>
            ))}

            <Text style={styles.h}>SEND TO MY PC</Text>
            <TextInput
              style={styles.input}
              placeholder="open youtube"
              placeholderTextColor={DIM}
              value={command}
              onChangeText={setCommand}
              onSubmitEditing={sendToPc}
            />
            <Pressable style={styles.button} onPress={sendToPc}>
              <Text style={styles.buttonText}>SEND</Text>
            </Pressable>

            <Text style={styles.h}>ACTIVITY</Text>
            {log.map((line, i) => (
              <Text key={`${line}-${i}`} style={styles.logLine}>{line}</Text>
            ))}
          </ScrollView>
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: BG },
  center: { alignItems: 'center', justifyContent: 'center' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 18, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: 'rgba(245,165,36,0.25)',
  },
  brand: { color: AMBER, fontSize: 16, letterSpacing: 4, fontWeight: '600' },
  badge: { color: AMBER, fontSize: 10, letterSpacing: 2, opacity: 0.8 },
  body: { padding: 18, paddingBottom: 48 },
  h: { color: AMBER, fontSize: 11, letterSpacing: 3, marginTop: 18, marginBottom: 8 },
  label: { color: DIM, fontSize: 9, letterSpacing: 2, marginTop: 10, marginBottom: 4 },
  input: {
    borderWidth: 1, borderColor: 'rgba(245,165,36,0.3)', color: '#ffd591',
    paddingHorizontal: 12, paddingVertical: 10, fontSize: 14,
    backgroundColor: 'rgba(0,0,0,0.45)',
  },
  button: {
    marginTop: 16, borderWidth: 1, borderColor: AMBER, paddingVertical: 12,
    alignItems: 'center', backgroundColor: 'rgba(245,165,36,0.08)',
  },
  buttonText: { color: AMBER, letterSpacing: 3, fontSize: 12 },
  codeBox: {
    marginTop: 20, borderWidth: 1, borderColor: 'rgba(245,165,36,0.35)', padding: 18,
    alignItems: 'center', backgroundColor: 'rgba(245,165,36,0.05)',
  },
  codeLabel: { color: DIM, fontSize: 9, letterSpacing: 2 },
  code: { color: AMBER, fontSize: 28, letterSpacing: 3, marginVertical: 12, fontWeight: '700' },
  hint: { color: DIM, fontSize: 11, textAlign: 'center', lineHeight: 16 },
  error: { color: '#ff8a8a', marginTop: 14, fontSize: 12 },
  footnote: { color: DIM, fontSize: 10, marginTop: 24, lineHeight: 15 },
  card: {
    borderWidth: 1, borderColor: 'rgba(245,165,36,0.22)', padding: 12, marginBottom: 8,
    backgroundColor: 'rgba(245,165,36,0.04)',
  },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 8 },
  cardTitle: { color: '#ffd591', fontSize: 14, flex: 1 },
  meta: { color: DIM, fontSize: 10 },
  logLine: { color: DIM, fontSize: 10, marginBottom: 3, fontVariant: ['tabular-nums'] },
});
