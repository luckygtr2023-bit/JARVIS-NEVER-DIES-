/**
 * JARVIS cross-device protocol, version 1 — client side.
 *
 * This file is the mirror image of backend/protocol.py. Keep them in step: the
 * backend serves its own copy of the contract at GET /api/protocol, and
 * `assertCompatible()` below refuses to run against a server that has moved on.
 */

export const PROTOCOL_VERSION = 1;

export const MessageType = {
  DEVICE_REGISTER: 'DEVICE_REGISTER',
  DEVICE_AUTH: 'DEVICE_AUTH',
  DEVICE_PAIR_REQUEST: 'DEVICE_PAIR_REQUEST',
  DEVICE_PAIR_APPROVE: 'DEVICE_PAIR_APPROVE',
  DEVICE_REVOKE: 'DEVICE_REVOKE',
  DEVICE_HEARTBEAT: 'DEVICE_HEARTBEAT',
  DEVICE_STATUS: 'DEVICE_STATUS',
  DEVICE_CAPABILITIES: 'DEVICE_CAPABILITIES',
  TASK_CREATE: 'TASK_CREATE',
  TASK_ASSIGN: 'TASK_ASSIGN',
  TASK_UPDATE: 'TASK_UPDATE',
  TASK_RESULT: 'TASK_RESULT',
  TASK_CANCEL: 'TASK_CANCEL',
  COMMAND_REQUEST: 'COMMAND_REQUEST',
  COMMAND_RESULT: 'COMMAND_RESULT',
  CONFIRMATION_REQUEST: 'CONFIRMATION_REQUEST',
  CONFIRMATION_RESULT: 'CONFIRMATION_RESULT',
  HELLO: 'HELLO',
  ACK: 'ACK',
  PONG: 'PONG',
  DISCONNECT: 'DISCONNECT',
  ERROR_EVENT: 'ERROR_EVENT',
};

export const Status = {
  PENDING: 'PENDING',
  QUEUED: 'QUEUED',
  ASSIGNED: 'ASSIGNED',
  RUNNING: 'RUNNING',
  WAITING_CONFIRMATION: 'WAITING_CONFIRMATION',
  COMPLETED: 'COMPLETED',
  FAILED: 'FAILED',
  CANCELLED: 'CANCELLED',
  OFFLINE: 'OFFLINE',
  TIMEOUT: 'TIMEOUT',
  REJECTED: 'REJECTED',
};

export const ErrorCode = {
  UNAUTHENTICATED: 'UNAUTHENTICATED',
  FORBIDDEN: 'FORBIDDEN',
  DEVICE_REVOKED: 'DEVICE_REVOKED',
  UNSUPPORTED_VERSION: 'UNSUPPORTED_VERSION',
  MALFORMED: 'MALFORMED',
  UNKNOWN_MESSAGE_TYPE: 'UNKNOWN_MESSAGE_TYPE',
  NOT_CLIENT_ORIGINATED: 'NOT_CLIENT_ORIGINATED',
  TARGET_OFFLINE: 'TARGET_OFFLINE',
  TARGET_UNKNOWN: 'TARGET_UNKNOWN',
  CAPABILITY_MISSING: 'CAPABILITY_MISSING',
  PERMISSION_MISSING: 'PERMISSION_MISSING',
  CONFIRMATION_REQUIRED: 'CONFIRMATION_REQUIRED',
  DUPLICATE: 'DUPLICATE',
  TIMEOUT: 'TIMEOUT',
  INTERNAL: 'INTERNAL',
};

/** The 1.0.0 short dialect the backend also still speaks. */
const LEGACY_ALIASES = {
  hello: MessageType.HELLO,
  heartbeat: MessageType.DEVICE_HEARTBEAT,
  ping: MessageType.DEVICE_HEARTBEAT,
  pong: MessageType.PONG,
  task: MessageType.TASK_ASSIGN,
  result: MessageType.TASK_RESULT,
  ack: MessageType.ACK,
  command: MessageType.COMMAND_REQUEST,
  command_result: MessageType.COMMAND_RESULT,
  disconnect: MessageType.DISCONNECT,
  error: MessageType.ERROR_EVENT,
};

let counter = 0;
export function newRequestId() {
  counter += 1;
  return `req_${Date.now().toString(36)}${counter.toString(36)}${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

export function envelope(messageType, fields = {}) {
  return {
    protocol_version: PROTOCOL_VERSION,
    message_type: messageType,
    request_id: fields.request_id || newRequestId(),
    task_id: fields.task_id || '',
    user_id: fields.user_id || '',
    source_device_id: fields.source_device_id || '',
    target_device_id: fields.target_device_id || '',
    timestamp: Date.now() / 1000,
    payload: fields.payload || {},
    status: fields.status || '',
  };
}

/** Normalise anything the server sent (v1 or legacy) into a v1-shaped object. */
export function parseFrame(raw) {
  const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
  let type = data.message_type || data.type;
  if (type && !MessageType[type]) {
    type = LEGACY_ALIASES[String(type).toLowerCase()] || type;
  }
  let payload = data.payload;
  if (!payload || typeof payload !== 'object') {
    const skip = new Set([
      'type', 'message_type', 'protocol_version', 'request_id', 'task_id', 'user_id',
      'source_device_id', 'target_device_id', 'timestamp', 'status', 'seq', 'ts',
    ]);
    payload = Object.fromEntries(Object.entries(data).filter(([k]) => !skip.has(k)));
  }
  return {
    protocol_version: data.protocol_version || 0,
    message_type: type,
    request_id: data.request_id || '',
    task_id: data.task_id || payload.task_id || '',
    user_id: data.user_id || '',
    source_device_id: data.source_device_id || '',
    target_device_id: data.target_device_id || '',
    timestamp: data.timestamp || data.ts || Date.now() / 1000,
    payload,
    status: data.status || '',
    seq: typeof data.seq === 'number' ? data.seq : null,
  };
}

/**
 * Refuse to run against an incompatible server instead of failing in odd ways
 * later. `descriptor` is the body of GET /api/protocol.
 */
export function assertCompatible(descriptor) {
  const server = Number(descriptor?.protocol_version);
  const min = Number(descriptor?.min_supported_version ?? server);
  if (!server) throw new Error('The server did not report a protocol version.');
  if (PROTOCOL_VERSION < min || PROTOCOL_VERSION > server) {
    throw new Error(
      `This app speaks protocol v${PROTOCOL_VERSION}; the server needs v${min}-v${server}. ` +
        'Update JARVIS or the app.',
    );
  }
  return true;
}
