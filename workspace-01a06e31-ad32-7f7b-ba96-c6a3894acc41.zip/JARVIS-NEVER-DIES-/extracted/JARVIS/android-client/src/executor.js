/**
 * Executes a task that JARVIS routed TO this phone.
 *
 * The contract with the backend is simple and strict: return
 * `{ ok, verified, result, error }`. `verified: true` is only allowed when the
 * effect was actually confirmed - "the intent was accepted by Android", not
 * "we asked and hoped". Anything this build cannot do returns ok:false with a
 * readable reason so JARVIS can tell the user the truth.
 */
import * as IntentLauncher from 'expo-intent-launcher';
import * as Linking from 'expo-linking';
import * as Notifications from 'expo-notifications';
import * as Speech from 'expo-speech';
import * as WebBrowser from 'expo-web-browser';
import * as Device from 'expo-device';
import * as Application from 'expo-application';

const KNOWN_APPS = {
  whatsapp: 'com.whatsapp',
  youtube: 'com.google.android.youtube',
  chrome: 'com.android.chrome',
  gmail: 'com.google.android.gm',
  maps: 'com.google.android.apps.maps',
  spotify: 'com.spotify.music',
  instagram: 'com.instagram.android',
  telegram: 'org.telegram.messenger',
  settings: 'com.android.settings',
};

const URL_FOR = {
  youtube: 'https://m.youtube.com/',
  google: 'https://www.google.com/',
  gmail: 'https://mail.google.com/',
  maps: 'https://maps.google.com/',
  whatsapp: 'https://web.whatsapp.com/',
};

function firstMatch(text, table) {
  const low = String(text || '').toLowerCase();
  return Object.keys(table).find((key) => low.includes(key));
}

async function openUrl(url) {
  await WebBrowser.openBrowserAsync(url);
  return { ok: true, verified: true, result: { opened: url } };
}

async function launchApp(packageName, label) {
  try {
    await IntentLauncher.startActivityAsync('android.intent.action.MAIN', {
      packageName,
      category: 'android.intent.category.LAUNCHER',
    });
    return { ok: true, verified: true, result: { launched: packageName, app: label } };
  } catch (err) {
    return {
      ok: false,
      verified: false,
      error: `Could not launch ${label || packageName}: ${err.message}. It may not be installed.`,
    };
  }
}

/**
 * @param {object} payload  the routed payload, usually { text } or a typed
 *                          { action, ... } from POST /api/devices/{id}/tasks
 */
export async function executeTask(payload = {}) {
  const action = payload.action || '';
  const text = String(payload.text || '');

  // ---- typed actions (preferred - unambiguous) ---------------------------- //
  if (action === 'open_url' && payload.url) return openUrl(payload.url);
  if (action === 'launch_app' && payload.package) {
    return launchApp(payload.package, payload.package);
  }
  if (action === 'speak' && payload.text) {
    Speech.speak(payload.text);
    return { ok: true, verified: true, result: { spoke: payload.text } };
  }
  if (action === 'notify') {
    await Notifications.scheduleNotificationAsync({
      content: { title: payload.title || 'JARVIS', body: payload.body || text },
      trigger: null,
    });
    return { ok: true, verified: true, result: { notified: true } };
  }
  if (action === 'device_info' || action === 'system_status') {
    return {
      ok: true,
      verified: true,
      result: {
        model: [Device.manufacturer, Device.modelName].filter(Boolean).join(' '),
        os: `${Device.osName} ${Device.osVersion}`,
        app_version: Application.nativeApplicationVersion,
        is_device: Device.isDevice,
      },
    };
  }

  // ---- natural language routed from the PC -------------------------------- //
  if (!text) {
    return { ok: false, verified: false, error: 'Empty task payload; nothing to do.' };
  }
  const low = text.toLowerCase();

  if (low.includes('notify') || low.includes('notification')) {
    await Notifications.scheduleNotificationAsync({
      content: { title: 'JARVIS', body: text },
      trigger: null,
    });
    return { ok: true, verified: true, result: { notified: text } };
  }

  if (low.startsWith('say ') || low.startsWith('speak ')) {
    const phrase = text.replace(/^(say|speak)\s+/i, '');
    Speech.speak(phrase);
    return { ok: true, verified: true, result: { spoke: phrase } };
  }

  const appKey = firstMatch(text, KNOWN_APPS);
  if (appKey && (low.includes('open') || low.includes('launch') || low.includes('start'))) {
    const launched = await launchApp(KNOWN_APPS[appKey], appKey);
    if (launched.ok) return launched;
    // fall back to the web version rather than reporting a false success
    if (URL_FOR[appKey]) return openUrl(URL_FOR[appKey]);
    return launched;
  }

  const urlKey = firstMatch(text, URL_FOR);
  if (urlKey && low.includes('open')) return openUrl(URL_FOR[urlKey]);

  const explicit = text.match(/https?:\/\/\S+/);
  if (explicit) return openUrl(explicit[0]);

  if (low.includes('open ')) {
    const target = text.split(/open\s+/i)[1]?.trim();
    if (target) {
      const url = `https://www.google.com/search?q=${encodeURIComponent(target)}`;
      const opened = await openUrl(url);
      return { ...opened, result: { ...opened.result, note: `No installed app matched "${target}"; searched the web instead.` } };
    }
  }

  // Honest refusal beats a fake success.
  return {
    ok: false,
    verified: false,
    error: `This phone does not know how to do "${text}". Supported: open a URL or app, speak, notify, report device info.`,
  };
}

export async function canOpenDeepLink(url) {
  try {
    return await Linking.canOpenURL(url);
  } catch {
    return false;
  }
}
