/**
 * REST layer: pairing, presence, routing a task to another of my devices.
 *
 * Every authenticated call carries X-Device-Token. A 401 means the OWNER
 * revoked this device: the caller must wipe the credentials and go back to the
 * pairing screen rather than retrying.
 */
import { assertCompatible } from './protocol';

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

export class RevokedError extends ApiError {}

function normaliseBase(url) {
  return String(url || '').trim().replace(/\/+$/, '');
}

export async function call(baseUrl, path, { method = 'GET', body, token, timeout = 20000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  let resp;
  try {
    resp = await fetch(`${normaliseBase(baseUrl)}${path}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'X-Device-Token': token } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    throw new ApiError(
      err.name === 'AbortError'
        ? 'JARVIS did not answer in time. Check the address and that the PC is awake.'
        : 'Cannot reach JARVIS. Check the backend URL and your connection.',
      0,
    );
  }
  clearTimeout(timer);

  const text = await resp.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      if (!resp.ok) throw new ApiError(`Server error ${resp.status}`, resp.status, text);
      throw new ApiError('The server sent a response this app could not read.', resp.status, text);
    }
  }
  if (resp.status === 401) {
    throw new RevokedError('This device is no longer authorised. Pair again.', 401, data);
  }
  if (!resp.ok) {
    const detail = data?.detail ?? data?.message ?? `HTTP ${resp.status}`;
    throw new ApiError(typeof detail === 'string' ? detail : JSON.stringify(detail),
      resp.status, data);
  }
  return data;
}

/** Fetch the contract and refuse to continue if the versions do not line up. */
export async function handshake(baseUrl) {
  const descriptor = await call(baseUrl, '/api/protocol');
  assertCompatible(descriptor);
  return descriptor;
}

export async function requestPairing(baseUrl, device, capabilities, username) {
  return call(baseUrl, '/api/devices/pairing', {
    method: 'POST',
    body: { ...device, capabilities, username: username || undefined },
  });
}

/**
 * Poll until the OWNER approves. 425 = not approved yet (keep waiting),
 * 404 = the code expired or was already used (start over).
 */
export async function claimPairing(baseUrl, code) {
  try {
    return await call(baseUrl, '/api/devices/pairing/claim', { method: 'POST', body: { code } });
  } catch (err) {
    if (err.status === 425) return null;
    throw err;
  }
}

export const getDevices = (baseUrl, token) => call(baseUrl, '/api/devices', { token });

export const getPresence = (baseUrl, token, deviceId) =>
  call(baseUrl, `/api/devices/${deviceId}/presence`, { token });

export const updateCapabilities = (baseUrl, token, deviceId, capabilities) =>
  call(baseUrl, `/api/devices/${deviceId}/capabilities`, {
    method: 'POST', token, body: { capabilities },
  });

/**
 * "Open YouTube on my PC" — send a typed task to another device.
 * requestId makes a retry idempotent: the same id returns the original task
 * instead of running the work twice.
 */
export const routeTask = (baseUrl, token, deviceId, payload, opts = {}) =>
  call(baseUrl, `/api/devices/${deviceId}/tasks`, {
    method: 'POST',
    token,
    timeout: (opts.timeout || 45) * 1000 + 5000,
    body: {
      kind: opts.kind || 'command',
      payload,
      request_id: opts.requestId || '',
      required_capability: opts.requiredCapability || '',
      timeout: opts.timeout || 45,
    },
  });
