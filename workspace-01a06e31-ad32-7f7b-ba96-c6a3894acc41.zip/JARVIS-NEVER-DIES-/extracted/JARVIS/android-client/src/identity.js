/**
 * Device identity + secure credential storage.
 *
 * Two rules from the spec are enforced here:
 *   * the device_id is issued BY THE BACKEND at pairing time and stored; the
 *     app never invents one and never treats its own package name as identity;
 *   * the device token lives in the Android Keystore via expo-secure-store,
 *     never in AsyncStorage and never in a log line.
 */
import * as Application from 'expo-application';
import * as Device from 'expo-device';
import * as SecureStore from 'expo-secure-store';

const KEY_TOKEN = 'jarvis.device_token';
const KEY_DEVICE_ID = 'jarvis.device_id';
const KEY_BACKEND = 'jarvis.backend_url';
const KEY_USER = 'jarvis.user_id';

export async function saveCredentials({ deviceId, deviceToken, backendUrl, userId }) {
  if (deviceToken) await SecureStore.setItemAsync(KEY_TOKEN, deviceToken);
  if (deviceId) await SecureStore.setItemAsync(KEY_DEVICE_ID, deviceId);
  if (backendUrl) await SecureStore.setItemAsync(KEY_BACKEND, backendUrl);
  if (userId) await SecureStore.setItemAsync(KEY_USER, userId);
}

export async function loadCredentials() {
  const [deviceToken, deviceId, backendUrl, userId] = await Promise.all([
    SecureStore.getItemAsync(KEY_TOKEN),
    SecureStore.getItemAsync(KEY_DEVICE_ID),
    SecureStore.getItemAsync(KEY_BACKEND),
    SecureStore.getItemAsync(KEY_USER),
  ]);
  return { deviceToken, deviceId, backendUrl, userId };
}

/** Called when the server says 401/revoked: forget everything, re-pair. */
export async function clearCredentials() {
  await Promise.all([
    SecureStore.deleteItemAsync(KEY_TOKEN),
    SecureStore.deleteItemAsync(KEY_DEVICE_ID),
    SecureStore.deleteItemAsync(KEY_USER),
  ]);
}

/** What this installation reports about itself when it asks to pair. */
export function describeThisDevice() {
  const model = [Device.manufacturer, Device.modelName].filter(Boolean).join(' ');
  return {
    device_name: Device.deviceName || model || 'Android device',
    device_type: 'android',
    os: `${Device.osName || 'Android'}`,
    os_version: `${Device.osVersion || ''}`,
    app_version: Application.nativeApplicationVersion || '1.0.0',
    model: model || 'unknown',
    // NOTE: the package name is included for display only. The backend does not
    // treat it as proof of anything - ownership comes from OWNER approval.
    package: Application.applicationId || 'com.jarvis.ai',
  };
}
