/**
 * The device bus client: one authenticated WebSocket, kept alive across
 * network changes.
 *
 * Behaviour required by the spec and implemented here:
 *   * heartbeat every 20 s (the server marks a device offline after 45 s);
 *   * reconnect with exponential backoff + full jitter, capped at 30 s;
 *   * a monotonic `seq` from the server is checked so gaps are visible;
 *   * every inbound TASK_ASSIGN is executed and answered with exactly one
 *     TASK_RESULT carrying `verified`;
 *   * duplicate TASK_ASSIGNs (same task_id) are answered from the cache
 *     instead of being run twice;
 *   * close code 4401/4403 means revoked - stop retrying and tell the app.
 */
import { MessageType, Status, envelope, parseFrame } from './protocol';

const HEARTBEAT_MS = 20000;
const MAX_BACKOFF_MS = 30000;
const RESULT_CACHE = 64;

export class DeviceBus {
  constructor({ baseUrl, token, onEvent, execute }) {
    this.baseUrl = String(baseUrl).replace(/\/+$/, '');
    this.token = token;
    this.onEvent = onEvent || (() => {});
    this.execute = execute;
    this.ws = null;
    this.attempt = 0;
    this.stopped = false;
    this.lastSeq = 0;
    this.heartbeatTimer = null;
    this.reconnectTimer = null;
    this.done = new Map(); // task_id -> result, so a replay is answered once
  }

  wsUrl() {
    const scheme = this.baseUrl.startsWith('https') ? 'wss' : 'ws';
    const host = this.baseUrl.replace(/^https?:\/\//, '');
    return `${scheme}://${host}/api/bus/ws?token=${encodeURIComponent(this.token)}`;
  }

  connect() {
    if (this.stopped) return;
    this.emit('connecting');
    let ws;
    try {
      ws = new WebSocket(this.wsUrl());
    } catch (err) {
      this.scheduleReconnect(`could not open socket: ${err.message}`);
      return;
    }
    this.ws = ws;

    ws.onopen = () => {
      this.attempt = 0;
      this.lastSeq = 0;
      this.emit('connected');
      this.startHeartbeat();
    };

    ws.onmessage = (event) => {
      let frame;
      try {
        frame = parseFrame(event.data);
      } catch {
        return; // never let one bad frame kill the connection
      }
      if (frame.seq != null) {
        if (frame.seq > this.lastSeq + 1 && this.lastSeq !== 0) {
          this.emit('gap', { expected: this.lastSeq + 1, got: frame.seq });
        }
        this.lastSeq = frame.seq;
      }
      this.handle(frame);
    };

    ws.onerror = () => {
      /* onclose always follows; the reconnect is scheduled there */
    };

    ws.onclose = (event) => {
      this.stopHeartbeat();
      if (event && (event.code === 4401 || event.code === 4403)) {
        this.stopped = true;
        this.emit('revoked', { code: event.code });
        return;
      }
      this.scheduleReconnect(`socket closed (${event?.code ?? 'unknown'})`);
    };
  }

  handle(frame) {
    switch (frame.message_type) {
      case MessageType.HELLO:
        this.emit('hello', frame.payload);
        break;
      case MessageType.PONG:
        break;
      case MessageType.TASK_ASSIGN:
        this.runTask(frame);
        break;
      case MessageType.TASK_CANCEL:
        this.emit('task_cancelled', frame);
        break;
      case MessageType.CONFIRMATION_REQUEST:
        this.emit('confirmation_request', frame);
        break;
      case MessageType.COMMAND_RESULT:
        this.emit('command_result', frame);
        break;
      case MessageType.ACK:
        this.emit('ack', frame);
        break;
      case MessageType.DISCONNECT:
        this.emit('server_disconnect', frame.payload);
        break;
      case MessageType.ERROR_EVENT:
        this.emit('error_event', frame.payload);
        break;
      default:
        this.emit('unknown_frame', frame);
    }
  }

  async runTask(frame) {
    const taskId = frame.task_id;
    // Idempotency: the same task must never be executed twice, e.g. after a
    // reconnect where the server re-sent an assignment it had not seen answered.
    if (this.done.has(taskId)) {
      this.send(envelope(MessageType.TASK_RESULT, {
        task_id: taskId,
        status: Status.COMPLETED,
        payload: { ...this.done.get(taskId), replayed: true },
      }));
      return;
    }

    this.emit('task', frame);
    let outcome;
    try {
      outcome = await this.execute(frame.payload || {}, frame);
    } catch (err) {
      outcome = { ok: false, verified: false, error: String(err?.message || err) };
    }
    // `verified` must only ever be true when the executor actually confirmed
    // the effect. It defaults to false here on purpose.
    const result = {
      ok: !!outcome.ok,
      verified: !!outcome.verified,
      result: outcome.result ?? null,
      error: outcome.error ?? null,
    };

    this.done.set(taskId, result);
    if (this.done.size > RESULT_CACHE) {
      this.done.delete(this.done.keys().next().value);
    }

    this.send(envelope(MessageType.TASK_RESULT, {
      task_id: taskId,
      status: result.ok ? Status.COMPLETED : Status.FAILED,
      payload: result,
    }));
    this.emit('task_done', { taskId, result });
  }

  send(message) {
    if (this.ws && this.ws.readyState === 1) {
      this.ws.send(JSON.stringify(message));
      return true;
    }
    return false;
  }

  sendCapabilities(capabilities, device = {}) {
    return this.send(envelope(MessageType.DEVICE_CAPABILITIES, {
      payload: { capabilities, ...device },
    }));
  }

  sendCommand(text, requestId) {
    return this.send(envelope(MessageType.COMMAND_REQUEST, {
      request_id: requestId,
      payload: { text },
    }));
  }

  answerConfirmation(confirmationId, approved) {
    return this.send(envelope(MessageType.CONFIRMATION_RESULT, {
      payload: { confirmation_id: confirmationId, approved },
    }));
  }

  startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(() => {
      this.send(envelope(MessageType.DEVICE_HEARTBEAT, { payload: {} }));
    }, HEARTBEAT_MS);
  }

  stopHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    this.heartbeatTimer = null;
  }

  /** 1s, 2s, 4s, 8s, 16s, 30s… each with full jitter so devices do not sync up. */
  backoffDelay() {
    const base = Math.min(MAX_BACKOFF_MS, 1000 * 2 ** this.attempt);
    return Math.round(Math.random() * base);
  }

  scheduleReconnect(reason) {
    if (this.stopped) return;
    const delay = this.backoffDelay();
    this.attempt += 1;
    this.emit('disconnected', { reason, retryInMs: delay, attempt: this.attempt });
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => this.connect(), delay);
  }

  stop() {
    this.stopped = true;
    this.stopHeartbeat();
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    try {
      this.ws?.close();
    } catch {
      /* already gone */
    }
  }

  emit(type, data) {
    this.onEvent({ type, data });
  }
}
