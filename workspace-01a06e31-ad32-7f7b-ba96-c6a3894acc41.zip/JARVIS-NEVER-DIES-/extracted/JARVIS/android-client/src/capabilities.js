/**
 * What this Android installation can actually do.
 *
 * Capabilities are advertised at pairing time and refreshed over the socket
 * with a DEVICE_CAPABILITIES frame. They must reflect reality: if the user has
 * not granted the microphone permission, do not claim voice.microphone -
 * JARVIS routes tasks based on this list and would otherwise send work the
 * phone cannot perform.
 */

/** Everything a fully-permitted build can offer. */
export const SUPPORTED = [
  'chat',
  'device.info',
  'notifications',
  'browser',
  'media.control',
  'voice.tts',
  'voice.microphone',
  'voice.stt',
  'app.launch',
  'android.intent',
  'files.scoped',
  'system.info',
];

/**
 * Build the advertised list from what is actually granted right now.
 * `grants` comes from the runtime permission checks in App.js.
 */
export function advertise(grants = {}) {
  const caps = ['chat', 'device.info', 'browser', 'app.launch', 'android.intent', 'system.info'];
  if (grants.notifications) caps.push('notifications');
  if (grants.microphone) {
    caps.push('voice.microphone');
    if (grants.speechRecognition) caps.push('voice.stt');
  }
  if (grants.tts !== false) caps.push('voice.tts');
  if (grants.media) caps.push('media.control');
  if (grants.scopedFiles) caps.push('files.scoped');
  // android.accessibility is deliberately NOT advertised unless the user has
  // explicitly enabled the accessibility service in Android settings.
  if (grants.accessibility) caps.push('android.accessibility');
  return Array.from(new Set(caps));
}
