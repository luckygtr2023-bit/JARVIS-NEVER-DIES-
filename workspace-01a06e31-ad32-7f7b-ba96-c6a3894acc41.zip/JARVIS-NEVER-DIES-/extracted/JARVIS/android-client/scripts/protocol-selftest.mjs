/**
 * Self-test for the Android client's protocol layer. Runs on plain Node with
 * zero dependencies:  node scripts/protocol-selftest.mjs
 *
 * src/protocol.js is written as an ES module for Metro, and this package is
 * CommonJS by default, so the source is loaded through a data: URL import
 * rather than changing the package type (which would break babel.config.js).
 *
 * It checks the client contract against the same rules the backend enforces in
 * tests/test_crossdevice.py, so a drift between the two shows up immediately.
 */
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const source = readFileSync(resolve(here, '../src/protocol.js'), 'utf8');
const mod = await import(`data:text/javascript,${encodeURIComponent(source)}`);

const { MessageType, Status, ErrorCode, PROTOCOL_VERSION, envelope, parseFrame,
  assertCompatible, newRequestId } = mod;

let passed = 0;
const failures = [];

function check(name, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`[PASS] ${name}`);
  } else {
    failures.push(name);
    console.log(`[FAIL] ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

// ---- envelope ------------------------------------------------------------ //
const env = envelope(MessageType.TASK_RESULT, {
  task_id: 'tsk_1', payload: { ok: true, verified: true }, status: Status.COMPLETED,
});
check('envelope carries every protocol field',
  ['protocol_version', 'message_type', 'request_id', 'task_id', 'user_id',
    'source_device_id', 'target_device_id', 'timestamp', 'payload', 'status']
    .every((k) => k in env));
check('envelope pins protocol_version 1', env.protocol_version === 1);
check('request ids are unique', newRequestId() !== newRequestId());

// ---- parsing the server's frames ----------------------------------------- //
const v1 = parseFrame(JSON.stringify({
  protocol_version: 1, message_type: 'TASK_ASSIGN', task_id: 'tsk_9',
  payload: { text: 'open youtube' }, seq: 4,
}));
check('parses a v1 TASK_ASSIGN', v1.message_type === MessageType.TASK_ASSIGN
  && v1.payload.text === 'open youtube' && v1.seq === 4);

const legacy = parseFrame(JSON.stringify({
  type: 'task', task_id: 'tsk_10', payload: { text: 'open whatsapp' }, seq: 2,
}));
check('parses a legacy task frame', legacy.message_type === MessageType.TASK_ASSIGN
  && legacy.task_id === 'tsk_10');

const flat = parseFrame(JSON.stringify({ type: 'ack', task_id: 't', duplicate: true }));
check('recovers a flattened legacy body into payload', flat.payload.duplicate === true);

const hello = parseFrame(JSON.stringify({
  type: 'hello', payload: { device_id: 'dev_android_1', protocol_version: 1 }, seq: 1,
}));
check('parses hello', hello.message_type === MessageType.HELLO
  && hello.payload.device_id === 'dev_android_1');

// ---- version negotiation -------------------------------------------------- //
check('accepts a matching server',
  assertCompatible({ protocol_version: 1, min_supported_version: 1 }) === true);

let refused = false;
try {
  assertCompatible({ protocol_version: 2, min_supported_version: 2 });
} catch {
  refused = true;
}
check('refuses a server that outgrew this client', refused);

refused = false;
try {
  assertCompatible({});
} catch {
  refused = true;
}
check('refuses a server that reports no version', refused);

// ---- vocabulary parity with the backend ----------------------------------- //
const required = ['DEVICE_REGISTER', 'DEVICE_AUTH', 'DEVICE_PAIR_REQUEST',
  'DEVICE_PAIR_APPROVE', 'DEVICE_REVOKE', 'DEVICE_HEARTBEAT', 'DEVICE_STATUS',
  'DEVICE_CAPABILITIES', 'TASK_CREATE', 'TASK_ASSIGN', 'TASK_UPDATE', 'TASK_RESULT',
  'TASK_CANCEL', 'COMMAND_REQUEST', 'COMMAND_RESULT', 'CONFIRMATION_REQUEST',
  'CONFIRMATION_RESULT', 'ERROR_EVENT'];
check('client knows every spec message type',
  required.every((t) => MessageType[t] === t),
  required.filter((t) => MessageType[t] !== t).join(','));
check('client knows the offline error code',
  ErrorCode.TARGET_OFFLINE === 'TARGET_OFFLINE' && Status.OFFLINE === 'OFFLINE');
check('protocol version constant is 1', PROTOCOL_VERSION === 1);

console.log(`\n${'='.repeat(56)}`);
console.log(`ANDROID CLIENT PROTOCOL SELF-TEST: ${passed}/${passed + failures.length} PASS`);
if (failures.length) {
  console.log(`FAILED: ${failures.join(', ')}`);
  process.exit(1);
}
console.log('='.repeat(56));
