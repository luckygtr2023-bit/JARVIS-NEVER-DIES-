# J.A.R.V.I.S. — start here

This is the **Windows JARVIS project**. It is the whole system: the backend, the
HUD, the Windows shell and build, and the cross-device layer that a future
Android client plugs into.

**Made by Lucky Kumar.**

---

## Run it on Windows (30 seconds of typing)

```
1. Extract the ZIP, e.g. to C:\JARVIS\
2. Double-click  start_jarvis.bat
3. Create your account in the HUD — the FIRST account becomes the OWNER
```

That is the whole setup. The launcher builds a virtual environment, installs
dependencies on first run, and serves the HUD at `http://localhost:8420/`.
Full detail, troubleshooting and the EXE build: **`WINDOWS_SETUP.md`**.

## What this project is

```
JARVIS/
├── start_jarvis.bat     ← run JARVIS on Windows (primary entry point)
├── stop_jarvis.bat      ← stop a stray background backend
├── backend/             FastAPI control plane — the brain of the system
│   ├── main.py            app factory, SPA mount, greeting, browser-open guard
│   ├── security.py        PBKDF2 passwords, session + device tokens, roles
│   ├── db.py              SQLite (WAL) schema and helpers
│   ├── deps.py            principal / owner / permission dependencies
│   ├── device_bus.py      WebSocket registry, dispatch, task records
│   ├── protocol.py        cross-device protocol v1  ← the device contract
│   ├── capabilities.py    what each device CAN do; checked before dispatch
│   ├── combos.py          dynamic OmniRoute Combo management (unlimited)
│   ├── memory_store.py    long-term memory with credential guards
│   ├── audit.py           append-only audit log, scrubs anything secret-shaped
│   ├── routers/           auth, devices, bus, agent, combos, crossdevice, …
│   ├── services/          agent loop, AI clients, tools, browser, voice
│   └── webui/             the built HUD the backend serves (generated)
├── frontend/            HUD source (React + Vite) → builds into backend/webui
├── src-tauri/           optional Tauri desktop shell: window, tray, global hotkey
├── android-client/      Android companion app source (Expo, com.jarvis.ai)
├── scripts/             BUILD_EXE.bat, verify_exe.bat, jarvis.spec, verifiers
├── tests/               139 pytest tests
├── docs/                PROTOCOL.md, ANDROID_BUILD.md, screenshots, references
├── WINDOWS_SETUP.md     exact Windows setup, build and troubleshooting
├── FINAL_REPORT.md      PASS/FAIL per area, labelled honestly
└── BLOCKERS.md          what genuinely cannot be done here, and why
```

One backend. One device ecosystem. Windows is the base JARVIS; Android is a
companion client that pairs into the same account and speaks the same protocol.

## The device ecosystem

```
                 ┌──────────────────────────────┐
                 │   Windows JARVIS (this app)  │
                 │   backend + HUD + host device│
                 └──────────────┬───────────────┘
                                │  authenticated WSS  /api/bus/ws
              ┌─────────────────┼─────────────────┐
              │                 │                 │
        Android phone     Android tablet     second Windows PC
        (com.jarvis.ai)                      (same installer)
```

* one `user_id` owns many devices; each installation has its own `device_id`
* a new device shows a single-use `PAIR-XXXX-XXXX` code that expires in 10
  minutes, dies on use, and needs OWNER approval — it is never a password
* one authenticated WebSocket carries everything, so it works across different
  networks behind any HTTPS/WSS reverse proxy; nothing assumes a LAN
* capabilities are checked **before** a task is routed, so you are told "your
  phone cannot do that" instead of watching a task time out
* a task sent to an offline device is reported as offline, never as done

Full contract: **`docs/PROTOCOL.md`**, and live at `GET /api/protocol`.

## Verify it yourself — do not take anyone's word for it

```cmd
.venv\Scripts\python -m pytest                    :: 139 tests
.venv\Scripts\python scripts\verify_live.py       :: 72 live checks (fresh DB)
.venv\Scripts\python scripts\verify_omniroute.py  :: 17 Combo-fidelity checks
.venv\Scripts\python scripts\verify_ui.py         :: 42 real-browser UI checks
cd android-client && npm test                     :: 13 client protocol self-tests
```

`verify_live.py` drives a **running** server over real HTTP and real WebSockets:
pairing, revocation, cross-device routing, confirmation, Combo permissions, the
protocol handshake and the capability gate.

### The two browser-level suites

`scripts/verify_ui.py` drives the **real built HUD in a real Chromium**: it
creates the first account, proves it becomes OWNER, logs out, is refused with a
wrong password, logs back in, opens COMBOS, then adds / edits / disables /
enables / defaults / grants / deletes a Combo by clicking the same buttons you
would. It finishes as a second, non-OWNER account and proves the management
controls are absent *and* that the backend still refuses the same calls when the
UI is bypassed. Needs `pip install playwright && playwright install chromium`.

`scripts/verify_omniroute.py` starts a stand-in OmniRoute that records what it
receives, points JARVIS at it, and asserts that awkward Combo names
(`My Custom Combo`, `combo.with.dots-and_UNDERSCORES`, `JARVIS-copy-400`) arrive
on the wire byte-for-byte with no provider prefix. It needs no network.

## Building the binaries

| Target | Command | Where |
|---|---|---|
| `JARVIS.exe` | `scripts\BUILD_EXE.bat` | a real Windows PC |
| Android APK | `cd android-client && eas build --platform android --profile preview` | any Android-capable environment |

Neither binary is included. Both were left unbuilt on purpose — the environment
that assembled this ZIP is Linux with no Windows toolchain and no Android SDK,
and a placeholder binary would be a lie. Every source file and build
configuration needed for both is here.

## For the next agent working on Android

The backend does not need redesigning. Implement or extend
`android-client/` against the existing contract:

1. `docs/PROTOCOL.md` — envelope, all 18 message types, guarantees
2. `docs/ANDROID_BUILD.md` — SDK/JDK versions, permissions, build commands
3. `android-client/src/` — protocol mirror, pairing, device bus, executor,
   already self-tested with `npm test`

## House rules this project is held to

* Never fake success. Work is labelled IMPLEMENTED / TESTED / VERIFIED /
  SIMULATED / BLOCKED / NOT TESTED and the label is meant.
* A task sent to an offline device is reported as offline, never as executed.
* `verified: true` only when the effect was actually read back.
* No secrets in the repo, the EXE or the APK. No plaintext passwords ever.
* The AI can read configuration but can never grant itself a permission or a
  Combo, and a paired device can never promote itself to OWNER.
* The HUD is a HUD: amber `#f5a524` on `#030509`, rings, panels, mono type.
  Not a dashboard, and never any browser or OS chrome drawn inside it.
* Combo names reach OmniRoute **verbatim** — no prefixes, no whitelist, no cap.
