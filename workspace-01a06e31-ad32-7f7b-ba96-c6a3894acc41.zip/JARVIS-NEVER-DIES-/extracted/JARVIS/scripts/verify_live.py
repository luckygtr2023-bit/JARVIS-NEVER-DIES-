"""Live end-to-end verification against a RUNNING JARVIS backend.

This is not a unit test: it drives the real HTTP + WebSocket server exactly as a
Windows HUD and a future Android client would, and prints PASS/FAIL per step.

Usage:  python3 scripts/verify_live.py [base_url]
"""
from __future__ import annotations

import asyncio
import json
import sys
import time

import httpx
import websockets

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8420"
WS_BASE = BASE.replace("http://", "ws://").replace("https://", "wss://")

results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> bool:
    results.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))
    return ok


async def main() -> int:
    stamp = str(int(time.time()))
    user = f"lucky{stamp[-6:]}"
    async with httpx.AsyncClient(base_url=BASE, timeout=30) as c:
        # ---------------- health ---------------- #
        r = await c.get("/api/health")
        check("health endpoint responds", r.status_code == 200, f"HTTP {r.status_code}")
        comps = r.json()["components"]
        check("health reports components honestly",
              all(v.get("status") for v in comps.values()),
              ", ".join(f"{k}={v['status']}" for k, v in list(comps.items())[:6]))

        # ---------------- HUD served ---------------- #
        r = await c.get("/")
        check("HUD html is served", r.status_code == 200 and "<div id=\"root\">" in r.text)

        # ---------------- greeting ---------------- #
        r = await c.get("/api/greeting")
        check("startup greeting contains the author line",
              "Made by Lucky Kumar." in r.json()["text"], r.json()["text"][:70])

        # ---------------- account ---------------- #
        r = await c.post("/api/auth/register", json={"username": user, "password": "supersecret1"})
        check("account creation", r.status_code == 200, r.text[:120])
        token = r.json()["token"]
        role = r.json()["user"]["role"]
        H = {"Authorization": f"Bearer {token}"}
        check("first account is OWNER (or later account is limited)",
              role in ("OWNER", "LIMITED_USER"), f"role={role}")

        r = await c.post("/api/auth/login", json={"username": user, "password": "wrong"})
        check("wrong password rejected", r.status_code == 401)

        r = await c.get("/api/auth/me", headers=H)
        check("session authenticates", r.status_code == 200, r.json().get("username", ""))

        # ---------------- devices ---------------- #
        r = await c.get("/api/devices", headers=H)
        devices = r.json()["devices"]
        host = next((d for d in devices if d["is_host"]), None)
        check("host device auto-registered", host is not None,
              host["device_id"] if host else "missing")

        if role != "OWNER":
            print("\n! Not the OWNER on this database — pairing checks need a fresh DB.")
            return summary()

        # ---------------- pairing ---------------- #
        r = await c.post("/api/devices/pairing",
                         json={"device_name": "Verification Phone", "device_type": "android",
                               "os": "Android", "os_version": "14",
                               # what this simulated client can really do; the
                               # capability gate refuses anything not listed here
                               "capabilities": ["chat", "browser", "app.launch",
                                                "voice.tts", "notifications"]})
        pairing = r.json()
        code = pairing["code"]
        check("pairing code issued", code.startswith("PAIR-") and len(code) == 14, code)

        r = await c.post("/api/devices/pairing/claim", json={"code": code})
        check("claim before approval is refused", r.status_code == 425)

        r = await c.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve", headers=H)
        check("owner approves pairing", r.status_code == 200, r.text[:120])
        device_id = r.json()["device_id"]

        r = await c.post("/api/devices/pairing/claim", json={"code": code})
        check("device claims its credential", r.status_code == 200, r.text[:120])
        device_token = r.json()["device_token"]
        check("device credential is a token, not the code",
              device_token.startswith("jtk_") and code not in device_token)

        r = await c.post("/api/devices/pairing/claim", json={"code": code})
        check("pairing code is single-use", r.status_code == 404)

        r = await c.get("/api/auth/me", headers={"X-Device-Token": device_token})
        check("device authenticates with its own token",
              r.status_code == 200 and r.json()["via"] == "device")

        # ---------------- offline routing ---------------- #
        r = await c.post("/api/chat", json={"text": "Open YouTube on my phone"}, headers=H)
        body = r.json()
        check("offline target reported, not faked",
              body["status"] == "FAILED" and body.get("offline") is True, body.get("message", "")[:90])

        # ---------------- WebSocket bus: the future Android client ---------------- #
        connected = asyncio.Event()
        got_task = asyncio.Event()
        task_payload = {}

        async def fake_android():
            url = f"{WS_BASE}/api/bus/ws?token={device_token}"
            async with websockets.connect(url) as ws:
                hello = json.loads(await ws.recv())
                if hello.get("type") == "hello":
                    connected.set()
                await ws.send(json.dumps({"type": "heartbeat"}))
                await ws.recv()  # pong
                while True:
                    msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=30))
                    if msg.get("type") == "task":
                        task_payload.update(msg)
                        got_task.set()
                        # the device really "does the work" and reports back
                        await ws.send(json.dumps({
                            "type": "result", "task_id": msg["task_id"], "ok": True,
                            "verified": True,
                            "result": {"opened": "youtube", "url": "https://m.youtube.com/"},
                        }))
                    elif msg.get("type") == "disconnect":
                        return

        android = asyncio.create_task(fake_android())
        try:
            await asyncio.wait_for(connected.wait(), timeout=10)
            check("paired device connects to the control plane", True, "WebSocket hello received")
        except asyncio.TimeoutError:
            check("paired device connects to the control plane", False, "no hello frame")

        await asyncio.sleep(0.4)
        r = await c.get("/api/devices", headers=H)
        phone = next((d for d in r.json()["devices"] if d["device_id"] == device_id), None)
        check("presence shows the device online", bool(phone and phone["online"]))

        # PC -> phone task, with a real verified result coming back
        r = await c.post("/api/chat", json={"text": "Open YouTube on my phone"}, headers=H, timeout=60)
        body = r.json()
        check("cross-device task routed and completed",
              body["status"] == "COMPLETED", json.dumps(body.get("result_data"))[:90])
        check("result is marked verified by the target device", body.get("verified") is True)
        check("target device actually received the task", got_task.is_set())

        # ---------------- permissions ---------------- #
        DH = {"X-Device-Token": device_token}
        r = await c.post("/api/tools/run", json={"name": "shutdown_pc", "args": {}}, headers=DH)
        check("device without permission is blocked", r.status_code == 403,
              r.json().get("detail", "")[:80])

        # ---------------- confirmation ---------------- #
        import pathlib

        # NOTE: must live inside the configured file access root, otherwise the
        # path sandbox correctly refuses it before the tool ever runs.
        root = pathlib.Path((await c.get("/api/settings", headers=H)).json()["security"]["file_root"])
        tmp = root / f"jarvis_verify_{stamp}.txt"
        tmp.write_text("delete me")
        r = await c.post("/api/tools/run",
                         json={"name": "delete_file", "args": {"path": str(tmp)}}, headers=H)
        body = r.json()
        check("destructive action pauses for confirmation",
              body.get("status") == "WAITING_CONFIRMATION" and tmp.exists())
        r = await c.post("/api/tools/confirm",
                         json={"confirm_id": body["confirm_id"], "approve": False}, headers=H)
        check("cancel leaves the file untouched",
              r.json()["status"] == "CANCELLED" and tmp.exists())

        r = await c.post("/api/tools/run",
                         json={"name": "delete_file", "args": {"path": str(tmp)}}, headers=H)
        cid = r.json()["confirm_id"]
        r = await c.post("/api/tools/confirm", json={"confirm_id": cid, "approve": True}, headers=H)
        check("authorized action executes and verifies",
              r.json()["status"] == "COMPLETED" and not tmp.exists(), json.dumps(r.json())[:120])

        # the path sandbox itself
        outside = await c.post("/api/tools/run",
                               json={"name": "delete_file", "args": {"path": "/etc/hostname"}},
                               headers=H)
        oid = outside.json().get("confirm_id")
        outside2 = await c.post("/api/tools/confirm", json={"confirm_id": oid, "approve": True},
                                headers=H)
        check("file sandbox blocks paths outside the root",
              outside2.json()["status"] == "FAILED"
              and "outside the permitted file root" in (outside2.json().get("error") or ""))

        # ---------------- revocation kicks the live device ---------------- #
        r = await c.post(f"/api/devices/{device_id}/revoke", headers=H)
        check("device revoked", r.status_code == 200)
        await asyncio.sleep(0.6)
        r = await c.get("/api/auth/me", headers=DH)
        check("revoked token stops working", r.status_code == 401)

        android.cancel()

        # ---------------- streaming + memory + telemetry ---------------- #
        async with c.stream("POST", "/api/chat/stream", json={"text": "what's my cpu"},
                            headers=H) as resp:
            frames = [line async for line in resp.aiter_lines() if line.startswith("data:")]
        check("SSE stream returns a verified tool result",
              any("CPU is at" in f for f in frames), frames[0][:80] if frames else "no frames")

        r = await c.post("/api/memory", json={"key": "gmail_password", "value": "hunter2000"},
                         headers=H)
        check("memory guard refuses credentials", r.status_code == 422,
              r.json().get("detail", "")[:60])

        r = await c.post("/api/memory", json={"key": "favorite_city", "value": "Patna"}, headers=H)
        check("memory stores a normal fact", r.status_code == 200)

        r = await c.get("/api/system/status", headers=H)
        s = r.json()
        check("live telemetry is real", s["available"] and s["processes"] > 0,
              f"cpu={s['cpu']}% ram={s['ram']}% proc={s['processes']}")

        r = await c.get("/api/audit?limit=200", headers=H)
        actions = {e["action"] for e in r.json()["entries"]}
        check("audit log captured the security events",
              {"pairing.approve", "pairing.claim", "device.revoke"} <= actions,
              f"{len(actions)} distinct actions")


        # ---------------- Combo management (spec 10) ---------------- #
        r = await c.get("/api/combos", headers=H)
        cj = r.json()
        check("combo registry readable", r.status_code == 200, f"HTTP {r.status_code}")
        check("legacy JARVIS-copy-2..12 auto-migrated, nothing lost",
              {f"JARVIS-copy-{i}" for i in range(2, 13)}
              <= {x["omniroute_identifier"] for x in cj.get("combos", [])},
              f"{cj.get('total')} combos present")
        check("combo count is advertised as unlimited", cj.get("limit") is None,
              f"limit={cj.get('limit')}")

        r = await c.get("/api/combos")
        check("combo registry rejects unauthenticated reads", r.status_code == 401,
              f"HTTP {r.status_code}")

        ident = f"JARVIS-copy-13-{stamp[-4:]}"
        r = await c.post("/api/combos", headers=H, json={
            "display_name": "Live Check", "omniroute_identifier": ident})
        new_id = r.json().get("combo_id", "")
        check("owner can add a 13th+ combo (no cap)", r.status_code == 200, r.text[:100])
        check("identifier is stored byte-for-byte",
              r.json().get("omniroute_identifier") == ident,
              repr(r.json().get("omniroute_identifier")))

        r = await c.post("/api/combos", headers=H, json={
            "display_name": "Dup", "omniroute_identifier": ident})
        check("duplicate combo identifier refused", r.status_code == 400, f"HTTP {r.status_code}")

        other = f"limited{stamp[-6:]}"
        r = await c.post("/api/auth/register", json={"username": other, "password": "anotherpass9"})
        oh = {"Authorization": f"Bearer {r.json()['token']}"}
        oid = r.json()["user"]["user_id"]
        check("second account is not OWNER", r.json()["user"]["role"] != "OWNER",
              r.json()["user"]["role"])

        r = await c.get("/api/combos", headers=oh)
        check("non-owner sees only granted combos (none yet)", r.json().get("total") == 0,
              f"total={r.json().get('total')}")

        for label, path, body in [
            ("create", "/api/combos",
             {"display_name": "X", "omniroute_identifier": "JARVIS-copy-999"}),
            ("edit", f"/api/combos/{new_id}", {"display_name": "X"}),
            ("enable/disable", f"/api/combos/{new_id}/enabled", {"enabled": False}),
            ("set-default", f"/api/combos/{new_id}/default", {}),
            ("delete", f"/api/combos/{new_id}/delete", {"confirm": True}),
            ("assign", f"/api/combos/{new_id}/assign",
             {"subject_type": "user", "subject_id": oid}),
            ("unassign", f"/api/combos/{new_id}/unassign",
             {"subject_type": "user", "subject_id": oid}),
        ]:
            rr = await c.post(path, headers=oh, json=body)
            check(f"non-owner {label} blocked by the server", rr.status_code == 403,
                  f"HTTP {rr.status_code}")

        r = await c.post("/api/combos/select", headers=oh, json={"omniroute_identifier": ident})
        check("non-owner cannot select an ungranted combo", r.status_code == 403,
              f"HTTP {r.status_code}")
        r = await c.post("/api/settings", headers=oh, json={"ai": {"combo": ident}})
        check("non-owner cannot smuggle a combo through /api/settings",
              r.status_code == 403, f"HTTP {r.status_code}")

        await c.post(f"/api/combos/{new_id}/assign", headers=H,
                     json={"subject_type": "user", "subject_id": oid})
        r = await c.get("/api/combos", headers=oh)
        check("granted combo becomes visible to the user",
              [x["omniroute_identifier"] for x in r.json()["combos"]] == [ident],
              str([x["omniroute_identifier"] for x in r.json()["combos"]]))
        r = await c.post("/api/combos/select", headers=oh, json={"omniroute_identifier": ident})
        check("granted user can select the combo", r.status_code == 200, f"HTTP {r.status_code}")

        await c.post(f"/api/combos/{new_id}/unassign", headers=H,
                     json={"subject_type": "user", "subject_id": oid})
        r = await c.get("/api/combos/mine", headers=oh)
        check("revoking access drops the stale selection at once",
              r.json().get("selected") == "", f"selected={r.json().get('selected')!r}")

        r = await c.post(f"/api/combos/{new_id}/delete", headers=H, json={"confirm": False})
        check("combo deletion demands explicit confirmation",
              r.status_code == 409 and "confirm=true" in r.text, f"HTTP {r.status_code}")
        r = await c.post(f"/api/combos/{new_id}/delete", headers=H, json={"confirm": True})
        check("confirmed combo deletion succeeds", r.status_code == 200, f"HTTP {r.status_code}")


        # ---------------- protocol v1 + capabilities (spec 7/8) ----------- #
        r = await c.get("/api/protocol")
        desc = r.json()
        check("protocol descriptor is served unauthenticated", r.status_code == 200,
              f"v{desc.get('protocol_version')}")
        required_types = {"DEVICE_REGISTER", "DEVICE_AUTH", "DEVICE_PAIR_REQUEST",
                          "DEVICE_PAIR_APPROVE", "DEVICE_REVOKE", "DEVICE_HEARTBEAT",
                          "DEVICE_STATUS", "DEVICE_CAPABILITIES", "TASK_CREATE",
                          "TASK_ASSIGN", "TASK_UPDATE", "TASK_RESULT", "TASK_CANCEL",
                          "COMMAND_REQUEST", "COMMAND_RESULT", "CONFIRMATION_REQUEST",
                          "CONFIRMATION_RESULT", "ERROR_EVENT"}
        check("every spec message type is in the contract",
              required_types <= set(desc["message_types"]),
              f"{len(desc['message_types'])} types")
        check("contract documents reconnect + heartbeat",
              "backoff" in desc["transport"]["reconnect"]
              and desc["transport"]["heartbeat_seconds"] > 0)

        r = await c.get("/api/capabilities")
        caps_catalog = {x["capability"] for x in r.json()["capabilities"]}
        check("capability catalogue covers android and windows",
              {"android.intent", "voice.stt", "notifications", "windows.automation",
               "input.keyboard_mouse", "ai.local"} <= caps_catalog,
              f"{len(caps_catalog)} capabilities")

        # a SECOND android device, speaking protocol v1 this time
        r = await c.post("/api/devices/pairing",
                         json={"device_name": "Verification Tablet", "device_type": "android",
                               "os": "Android", "os_version": "15", "app_version": "1.0.0",
                               "capabilities": ["chat", "browser", "voice.tts"]})
        p2 = r.json()
        check("a user can pair a SECOND android device", p2["code"].startswith("PAIR-"),
              p2["code"])
        pid2 = p2["pairing_id"]
        await c.post(f"/api/devices/pairing/{pid2}/approve", headers=H)
        claim2 = (await c.post("/api/devices/pairing/claim", json={"code": p2["code"]})).json()
        tablet_token = claim2["device_token"]
        tablet_id = claim2["device_id"]
        check("second device gets its own distinct identity",
              tablet_id != device_id, f"{tablet_id} vs {device_id}")
        await c.post(f"/api/devices/{tablet_id}/permissions",
                     json={"permissions": ["chat"]}, headers=H)

        r = await c.get("/api/devices", headers=H)
        listing = r.json()
        check("all devices of one user are listed together",
              listing["total"] >= 3, f"{listing['total']} devices")

        v1_done = asyncio.Event()
        v1_state = {}

        async def v1_android():
            """A client speaking protocol v1 exactly as the Android app does."""
            async with websockets.connect(f"{WS_BASE}/api/bus/ws?token={tablet_token}") as ws:
                hello = json.loads(await ws.recv())
                v1_state["hello"] = hello
                # v1 heartbeat -> expect a v1 PONG (dialect promotion)
                await ws.send(json.dumps({
                    "protocol_version": 1, "message_type": "DEVICE_HEARTBEAT",
                    "request_id": "req_hb_1", "payload": {}}))
                v1_state["pong"] = json.loads(await ws.recv())
                # refresh capabilities over the socket
                await ws.send(json.dumps({
                    "protocol_version": 1, "message_type": "DEVICE_CAPABILITIES",
                    "request_id": "req_caps_1",
                    "payload": {"capabilities": ["chat", "browser", "voice.tts",
                                                 "notifications", "app.launch"],
                                "app_version": "1.1.0"}}))
                v1_state["caps_ack"] = json.loads(await ws.recv())
                # try to forge a server frame - must be refused
                await ws.send(json.dumps({
                    "protocol_version": 1, "message_type": "DEVICE_PAIR_APPROVE",
                    "request_id": "req_forge", "payload": {}}))
                v1_state["forged"] = json.loads(await ws.recv())
                v1_done.set()
                # then behave like a real device and answer routed work
                while True:
                    msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=30))
                    if msg.get("message_type") == "TASK_ASSIGN" or msg.get("type") == "task":
                        v1_state["task"] = msg
                        await ws.send(json.dumps({
                            "protocol_version": 1, "message_type": "TASK_RESULT",
                            "task_id": msg.get("task_id"),
                            "payload": {"ok": True, "verified": True,
                                        "result": {"opened": "https://m.youtube.com/"}}}))
                    elif msg.get("message_type") == "DISCONNECT":
                        return

        v1_task = asyncio.create_task(v1_android())
        try:
            await asyncio.wait_for(v1_done.wait(), timeout=15)
        except asyncio.TimeoutError:
            pass

        check("v1 client is greeted with the protocol version",
              v1_state.get("hello", {}).get("payload", {}).get("protocol_version") == 1)
        check("v1 heartbeat is answered in v1",
              v1_state.get("pong", {}).get("message_type") == "PONG",
              str(v1_state.get("pong", {}).get("message_type")))
        check("capabilities refresh over the socket is accepted",
              "app.launch" in v1_state.get("caps_ack", {}).get("payload", {})
                                     .get("capabilities", []))
        check("a device cannot forge a server-only frame",
              v1_state.get("forged", {}).get("payload", {}).get("code")
              == "NOT_CLIENT_ORIGINATED",
              str(v1_state.get("forged", {}).get("payload", {}).get("code")))

        r = await c.get(f"/api/devices/{tablet_id}/presence", headers=H)
        check("presence endpoint sees the live v1 device",
              r.json()["presence"] == "ONLINE", r.json()["presence"])

        # typed cross-device route, phone -> tablet, with idempotency
        r = await c.post(f"/api/devices/{tablet_id}/tasks", headers=H,
                         json={"kind": "command", "payload": {"text": "open youtube"},
                               "request_id": "req_route_once", "timeout": 20})
        routed = r.json()
        check("typed task routed to the v1 device and verified",
              routed["status"] == "COMPLETED" and routed["verified"] is True,
              json.dumps(routed.get("result"))[:70])
        r2 = await c.post(f"/api/devices/{tablet_id}/tasks", headers=H,
                          json={"kind": "command", "payload": {"text": "open youtube"},
                                "request_id": "req_route_once", "timeout": 20})
        check("same request_id does not run the work twice",
              r2.json()["task_id"] == routed["task_id"],
              f"{r2.json()['task_id']} vs {routed['task_id']}")

        # capability gate: the tablet never advertised screen.capture
        r = await c.post(f"/api/devices/{tablet_id}/tasks", headers=H,
                         json={"payload": {"text": "take a screenshot"},
                               "required_capability": "screen.capture"})
        check("capability is checked BEFORE the task is sent",
              r.status_code == 409
              and r.json()["detail"]["code"] == "CAPABILITY_MISSING",
              f"HTTP {r.status_code}")

        v1_task.cancel()

    return summary()


def summary() -> int:
    passed = sum(1 for _, ok, _ in results if ok)
    total = len(results)
    print(f"\n{'=' * 60}\nLIVE VERIFICATION: {passed}/{total} PASS")
    for name, ok, detail in results:
        if not ok:
            print(f"  FAILED: {name} — {detail}")
    print("=" * 60)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
