@echo off
REM ===================================================================
REM  Launch the built JARVIS.exe and PROVE it works.
REM  Prints PASS/FAIL for each check - paste the output back to the agent.
REM ===================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."
set "EXEPATH="
for /r "%CD%" %%F in (JARVIS.exe) do if not defined EXEPATH set "EXEPATH=%%F"
if not defined EXEPATH (echo [FAIL] JARVIS.exe not found. Run BUILD_EXE.bat first. & pause & exit /b 1)
echo EXE: !EXEPATH!

start "" "!EXEPATH!"
echo Waiting 25s for the backend to come up...
timeout /t 25 /nobreak >nul

curl -s -o "%TEMP%\jarvis_health.json" -w "HTTP %%{http_code}\n" http://127.0.0.1:8420/api/health
if errorlevel 1 (echo [FAIL] backend did not answer on port 8420) else (echo [PASS] backend answered)
type "%TEMP%\jarvis_health.json"
echo.
echo Now check by hand:
echo   1. Did the HUD open in the browser exactly ONCE?
echo   2. Does the greeting say "Made by Lucky Kumar."?
echo   3. Press V outside the window - does it start listening?
echo   4. Close the window - does the process exit cleanly?
echo.
python scripts\verify_live.py http://127.0.0.1:8420
pause
