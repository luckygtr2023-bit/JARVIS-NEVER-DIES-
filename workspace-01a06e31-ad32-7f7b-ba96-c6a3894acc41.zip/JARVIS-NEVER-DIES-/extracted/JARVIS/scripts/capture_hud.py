"""Visual regression capture: drives the real HUD in Chromium and saves a PNG per
screen so the result can be compared with the reference screenshots (spec 17)."""
from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path

from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8420"
OUT = Path(__file__).resolve().parent.parent / "docs" / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)

USER = "lucky"
PASSWORD = "supersecret1"


async def main() -> None:
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1568, "height": 733})
        errors: list[str] = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

        await page.goto(BASE, wait_until="networkidle")
        await page.wait_for_timeout(800)
        await page.screenshot(path=str(OUT / "00-auth.png"))

        # log in (or create the account on a fresh database)
        await page.fill("#u", USER)
        await page.fill("#p", PASSWORD)
        await page.click("button[type=submit]")
        await page.wait_for_timeout(1500)
        if await page.query_selector(".auth-err"):
            msg = await page.inner_text(".auth-err")
            if "Invalid" in msg:
                toggle = await page.query_selector(".auth-toggle")
                if toggle:
                    await toggle.click()
                    await page.fill("#u", USER)
                    await page.fill("#p", PASSWORD)
                    await page.click("button[type=submit]")
                    await page.wait_for_timeout(1500)

        await page.wait_for_selector(".hud-grid", timeout=15000)
        await page.wait_for_timeout(2500)          # let telemetry + greeting land
        await page.screenshot(path=str(OUT / "01-hud.png"))

        # a real command so the comms log is populated
        await page.fill(".chat-input", "what's my cpu")
        await page.click(".send-btn")
        await page.wait_for_timeout(2500)
        await page.screenshot(path=str(OUT / "02-hud-conversation.png"))

        for tab, name in [("ACTIVITY", "03-activity"), ("MEMORY", "04-memory"),
                          ("DEVICES", "05-devices"), ("COMBOS", "08-combos"),
                          ("SETTINGS", "06-settings")]:
            await page.click(f".nav a:text('{tab}')")
            await page.wait_for_timeout(1600)
            await page.screenshot(path=str(OUT / f"{name}.png"))

        # settings is a long page - capture the AI block full height too
        await page.screenshot(path=str(OUT / "07-settings-full.png"), full_page=True)

        print("Saved:", ", ".join(sorted(f.name for f in OUT.glob("*.png"))))
        real_errors = [e for e in errors if "favicon" not in e.lower()]
        print("Console/page errors:", real_errors if real_errors else "NONE")
        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
