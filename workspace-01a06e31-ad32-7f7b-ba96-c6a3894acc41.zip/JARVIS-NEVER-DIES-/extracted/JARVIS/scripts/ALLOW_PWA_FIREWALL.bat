@echo off
REM ===================================================================
REM  Add the Windows Firewall inbound rule so your phone / LAN devices can
REM  reach the JARVIS backend (and its /pwa/ screen) on TCP 8420.
REM
REM  IMPORTANT: Run this from an ELEVATED (Run as Administrator) prompt,
REM       or right-click the file and choose "Run as administrator".
REM
REM  This only opens the port on PRIVATE networks (your home / trusted Wi-Fi).
REM  It does NOT expose the port to the internet.
REM ===================================================================
setlocal
netsh advfirewall firewall delete rule name="JARVIS (TCP 8420)" >nul 2>&1
netsh advfirewall firewall add rule name="JARVIS (TCP 8420)" ^
  dir=in action=allow protocol=TCP localport=8420 profile=private
if errorlevel 1 (
  echo.
  echo [FAIL] Could not add the rule. Run this as Administrator:
  echo   Right-click  -Run as administrator-, or open an elevated Command
  echo   Prompt in this folder and run:  scripts\ALLOW_PWA_FIREWALL.bat
) else (
  echo.
  echo [OK] Added firewall rule "JARVIS (TCP 8420)" for inbound TCP 8420 on
  echo      Private networks. Your Android phone can now reach:
  echo          http://<this-PC-IP>:8420/pwa/
  echo      Find your IP with:  ipconfig  (IPv4 Address)
)
echo.
pause
endlocal
