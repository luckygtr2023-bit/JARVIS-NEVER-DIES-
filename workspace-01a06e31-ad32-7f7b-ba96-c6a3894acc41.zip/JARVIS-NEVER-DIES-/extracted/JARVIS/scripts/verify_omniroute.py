#!/usr/bin/env python3
"""
Prove that a Combo created in the HUD reaches OmniRoute BYTE-FOR-BYTE.

A stand-in OmniRoute is started on a local port and records every request it
receives. JARVIS is pointed at it, an OWNER creates Combos with deliberately
awkward names through the ordinary API, selects each one, and sends a chat.
The assertion is on what the wire actually carried - not on what the code
appears to do.

Run with the JARVIS backend NOT already using the port; this script starts and
stops its own JARVIS instance.

    python scripts/verify_omniroute.py
"""
import json, os, shutil, socket, subprocess, sys, tempfile, threading, time
import urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer

RECEIVED = []
results = []


def check(label, ok, detail=""):
    results.append((label, bool(ok), detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {label}" + (f" — {detail}" if detail else ""))


class FakeOmniRoute(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        if self.path.endswith("/models"):
            self._json(200, {"data": [{"id": "JARVIS-copy-2"}]})
        else:
            self._json(404, {"error": "nope"})

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        RECEIVED.append(body)
        self._json(200, {
            "choices": [{"message": {"role": "assistant", "content": "ack"}}],
            "model": body.get("model"),
        })


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


def api(base, method, path, token=None, body=None):
    req = urllib.request.Request(f"{base}/api{path}", method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    data = json.dumps(body).encode() if body is not None else None
    try:
        with urllib.request.urlopen(req, data, timeout=60) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:200]


def main():
    omni_port = free_port()
    jarvis_port = free_port()
    srv = HTTPServer(("127.0.0.1", omni_port), FakeOmniRoute)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    home = tempfile.mkdtemp(prefix="jarvis-omni-")

    env = dict(os.environ)
    env.update({
        "JARVIS_HOME": home,
        "JARVIS_HOST": "127.0.0.1",
        "JARVIS_PORT": str(jarvis_port),
        "JARVIS_OPEN_BROWSER": "0",
        "OMNIROUTE_BASE": f"http://127.0.0.1:{omni_port}/v1",
        # make sure Ollama can never be picked as a fallback during this test
        "OLLAMA_BASE": "http://127.0.0.1:1/v1",
        "OLLAMA_NATIVE": "http://127.0.0.1:1",
    })
    proc = subprocess.Popen([sys.executable, "-m", "backend.main"], env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{jarvis_port}"
    try:
        for _ in range(100):
            try:
                urllib.request.urlopen(f"{base}/api/health", timeout=2)
                break
            except Exception:
                time.sleep(0.2)
        else:
            print("backend never came up")
            return 1

        st, reg = api(base, "POST", "/auth/register",
                      body={"username": "owner", "password": "supersecret1"})
        token = reg["token"]
        check("test OWNER created", reg["user"]["role"] == "OWNER", reg["user"]["role"])

        # Names chosen to break any prefixing / normalising / whitelisting.
        names = [
            "JARVIS-copy-13",
            "JARVIS-copy-400",
            "MY-CUSTOM-COMBO",
            "My Custom Combo",
            "combo.with.dots-and_UNDERSCORES",
        ]
        for n in names:
            st, _ = api(base, "POST", "/combos", token,
                        {"display_name": f"T {n}", "omniroute_identifier": n})
            check(f"Combo accepted with no whitelist: {n!r}", st == 200, f"HTTP {st}")

        for n in names:
            RECEIVED.clear()
            st, _ = api(base, "POST", "/combos/select", token, {"omniroute_identifier": n})
            if st != 200:
                check(f"select {n!r}", False, f"HTTP {st}")
                continue
            st, chat = api(base, "POST", "/chat", token, {"text": "ping"})
            sent = [r.get("model") for r in RECEIVED]
            ok = bool(sent) and sent[0] == n
            check(f"OmniRoute received {n!r} unchanged", ok,
                  f"wire model={sent[0]!r}" if sent else "no request reached OmniRoute")
            if sent:
                check(f"no provider prefix added to {n!r}",
                      "/" not in sent[0] and not sent[0].lower().startswith(("openai", "omniroute", "anthropic")),
                      sent[0])

        # a disabled Combo must not be usable even though it exists
        st, listing = api(base, "GET", "/combos", token)
        target = next(c for c in listing["combos"] if c["omniroute_identifier"] == "JARVIS-copy-13")
        api(base, "POST", f"/combos/{target['combo_id']}/enabled", token, {"enabled": False})
        st, _ = api(base, "POST", "/combos/select", token,
                    {"omniroute_identifier": "JARVIS-copy-13"})
        check("a disabled Combo cannot be selected", st >= 400, f"HTTP {st}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        srv.shutdown()
        shutil.rmtree(home, ignore_errors=True)

    passed = sum(1 for _, ok, _ in results if ok)
    print("\n" + "=" * 60)
    print(f"OMNIROUTE COMBO FIDELITY: {passed}/{len(results)} PASS")
    print("=" * 60)
    return 0 if passed == len(results) else 1


sys.exit(main())
