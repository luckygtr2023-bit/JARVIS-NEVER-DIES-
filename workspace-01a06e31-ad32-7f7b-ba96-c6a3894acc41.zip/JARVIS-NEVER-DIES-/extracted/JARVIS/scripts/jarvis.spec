# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec for JARVIS.exe.

Run from the project root:  pyinstaller scripts/jarvis.spec --noconfirm

Notes that matter (spec 30):
  * fastapi.middleware.cors and the uvicorn *.auto loaders are imported
    dynamically at runtime, so they MUST be listed as hiddenimports
  * backend/webui (the built HUD) is bundled as data, not code
  * console=True by default: a visible console makes first-run problems
    diagnosable. Set JARVIS_WINDOWED=1 before building for a silent exe -
    backend/main.py already guards against sys.stdout being None.
"""
import os
import sys
from pathlib import Path

ROOT = Path(os.path.abspath(SPECPATH)).parent
WEBUI = ROOT / "backend" / "webui"

if not WEBUI.is_dir():
    raise SystemExit(
        "backend/webui is missing. Build the HUD first:\n"
        "    cd frontend && npm install && npm run build"
    )

WINDOWED = os.environ.get("JARVIS_WINDOWED", "0") == "1"

hiddenimports = [
    # dynamically resolved by FastAPI / Starlette
    "fastapi.middleware.cors",
    "fastapi.middleware.gzip",
    "starlette.middleware.cors",
    "multipart",
    "python_multipart",
    # uvicorn picks these at runtime through the "auto" indirection
    "uvicorn.logging",
    "uvicorn.loops",
    "uvicorn.loops.auto",
    "uvicorn.loops.asyncio",
    "uvicorn.protocols",
    "uvicorn.protocols.http",
    "uvicorn.protocols.http.auto",
    "uvicorn.protocols.http.h11_impl",
    "uvicorn.protocols.websockets",
    "uvicorn.protocols.websockets.auto",
    "uvicorn.protocols.websockets.websockets_impl",
    "uvicorn.lifespan",
    "uvicorn.lifespan.on",
    "websockets.legacy",
    "websockets.legacy.server",
    "wsproto",
    "h11",
    # our own lazily imported modules
    "backend.services.browser_tools",
    "backend.services.windows_tools",
    "backend.services.voice_engine",
    "backend.services.tools_registry",
    "backend.services.agent_loop",
    "backend.routers.auth",
    "backend.routers.devices",
    "backend.routers.agent",
    "backend.routers.system",
    "backend.routers.misc",
    "backend.routers.voice_ai",
    "backend.routers.bus",
    # optional runtime extras - harmless if absent
    "psutil",
    "pyperclip",
]

# Windows-only extras; only collected when actually building on Windows.
if sys.platform.startswith("win"):
    hiddenimports += ["win32api", "win32con", "win32gui", "win32process", "pythoncom",
                      "pywintypes", "pyautogui", "mss", "pyttsx3",
                      "pyttsx3.drivers", "pyttsx3.drivers.sapi5", "comtypes"]

datas = [(str(WEBUI), "webui")]

a = Analysis(
    [str(ROOT / "scripts" / "jarvis_entry.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "matplotlib", "notebook", "pytest", "playwright"],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="JARVIS",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    runtime_tmpdir=None,
    console=not WINDOWED,
    disable_windowed_traceback=False,
    icon=None,
)
