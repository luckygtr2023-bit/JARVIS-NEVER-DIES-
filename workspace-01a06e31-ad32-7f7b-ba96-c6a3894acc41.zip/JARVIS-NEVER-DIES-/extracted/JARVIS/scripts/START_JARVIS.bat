@echo off
REM Run JARVIS from source (no packaging). Useful for development and updates.
setlocal
cd /d "%~dp0\.."
where python >nul 2>&1 || (echo Python is not on PATH. & pause & exit /b 1)
if not exist "backend\webui\index.html" (
  echo Building the HUD once...
  pushd frontend && call npm install --no-audit --no-fund && call npm run build && popd
)
set JARVIS_OPEN_BROWSER=1
python -m backend.main
pause
