@echo off
REM ===================================================================
REM  JARVIS - build the real Windows JARVIS.exe
REM  Run this from a normal Command Prompt in the project root:
REM       scripts\BUILD_EXE.bat
REM ===================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."
echo.
echo === JARVIS Windows build ===
echo Project root: %CD%
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [FAIL] Python is not on PATH. Install Python 3.11+ and tick "Add to PATH".
  pause & exit /b 1
)

echo [1/5] Python dependencies...
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt || (echo [FAIL] pip install failed & pause & exit /b 1)
python -m pip install pyinstaller || (echo [FAIL] pyinstaller install failed & pause & exit /b 1)

echo [2/5] Building the HUD...
where npm >nul 2>&1
if errorlevel 1 (
  echo [WARN] npm not found - reusing the existing backend\webui bundle.
) else (
  pushd frontend
  call npm install --no-audit --no-fund || (echo [FAIL] npm install failed & popd & pause & exit /b 1)
  call npm run build || (echo [FAIL] HUD build failed & popd & pause & exit /b 1)
  popd
)
if not exist "backend\webui\index.html" (
  echo [FAIL] backend\webui\index.html missing - the HUD did not build.
  pause & exit /b 1
)

echo [3/5] Running the test suite...
python -m pytest -q
if errorlevel 1 (
  echo [WARN] Tests failed. Continuing, but read the output above.
)

echo [4/5] Packaging JARVIS.exe with PyInstaller...
rmdir /s /q build 2>nul
python -m PyInstaller scripts\jarvis.spec --noconfirm --distpath dist_win --workpath build
if errorlevel 1 (echo [FAIL] PyInstaller failed & pause & exit /b 1)

echo [5/5] Locating the real executable...
set "EXEPATH="
for /r "%CD%" %%F in (JARVIS.exe) do if not defined EXEPATH set "EXEPATH=%%F"
if not defined EXEPATH (
  echo [FAIL] No JARVIS.exe found anywhere under %CD%.
  pause & exit /b 1
)
echo.
echo ===================================================================
echo  BUILD COMPLETE
echo  EXACT EXE PATH: !EXEPATH!
for %%A in ("!EXEPATH!") do echo  Size: %%~zA bytes
echo ===================================================================
echo.
echo Launch it now to verify? (the HUD should open once at localhost:8420)
choice /c YN /m "Launch JARVIS.exe"
if errorlevel 2 goto :end
start "" "!EXEPATH!"
:end
pause
