"""Frozen-app entrypoint for JARVIS.exe.

Kept deliberately tiny: it fixes sys.path for the bundle, guards stdio, points
the app at the bundled HUD, opens the HUD exactly once, and starts the server.
"""
from __future__ import annotations

import io
import os
import sys
from pathlib import Path


def _guard_stdio() -> None:
    """--windowed builds hand us None streams; anything that prints would crash."""
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is None or not hasattr(stream, "write"):
            setattr(sys, name, io.TextIOWrapper(io.BytesIO(), encoding="utf-8", errors="replace"))
    if getattr(sys, "stdin", None) is None:
        sys.stdin = io.TextIOWrapper(io.BytesIO(), encoding="utf-8")


_guard_stdio()

if getattr(sys, "frozen", False):
    BUNDLE = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    os.environ.setdefault("JARVIS_WEBUI", str(BUNDLE / "webui"))
    sys.path.insert(0, str(BUNDLE))
else:
    ROOT = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(ROOT))
    os.environ.setdefault("JARVIS_WEBUI", str(ROOT / "backend" / "webui"))

os.environ.setdefault("JARVIS_OPEN_BROWSER", "1")


def main() -> None:
    from backend import config
    from backend.main import app, _open_browser_once
    import uvicorn

    print(f"{config.APP_NAME} {config.APP_VERSION} — starting on port {config.PORT}")
    print(f"HUD:  http://localhost:{config.PORT}")
    print(f"Data: {config.DATA_DIR}")
    print(f"Bind: {config.HOST}:{config.PORT}  (0.0.0.0 = reachable from your LAN)")

    # Start the real OS-level V hotkey when the HUD is not embedded in Tauri.
    if os.environ.get("JARVIS_GLOBAL_HOTKEY", "1") == "1":
        try:
            from backend.services.voice_engine import hotkeys
            status = hotkeys.start()
            print(f"Global hotkey: {'V (OS level)' if status['os_level'] else status.get('error')}")
        except Exception as exc:
            print(f"Global hotkey unavailable: {exc}")

    _open_browser_once(config.PORT)
    uvicorn.run(app, host=config.HOST, port=config.PORT, log_level="info", access_log=False)


if __name__ == "__main__":
    main()
