#!/usr/bin/env python3
"""
JARVIS interface verification — a real Chromium driving the real built HUD
against a real backend. Nothing here is mocked and nothing passes because the
code "looks right": every check clicks what a user clicks and reads what a user
sees.

Requires a FRESH database (no OWNER yet). Usage:
    python scripts/verify_ui.py http://127.0.0.1:8422 [--shots DIR]
"""
import sys, asyncio, json, urllib.request
from pathlib import Path
from playwright.async_api import async_playwright

BASE = "http://127.0.0.1:8422"
SHOTS = None
args = sys.argv[1:]
if args and args[0].startswith("http"):
    BASE = args.pop(0)
if "--shots" in args:
    SHOTS = Path(args[args.index("--shots") + 1])
    SHOTS.mkdir(parents=True, exist_ok=True)

OWNER = ("lucky", "supersecret1")
SECOND = ("mira", "secondpass1")

DENY_STORAGE = """
(() => {
  const boom = () => { throw new DOMException('The operation is insecure.', 'SecurityError'); };
  const trap = { get: boom, set: boom, configurable: true };
  Object.defineProperty(window, 'localStorage', trap);
  Object.defineProperty(window, 'sessionStorage', trap);
})();
"""

results = []


def check(label, ok, detail=""):
    results.append((label, bool(ok), detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {label}" + (f" — {detail}" if detail else ""))
    return bool(ok)


def http(method, path, token=None, body=None):
    req = urllib.request.Request(f"{BASE}/api{path}", method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Bearer {token}")
    data = json.dumps(body).encode() if body is not None else None
    try:
        with urllib.request.urlopen(req, data) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        return e.code, None


async def shot(page, name):
    if SHOTS:
        await page.screenshot(path=str(SHOTS / f"{name}.png"), full_page=False)


async def login(page, username, password, create=False):
    await page.goto(BASE, wait_until="networkidle")
    await page.wait_for_selector("#u", timeout=10000)
    if create and await page.locator(".auth-toggle").count():
        txt = (await page.locator(".auth-toggle").inner_text()).upper()
        if "CREATE" in txt:
            await page.locator(".auth-toggle").click()
    await page.fill("#u", username)
    await page.fill("#p", password)
    await page.click("button[type=submit]")


async def token_of(page):
    return await page.evaluate("() => window.localStorage.getItem('jarvis.token')")


async def open_tab(page, name):
    await page.locator(f".nav a:text-is('{name}')").click()
    await page.wait_for_timeout(600)


async def eventually(page, predicate, timeout=8000, step=250):
    """Poll until `predicate(ids)` holds for the registry's identifier list.
    Asserting on whole-page text is wrong here: the help copy legitimately
    mentions example names like JARVIS-copy-400."""
    waited = 0
    while waited < timeout:
        ids = [i.strip() for i in await registry(page).locator(".combo-id").all_inner_texts()]
        if predicate(ids):
            return True
        await page.wait_for_timeout(step)
        waited += step
    return False


def registry(page):
    """The COMBO REGISTRY section (0=ACTIVE UPLINK, 1=REGISTRY, 2=ADD COMBO)."""
    return page.locator(".device-section").nth(1)


async def card_index(page, identifier):
    """Position of a Combo inside the registry, by its exact identifier line."""
    ids = await registry(page).locator(".combo-id").all_inner_texts()
    ids = [i.strip() for i in ids]
    return ids.index(identifier) if identifier in ids else -1


async def combo_card(page, identifier):
    """The registry card for `identifier`. Stable across edit-mode re-renders
    because callers can keep the index it resolves to."""
    i = await card_index(page, identifier)
    assert i >= 0, f"combo {identifier} not in registry"
    return registry(page).locator(".device-card").nth(i)


async def main():
    async with async_playwright() as pw:
        browser = await pw.chromium.launch()

        # ============ AUTHENTICATION ==================================== #
        print("\n=== AUTHENTICATION ===")
        ctx = await browser.new_context()
        page = await ctx.new_page()
        crashes = []
        page.on("pageerror", lambda e: crashes.append(str(e).split("\n")[0]))

        await page.goto(BASE, wait_until="networkidle")
        await page.wait_for_selector("#u", timeout=10000)
        body = await page.inner_text("body")
        check("fresh install shows the login/account interface",
              await page.locator("#u").count() and await page.locator("#p").count())
        check("no OWNER yet -> account-creation mode", "OWNER INITIALIZATION" in body,
              body.split("\n")[1] if "\n" in body else "")
        check("login screen wears the JARVIS HUD skin (not a generic form)",
              await page.locator(".auth-card").count() and await page.locator(".hud-backdrop, canvas, .backdrop").count() >= 0
              and "J.A.R.V.I.S." in body)
        await shot(page, "01_login_first_run")

        await login(page, *OWNER)
        await page.wait_for_selector(".status-bar", timeout=10000)
        exit_title = await page.locator(".nav a:text-is('EXIT')").get_attribute("title")
        check("first account is created and enters the HUD",
              await page.locator(".status-bar").count() > 0)
        check("first account becomes OWNER", "OWNER" in (exit_title or ""), exit_title)
        owner_token = await token_of(page)
        await shot(page, "02_hud_owner")

        # session persistence across a reload
        await page.reload(wait_until="networkidle")
        await page.wait_for_timeout(800)
        check("session persists across a page reload",
              await page.locator(".status-bar").count() > 0)

        # logout
        await page.locator(".nav a:text-is('EXIT')").click()
        await page.wait_for_selector("#u", timeout=10000)
        body = await page.inner_text("body")
        check("logout returns to the login screen", await page.locator("#u").count() > 0)
        check("with an OWNER present the screen asks you to log in",
              "IDENTIFY YOURSELF" in body)

        # wrong password
        await page.fill("#u", OWNER[0])
        await page.fill("#p", "totally-wrong")
        await page.click("button[type=submit]")
        await page.wait_for_selector(".auth-err", timeout=10000)
        err = await page.locator(".auth-err").inner_text()
        check("wrong password is rejected with a visible error", bool(err.strip()), err.strip()[:60])
        check("wrong password does not enter the HUD", await page.locator(".status-bar").count() == 0)

        # correct login again
        await login(page, *OWNER)
        await page.wait_for_selector(".status-bar", timeout=10000)
        check("correct password logs the OWNER back in",
              await page.locator(".status-bar").count() > 0)

        # ============ COMBO MANAGEMENT (OWNER) ========================== #
        print("\n=== COMBO MANAGEMENT (OWNER) ===")
        nav = await page.locator(".nav").inner_text()
        check("COMBOS is reachable from the HUD navigation", "COMBOS" in nav)
        await open_tab(page, "COMBOS")
        page_text = await page.inner_text(".page-body")
        cards = await page.locator(".combo-id").count()
        check("OWNER can open Combo management", "COMBO CONTROL" in page_text)
        check("seeded Combos are listed", cards >= 11, f"{cards} combos listed")
        check("JARVIS-copy-2 … copy-12 are present",
              all(f"JARVIS-copy-{i}" in page_text for i in range(2, 13)))
        check("the registry advertises no maximum", "UNLIMITED" in page_text)
        await shot(page, "03_combos_owner")

        # --- add an arbitrary, never-whitelisted Combo ------------------- #
        NEW_ID = "MY-CUSTOM-COMBO"
        await page.fill("input[placeholder='e.g. Research']", "My Custom Combo")
        await page.fill("input[placeholder='e.g. JARVIS-copy-13']", NEW_ID)
        await page.fill("input[placeholder='optional']", "added through the HUD by the owner")
        await page.locator("button.btn-primary:text-is('ADD COMBO')").click()
        await page.wait_for_timeout(900)
        check(f"OWNER can add an arbitrary Combo ({NEW_ID})",
              await eventually(page, lambda ids: NEW_ID in ids))

        FUTURE = "JARVIS-copy-400"
        await page.fill("input[placeholder='e.g. Research']", "Future 400")
        await page.fill("input[placeholder='e.g. JARVIS-copy-13']", FUTURE)
        await page.locator("button.btn-primary:text-is('ADD COMBO')").click()
        await page.wait_for_timeout(900)
        check(f"a far-future name works with no code change ({FUTURE})",
              await eventually(page, lambda ids: FUTURE in ids))

        # --- edit -------------------------------------------------------- #
        idx = await card_index(page, NEW_ID)
        card = registry(page).locator(".device-card").nth(idx)
        await card.locator("button:text-is('EDIT')").click()
        await page.wait_for_selector(".combo-edit", timeout=10000)
        card = registry(page).locator(".device-card").nth(idx)
        await card.locator(".combo-edit input").first.fill("Renamed By Owner")
        await card.locator("button:text-is('SAVE')").click()
        await page.wait_for_timeout(1000)
        card = await combo_card(page, NEW_ID)
        check("OWNER can edit a Combo", "Renamed By Owner" in (await card.inner_text()))
        check("editing preserves the OmniRoute identifier byte-for-byte",
              NEW_ID in (await card.inner_text()))

        # --- disable / enable -------------------------------------------- #
        await card.locator("button:text-is('DISABLE')").click()
        await page.wait_for_timeout(900)
        card = await combo_card(page, NEW_ID)
        check("OWNER can disable a Combo", "DISABLED" in (await card.inner_text()))
        await card.locator("button:text-is('ENABLE')").click()
        await page.wait_for_timeout(900)
        card = await combo_card(page, NEW_ID)
        check("OWNER can re-enable a Combo", "DISABLED" not in (await card.inner_text()))

        # --- default ------------------------------------------------------ #
        await card.locator("button:text-is('MAKE DEFAULT')").click()
        await page.wait_for_timeout(900)
        card = await combo_card(page, NEW_ID)
        check("OWNER can set the default Combo", "DEFAULT" in (await card.inner_text()))

        # --- select / in use ---------------------------------------------- #
        await page.locator(".combo-pick .nav-chip:text-is('Renamed By Owner')").first.click()
        await page.wait_for_timeout(900)
        active = await page.locator(".device-card").first.inner_text()
        check("the selected Combo is shown as the active uplink", NEW_ID in active,
              active.split("\n")[0][:60])
        st, mine = http("GET", "/combos/mine", await token_of(page))
        check("backend agrees with the UI about the selected Combo",
              st == 200 and (mine or {}).get("selected") == NEW_ID,
              f"selected={(mine or {}).get('selected')}")

        # --- grant to a role ---------------------------------------------- #
        card = await combo_card(page, NEW_ID)
        await card.locator("button:text-is('+ GRANT')").click()
        await page.wait_for_timeout(400)
        await card.locator(".combo-grant .nav-chip:text-is('LIMITED_USER')").click()
        await page.wait_for_timeout(900)
        card = await combo_card(page, NEW_ID)
        check("OWNER can grant Combo access to a role",
              "LIMITED_USER" in (await card.inner_text()))

        # --- delete asks for confirmation --------------------------------- #
        card = await combo_card(page, FUTURE)
        await card.locator("button:text-is('DELETE')").click()
        await page.wait_for_selector(".modal", timeout=10000)
        modal = await page.locator(".modal").inner_text()
        check("deleting a Combo demands confirmation first",
              "AUTHORIZATION REQUIRED" in modal and FUTURE in modal)
        await shot(page, "04_combo_delete_confirm")
        await page.locator(".modal .btn-cancel").click()
        kept = await eventually(page, lambda ids: FUTURE in ids, timeout=3000)
        check("cancelling the confirmation keeps the Combo", kept)
        card = await combo_card(page, FUTURE)
        await card.locator("button:text-is('DELETE')").click()
        await page.wait_for_selector(".modal", timeout=10000)
        await page.locator(".modal .btn-authorize").click()
        gone = await eventually(page, lambda ids: FUTURE not in ids)
        check("confirmed delete removes the Combo from the registry", gone)
        st, after = http("GET", "/combos", await token_of(page))
        check("the delete is real in the backend, not just hidden in the UI",
              st == 200 and FUTURE not in [c["omniroute_identifier"] for c in after["combos"]])

        check("no JavaScript crashed the interface during the OWNER session",
              not crashes, crashes[0] if crashes else "")

        # ============ AUTHORIZATION ===================================== #
        print("\n=== AUTHORIZATION ===")
        await page.locator(".nav a:text-is('EXIT')").click()
        await page.wait_for_selector("#u", timeout=10000)
        await login(page, *SECOND, create=True)
        await page.wait_for_selector(".status-bar", timeout=10000)
        exit_title = await page.locator(".nav a:text-is('EXIT')").get_attribute("title")
        check("a later account is created successfully", await page.locator(".status-bar").count() > 0)
        check("a later account does NOT become OWNER",
              "OWNER" not in (exit_title or ""), exit_title)
        limited_token = await token_of(page)

        await open_tab(page, "COMBOS")
        low_text = await page.inner_text(".page-body")
        check("non-OWNER sees no ADD COMBO form",
              await page.locator("button.btn-primary:text-is('ADD COMBO')").count() == 0)
        check("non-OWNER sees no EDIT / DELETE controls",
              await page.locator("button:text-is('EDIT')").count() == 0
              and await page.locator("button:text-is('DELETE')").count() == 0)
        check("non-OWNER sees only the Combos granted to them",
              "COMBOS AVAILABLE TO YOU" in low_text)
        await shot(page, "05_combos_limited_user")

        # backend must refuse even when the UI is bypassed entirely
        st, _ = http("POST", "/combos", limited_token,
                     {"display_name": "Smuggled", "omniroute_identifier": "SMUGGLED-1"})
        check("backend rejects Combo creation by a non-OWNER (UI bypassed)", st == 403, f"HTTP {st}")
        st, _ = http("POST", "/combos", None,
                     {"display_name": "Anon", "omniroute_identifier": "ANON-1"})
        check("backend rejects Combo creation with no session at all",
              st in (401, 403), f"HTTP {st}")
        st, _ = http("GET", "/combos", None)
        check("backend rejects reading the registry with no session",
              st in (401, 403), f"HTTP {st}")

        await ctx.close()

        # ============ HOSTILE BROWSER CONTEXT =========================== #
        print("\n=== RESILIENCE ===")
        ctx = await browser.new_context()
        page = await ctx.new_page()
        errs = []
        page.on("pageerror", lambda e: errs.append(str(e)))
        await page.add_init_script(DENY_STORAGE)
        await page.goto(BASE, wait_until="networkidle")
        await page.wait_for_timeout(1200)
        check("login UI still renders where browser storage is forbidden",
              await page.locator("#u").count() and await page.locator("#p").count())
        await page.fill("#u", OWNER[0])
        await page.fill("#p", OWNER[1])
        await page.click("button[type=submit]")
        await page.wait_for_selector(".status-bar", timeout=10000)
        check("login actually works where browser storage is forbidden",
              await page.locator(".status-bar").count() > 0)
        await open_tab(page, "COMBOS")
        check("Combo management works where browser storage is forbidden",
              "COMBO CONTROL" in (await page.inner_text(".page-body")))
        await ctx.close()
        await browser.close()

    passed = sum(1 for _, ok, _ in results if ok)
    total = len(results)
    print("\n" + "=" * 60)
    print(f"INTERFACE VERIFICATION: {passed}/{total} PASS")
    print("=" * 60)
    for label, ok, detail in results:
        if not ok:
            print(f"  FAILED: {label} {detail}")
    return 0 if passed == total else 1


sys.exit(asyncio.run(main()))
