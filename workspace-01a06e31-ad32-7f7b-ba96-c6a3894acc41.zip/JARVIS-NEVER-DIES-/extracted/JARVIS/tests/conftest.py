"""Shared fixtures. Every test runs against a throwaway database."""
from __future__ import annotations

import os
import sys
import tempfile
import uuid
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# Keep the tmpfs from filling with orphaned WAL/SHM files if a run is interrupted.
os.environ.setdefault("JARVIS_HOME", tempfile.mkdtemp(prefix="jarvis_test_"))


@pytest.fixture()
def client(monkeypatch):
    from fastapi.testclient import TestClient

    from backend import config, db

    tmpdb = Path(tempfile.gettempdir()) / f"jarvis_test_{uuid.uuid4().hex}.db"
    db.reset_for_tests(str(tmpdb))

    from backend.main import create_app

    app = create_app()
    with TestClient(app) as c:
        yield c

    try:
        tmpdb.unlink(missing_ok=True)
    except Exception:
        pass
    # SQLite WAL / SHM companions can be left behind if a connection lingered;
    # remove them so repeated runs never exhaust the tmpfs.
    for suffix in ("-wal", "-shm"):
        try:
            Path(str(tmpdb) + suffix).unlink(missing_ok=True)
        except Exception:
            pass


def register(client, username="lucky", password="supersecret1"):
    resp = client.post("/api/auth/register", json={"username": username, "password": password})
    assert resp.status_code == 200, resp.text
    return resp.json()


def auth_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture()
def owner(client):
    data = register(client)
    return {"token": data["token"], "user": data["user"],
            "headers": auth_headers(data["token"])}
