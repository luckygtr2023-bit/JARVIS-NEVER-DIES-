"""PWA structural + functional tests.

The PWA is served by the EXISTING backend (no second server). These tests prove
the offline shell, manifest, service worker and icons are served, and that the
PWA uses the real auth + device-bus + protocol endpoints rather than inventing
its own.
"""
from __future__ import annotations

import json

from tests.conftest import register


def _login(client, user="pwa_owner", password="password1"):
    d = register(client, username=user, password=password)
    return {"Authorization": f"Bearer {d['token']}"}


# ------------------------------ static shell ------------------------------ #
def test_pwa_index_served(client):
    r = client.get("/pwa/")
    assert r.status_code == 200
    assert "J.A.R.V.I.S." in r.text
    assert "/pwa/manifest.json" in r.text or "/pwa/styles.css" in r.text


def test_pwa_manifest_valid(client):
    r = client.get("/pwa/manifest.json")
    assert r.status_code == 200
    data = json.loads(r.text)
    assert data["name"]
    assert data["start_url"] == "/pwa/"
    assert data["display"] == "standalone"
    assert any(i["sizes"] == "512x512" for i in data["icons"])


def test_pwa_service_worker(client):
    r = client.get("/pwa/sw.js")
    assert r.status_code == 200
    assert "addEventListener('fetch'" in r.text or "addEventListener(\"fetch\"" in r.text
    assert "/api/" in r.text          # API is network-only, never cached


def test_pwa_icons(client):
    r = client.get("/pwa/icons/icon-192.png")
    assert r.status_code == 200
    assert r.content[:8] == b"\x89PNG\r\n\x1a\n"   # PNG magic


def test_pwa_css(client):
    r = client.get("/pwa/styles.css")
    assert r.status_code == 200
    assert "--amber:#f5a524" in r.text.replace(" ", "").replace(" ", "")


def test_pwa_no_path_traversal(client):
    # a traversal attempt must never leak a file outside the PWA dir
    r = client.get("/pwa/../db.py")
    assert r.status_code in (403, 200)
    if r.status_code == 200:
        # if it returns a body it must be the PWA index shell, not a Python file
        assert "J.A.R.V.I.S." in r.text or "<html" in r.text


# --------------------------- uses existing backend ----------------------- #
def test_pwa_uses_real_auth(client):
    h = _login(client)
    me = client.get("/api/auth/me", headers=h)
    assert me.status_code == 200
    assert me.json()["username"] == "pwa_owner"


def test_pwa_chat_uses_real_agent(client):
    h = _login(client)
    r = client.post("/api/chat", json={"text": "what's my cpu"}, headers=h)
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "COMPLETED"
    assert body["route"] == "DETERMINISTIC"


def test_pwa_pairing_flow_endpoints(client):
    """The pairing section of the PWA drives the existing pairing endpoints."""
    h = _login(client)
    d = client.post("/api/devices/pairing", headers=h,
                    json={"device_name": "My Phone", "device_type": "web",
                          "capabilities": ["WEB_PWA", "BROWSER", "NOTIFICATIONS"]})
    assert d.status_code == 200
    body = d.json()
    assert body["code"].startswith("PAIR-")
    # device advertises only real browser capabilities (never Windows automation)
    caps = body["capabilities"]
    assert "WEB_PWA" in caps
    assert "windows.automation" not in caps


def test_pwa_registers_as_device_after_approval(client):
    h = _login(client)
    d = client.post("/api/devices/pairing", headers=h,
                    json={"device_name": "Tablet", "device_type": "web",
                          "capabilities": ["WEB_PWA", "BROWSER"]})
    pid = d.json()["pairing_id"]
    # owner approves
    appr = client.post(f"/api/devices/pairing/{pid}/approve", headers=h)
    assert appr.status_code == 200
    dev_id = appr.json()["device_id"]
    # device claims its permanent token
    claim = client.post("/api/devices/pairing/claim", headers=h,
                        json={"code": d.json()["code"]})
    assert claim.status_code == 200
    assert claim.json()["device_token"].startswith("jtk_")
    # now the device can authenticate with its own token, not the owner password
    dev = client.get("/api/devices", headers={"X-Device-Token": claim.json()["device_token"]})
    assert dev.status_code == 200
    assert any(x["device_id"] == dev_id for x in dev.json()["devices"])


def test_pwa_offline_honesty(client):
    """Routing a task to an offline device must never claim success."""
    # register an android-type device then do not bring it online
    h = _login(client)
    d = client.post("/api/devices/pairing", headers=h,
                    json={"device_name": "Offline Phone", "device_type": "android",
                          "capabilities": ["chat"]})
    pid = d.json()["pairing_id"]
    appr = client.post(f"/api/devices/pairing/{pid}/approve", headers=h)
    assert appr.status_code == 200
    dev_id = appr.json()["device_id"]
    claim = client.post("/api/devices/pairing/claim", headers=h,
                        json={"code": d.json()["code"]})
    dev_token = claim.json()["device_token"]
    # run 'hello' on the (never-connected) phone from another device
    r = client.post("/api/chat", headers=h,
                    json={"text": "hello on my phone"})
    assert r.status_code == 200
    body = r.json()
    # the phone is offline -> the task must not be marked COMPLETED
    assert body["status"] in ("FAILED", "QUEUED")
    if body["status"] == "FAILED":
        assert "offline" in (body.get("message") or "").lower() or \
            "offline" in (body.get("error") or "").lower()


def test_pwa_routing_and_memory_controls_present():
    """The PWA JS wires the real backend APIs for memory, AI routing, combo and
    the device bus - it must contain the relevant endpoint calls."""
    import pathlib
    js = (pathlib.Path(__file__).parent.parent / "backend/pwa/app.js").read_text()
    for needle in ["/memory/enabled", "/memory/export", "/memory/import",
                    "/memory/context", "/workflows", "/ai/routing", "/ai/usage",
                    "/combos/mine", "/devices/pairing", "/api/bus/ws",
                    "SpeechRecognition", "speechSynthesis", "Notification"]:
        assert needle in js, f"PWA should reference {needle}"


def test_pwa_bus_uses_backoff_and_heartbeat():
    import pathlib
    js = (pathlib.Path(__file__).parent.parent / "backend/pwa/app.js").read_text()
    assert "busBackoff" in js and "heartbeat" in js
    assert "exponential" in js or "backoff" in js.lower()


def test_pwa_manifest_production_fields():
    """manifest must advertise what an Android install needs."""
    import pathlib, json
    m = json.loads((pathlib.Path(__file__).parent.parent / "backend/pwa/manifest.json").read_text())
    assert m["scope"] == "/pwa/" and m["start_url"] == "/pwa/"
    assert m["display"] == "standalone"
    assert "background_color" in m and "theme_color" in m and "orientation" in m
    sizes = {i["sizes"] for i in m["icons"]}
    assert "192x192" in sizes and "512x512" in sizes


def test_pwa_offline_banner_and_honest_status():
    import pathlib
    js = (pathlib.Path(__file__).parent.parent / "backend/pwa/app.js").read_text()
    assert "JARVIS OFFLINE" in js or "OFFLINE" in js
    assert "COMPLETED" in js
    # never report COMPLETED unless verified
    assert 'res.status === "COMPLETED"' in js or 'STATUS " + (res.status' in js
