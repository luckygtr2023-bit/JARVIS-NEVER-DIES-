"""Final hardening pass: memory controls, workflow enable/disable, diagnostics,
and the security audit (server-side enforcement, user isolation, no exposed
secrets, no unauthenticated remote control).

These tests verify the closing gaps and are additive - no existing test was
weakened or removed.
"""
from __future__ import annotations

import json

from backend import memory_store, quota, routing, workflows
from tests.conftest import register


def make_limit_user(client, name="limit_hard"):
    u = register(client, username=name, password="password1")
    return {"Authorization": f"Bearer {u['token']}"}


# ------------------------------ memory controls --------------------------- #
def test_memory_edit(client, owner):
    h = owner["headers"]
    mem = client.post("/api/memory", json={"key": "city", "value": "Patna"},
                      headers=h).json()
    r = client.patch(f"/api/memory/{mem['id']}", json={"value": "Delhi", "category": "preference"},
                     headers=h)
    assert r.status_code == 200
    assert r.json()["value"] == "Delhi"
    assert r.json()["category"] == "preference"


def test_memory_edit_guards_secrets(client, owner):
    h = owner["headers"]
    mem = client.post("/api/memory", json={"key": "city", "value": "Patna"},
                      headers=h).json()
    r = client.patch(f"/api/memory/{mem['id']}", json={"value": "sk-abcdefghijklmnop1234567890"},
                     headers=h)
    assert r.status_code == 422


def test_memory_enable_disable(client, owner):
    h = owner["headers"]
    r = client.post("/api/memory/enabled", json={"enabled": False}, headers=h)
    assert r.json()["memory_enabled"] is False
    # disabling memory stops local recall
    client.post("/api/memory", json={"key": "city", "value": "Patna"}, headers=h)
    resp = client.post("/api/chat", json={"text": "what did I tell you about my city"},
                       headers=h).json()
    # memory disabled -> no MEMORY route; it should fall through (no AI backend -> honest FAILED)
    assert resp["route"] != "MEMORY"
    client.post("/api/memory/enabled", json={"enabled": True}, headers=h)
    resp2 = client.post("/api/chat", json={"text": "what did I tell you about my city"},
                        headers=h).json()
    assert resp2["route"] == "MEMORY"


def test_memory_export_import(client, owner):
    h = owner["headers"]
    client.post("/api/memory", json={"key": "fav", "value": "linux"}, headers=h)
    exp = client.get("/api/memory/export", headers=h).json()
    assert exp["version"] == 1
    assert any(m["key"] == "fav" for m in exp["memories"])
    # import back into a fresh user, incl. a malicious record that must be skipped
    other = make_limit_user(client, "import_target")
    payload = list(exp["memories"]) + [{"key": "apikey", "value": "sk-abcdefghijklmnop1234567890"}]
    imp = client.post("/api/memory/import", json={"memories": payload}, headers=other)
    assert imp.status_code == 200
    body = imp.json()
    assert body["imported"] >= 1
    assert body["skipped"] >= 1            # the secret record was refused


def test_memory_search(client, owner):
    h = owner["headers"]
    client.post("/api/memory", json={"key": "color", "value": "amber"}, headers=h)
    r = client.get("/api/memory?q=amber", headers=h).json()
    assert r["searched"] is True
    assert any(m["key"] == "color" for m in r["memories"])


# --------------------------- learned workflows --------------------------- #
def test_workflow_disable_stops_use(client, owner):
    h = owner["headers"]
    uid = owner["user"]["user_id"]
    workflows.learn(uid, "show top processes", "list_processes", {"limit": 5})
    wf = workflows.lookup(uid, "show top processes")
    # disable it
    r = client.patch(f"/api/workflows/{wf['id']}", json={"enabled": False}, headers=h)
    assert r.status_code == 200
    assert r.json()["enabled"] is False
    # disabled -> lookup returns None -> won't be used as a cached workflow
    assert workflows.lookup(uid, "show top processes") is None
    # re-enable
    client.patch(f"/api/workflows/{wf['id']}", json={"enabled": True}, headers=h)
    assert workflows.lookup(uid, "show top processes") is not None


# ------------------------------ diagnostics ------------------------------ #
def test_diagnostics_include_request_reason_status(client, owner):
    h = owner["headers"]
    client.post("/api/chat", json={"text": "what's my cpu"}, headers=h)
    r = client.get("/api/ai/routing", headers=h).json()
    diag = [d for d in r["diagnostics"] if d["request"] == "what's my cpu"]
    assert diag, "the deterministic request should appear in diagnostics"
    d = diag[0]
    assert d["route"] == "DETERMINISTIC"
    assert d["cloud_used"] is False
    assert "status" in d
    assert "reason" in d


def test_usage_by_combo_and_device(client, owner):
    uid = owner["user"]["user_id"]
    quota.record(user_id=uid, device_id="dev_a", combo="JARVIS-copy-13",
                 provider="omniroute", route="CLOUD", cloud=True, prompt_tokens=5,
                 completion_tokens=5, model="JARVIS-copy-13")
    s = quota.summary(uid)
    assert s["today"]["cloud"] >= 1
    assert s["today"]["estimated_cloud_tokens"] >= 10


# ------------------------------ security audit --------------------------- #
def test_unauthenticated_cannot_execute(client):
    # control-plane execution endpoints must reject anonymous callers
    posts = [("/api/chat", {"text": "x"}), ("/api/tools/run", {"name": "cpu_usage"}),
             ("/api/memory", {"key": "k", "value": "v"}),
             ("/api/ai/routing", {"routing": "auto"}),
             ("/api/routing/limits", {"daily_cloud_limit": 5})]
    for path, payload in posts:
        r = client.post(path, json=payload)
        assert r.status_code == 401, f"POST {path} should reject anonymous callers (got {r.status_code})"
    for path in ("/api/tasks", "/api/devices", "/api/memory", "/api/ai/usage",
                 "/api/ai/routing", "/api/workflows", "/api/settings"):
        r = client.get(path)
        assert r.status_code == 401, f"GET {path} should reject anonymous callers (got {r.status_code})"


def test_user_isolation_of_memory(client, owner):
    h = owner["headers"]
    client.post("/api/memory", json={"key": "owner_note", "value": "owner value"}, headers=h)
    other = make_limit_user(client, "iso_other")
    # other user cannot see or edit the owner's memory
    mems = client.get("/api/memory", headers=other).json()["memories"]
    assert all(m["key"] != "owner_note" for m in mems)
    # cannot edit another's memory by id
    own_id = client.get("/api/memory", headers=h).json()["memories"][0]["id"]
    r = client.patch(f"/api/memory/{own_id}", json={"value": "hacked"}, headers=other)
    assert r.status_code == 404
    # cannot clear another's memory
    client.delete("/api/memory", headers=other)
    assert client.get("/api/memory", headers=h).json()["memories"], "owner memory intact"


def test_one_user_cannot_route_to_anothers_device(client, owner):
    h = owner["headers"]
    dev = client.get("/api/devices", headers=h).json()["devices"][0]
    other = make_limit_user(client, "route_other")
    # list devices for other user: should not include owner's host device
    devs = client.get("/api/devices", headers=other).json()["devices"]
    assert all(d["device_id"] != dev["device_id"] for d in devs)


def test_no_credentials_in_public_diagnostics(client, owner):
    h = owner["headers"]
    client.post("/api/memory", json={"key": "k", "value": "v"}, headers=h)
    # run a hop so diagnostics have data
    client.post("/api/chat", json={"text": "show cpu usage"}, headers=h)
    usage = client.get("/api/ai/usage", headers=h).json()
    rout = client.get("/api/ai/routing", headers=h).json()
    text = json.dumps([usage, rout])
    assert "sk-" not in text and "api_key" not in text.lower()
    assert "provider_secret" not in text and "oauth" not in text.lower()


def test_pwa_payloads_carry_no_provider_credentials(client, owner):
    # settings/diagnostics never return an API key for the PWA to store
    s = client.get("/api/settings", headers=owner["headers"]).json()
    assert "api_key" not in str(s).lower()
    assert "secret" not in str(s).lower()
    assert not any("key" in str(k).lower() for k in s if "key" in str(k).lower())


def test_consequential_actions_require_confirmation(client, owner):
    h = owner["headers"]
    tools = client.get("/api/tools", headers=h).json()["tools"]
    by_name = {t["name"]: t for t in tools}
    for name in ("delete_file", "shutdown_pc", "run_powershell", "close_application"):
        assert by_name[name]["risk"] == "CONFIRM", f"{name} must require confirmation"


def test_secret_turn_not_kept_in_conversation(client, owner):
    uid = owner["user"]["user_id"]
    memory_store.append_turn(uid, "default", "user",
                             "my key is ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")
    ctx = memory_store.get_context(uid, "default")
    assert all("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" not in m["content"] for m in ctx)
