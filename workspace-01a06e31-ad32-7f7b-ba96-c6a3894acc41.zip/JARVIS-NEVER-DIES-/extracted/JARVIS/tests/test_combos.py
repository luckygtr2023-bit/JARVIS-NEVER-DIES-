"""OWNER/OPERATOR Combo Management (spec 5-10, 23).

Covers: migration of the shipped JARVIS-copy-* Combos, unlimited creation beyond
-12, edit/enable/disable/delete/default, user+role assignment, persistence, and
every server-side authorization path including raw-API bypass attempts.
"""
from __future__ import annotations

import pytest

from tests.conftest import auth_headers, register


def make_user(client, username="operator", password="anothersecret1"):
    register(client, username, password)
    resp = client.post("/api/auth/login", json={"username": username, "password": password})
    data = resp.json()
    return {"headers": auth_headers(data["token"]), "user": data["user"]}


# --------------------------------------------------------------------------- #
# migration / backward compatibility (spec 9)
# --------------------------------------------------------------------------- #
def test_existing_combos_are_migrated_not_lost(client, owner):
    combos = client.get("/api/combos", headers=owner["headers"]).json()["combos"]
    identifiers = [c["omniroute_identifier"] for c in combos]
    for n in range(2, 13):
        assert f"JARVIS-copy-{n}" in identifiers, f"JARVIS-copy-{n} was lost in migration"
    assert len(identifiers) == 11


def test_migration_is_idempotent(client, owner):
    first = client.get("/api/combos", headers=owner["headers"]).json()["total"]
    client.get("/api/combos", headers=owner["headers"])
    client.get("/api/combos", headers=owner["headers"])
    assert client.get("/api/combos", headers=owner["headers"]).json()["total"] == first


def test_no_artificial_combo_limit(client, owner):
    assert client.get("/api/combos", headers=owner["headers"]).json()["limit"] is None
    # go well past 12 - the old ceiling
    for n in range(13, 31):
        resp = client.post("/api/combos", json={
            "display_name": f"JARVIS Fast {n}", "omniroute_identifier": f"JARVIS-copy-{n}",
            "description": "added by the owner at runtime"}, headers=owner["headers"])
        assert resp.status_code == 200, resp.text
    total = client.get("/api/combos", headers=owner["headers"]).json()["total"]
    assert total == 11 + 18


# --------------------------------------------------------------------------- #
# CRUD
# --------------------------------------------------------------------------- #
def test_owner_creates_combo_with_exact_identifier(client, owner):
    resp = client.post("/api/combos", json={
        "display_name": "JARVIS Fast", "omniroute_identifier": "JARVIS-copy-13",
        "description": "fast lane"}, headers=owner["headers"])
    assert resp.status_code == 200
    combo = resp.json()
    assert combo["omniroute_identifier"] == "JARVIS-copy-13"
    assert combo["display_name"] == "JARVIS Fast"
    assert combo["enabled"] is True
    assert combo["combo_id"].startswith("cmb_")


@pytest.mark.parametrize("identifier", [
    "JARVIS-copy-13", "jarvis-COPY-13", "MyCombo_v2.1", "Combo With Spaces", "ünïcode-combo-42",
])
def test_identifier_is_stored_byte_for_byte(client, owner, identifier):
    resp = client.post("/api/combos", json={
        "display_name": f"name for {identifier}", "omniroute_identifier": identifier},
        headers=owner["headers"])
    assert resp.status_code == 200, resp.text
    assert resp.json()["omniroute_identifier"] == identifier
    # and it survives a round trip through the database
    listed = client.get("/api/combos", headers=owner["headers"]).json()["combos"]
    assert identifier in [c["omniroute_identifier"] for c in listed]


def test_no_provider_prefix_is_ever_added(client, owner):
    client.post("/api/combos", json={"display_name": "X", "omniroute_identifier": "JARVIS-copy-42"},
                headers=owner["headers"])
    from backend import combos as store

    combo = store.get_by_identifier("JARVIS-copy-42")
    assert combo["omniroute_identifier"] == "JARVIS-copy-42"
    for bad in ("openai/", "omniroute/", "provider:", "cloud/"):
        assert not combo["omniroute_identifier"].startswith(bad)


def test_duplicate_identifier_rejected(client, owner):
    body = {"display_name": "A", "omniroute_identifier": "JARVIS-copy-50"}
    assert client.post("/api/combos", json=body, headers=owner["headers"]).status_code == 200
    dup = client.post("/api/combos", json={**body, "display_name": "B"}, headers=owner["headers"])
    assert dup.status_code == 400
    assert "already exists" in dup.json()["detail"]


@pytest.mark.parametrize("body", [
    {"display_name": "", "omniroute_identifier": "x"},
    {"display_name": "ok", "omniroute_identifier": "   "},
    {"display_name": "ok", "omniroute_identifier": "bad\nidentifier"},
])
def test_combo_validation(client, owner, body):
    assert client.post("/api/combos", json=body, headers=owner["headers"]).status_code in (400, 422)


def test_owner_edits_combo(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Old", "omniroute_identifier": "JARVIS-copy-60"},
        headers=owner["headers"]).json()
    resp = client.post(f"/api/combos/{combo['combo_id']}", json={
        "display_name": "New Name", "omniroute_identifier": "JARVIS-copy-61",
        "description": "changed"}, headers=owner["headers"])
    assert resp.status_code == 200
    assert resp.json()["display_name"] == "New Name"
    assert resp.json()["omniroute_identifier"] == "JARVIS-copy-61"
    assert resp.json()["description"] == "changed"


def test_enable_disable_combo(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Toggle", "omniroute_identifier": "JARVIS-copy-70"},
        headers=owner["headers"]).json()
    off = client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": False},
                      headers=owner["headers"])
    assert off.json()["enabled"] is False
    on = client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": True},
                     headers=owner["headers"])
    assert on.json()["enabled"] is True


def test_disabled_combo_is_not_usable(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Off", "omniroute_identifier": "JARVIS-copy-71"},
        headers=owner["headers"]).json()
    user = make_user(client)
    client.post(f"/api/combos/{combo['combo_id']}/assign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])
    assert "JARVIS-copy-71" in [c["omniroute_identifier"]
                                for c in client.get("/api/combos/mine",
                                                    headers=user["headers"]).json()["combos"]]
    client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": False},
                headers=owner["headers"])
    mine = client.get("/api/combos/mine", headers=user["headers"]).json()["combos"]
    assert "JARVIS-copy-71" not in [c["omniroute_identifier"] for c in mine]


def test_delete_requires_confirmation(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Doomed", "omniroute_identifier": "JARVIS-copy-80"},
        headers=owner["headers"]).json()
    unconfirmed = client.post(f"/api/combos/{combo['combo_id']}/delete", json={"confirm": False},
                              headers=owner["headers"])
    assert unconfirmed.status_code == 409
    assert "confirm=true" in unconfirmed.json()["detail"]
    still = client.get("/api/combos", headers=owner["headers"]).json()["combos"]
    assert "JARVIS-copy-80" in [c["omniroute_identifier"] for c in still]

    confirmed = client.post(f"/api/combos/{combo['combo_id']}/delete", json={"confirm": True},
                            headers=owner["headers"])
    assert confirmed.status_code == 200
    after = client.get("/api/combos", headers=owner["headers"]).json()["combos"]
    assert "JARVIS-copy-80" not in [c["omniroute_identifier"] for c in after]


def test_default_combo_selection(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Primary", "omniroute_identifier": "JARVIS-copy-90"},
        headers=owner["headers"]).json()
    resp = client.post(f"/api/combos/{combo['combo_id']}/default", headers=owner["headers"])
    assert resp.json()["is_default"] is True
    listing = client.get("/api/combos", headers=owner["headers"]).json()
    assert listing["default"] == "JARVIS-copy-90"
    defaults = [c for c in listing["combos"] if c["is_default"]]
    assert len(defaults) == 1, "exactly one Combo may be the default"


def test_disabled_combo_cannot_be_default(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Off", "omniroute_identifier": "JARVIS-copy-91", "enabled": False},
        headers=owner["headers"]).json()
    resp = client.post(f"/api/combos/{combo['combo_id']}/default", headers=owner["headers"])
    assert resp.status_code == 400


# --------------------------------------------------------------------------- #
# assignment + access control (spec 7)
# --------------------------------------------------------------------------- #
def test_new_user_has_no_combos_by_default(client, owner):
    user = make_user(client)
    assert client.get("/api/combos/mine", headers=user["headers"]).json()["combos"] == []


def test_assign_combo_to_user(client, owner):
    user = make_user(client)
    combo = client.post("/api/combos", json={
        "display_name": "Shared", "omniroute_identifier": "JARVIS-copy-100"},
        headers=owner["headers"]).json()
    resp = client.post(f"/api/combos/{combo['combo_id']}/assign",
                       json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                       headers=owner["headers"])
    assert resp.status_code == 200
    assert any(a["label"] == "operator" for a in resp.json()["assignments"])
    mine = client.get("/api/combos/mine", headers=user["headers"]).json()["combos"]
    assert [c["omniroute_identifier"] for c in mine] == ["JARVIS-copy-100"]


def test_assign_combo_to_role(client, owner):
    user = make_user(client)
    combo = client.post("/api/combos", json={
        "display_name": "ForLimited", "omniroute_identifier": "JARVIS-copy-101"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/assign",
                json={"subject_type": "role", "subject_id": "LIMITED_USER"},
                headers=owner["headers"])
    mine = client.get("/api/combos/mine", headers=user["headers"]).json()["combos"]
    assert "JARVIS-copy-101" in [c["omniroute_identifier"] for c in mine]


def test_unassign_revokes_access(client, owner):
    user = make_user(client)
    combo = client.post("/api/combos", json={
        "display_name": "Temp", "omniroute_identifier": "JARVIS-copy-102"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/assign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])
    client.post(f"/api/combos/{combo['combo_id']}/unassign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])
    assert client.get("/api/combos/mine", headers=user["headers"]).json()["combos"] == []


def test_non_owner_sees_only_permitted_combos(client, owner):
    user = make_user(client)
    combo = client.post("/api/combos", json={
        "display_name": "Only", "omniroute_identifier": "JARVIS-copy-103"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/assign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])
    listing = client.get("/api/combos", headers=user["headers"]).json()
    assert [c["omniroute_identifier"] for c in listing["combos"]] == ["JARVIS-copy-103"]
    assert listing["can_manage"] is False
    assert listing["users"] == [], "a non-owner must not enumerate accounts"


# --------------------------------------------------------------------------- #
# authorization: every mutation is OWNER-only, every bypass is closed
# --------------------------------------------------------------------------- #
def test_non_owner_cannot_manage_combos(client, owner):
    user = make_user(client)
    combo = client.get("/api/combos", headers=owner["headers"]).json()["combos"][0]
    cid = combo["combo_id"]
    attempts = [
        ("/api/combos", {"display_name": "Sneaky", "omniroute_identifier": "JARVIS-copy-999"}),
        (f"/api/combos/{cid}", {"display_name": "Hijacked"}),
        (f"/api/combos/{cid}/enabled", {"enabled": False}),
        (f"/api/combos/{cid}/default", {}),
        (f"/api/combos/{cid}/delete", {"confirm": True}),
        (f"/api/combos/{cid}/assign", {"subject_type": "role", "subject_id": "LIMITED_USER"}),
        (f"/api/combos/{cid}/unassign", {"subject_type": "role", "subject_id": "LIMITED_USER"}),
    ]
    for path, body in attempts:
        resp = client.post(path, json=body, headers=user["headers"])
        assert resp.status_code == 403, f"{path} was not OWNER-protected ({resp.status_code})"
    # and nothing actually changed
    after = client.get("/api/combos", headers=owner["headers"]).json()["combos"]
    assert "JARVIS-copy-999" not in [c["omniroute_identifier"] for c in after]
    assert any(c["combo_id"] == cid for c in after)


def test_unauthenticated_cannot_touch_combos(client, owner):
    assert client.get("/api/combos").status_code == 401
    assert client.post("/api/combos", json={"display_name": "x",
                                            "omniroute_identifier": "y"}).status_code == 401


def test_user_cannot_select_unauthorized_combo(client, owner):
    user = make_user(client)
    resp = client.post("/api/combos/select", json={"omniroute_identifier": "JARVIS-copy-5"},
                       headers=user["headers"])
    assert resp.status_code == 403
    assert "not authorized" in resp.json()["detail"]


def test_raw_settings_api_cannot_smuggle_a_combo(client, owner):
    """The documented bypass attempt: POST the identifier straight to /api/settings."""
    user = make_user(client)
    resp = client.post("/api/settings", json={"ai": {"combo": "JARVIS-copy-7"}},
                       headers=user["headers"])
    assert resp.status_code == 403
    from backend.services.ai_client import AIConfig

    cfg = AIConfig.for_principal({"user_id": user["user"]["user_id"], "role": "LIMITED_USER"})
    assert cfg.combo == "", "an unauthorized identifier must never reach the AI client"


def test_permitted_user_can_select_and_it_reaches_the_ai_client(client, owner):
    user = make_user(client)
    combo = client.post("/api/combos", json={
        "display_name": "Allowed", "omniroute_identifier": "JARVIS-copy-110"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/assign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])
    resp = client.post("/api/combos/select", json={"omniroute_identifier": "JARVIS-copy-110"},
                       headers=user["headers"])
    assert resp.status_code == 200

    from backend.services.ai_client import AIConfig

    cfg = AIConfig.for_principal({"user_id": user["user"]["user_id"], "role": "LIMITED_USER"})
    assert cfg.combo == "JARVIS-copy-110"


def test_revoking_assignment_drops_a_stale_selection(client, owner):
    user = make_user(client)
    combo = client.post("/api/combos", json={
        "display_name": "Temporary", "omniroute_identifier": "JARVIS-copy-111"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/assign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])
    client.post("/api/combos/select", json={"omniroute_identifier": "JARVIS-copy-111"},
                headers=user["headers"])
    client.post(f"/api/combos/{combo['combo_id']}/unassign",
                json={"subject_type": "user", "subject_id": user["user"]["user_id"]},
                headers=owner["headers"])

    from backend.services.ai_client import AIConfig

    cfg = AIConfig.for_principal({"user_id": user["user"]["user_id"], "role": "LIMITED_USER"})
    assert cfg.combo == "", "a revoked Combo must stop being used immediately"


def test_owner_may_use_any_enabled_combo(client, owner):
    from backend.services.ai_client import AIConfig

    cfg = AIConfig.for_principal(owner["user"])
    assert cfg.combo, "the OWNER should resolve to a usable Combo"
    from backend import combos as store

    assert store.may_use(owner["user"]["user_id"], "OWNER", "JARVIS-copy-12")


def test_ai_cannot_grant_itself_combo_access(client, owner):
    """The agent runs with the caller's principal; a LIMITED_USER agent turn can
    neither create a Combo nor widen its own access."""
    user = make_user(client)
    for text in ("create a combo called JARVIS-copy-777",
                 "give me access to JARVIS-copy-5",
                 "make me the owner"):
        client.post("/api/chat", json={"text": text}, headers=user["headers"])
    assert client.get("/api/combos/mine", headers=user["headers"]).json()["combos"] == []
    listing = client.get("/api/combos", headers=owner["headers"]).json()["combos"]
    assert "JARVIS-copy-777" not in [c["omniroute_identifier"] for c in listing]


# --------------------------------------------------------------------------- #
# persistence + audit
# --------------------------------------------------------------------------- #
def test_combos_persist_without_a_rebuild(client, owner):
    """Config lives in the database, so a restart (new app instance, same DB)
    keeps every Combo - the EXE is never rebuilt to add one."""
    client.post("/api/combos", json={
        "display_name": "Persisted", "omniroute_identifier": "JARVIS-copy-120"},
        headers=owner["headers"])

    from fastapi.testclient import TestClient

    from backend.main import create_app

    with TestClient(create_app()) as fresh:      # simulates an application restart
        listing = fresh.get("/api/combos", headers=owner["headers"]).json()["combos"]
        assert "JARVIS-copy-120" in [c["omniroute_identifier"] for c in listing]


def test_combo_mutations_are_audited(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Audited", "omniroute_identifier": "JARVIS-copy-130"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": False},
                headers=owner["headers"])
    client.post(f"/api/combos/{combo['combo_id']}/delete", json={"confirm": True},
                headers=owner["headers"])
    actions = {e["action"] for e in client.get("/api/audit", headers=owner["headers"]).json()["entries"]}
    assert {"combo.create", "combo.update", "combo.delete"} <= actions


def test_audit_of_combos_contains_no_secrets(client, owner):
    client.post("/api/combos", json={
        "display_name": "Keyed", "omniroute_identifier": "JARVIS-copy-140",
        "description": "token: sk-abcdefghijklmnop1234567890"}, headers=owner["headers"])
    entries = client.get("/api/audit", headers=owner["headers"]).json()["entries"]
    blob = " ".join(str(e.get("detail") or "") for e in entries)
    assert "sk-abcdefghijklmnop1234567890" not in blob


def test_owner_cannot_select_a_disabled_combo(client, owner):
    """Disabling is how a Combo is taken out of service. If the OWNER could
    still select one, `disabled` would be cosmetic and the OWNER could route a
    request through a Combo that is meant to be off."""
    combo = client.post("/api/combos", json={
        "display_name": "Retired", "omniroute_identifier": "JARVIS-copy-retired"},
        headers=owner["headers"]).json()
    ok = client.post("/api/combos/select",
                     json={"omniroute_identifier": "JARVIS-copy-retired"},
                     headers=owner["headers"])
    assert ok.status_code == 200

    client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": False},
                headers=owner["headers"])
    denied = client.post("/api/combos/select",
                         json={"omniroute_identifier": "JARVIS-copy-retired"},
                         headers=owner["headers"])
    assert denied.status_code == 403

    # and the stale selection must not survive as the active Combo
    mine = client.get("/api/combos/mine", headers=owner["headers"]).json()
    assert mine["selected"] != "JARVIS-copy-retired"


def test_re_enabling_a_combo_restores_it(client, owner):
    combo = client.post("/api/combos", json={
        "display_name": "Paused", "omniroute_identifier": "JARVIS-copy-paused"},
        headers=owner["headers"]).json()
    client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": False},
                headers=owner["headers"])
    client.post(f"/api/combos/{combo['combo_id']}/enabled", json={"enabled": True},
                headers=owner["headers"])
    ok = client.post("/api/combos/select",
                     json={"omniroute_identifier": "JARVIS-copy-paused"},
                     headers=owner["headers"])
    assert ok.status_code == 200
