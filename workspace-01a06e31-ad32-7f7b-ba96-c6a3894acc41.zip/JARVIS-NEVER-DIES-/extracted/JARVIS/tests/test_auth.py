"""Accounts, OWNER initialisation, sessions, roles (spec 3, 44)."""
from __future__ import annotations

from tests.conftest import auth_headers, register


def test_first_account_becomes_owner(client):
    data = register(client, "lucky", "supersecret1")
    assert data["user"]["role"] == "OWNER"
    assert data["user"]["user_id"].startswith("usr_")
    assert data["token"].startswith("jsess_")


def test_second_account_is_not_owner(client):
    register(client, "lucky", "supersecret1")
    second = register(client, "guest", "anothersecret1")
    assert second["user"]["role"] == "LIMITED_USER"


def test_owner_flag_cannot_be_requested_by_client(client):
    register(client, "lucky", "supersecret1")
    resp = client.post("/api/auth/register",
                       json={"username": "sneaky", "password": "password123", "role": "OWNER"})
    assert resp.status_code == 200
    assert resp.json()["user"]["role"] == "LIMITED_USER"


def test_login_logout_login_again(client):
    register(client, "lucky", "supersecret1")
    login = client.post("/api/auth/login", json={"username": "lucky", "password": "supersecret1"})
    assert login.status_code == 200
    token = login.json()["token"]

    me = client.get("/api/auth/me", headers=auth_headers(token))
    assert me.status_code == 200 and me.json()["username"] == "lucky"

    assert client.post("/api/auth/logout", headers=auth_headers(token)).status_code == 200
    assert client.get("/api/auth/me", headers=auth_headers(token)).status_code == 401

    again = client.post("/api/auth/login", json={"username": "lucky", "password": "supersecret1"})
    assert again.status_code == 200 and again.json()["token"] != token


def test_invalid_password_is_rejected(client):
    register(client, "lucky", "supersecret1")
    bad = client.post("/api/auth/login", json={"username": "lucky", "password": "wrong-password"})
    assert bad.status_code == 401
    assert "Invalid username or password" in bad.json()["detail"]


def test_unknown_user_is_rejected(client):
    assert client.post("/api/auth/login",
                       json={"username": "nobody", "password": "whatever12"}).status_code == 401


def test_passwords_are_never_stored_in_plaintext(client):
    register(client, "lucky", "supersecret1")
    from backend import db

    row = db.one("SELECT password_hash FROM users WHERE username='lucky'")
    assert "supersecret1" not in row["password_hash"]
    assert row["password_hash"].startswith("pbkdf2_sha256$")


def test_short_password_rejected(client):
    resp = client.post("/api/auth/register", json={"username": "tiny", "password": "abc"})
    assert resp.status_code == 400


def test_duplicate_username_rejected(client):
    register(client, "lucky", "supersecret1")
    resp = client.post("/api/auth/register", json={"username": "LUCKY", "password": "supersecret1"})
    assert resp.status_code == 400


def test_protected_route_requires_auth(client):
    assert client.get("/api/memory").status_code == 401
    assert client.get("/api/devices").status_code == 401


def test_auth_state_reports_owner_presence(client):
    assert client.get("/api/auth/state").json()["owner_exists"] is False
    register(client, "lucky", "supersecret1")
    assert client.get("/api/auth/state").json()["owner_exists"] is True
