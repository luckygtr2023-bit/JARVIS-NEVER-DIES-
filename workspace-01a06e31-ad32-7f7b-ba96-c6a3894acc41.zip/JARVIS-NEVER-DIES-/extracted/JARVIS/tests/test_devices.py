"""Device identity, pairing lifecycle, permissions, revocation (spec 4, 5, 44)."""
from __future__ import annotations

import time

from tests.conftest import auth_headers, register


def pair_request(client, name="Lucky's Phone"):
    resp = client.post("/api/devices/pairing",
                       json={"device_name": name, "device_type": "android", "os": "Android 14"})
    assert resp.status_code == 200, resp.text
    return resp.json()


def test_host_device_is_registered(client, owner):
    devices = client.get("/api/devices", headers=owner["headers"]).json()["devices"]
    assert len(devices) == 1
    host = devices[0]
    assert host["is_host"] is True
    assert host["device_id"].startswith("dev_")
    assert host["online"] is True


def test_pairing_code_format_and_expiry_window(client, owner):
    pairing = pair_request(client)
    code = pairing["code"]
    assert code.startswith("PAIR-") and len(code) == 14
    assert pairing["expires_in"] == 600
    assert pairing["status"] == "PENDING"


def test_full_pairing_flow_issues_device_identity(client, owner):
    pairing = pair_request(client)
    pending = client.get("/api/devices/pairing", headers=owner["headers"]).json()["pairings"]
    assert any(p["pairing_id"] == pairing["pairing_id"] for p in pending)
    # the owner sees the SAME code for visual confirmation
    assert pending[0]["code_display"] == pairing["code"]

    approved = client.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve",
                           headers=owner["headers"])
    assert approved.status_code == 200, approved.text
    device_id = approved.json()["device_id"]
    assert device_id.startswith("dev_android_")

    claim = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]})
    assert claim.status_code == 200, claim.text
    body = claim.json()
    assert body["device_token"].startswith("jtk_")
    assert body["device_id"] == device_id
    assert body["permissions"] == ["chat", "system.read"]

    # the new device can now authenticate with its own credential
    me = client.get("/api/auth/me", headers={"X-Device-Token": body["device_token"]})
    assert me.status_code == 200 and me.json()["via"] == "device"


def test_pairing_code_is_single_use(client, owner):
    pairing = pair_request(client)
    client.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve", headers=owner["headers"])
    first = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]})
    assert first.status_code == 200
    replay = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]})
    assert replay.status_code == 404
    assert "already-used" in replay.json()["detail"]


def test_pairing_code_expires(client, owner):
    from backend import db

    pairing = pair_request(client)
    db.execute("UPDATE pairings SET expires_at=? WHERE pairing_id=?",
               (time.time() - 5, pairing["pairing_id"]))
    approve = client.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve",
                          headers=owner["headers"])
    assert approve.status_code in (409, 410)


def test_cannot_claim_before_approval(client, owner):
    pairing = pair_request(client)
    resp = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]})
    assert resp.status_code == 425


def test_rejected_pairing_cannot_be_claimed(client, owner):
    pairing = pair_request(client)
    client.post(f"/api/devices/pairing/{pairing['pairing_id']}/reject", headers=owner["headers"])
    resp = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]})
    assert resp.status_code == 409


def test_only_owner_can_approve(client, owner):
    register(client, "guest", "anothersecret1")
    guest = client.post("/api/auth/login", json={"username": "guest", "password": "anothersecret1"})
    guest_headers = auth_headers(guest.json()["token"])
    pairing = pair_request(client)
    resp = client.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve", headers=guest_headers)
    assert resp.status_code == 403


def paired_device(client, owner, name="Phone"):
    pairing = pair_request(client, name)
    client.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve", headers=owner["headers"])
    claim = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]}).json()
    return claim


def test_revocation_kills_the_device_token(client, owner):
    dev = paired_device(client, owner)
    headers = {"X-Device-Token": dev["device_token"]}
    assert client.get("/api/auth/me", headers=headers).status_code == 200

    resp = client.post(f"/api/devices/{dev['device_id']}/revoke", headers=owner["headers"])
    assert resp.status_code == 200 and resp.json()["state"] == "REVOKED"
    assert client.get("/api/auth/me", headers=headers).status_code == 401


def test_permission_grant_and_enforcement(client, owner):
    dev = paired_device(client, owner)
    headers = {"X-Device-Token": dev["device_token"]}

    # default permissions do NOT include windows control
    denied = client.post("/api/tools/run", json={"name": "shutdown_pc", "args": {}}, headers=headers)
    assert denied.status_code == 403
    assert "windows.control" in denied.json()["detail"]

    granted = client.post(f"/api/devices/{dev['device_id']}/permissions",
                          json={"permissions": ["chat", "system.read", "windows.control"]},
                          headers=owner["headers"])
    assert granted.status_code == 200
    assert "windows.control" in granted.json()["permissions"]

    # now it passes the permission gate (and hits confirmation / capability instead)
    after = client.post("/api/tools/run", json={"name": "shutdown_pc", "args": {}}, headers=headers)
    assert after.status_code != 403


def test_unknown_permission_rejected(client, owner):
    dev = paired_device(client, owner)
    resp = client.post(f"/api/devices/{dev['device_id']}/permissions",
                       json={"permissions": ["root.everything"]}, headers=owner["headers"])
    assert resp.status_code == 400


def test_device_rename_and_remove(client, owner):
    dev = paired_device(client, owner)
    renamed = client.post(f"/api/devices/{dev['device_id']}/rename",
                          json={"name": "Pixel 9"}, headers=owner["headers"])
    assert renamed.json()["name"] == "Pixel 9"
    removed = client.delete(f"/api/devices/{dev['device_id']}", headers=owner["headers"])
    assert removed.status_code == 200
    remaining = client.get("/api/devices", headers=owner["headers"]).json()["devices"]
    assert all(d["device_id"] != dev["device_id"] for d in remaining)


def test_host_device_cannot_be_revoked(client, owner):
    host = client.get("/api/devices", headers=owner["headers"]).json()["devices"][0]
    resp = client.post(f"/api/devices/{host['device_id']}/revoke", headers=owner["headers"])
    assert resp.status_code == 400


def test_device_tokens_are_stored_hashed(client, owner):
    dev = paired_device(client, owner)
    from backend import db

    row = db.one("SELECT token_hash FROM devices WHERE device_id=?", (dev["device_id"],))
    assert row["token_hash"] and dev["device_token"] not in row["token_hash"]
    assert len(row["token_hash"]) == 64


def test_invalid_pairing_code_rejected(client, owner):
    assert client.post("/api/devices/pairing/claim",
                       json={"code": "PAIR-XXXX-YYYY"}).status_code == 404
