"""Offline reporting, task lifecycle, confirmation enforcement, memory guard,
AI error handling, tools and health (spec 6, 18, 21, 22, 26, 36)."""
from __future__ import annotations

import json

import httpx
import pytest

from tests.test_devices import paired_device


# ------------------------------ cross-device ------------------------------- #
def test_offline_target_is_reported_not_faked(client, owner):
    dev = paired_device(client, owner, "Lucky's Phone")
    resp = client.post("/api/chat", json={"text": "Open YouTube on my phone"},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "FAILED"
    assert body.get("offline") is True
    assert "offline" in body["message"].lower()


def test_task_is_recorded_with_target_device(client, owner):
    dev = paired_device(client, owner, "Lucky's Phone")
    client.post("/api/chat", json={"text": "Open YouTube on my phone"}, headers=owner["headers"])
    tasks = client.get("/api/tasks", headers=owner["headers"]).json()["tasks"]
    assert tasks and tasks[0]["target_device_id"] == dev["device_id"]
    assert tasks[0]["status"] == "FAILED"


def test_request_id_makes_commands_idempotent(client, owner):
    from backend.device_bus import create_task

    a = create_task(owner["user"]["user_id"], "command", {"text": "x"}, request_id="req-1")
    b = create_task(owner["user"]["user_id"], "command", {"text": "x"}, request_id="req-1")
    assert a["task_id"] == b["task_id"]


def test_duplicate_results_are_dropped(client, owner):
    from backend.device_bus import bus

    assert bus.deliver_result("tsk_dup", {"ok": True}) in (True, False)
    assert bus.deliver_result("tsk_dup", {"ok": True}) is False


def test_task_cancel(client, owner):
    from backend.device_bus import create_task

    task = create_task(owner["user"]["user_id"], "command", {"text": "y"})
    resp = client.post(f"/api/tasks/{task['task_id']}/cancel", headers=owner["headers"])
    assert resp.json()["status"] == "CANCELLED"


# ------------------------------ confirmation ------------------------------- #
def test_destructive_tool_requires_backend_confirmation(client, owner, tmp_path):
    target = tmp_path / "doomed.txt"
    target.write_text("delete me")

    resp = client.post("/api/tools/run",
                       json={"name": "delete_file", "args": {"path": str(target)}},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "WAITING_CONFIRMATION"
    assert target.exists(), "file must NOT be touched before confirmation"

    cancelled = client.post("/api/tools/confirm",
                            json={"confirm_id": body["confirm_id"], "approve": False},
                            headers=owner["headers"])
    assert cancelled.json()["status"] == "CANCELLED"
    assert target.exists(), "cancelling must leave the file alone"


def test_confirmed_destructive_tool_executes_and_verifies(client, owner, tmp_path, monkeypatch):
    from backend import config

    monkeypatch.setattr(config, "FILE_ROOT", tmp_path)
    target = tmp_path / "doomed.txt"
    target.write_text("delete me")

    body = client.post("/api/tools/run",
                       json={"name": "delete_file", "args": {"path": str(target)}},
                       headers=owner["headers"]).json()
    done = client.post("/api/tools/confirm",
                       json={"confirm_id": body["confirm_id"], "approve": True},
                       headers=owner["headers"]).json()
    assert done["status"] == "COMPLETED"
    assert done["verified"] is True
    assert not target.exists()


def test_confirmation_cannot_be_replayed(client, owner, tmp_path, monkeypatch):
    from backend import config

    monkeypatch.setattr(config, "FILE_ROOT", tmp_path)
    target = tmp_path / "f.txt"
    target.write_text("x")
    body = client.post("/api/tools/run", json={"name": "delete_file", "args": {"path": str(target)}},
                       headers=owner["headers"]).json()
    client.post("/api/tools/confirm", json={"confirm_id": body["confirm_id"], "approve": True},
                headers=owner["headers"])
    replay = client.post("/api/tools/confirm",
                         json={"confirm_id": body["confirm_id"], "approve": True},
                         headers=owner["headers"])
    assert replay.status_code == 400


def test_another_user_cannot_confirm_your_action(client, owner, tmp_path):
    from tests.conftest import auth_headers, register

    target = tmp_path / "x.txt"
    target.write_text("x")
    body = client.post("/api/tools/run", json={"name": "delete_file", "args": {"path": str(target)}},
                       headers=owner["headers"]).json()
    register(client, "guest", "anothersecret1")
    guest = client.post("/api/auth/login", json={"username": "guest", "password": "anothersecret1"})
    resp = client.post("/api/tools/confirm",
                       json={"confirm_id": body["confirm_id"], "approve": True},
                       headers=auth_headers(guest.json()["token"]))
    assert resp.status_code == 403
    assert target.exists()


# --------------------------------- memory ---------------------------------- #
def test_memory_store_and_recall(client, owner):
    resp = client.post("/api/memory", json={"key": "favorite_city", "value": "Patna"},
                       headers=owner["headers"])
    assert resp.status_code == 200
    mems = client.get("/api/memory", headers=owner["headers"]).json()["memories"]
    assert any(m["key"] == "favorite_city" and m["value"] == "Patna" for m in mems)


@pytest.mark.parametrize("key,value", [
    ("gmail_password", "hunter2000"),
    ("api_key", "abc123def456"),
    ("openai", "sk-abcdefghijklmnopqrstuvwxyz123456"),
    ("groq", "gsk_abcdefghijklmnopqrstuvwxyz1234"),
    ("session", "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIn0.sig"),
])
def test_memory_guard_refuses_credentials(client, owner, key, value):
    resp = client.post("/api/memory", json={"key": key, "value": value}, headers=owner["headers"])
    assert resp.status_code == 422
    assert "Refused" in resp.json()["detail"]


def test_natural_language_remember(client, owner):
    resp = client.post("/api/chat", json={"text": "remember that my favorite city is Patna"},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "COMPLETED"
    mems = client.get("/api/memory", headers=owner["headers"]).json()["memories"]
    assert any("patna" in m["value"].lower() for m in mems)


def test_memory_delete_and_clear(client, owner):
    mem = client.post("/api/memory", json={"key": "k1", "value": "v1"},
                      headers=owner["headers"]).json()
    assert client.delete(f"/api/memory/{mem['id']}", headers=owner["headers"]).status_code == 200
    client.post("/api/memory", json={"key": "k2", "value": "v2"}, headers=owner["headers"])
    assert client.delete("/api/memory", headers=owner["headers"]).json()["removed"] == 1


# ----------------------------------- AI ------------------------------------ #
def test_non_json_ai_response_becomes_readable_error():
    from backend.services.ai_client import AIError, parse_chat_payload

    resp = httpx.Response(200, text="<html><body>Login required</body></html>",
                          headers={"content-type": "text/html"})
    with pytest.raises(AIError) as exc:
        parse_chat_payload(resp, "OmniRoute")
    assert "Expecting value" not in str(exc.value)
    assert "non-JSON" in str(exc.value)


def test_empty_ai_response_becomes_readable_error():
    from backend.services.ai_client import AIError, parse_chat_payload

    with pytest.raises(AIError) as exc:
        parse_chat_payload(httpx.Response(200, text=""), "Ollama")
    assert "empty response" in str(exc.value)


def test_http_error_bodies_are_described():
    from backend.services.ai_client import describe_http_failure

    assert "429" in describe_http_failure(httpx.Response(429, text="slow down"), "OmniRoute")
    assert "quota" in describe_http_failure(httpx.Response(429, text="x"), "OmniRoute")
    html = describe_http_failure(
        httpx.Response(500, text="<html>oops</html>", headers={"content-type": "text/html"}), "Ollama")
    assert "HTML page" in html
    js = describe_http_failure(
        httpx.Response(404, json={"error": {"message": "no such model"}}), "OmniRoute")
    assert "no such model" in js


def test_combo_name_is_never_modified(client, owner):
    resp = client.post("/api/settings", json={"ai": {"mode": "omniroute", "combo": "JARVIS-copy-77"}},
                       headers=owner["headers"])
    assert resp.json()["ai"]["combo"] == "JARVIS-copy-77"
    from backend.services.ai_client import AIConfig

    assert AIConfig.load().combo == "JARVIS-copy-77"


def test_ai_probes_report_unavailable_honestly(client, owner):
    detect = client.get("/api/ai/detect", headers=owner["headers"]).json()
    for backend_name in ("omniroute", "ollama"):
        info = detect[backend_name]
        if not info["available"]:
            assert info["error"], "an unavailable backend must explain why"


def test_settings_persist(client, owner):
    client.post("/api/settings", json={"ai": {"mode": "ollama", "ollama_model": "qwen3:8b"}},
                headers=owner["headers"])
    got = client.get("/api/settings", headers=owner["headers"]).json()
    assert got["ai"]["mode"] == "ollama" and got["ai"]["ollama_model"] == "qwen3:8b"


def test_invalid_ai_mode_rejected(client, owner):
    assert client.post("/api/settings", json={"ai": {"mode": "skynet"}},
                       headers=owner["headers"]).status_code == 400


# --------------------------------- tools ----------------------------------- #
def test_tool_registry_exposes_risk_levels(client, owner):
    tools = client.get("/api/tools", headers=owner["headers"]).json()["tools"]
    names = {t["name"]: t for t in tools}
    assert names["delete_file"]["risk"] == "CONFIRM"
    assert names["cpu_usage"]["risk"] == "SAFE"
    assert names["shutdown_pc"]["risk"] == "CONFIRM"


def test_windows_only_tools_report_unavailable_off_windows(client, owner):
    import sys

    tools = {t["name"]: t for t in client.get("/api/tools", headers=owner["headers"]).json()["tools"]}
    if not sys.platform.startswith("win"):
        assert tools["run_powershell"]["available"] is False
        assert "Windows-only" in tools["run_powershell"]["unavailable_reason"]


def test_safe_tool_runs_and_returns_real_data(client, owner):
    resp = client.post("/api/tools/run", json={"name": "cpu_usage", "args": {}},
                       headers=owner["headers"])
    assert resp.status_code == 200
    result = resp.json()["result"]
    assert 0 <= result["overall"] <= 100 and result["cores"] >= 1


def test_deterministic_intent_avoids_ai(client, owner):
    resp = client.post("/api/chat", json={"text": "what's my cpu"}, headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "COMPLETED"
    assert "CPU is at" in body["message"]
    assert "provider" not in body


def test_file_tools_are_root_confined(client, owner):
    resp = client.post("/api/tools/run", json={"name": "read_file", "args": {"path": "/etc/shadow"}},
                       headers=owner["headers"])
    assert resp.status_code == 400
    assert "outside the permitted file root" in resp.json()["detail"]


# --------------------------------- health ---------------------------------- #
def test_health_never_lies_about_components(client, owner):
    health = client.get("/api/health").json()
    comp = health["components"]
    assert comp["backend"]["status"] == "READY"
    for name in ("omniroute", "ollama", "browser", "voice_stt", "voice_tts"):
        assert comp[name]["status"] in ("READY", "UNAVAILABLE")
        if comp[name]["status"] == "UNAVAILABLE":
            assert comp[name]["detail"]


def test_gmail_calendar_credential_blocked_without_oauth(client, owner):
    health = client.get("/api/health").json()["components"]
    assert health["gmail"]["status"] in ("CREDENTIAL_BLOCKED", "CONFIGURED")
    url = client.get("/api/integrations/google/auth-url", headers=owner["headers"])
    if health["gmail"]["status"] == "CREDENTIAL_BLOCKED":
        assert url.status_code == 503
        assert "CREDENTIAL_BLOCKED" in url.json()["detail"]


def test_greeting_contains_author_line(client):
    assert "Made by Lucky Kumar." in client.get("/api/greeting").json()["text"]


def test_audit_log_records_and_scrubs(client, owner):
    from backend import audit

    audit.record("test.secret", "OK", user_id=owner["user"]["user_id"],
                 detail={"password": "hunter2", "token": "jtk_abc", "safe": "value"})
    entries = client.get("/api/audit", headers=owner["headers"]).json()["entries"]
    entry = next(e for e in entries if e["action"] == "test.secret")
    assert "hunter2" not in entry["detail"]
    assert "[REDACTED]" in entry["detail"]
    assert "value" in entry["detail"]


def test_system_status_reports_real_metrics(client, owner):
    status = client.get("/api/system/status", headers=owner["headers"]).json()
    assert status["available"] is True
    assert 0 <= status["cpu"] <= 100 and 0 <= status["ram"] <= 100
    assert status["processes"] > 0


def test_browser_reports_blocked_when_playwright_missing(client, owner):
    from backend.services.browser_tools import playwright_status

    status = playwright_status()
    if not status["installed"]:
        resp = client.post("/api/tools/run", json={"name": "browser_open", "args": {"target": "youtube"}},
                           headers=owner["headers"])
        assert resp.status_code == 501
        assert "playwright" in resp.json()["detail"].lower()


def test_named_destination_resolution(client, owner):
    from backend.services.browser_tools import resolve_destination

    assert resolve_destination("youtube") == "https://www.youtube.com/"
    assert resolve_destination("definitely-not-a-real-place") is None


def test_url_validation_rejects_nonsense(client, owner):
    from backend.services.browser_tools import ToolError, validate_url

    assert validate_url("youtube.com") == "https://youtube.com"
    with pytest.raises(ToolError):
        validate_url("javascript:alert(1)")


def test_voice_state_machine(client, owner):
    states = client.get("/api/voice/state", headers=owner["headers"]).json()
    assert states["state"] == "READY"
    assert set(["READY", "LISTENING", "THINKING", "SPEAKING", "ERROR"]).issubset(set(states["states"]))
    bad = client.post("/api/voice/state", json={"state": "DANCING"}, headers=owner["headers"])
    assert bad.status_code == 400


def test_voice_stt_reports_blocked_when_engine_missing(client, owner):
    from backend.services.voice_engine import stt_status

    if not stt_status()["available"]:
        resp = client.post("/api/voice/stt", files={"audio": ("a.webm", b"x", "audio/webm")},
                           headers=owner["headers"])
        assert resp.status_code == 501
