"""Tests for the intelligent AI workload routing (spec: PART 1).

Covers: deterministic bypass, routing-mode decisions (auto/local_first/
cloud_first/local_only/cloud_only/hybrid), explicit Combo preservation, quota
protection, usage tracking, memory recall and learned workflows.
"""
from __future__ import annotations

import pytest

from backend import routing, quota, workflows
from backend.memory_store import (append_turn, clear_conversation, get_context,
                                  set_conversation_enabled, summarize_context,
                                  store_memory)
from backend.services import agent_loop


# --------------------------------------------------------------------------- #
# complexity classification
# --------------------------------------------------------------------------- #
def test_classify_simple():
    assert routing.classify("open chrome") == routing.SIMPLE
    assert routing.classify("what time is it") == routing.SIMPLE


def test_classify_complex():
    assert routing.classify("explain this difficult programming problem in detail") == routing.COMPLEX


def test_classify_moderate_by_length():
    assert routing.classify("a moderately long sentence spanning several words in this example") == routing.MODERATE


# --------------------------------------------------------------------------- #
# deterministic bypass (no cloud)
# --------------------------------------------------------------------------- #
def test_deterministic_intents_bypass_ai():
    for phrase in ("what's my cpu", "open youtube", "show system status",
                   "take a screenshot", "what time is it"):
        intent = agent_loop.parse_intent(phrase)
        assert intent is not None, f"'{phrase}' should be deterministic"


def test_deterministic_command_routes_deterministic(client, owner):
    resp = client.post("/api/chat", json={"text": "what's my cpu"},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "COMPLETED"
    assert body["route"] == routing.ROUTE_DETERMINISTIC
    assert body["ai"] == "NONE"
    assert body["cloud_used"] is False
    assert body["tool"] == "cpu_usage"


# --------------------------------------------------------------------------- #
# routing-mode decisions (pure, no network)
# --------------------------------------------------------------------------- #
def test_local_first_prefers_ollama():
    d = routing.decide("hi there", mode="local_first",
                       availability={"ollama": True, "omniroute": True})
    assert d.provider == routing.PROVIDER_LOCAL
    assert d.cloud_used is False


def test_local_only_never_uses_cloud():
    d = routing.decide("explain a hard problem at length here", mode="local_only",
                       availability={"ollama": True, "omniroute": True})
    assert d.provider == routing.PROVIDER_LOCAL


def test_cloud_only_requires_cloud():
    d = routing.decide("hi", mode="cloud_only",
                       availability={"ollama": True, "omniroute": True})
    assert d.provider == routing.PROVIDER_CLOUD
    assert d.cloud_used is True
    # no cloud available -> honest failure, no silent fallback
    d2 = routing.decide("hi", mode="cloud_only",
                        availability={"ollama": True, "omniroute": False})
    assert d2.provider == ""


def test_auto_frugal_simple_to_local():
    d = routing.decide("hi", mode="auto", availability={"ollama": True, "omniroute": True})
    assert d.provider == routing.PROVIDER_LOCAL


def test_auto_complex_uses_cloud_when_combo_set():
    d = routing.decide("explain this difficult programming problem in detail",
                       mode="auto", availability={"ollama": True, "omniroute": True},
                       combo="JARVIS-copy-13")
    assert d.provider == routing.PROVIDER_CLOUD
    assert d.cloud_used is True


def test_cloud_first_falls_back_to_local():
    d = routing.decide("hi", mode="cloud_first",
                       availability={"ollama": True, "omniroute": False})
    assert d.provider == routing.PROVIDER_LOCAL
    assert d.fallback is True


def test_no_backend_honest_failure():
    d = routing.decide("hi", mode="auto",
                       availability={"ollama": False, "omniroute": False})
    assert d.provider == ""


# --------------------------------------------------------------------------- #
# explicit Combo (exact, byte-for-byte)
# --------------------------------------------------------------------------- #
def test_explicit_combo_extracted():
    assert routing.explicit_combo("use JARVIS-copy-13") == "JARVIS-copy-13"
    assert routing.explicit_combo("switch to MY-CUSTOM-COMBO") == "MY-CUSTOM-COMBO"
    assert routing.explicit_combo("using combo.with.dots-and_UNDERSCORES") == "combo.with.dots-and_UNDERSCORES"


def test_explicit_combo_not_lowercased():
    got = routing.explicit_combo("use JARVIS-copy-13")
    assert got == "JARVIS-copy-13"
    # casing is never folded
    assert got.islower() is not True
    assert got.startswith("JARVIS")


def test_explicit_combo_ignores_generic_words():
    assert routing.explicit_combo("use google") is None


# --------------------------------------------------------------------------- #
# memory recall (no cloud)
# --------------------------------------------------------------------------- #
def test_memory_recall_from_local_only(client, owner):
    client.post("/api/memory", json={"key": "favorite_city", "value": "Patna"},
                headers=owner["headers"])
    resp = client.post("/api/chat", json={"text": "what did I tell you about my favorite city"},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "COMPLETED"
    assert body["route"] == routing.ROUTE_MEMORY
    assert "Patna" in body["message"]
    assert body["cloud_used"] is False
    assert body["ai"] == "NONE"


# --------------------------------------------------------------------------- #
# learned workflows (SAFE only)
# --------------------------------------------------------------------------- #
def test_workflow_learns_only_safe_tools(client, owner):
    uid = owner["user"]["user_id"]
    wf = workflows.learn(uid, "open chrome", "browser_open", {"target": "google"})
    assert wf is not None
    # CONFIRM / dangerous tools are never learned
    wf2 = workflows.learn(uid, "delete file x", "delete_file", {"path": "x"})
    assert wf2 is None
    assert workflows.lookup(uid, "delete file x") is None


def test_workflow_lookup_and_learn_roundtrip(client, owner):
    user_id = owner["user"]["user_id"]
    workflows.learn(user_id, "show cpu usage", "cpu_usage", {})
    got = workflows.lookup(user_id, "show cpu usage")
    assert got is not None and got["tool"] == "cpu_usage"
    assert workflows.lookup(user_id, "nonexistent command") is None


def test_workflow_repeat_bumps_times_used(client, owner):
    user_id = owner["user"]["user_id"]
    workflows.learn(user_id, "ping", "system_info", {})
    workflows.learn(user_id, "ping", "system_info", {})
    got = workflows.lookup(user_id, "ping")
    assert got["times_used"] == 2


def test_workflow_delete(client, owner):
    user_id = owner["user"]["user_id"]
    workflows.learn(user_id, "do a thing", "battery_status", {})
    wf = workflows.lookup(user_id, "do a thing")
    assert workflows.delete(user_id, wf["id"]) is True


def test_learned_workflow_cache_runs_without_ai(client, owner):
    # use a command that parse_intent does NOT catch, so the workflow cache path runs
    user_id = owner["user"]["user_id"]
    workflows.learn(user_id, "show top processes", "list_processes", {"limit": 5})
    resp = client.post("/api/chat", json={"text": "show top processes"},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "COMPLETED"
    assert body["route"] == routing.ROUTE_WORKFLOW
    assert body["ai"] == "NONE"
    assert body["tool"] == "list_processes"


# --------------------------------------------------------------------------- #
# quota protection
# --------------------------------------------------------------------------- #
def test_quota_limits_default_and_save(client, owner):
    lim = quota.limits()
    assert lim["daily_cloud_limit"] >= 1
    new = quota.save_limits({"daily_cloud_limit": 7})
    assert new["daily_cloud_limit"] == 7


def test_quota_check_raises_when_exhausted(client, owner):
    quota.save_limits({"enforce_cloud_limits": True, "session_cloud_limit": 100,
                       "daily_cloud_limit": 100, "user_cloud_limit": 100,
                       "device_cloud_limit": 1})
    uid = owner["user"]["user_id"]
    quota.record(user_id=uid, device_id="dev_x", provider="omniroute", route="CLOUD",
                 cloud=True)
    with pytest.raises(quota.QuotaError):
        quota.check_cloud_limit(user_id=uid, device_id="dev_x")


def test_quota_records_and_summary(client, owner):
    uid = owner["user"]["user_id"]
    quota.record(user_id=uid, provider="ollama", route="LOCAL", cloud=False,
                 prompt_tokens=100, completion_tokens=50)
    quota.record(user_id=uid, provider="omniroute", route="CLOUD", cloud=True,
                 prompt_tokens=10, completion_tokens=20)
    s = quota.summary(uid)
    assert s["today"]["local"] >= 1
    assert s["today"]["cloud"] >= 1
    assert s["today"]["estimated_cloud_tokens"] >= 30


def test_secrets_never_revealed_in_usage(client, owner):
    uid = owner["user"]["user_id"]
    quota.record(user_id=uid, provider="omniroute", route="CLOUD", cloud=True,
                 detail={"combo": "JARVIS-copy-13"})
    s = quota.summary(uid)
    assert "sk-" not in str(s)
    assert "api_key" not in str(s).lower()
    assert "secret" not in str(s)


# --------------------------------------------------------------------------- #
# usage telemetry through the chat route
# --------------------------------------------------------------------------- #
def test_usage_only_counts_cloud_for_cloud_route(client, owner):
    uid = owner["user"]["user_id"]
    resp = client.post("/api/chat", json={"text": "what's my cpu"}, headers=owner["headers"])
    assert resp.json()["status"] == "COMPLETED"
    s = quota.summary(uid)
    # the deterministic call was recorded as a LOCAL (non-cloud) row
    assert s["today"]["cloud"] >= 0


# --------------------------------------------------------------------------- #
# bounded conversation memory
# --------------------------------------------------------------------------- #
def test_conversation_window_bounded(client, owner):
    uid = owner["user"]["user_id"]
    set_conversation_enabled(True)
    for i in range(30):
        append_turn(uid, "default", "user", f"message number {i}")
    ctx = get_context(uid, "default")
    # never more than MAX_TURNS live turns (+ optional summary)
    live = [m for m in ctx if not m["content"].startswith("[Local summary")]
    assert len(live) <= 12


def test_conversation_user_isolation(client, owner):
    uid1 = owner["user"]["user_id"]
    append_turn(uid1, "default", "user", "secret of user one")
    assert get_context("other_user_x", "default") == []


def test_conversation_clear(client, owner):
    uid = owner["user"]["user_id"]
    append_turn(uid, "default", "user", "hello")
    assert clear_conversation(uid) >= 1
    assert get_context(uid, "default") == []


def test_conversation_summarizes(client, owner):
    uid = owner["user"]["user_id"]
    for i in range(12):
        append_turn(uid, "default", "user", f"long message number {i} that has some content")
    summary = summarize_context(uid, "default")
    assert summary is None or "summary" in summary.lower()


def test_secret_turn_not_persisted(client, owner):
    uid = owner["user"]["user_id"]
    append_turn(uid, "default", "user", "my api key is sk-abcdefghijklmnop1234567890x")
    ctx = get_context(uid, "default")
    assert all("sk-abcdefghijklmnop1234567890x" not in m["content"] for m in ctx)


# --------------------------------------------------------------------------- #
# long-term memory retrieval helpers
# --------------------------------------------------------------------------- #
def test_search_memories_relevance(client, owner):
    uid = owner["user"]["user_id"]
    store_memory(uid, "name", "Lucky Kumar")
    store_memory(uid, "city", "Patna")
    from backend.memory_store import search_memories
    res = search_memories(uid, "lucky")
    assert any("Lucky" in m["value"] for m in res)
    # a query for one memory should not return the unrelated one
    res2 = search_memories(uid, "patna")
    assert len(res2) == 0 or all("Patna" in m["value"] for m in res2) or \
        all("Lucky" not in m["value"] for m in res2)


# --------------------------------------------------------------------------- #
# API endpoints
# --------------------------------------------------------------------------- #
def test_ai_routing_status_endpoint(client, owner):
    resp = client.get("/api/ai/routing", headers=owner["headers"])
    assert resp.status_code == 200
    body = resp.json()
    assert "mode" in body
    assert "local_first" in body["modes"]
    assert "diagnostics" in body


def test_ai_usage_endpoint(client, owner):
    uid = owner["user"]["user_id"]
    quota.record(user_id=uid, provider="ollama", route="LOCAL", cloud=False)
    resp = client.get("/api/ai/usage", headers=owner["headers"])
    assert resp.status_code == 200
    body = resp.json()
    assert body["summary"]["today"]["local"] >= 1
    assert "estimated_cloud_tokens" in body["summary"]["today"]


def test_set_routing_owner_only(client, owner):
    # OWNER can set routing
    resp = client.post("/api/ai/routing", json={"routing": "local_only"},
                       headers=owner["headers"])
    assert resp.status_code == 200
    assert resp.json()["routing"] == "local_only"
    # back to default
    client.post("/api/ai/routing", json={"routing": "local_first"}, headers=owner["headers"])


def test_set_routing_rejects_bad_mode(client, owner):
    resp = client.post("/api/ai/routing", json={"routing": "nonsense"},
                       headers=owner["headers"])
    assert resp.status_code == 400


def test_non_owner_cannot_set_routing(client, owner):
    # register a second account -> LIMITED_USER
    from tests.conftest import register
    user = register(client, username="limited_usr", password="secretpw123")
    resp = client.post("/api/ai/routing", json={"routing": "cloud_only"},
                       headers={"Authorization": f"Bearer {user['token']}"})
    assert resp.status_code == 403


def test_settings_accepts_routing_mode(client, owner):
    resp = client.post("/api/settings", json={"ai": {"routing": "hybrid"}},
                       headers=owner["headers"])
    assert resp.status_code == 200
    assert resp.json()["ai"]["routing"] == "hybrid"
    # legacy mode derived
    assert resp.json()["ai"]["mode"] == "auto"


def test_quota_limits_endpoint(client, owner):
    resp = client.get("/api/routing/limits", headers=owner["headers"])
    assert resp.status_code == 200
    assert "daily_cloud_limit" in resp.json()["limits"]
    resp = client.post("/api/routing/limits", json={"daily_cloud_limit": 42},
                       headers=owner["headers"])
    assert resp.status_code == 200
    assert resp.json()["limits"]["daily_cloud_limit"] == 42


def test_workflows_endpoints(client, owner):
    uid = owner["user"]["user_id"]
    workflows.learn(uid, "show top processes", "list_processes", {"limit": 5})
    resp = client.get("/api/workflows", headers=owner["headers"])
    body = resp.json()
    assert any(w["tool"] == "list_processes" for w in body["workflows"])
    wf_id = body["workflows"][0]["id"]
    assert client.delete(f"/api/workflows/{wf_id}", headers=owner["headers"]).status_code == 200
    resp = client.delete("/api/workflows", headers=owner["headers"])
    assert resp.status_code == 200


def test_memory_context_endpoint(client, owner):
    resp = client.get("/api/memory/context", headers=owner["headers"])
    assert resp.status_code == 200
    assert "window" in resp.json()
    resp = client.post("/api/memory/context/enabled", json={"enabled": False},
                       headers=owner["headers"])
    assert resp.json()["enabled"] is False
    resp = client.post("/api/memory/context/enabled", json={"enabled": True},
                       headers=owner["headers"])
    assert resp.json()["enabled"] is True


def test_secret_settings_not_exposed(client, owner):
    client.post("/api/settings", json={"ai": {"combo": "JARVIS-copy-999"}},
                headers=owner["headers"])
    resp = client.get("/api/settings", headers=owner["headers"])
    text = str(resp.json())
    assert "api_key" not in text.lower()
    assert "sk-" not in text


def test_learned_workflow_takes_priority_over_parse_intent(client, owner):
    """After a deterministic command runs once (and is learned), a repeat should
    hit the WORKFLOW cache, not re-parse as deterministic."""
    h = owner["headers"]
    first = client.post("/api/chat", json={"text": "what's my cpu"}, headers=h).json()
    assert first["route"] == "DETERMINISTIC"
    second = client.post("/api/chat", json={"text": "what's my cpu"}, headers=h).json()
    assert second["status"] == "COMPLETED"
    assert second["route"] == "WORKFLOW"
    assert second["ai"] == "NONE"
    assert second["tool"] == "cpu_usage"
