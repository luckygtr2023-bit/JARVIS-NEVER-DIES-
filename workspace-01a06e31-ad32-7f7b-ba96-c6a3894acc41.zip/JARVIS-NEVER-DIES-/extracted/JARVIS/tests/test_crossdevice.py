"""Protocol v1 + capability system + cross-device routing (spec 5-9).

These tests are deliberately paranoid about the things that would be easy to
fake: a device must not be able to originate a server frame, a task must not be
reported as executed when the target is offline, and a replayed result must not
be counted twice.
"""
from __future__ import annotations

import json

import pytest

from backend import capabilities, protocol
from backend.protocol import ErrorCode, MessageType, Status

from .conftest import auth_headers, register  # noqa: F401


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def pair_device(client, owner, name="Lucky's Phone", device_type="android", caps=None):
    body = {"device_name": name, "device_type": device_type, "os": "Android 14",
            "app_version": "1.0.0"}
    if caps is not None:
        body["capabilities"] = caps
    pairing = client.post("/api/devices/pairing", json=body).json()
    client.post(f"/api/devices/pairing/{pairing['pairing_id']}/approve", headers=owner["headers"])
    claim = client.post("/api/devices/pairing/claim", json={"code": pairing["code"]}).json()
    return claim


def grant_chat(client, owner, device_id, extra=()):
    client.post(f"/api/devices/{device_id}/permissions",
                json={"permissions": ["chat", *extra]}, headers=owner["headers"])


# --------------------------------------------------------------------------- #
# pure protocol
# --------------------------------------------------------------------------- #
def test_envelope_has_every_required_field():
    msg = protocol.envelope(MessageType.TASK_ASSIGN, task_id="tsk_1", user_id="usr_1",
                            source_device_id="dev_a", target_device_id="dev_b",
                            payload={"text": "hi"}, status=Status.ASSIGNED)
    for field in ("protocol_version", "message_type", "request_id", "task_id", "user_id",
                  "source_device_id", "target_device_id", "timestamp", "payload", "status"):
        assert field in msg, f"envelope is missing {field}"
    assert msg["protocol_version"] == 1
    assert msg["request_id"].startswith("req_")


def test_envelope_rejects_an_invented_message_type():
    with pytest.raises(protocol.ProtocolError):
        protocol.envelope("DROP_TABLE_USERS")


def test_every_message_type_from_the_spec_exists():
    required = {
        "DEVICE_REGISTER", "DEVICE_AUTH", "DEVICE_PAIR_REQUEST", "DEVICE_PAIR_APPROVE",
        "DEVICE_REVOKE", "DEVICE_HEARTBEAT", "DEVICE_STATUS", "DEVICE_CAPABILITIES",
        "TASK_CREATE", "TASK_ASSIGN", "TASK_UPDATE", "TASK_RESULT", "TASK_CANCEL",
        "COMMAND_REQUEST", "COMMAND_RESULT", "CONFIRMATION_REQUEST", "CONFIRMATION_RESULT",
        "ERROR_EVENT",
    }
    assert required <= set(protocol.ALL_MESSAGE_TYPES)


def test_legacy_frames_are_still_understood():
    frame = protocol.parse_frame({"type": "heartbeat"})
    assert frame["message_type"] == MessageType.DEVICE_HEARTBEAT
    assert frame["_legacy"] is True

    frame = protocol.parse_frame({"type": "result", "task_id": "tsk_9", "ok": True,
                                  "verified": True, "result": {"a": 1}})
    assert frame["message_type"] == MessageType.TASK_RESULT
    assert frame["task_id"] == "tsk_9"
    # a legacy body at the top level becomes the payload
    assert frame["payload"]["ok"] is True
    assert frame["payload"]["result"] == {"a": 1}


def test_v1_frames_are_marked_as_v1():
    frame = protocol.parse_frame({"protocol_version": 1,
                                  "message_type": MessageType.DEVICE_HEARTBEAT,
                                  "payload": {}})
    assert frame["_legacy"] is False


def test_a_newer_protocol_version_is_refused_not_guessed():
    with pytest.raises(protocol.ProtocolError) as exc:
        protocol.parse_frame({"protocol_version": 99, "message_type": "DEVICE_HEARTBEAT"})
    assert "protocol_version" in str(exc.value)


def test_malformed_frames_raise():
    for bad in ([], "hello", {"payload": {}}, {"type": "nonsense"},
                {"message_type": "DEVICE_HEARTBEAT", "payload": "not a dict"}):
        with pytest.raises(protocol.ProtocolError):
            protocol.parse_frame(bad)


def test_downgrade_keeps_the_old_shape():
    msg = protocol.envelope(MessageType.TASK_ASSIGN, task_id="tsk_3",
                            payload={"text": "open youtube"})
    legacy = protocol.downgrade(msg)
    assert legacy["type"] == "task"
    assert legacy["task_id"] == "tsk_3"
    assert legacy["payload"] == {"text": "open youtube"}
    assert legacy["text"] == "open youtube"      # flattened too, for old readers


def test_client_may_not_originate_server_frames():
    assert not protocol.is_client_originated(MessageType.DEVICE_PAIR_APPROVE)
    assert not protocol.is_client_originated(MessageType.TASK_ASSIGN)
    assert protocol.is_client_originated(MessageType.TASK_RESULT)
    assert protocol.is_client_originated(MessageType.DEVICE_HEARTBEAT)


def test_protocol_descriptor_is_served_and_complete(client):
    d = client.get("/api/protocol").json()
    assert d["protocol_version"] == 1
    assert "/api/bus/ws" in d["transport"]["websocket"]
    assert set(d["message_types"]) == set(protocol.ALL_MESSAGE_TYPES)
    assert d["transport"]["reconnect"].startswith("exponential backoff")
    assert any("offline" in g.lower() for g in d["guarantees"])


# --------------------------------------------------------------------------- #
# capabilities
# --------------------------------------------------------------------------- #
def test_capability_catalog_covers_android_and_windows(client):
    cat = client.get("/api/capabilities").json()
    names = {c["capability"] for c in cat["capabilities"]}
    for required in ("voice.microphone", "voice.stt", "voice.tts", "notifications",
                     "app.launch", "browser", "android.intent", "media.control",
                     "files.scoped", "android.accessibility", "device.info",
                     "windows.automation", "input.keyboard_mouse", "screen.capture",
                     "files.full", "system.info", "ai.local"):
        assert required in names, f"catalog is missing {required}"
    assert "android" in cat["defaults"] and "windows" in cat["defaults"]


def test_unknown_capabilities_are_kept_not_silently_dropped():
    caps = capabilities.normalize(["browser", "some.future.capability", "browser", " "])
    assert caps == ["browser", "some.future.capability"]
    assert capabilities.unknown(caps) == ["some.future.capability"]


def test_a_device_that_advertises_nothing_gets_its_platform_baseline(client, owner):
    dev = pair_device(client, owner, "Bare Phone", caps=[])
    caps = capabilities.device_capabilities(dev["device_id"])
    assert "browser" in caps and "voice.tts" in caps
    assert "windows.automation" not in caps      # not an Android capability


def test_device_can_update_its_own_capabilities(client, owner):
    dev = pair_device(client, owner)
    resp = client.post(f"/api/devices/{dev['device_id']}/capabilities",
                       json={"capabilities": ["chat", "browser", "voice.tts", "my.custom.thing"]},
                       headers=owner["headers"])
    assert resp.status_code == 200
    body = resp.json()
    assert body["capabilities"] == ["chat", "browser", "voice.tts", "my.custom.thing"]
    assert body["unknown"] == ["my.custom.thing"]


def test_capability_is_checked_before_routing_not_after(client, owner):
    """A phone with no browser capability must be told 'no', not sent the task."""
    dev = pair_device(client, owner, "Lucky's Phone", caps=["chat", "voice.tts"])
    grant_chat(client, owner, dev["device_id"])

    resp = client.post("/api/chat", json={"text": "Open YouTube on my phone"},
                       headers=owner["headers"])
    body = resp.json()
    assert body["status"] == "FAILED"
    assert body.get("missing_capability") == "browser"
    assert "does not support" in body["message"]
    # and it must NOT claim the phone did anything
    assert "done" not in body["message"].lower()


def test_capability_mismatch_is_reported_on_the_typed_route_too(client, owner):
    dev = pair_device(client, owner, "Tablet", caps=["chat"])
    grant_chat(client, owner, dev["device_id"])
    resp = client.post(f"/api/devices/{dev['device_id']}/tasks",
                       json={"kind": "command", "payload": {"text": "take a screenshot"},
                             "required_capability": "screen.capture"},
                       headers=owner["headers"])
    assert resp.status_code == 409
    detail = resp.json()["detail"]
    assert detail["code"] == ErrorCode.CAPABILITY_MISSING
    assert detail["capability"] == "screen.capture"


# --------------------------------------------------------------------------- #
# device identity (spec 3)
# --------------------------------------------------------------------------- #
def test_device_identity_exposes_every_required_field(client, owner):
    dev = pair_device(client, owner)
    devices = client.get("/api/devices", headers=owner["headers"]).json()["devices"]
    row = next(d for d in devices if d["device_id"] == dev["device_id"])
    for field in ("device_id", "user_id", "name", "device_type", "os", "app_version",
                  "capabilities", "permissions", "state", "last_seen", "online",
                  "auth_state", "pairing_state", "presence"):
        assert field in row, f"device identity is missing {field}"
    assert row["auth_state"] == "AUTHENTICATED"
    assert row["pairing_state"] == "PAIRED"
    assert "token_hash" not in row          # never leaves the database


def test_one_user_can_own_many_devices(client, owner):
    phone = pair_device(client, owner, "Phone", "android")
    tablet = pair_device(client, owner, "Tablet", "android")
    listing = client.get("/api/devices", headers=owner["headers"]).json()
    ids = {d["device_id"] for d in listing["devices"]}
    assert {phone["device_id"], tablet["device_id"]} <= ids
    assert listing["total"] >= 3            # phone + tablet + this host
    # distinct identities, not one shared "android" slot
    assert phone["device_id"] != tablet["device_id"]


def test_presence_endpoint_reports_offline_honestly(client, owner):
    dev = pair_device(client, owner)
    p = client.get(f"/api/devices/{dev['device_id']}/presence",
                   headers=owner["headers"]).json()
    assert p["presence"] == "OFFLINE" and p["online"] is False


def test_another_users_device_is_not_visible(client, owner):
    dev = pair_device(client, owner)
    other = register(client, "intruder", "anotherpass9")
    h = auth_headers(other["token"])
    assert client.get(f"/api/devices/{dev['device_id']}/presence", headers=h).status_code == 404
    assert client.post(f"/api/devices/{dev['device_id']}/tasks",
                       json={"payload": {"text": "hi"}}, headers=h).status_code == 404


# --------------------------------------------------------------------------- #
# live websocket behaviour
# --------------------------------------------------------------------------- #
def test_websocket_rejects_an_unauthenticated_device(client):
    from starlette.websockets import WebSocketDisconnect as WSD
    with pytest.raises(WSD):
        with client.websocket_connect("/api/bus/ws?token=nonsense") as ws:
            ws.receive_text()


def test_hello_advertises_the_protocol_and_capabilities(client, owner):
    dev = pair_device(client, owner)
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        hello = json.loads(ws.receive_text())
        assert hello["type"] == "hello"                  # legacy dialect by default
        assert hello["payload"]["protocol_version"] == 1
        assert hello["payload"]["device_id"] == dev["device_id"]
        assert "capabilities" in hello["payload"]
        assert hello["seq"] == 1


def test_v1_client_is_answered_in_v1(client, owner):
    dev = pair_device(client, owner)
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()                                 # hello
        ws.send_text(json.dumps(protocol.envelope(
            MessageType.DEVICE_HEARTBEAT, source_device_id=dev["device_id"])))
        pong = json.loads(ws.receive_text())
        assert pong["message_type"] == MessageType.PONG
        assert pong["protocol_version"] == 1
        assert pong["payload"]["next_heartbeat_seconds"] > 0


def test_device_cannot_forge_a_server_frame(client, owner):
    """A paired phone must not be able to approve its own pairing."""
    dev = pair_device(client, owner)
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        ws.send_text(json.dumps(protocol.envelope(
            MessageType.DEVICE_PAIR_APPROVE, payload={"pairing_id": "pair_whatever"})))
        err = json.loads(ws.receive_text())
        assert err["message_type"] == MessageType.ERROR_EVENT
        assert err["payload"]["code"] == ErrorCode.NOT_CLIENT_ORIGINATED


def test_unknown_frame_gets_an_error_event_not_a_dropped_connection(client, owner):
    dev = pair_device(client, owner)
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        ws.send_text(json.dumps({"message_type": "TELEPORT_ME"}))
        err = json.loads(ws.receive_text())
        assert err["payload"]["code"] == ErrorCode.UNKNOWN_MESSAGE_TYPE
        # connection still usable
        ws.send_text(json.dumps({"type": "heartbeat"}))
        assert json.loads(ws.receive_text())["type"] == "pong"


def test_malformed_json_is_survivable(client, owner):
    dev = pair_device(client, owner)
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        ws.send_text("{not json")
        err = json.loads(ws.receive_text())
        assert err["payload"]["code"] == ErrorCode.MALFORMED


def test_capabilities_frame_updates_the_registry(client, owner):
    dev = pair_device(client, owner, caps=["chat"])
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        ws.send_text(json.dumps(protocol.envelope(
            MessageType.DEVICE_CAPABILITIES,
            payload={"capabilities": ["chat", "browser", "notifications"],
                     "os_version": "15", "app_version": "1.2.0"})))
        ack = json.loads(ws.receive_text())
        assert ack["message_type"] == MessageType.ACK
        assert ack["payload"]["capabilities"] == ["chat", "browser", "notifications"]
    assert capabilities.supports(dev["device_id"], "browser")


def test_seq_is_monotonic_so_a_client_can_detect_gaps(client, owner):
    dev = pair_device(client, owner)
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        seqs = [json.loads(ws.receive_text())["seq"]]
        for _ in range(3):
            ws.send_text(json.dumps({"type": "heartbeat"}))
            seqs.append(json.loads(ws.receive_text())["seq"])
    assert seqs == sorted(seqs) and len(set(seqs)) == len(seqs)


def test_duplicate_task_result_is_rejected_once(client, owner):
    dev = pair_device(client, owner)
    from backend.device_bus import create_task
    task = create_task(owner["user"]["user_id"], "command", {"text": "x"},
                       target_device_id=dev["device_id"])
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        frame = {"type": "result", "task_id": task["task_id"], "ok": True,
                 "verified": True, "result": {"done": True}}
        ws.send_text(json.dumps(frame))
        first = json.loads(ws.receive_text())
        ws.send_text(json.dumps(frame))
        second = json.loads(ws.receive_text())
    assert first["duplicate"] is False
    assert second["duplicate"] is True


def test_a_device_cannot_cancel_another_users_task(client, owner):
    dev = pair_device(client, owner)
    other = register(client, "someone_else", "anotherpass9")
    from backend.device_bus import create_task
    foreign = create_task(other["user"]["user_id"], "command", {"text": "x"})
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        ws.send_text(json.dumps(protocol.envelope(
            MessageType.TASK_CANCEL, task_id=foreign["task_id"])))
        err = json.loads(ws.receive_text())
        assert err["message_type"] == MessageType.ERROR_EVENT
        assert err["payload"]["code"] == ErrorCode.FORBIDDEN


def test_command_request_needs_the_chat_permission(client, owner):
    dev = pair_device(client, owner)
    client.post(f"/api/devices/{dev['device_id']}/permissions",
                json={"permissions": []}, headers=owner["headers"])
    with client.websocket_connect(f"/api/bus/ws?token={dev['device_token']}") as ws:
        ws.receive_text()
        ws.send_text(json.dumps(protocol.envelope(
            MessageType.COMMAND_REQUEST, payload={"text": "what is my cpu"})))
        err = json.loads(ws.receive_text())
        assert err["payload"]["code"] == ErrorCode.PERMISSION_MISSING


# --------------------------------------------------------------------------- #
# routing (spec 6) - the end-to-end promise
# --------------------------------------------------------------------------- #
def test_task_to_an_offline_device_is_never_reported_as_done(client, owner):
    dev = pair_device(client, owner, "Lucky's Phone")
    grant_chat(client, owner, dev["device_id"])
    resp = client.post(f"/api/devices/{dev['device_id']}/tasks",
                       json={"kind": "command", "payload": {"text": "open youtube"}},
                       headers=owner["headers"]).json()
    assert resp["status"] == Status.FAILED
    assert resp["offline"] is True
    assert resp["code"] == ErrorCode.TARGET_OFFLINE
    assert "offline" in resp["message"]


def test_routing_to_a_revoked_device_is_refused(client, owner):
    dev = pair_device(client, owner)
    grant_chat(client, owner, dev["device_id"])
    client.post(f"/api/devices/{dev['device_id']}/revoke", headers=owner["headers"])
    resp = client.post(f"/api/devices/{dev['device_id']}/tasks",
                       json={"payload": {"text": "hi"}}, headers=owner["headers"])
    assert resp.status_code == 403
    assert "revoked" in resp.json()["detail"].lower()


def test_routing_requires_the_chat_permission(client, owner):
    dev = pair_device(client, owner)
    client.post(f"/api/devices/{dev['device_id']}/permissions",
                json={"permissions": []}, headers=owner["headers"])
    resp = client.post(f"/api/devices/{dev['device_id']}/tasks",
                       json={"payload": {"text": "hi"}}, headers=owner["headers"])
    assert resp.status_code == 403
    assert "chat" in resp.json()["detail"]


def test_request_id_makes_routing_idempotent(client, owner):
    dev = pair_device(client, owner)
    grant_chat(client, owner, dev["device_id"])
    body = {"payload": {"text": "open youtube"}, "request_id": "req_same_one"}
    first = client.post(f"/api/devices/{dev['device_id']}/tasks", json=body,
                        headers=owner["headers"]).json()
    second = client.post(f"/api/devices/{dev['device_id']}/tasks", json=body,
                         headers=owner["headers"]).json()
    assert first["task_id"] == second["task_id"]      # one task, not two


def test_routing_is_audited(client, owner):
    dev = pair_device(client, owner)
    grant_chat(client, owner, dev["device_id"])
    client.post(f"/api/devices/{dev['device_id']}/tasks",
                json={"payload": {"text": "open youtube"}}, headers=owner["headers"])
    entries = client.get("/api/audit?limit=100", headers=owner["headers"]).json()["entries"]
    assert any(e["action"] == "task.route" for e in entries)
