# PWA Blank-Screen Bug — Root Cause & Fix Report

**Deliverables rebuilt:** `JARVIS-PC-WINDOWS-FINAL.zip` (2,010,742 bytes) and `JARVIS-PWA-ANDROID-FINAL.zip` (25,803 bytes).
**Tests:** 212/212 pass.
**Verified:** repackaged PC ZIP extracted to a clean dir, backend launched from *those files*, `/pwa/` load + full login + HOME screen confirmed in a real headless Chromium (390×844, Android Chrome UA) with 0 page errors / 0 failed requests.

---

## What was wrong (exact root cause)

The PWA routes in `backend/main.py` were mounted with a **bare `FileResponse(...)` and no explicit `media_type`**. Starlette/FastAPI then asked the **operating system's MIME registry** to guess the type for each file. On the live uvicorn host that registry resolved essentially every PWA asset to:

```
content-type: application/json
```

Browsers **refuse to apply** a stylesheet or script served as `application/json`, so `Content-Security` MIME-blocking silently discarded `styles.css` and `app.js`. Result: `/pwa/` returned HTTP 200 but an **empty dark page** — no login UI. It was purely a server-side content-type problem, **not** a bug in the PWA's JS/CSS, which is why it could look fine under FastAPI's `TestClient` (whose resolver differs) yet fail on the real host.

## What was changed

1. **`backend/main.py`** — added `_media_type(path)` and `_pwa_file(path, index)` and rewrote `_mount_pwa` to serve every PWA asset with an **explicit, hard-coded** content type independent of the OS registry:
   - `.html` → `text/html; charset=utf-8`
   - `.css` → `text/css; charset=utf-8`
   - `.js` / `.mjs` → `text/javascript; charset=utf-8`
   - `.json` → `application/json; charset=utf-8`, but **`manifest.json` → `application/manifest+json; charset=utf-8`** (so Chrome treats it as an installable manifest)
   - `.png` → `image/png`, `.svg`, `.ico`, `.woff2` likewise wired
   - never falls back to a wrong type.

2. **`backend/pwa/index.html`** — added a **critical inline `<style>` fallback** plus a `<noscript>` guard, so even if the external stylesheet ever fails to load, the J.A.R.V.I.S. branding, field labels, inputs, and SIGN IN button always render (never an empty void).

3. **`backend/pwa/sw.js`** — cache bumped to `jarvis-pwa-v2` and the shell changed from cache-first to **network-first** (cache only as offline fallback), so a stale cached copy from an older build can never mask a fixed release. `/api/*` is still never cached.

4. **`backend/pwa/README-ANDROID.md`** — added a **Troubleshooting** section documenting the MIME root cause, the inline-fallback behavior, and the network-first upgrade.

## Confirmed at runtime (GET requests, live server)

| Path | Content-Type |
|---|---|
| `/pwa/`, `/pwa/index.html` | `text/html; charset=utf-8` |
| `/pwa/app.js`, `/pwa/sw.js` | `text/javascript; charset=utf-8` |
| `/pwa/styles.css` | `text/css; charset=utf-8` |
| `/pwa/manifest.json` | `application/manifest+json; charset=utf-8` |
| `/pwa/icons/icon-192.png`, `icon-512.png` | `image/png` |
| `/api/health` | `application/json` (correct) |

## Browser render proof (real mobile UA)

- `/pwa/` → **HTTP 200**, login visible: `J.A.R.V.I.S. / Android Companion / USERNAME / PASSWORD / SIGN IN`.
- Body background `rgb(3,5,9)`; SIGN IN button `rgb(245,165,36)` — theme CSS applied.
- Service worker registered; **0 page errors, 0 failed requests, 0 console/MIME warnings.**
- After login: `#app` visible; HOME card shows SYSTEM STATUS / JARVIS / OFFLINE; QR/quick commands render.

## Host-relative (no localhost assumptions)

`app.js` calls `fetch("/api" + path)` and the WebSocket uses `location.host + "/api/bus/ws"` — both relative to whatever host serves `/pwa/`, so it works under `http://<PC-ip>:8420/pwa/`. No hard-coded `localhost` / `127.0.0.1` anywhere in the PWA.

## Not modified / still NOT VERIFIED

No second backend was created (one backend). No APK built (PWA is the Android client). OmniRoute/Ollama live content and all Windows-only features (STT/TTS/hotkey/tray/Tauri/EXE) remain marked **NOT VERIFIED** — they were not touched by this fix.
