# LAN Bind Fix — JARVIS now listens on `0.0.0.0:8420`

**Goal:** make the backend listen on every interface (`0.0.0.0:8420`) by default so the Android phone can reach it over LAN, **without** hard-coding any specific IP (which DHCP can change).

---

## Exact root cause

`config.HOST` already defaults to `0.0.0.0` (`backend/config.py:38`). The problem was **two hard-coded localhost overrides** in the startup path that beat the default:

1. **`start_jarvis.bat`** (the main Windows launcher) had:
   ```
   set "JARVIS_HOST=127.0.0.1"
   ```
   This set an env var that `config.HOST` then read → **`127.0.0.1`**. This is exactly why your `netstat` showed `TCP 127.0.0.1:8420 ... LISTENING`.

2. **`scripts/jarvis_entry.py`** (the PyInstaller `JARVIS.exe` entry point) had the host hard-coded in the uvicorn call:
   ```python
   uvicorn.run(app, host="127.0.0.1", ...)
   ```
   So the packaged EXE always bound to localhost too.

3. **`.env.example`** documented `JARVIS_HOST=127.0.0.1`, which would re-introduce the same bug if copied.

`backend/main.py` and `config.py` were already correct (they honor `config.HOST`); they were simply being overridden.

---

## What was changed

| File | Change |
|---|---|
| `start_jarvis.bat` | `set "JARVIS_HOST=127.0.0.1"` → `set "JARVIS_HOST=0.0.0.0"`, plus startup echo that it's listening on `0.0.0.0:<port>` and the LAN `/pwa/` URL. |
| `start_jarvis.bat` | Added a best-effort **Windows Firewall** step to allow inbound **TCP 8420 on Private** networks. If not run as Administrator it warns and continues. |
| `scripts/jarvis_entry.py` | `uvicorn.run(app, host="127.0.0.1", ...)` → `host=config.HOST` (now `0.0.0.0`), plus a startup `Bind:` line for transparency. |
| `scripts/ALLOW_PWA_FIREWALL.bat` | **New** convenience script to add the inbound firewall rule (run as Administrator). |
| `.env.example` | `JARVIS_HOST` documented as `0.0.0.0` with a note on when to use `127.0.0.1`. |
| `WINDOWS_SETUP.md` | Config table updated to `0.0.0.0`; "Connecting your phone" rewritten with the `netstat` check, firewall command, and a **LAN-not-localhost** sanity check. |

No IP is hard-coded anywhere — the bind is `0.0.0.0`, and only the phone's *current* IP matters at browse time (shown to you by `ipconfig`), which you enter on the phone.

---

## Verification

Launched the backend from the **repackaged `JARVIS-PC-WINDOWS-FINAL.zip`** in a clean dir with `JARVIS_HOST` unset.

**Listener (netstat/`ss` equivalent):**
```
LISTEN 0  2048  0.0.0.0:8423  0.0.0.0:*   (no 127.0.0.1:8423 listener)
```
→ bound to `0.0.0.0`, **not** loopback.

**Reachable from a separate device (non-loopback IP `169.254.0.21`, not `127.0.0.1`):**
```
GET http://<LAN-IP>:8423/api/health  ->  {"status":"ok","app":"J.A.R.V.I.S.","version":"1.0.0",...}
GET http://<LAN-IP>:8423/pwa/        ->  HTTP 200  content-type: text/html; charset=utf-8
```
Full mobile-format browser test through the LAN IP: login rendered, authenticated, HOME screen (SYSTEM STATUS / JARVIS / OFFLINE) loaded — **0 page errors, 0 failed requests.**

**Tests:** `pytest` → **212/212 pass.**

**ZIPs:** `JARVIS-PC-WINDOWS-FINAL.zip` rebuilt (2,013,564 bytes) with the bat, EXE entry point, firewall helper, env example, and setup doc. `JARVIS-PWA-ANDROID-FINAL.zip` unchanged this turn (no PWA asset changed; it already documented the `0.0.0.0` bind).

---

## What to do on your PC (one-time)

1. **Make sure no stale `JARVIS_HOST` is set globally.** In a Command Prompt run `set JARVIS_HOST`. If it prints anything, clear it: `set JARVIS_HOST=` (and remove any user/system env var of that name, or set it to `0.0.0.0`). This is the only thing that could still force localhost after this fix.
2. Run `start_jarvis.bat` (it now sets `JARVIS_HOST=0.0.0.0` and adds the firewall rule; run it **as Administrator** once so the rule sticks). Alternative: run `scripts\ALLOW_PWA_FIREWALL.bat` as Administrator.
3. Verify with: `netstat -ano | findstr :8420` → you want `TCP 0.0.0.0:8420 ... LISTENING`.
4. On the phone open `http://<current-PC-IP>:8420/pwa/` (find the IP with `ipconfig`).

Note: I can't run `netstat` on your physical PC from here, but the fix removes the overrides that caused your `127.0.0.1` binding, and I verified the equivalent LAN path (non-loopback IP) end-to-end from the repackaged ZIP.

## NOT VERIFIED (unchanged, not touched by this fix)

Live OmniRoute/Ollama content, and all Windows-only features (STT/TTS/hotkey/tray/Tauri/EXE), remain marked **NOT VERIFIED**. Android remains **PWA only — no APK**.
