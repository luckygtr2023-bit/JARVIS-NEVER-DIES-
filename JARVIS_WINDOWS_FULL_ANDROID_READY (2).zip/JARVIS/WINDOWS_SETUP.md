# J.A.R.V.I.S. — Windows setup

The exact steps, start to finish. Nothing here is optional guesswork.

**Made by Lucky Kumar.**

---

## What you need

| | Minimum | Notes |
|---|---|---|
| Windows | 10 (1803+) or 11 | 64-bit |
| Python | **3.11+** | tick **“Add python.exe to PATH”** during install |
| Node.js | 20+ | **only** if you want to rebuild the HUD; a prebuilt HUD ships in `backend\webui` |
| Disk | ~400 MB | mostly the Python virtual environment |

---

## 1. Extract

Unzip the project anywhere you like, for example:

```
C:\JARVIS\
```

Avoid a OneDrive-synced folder — file locking can interfere with the database.

## 2. Start

Double-click:

```
start_jarvis.bat
```

or run it from a Command Prompt in the project root. On the **first run** it:

1. creates a local virtual environment in `.venv\`
2. installs everything in `requirements.txt` (a few minutes, once)
3. checks that the HUD bundle is present
4. starts the backend on `http://localhost:8420/` and opens the HUD **once**

Later runs skip steps 1–3 and start in a couple of seconds.

If JARVIS is *already* running, the launcher detects it, opens the HUD in your
browser and exits instead of starting a second copy.

## 3. Create your account

The HUD opens on the sign-in panel. **The first account created becomes the
OWNER.** Everyone added later is a `LIMITED_USER` until the OWNER promotes them.

Passwords are stored only as `pbkdf2_sha256$210000$…` hashes — never in plain
text, never in the ZIP, never in a log.

## 3a. Manage your OmniRoute Combos

Sign in, then open the **COMBOS** tab in the HUD navigation bar. As the OWNER
you get the full registry:

| Action | Where |
|---|---|
| See every Combo and which one is live | COMBO REGISTRY · the `IN USE` and `DEFAULT` chips |
| Switch the Combo you are using | ACTIVE UPLINK · click a Combo chip |
| Add a Combo | ADD COMBO · display name + OmniRoute identifier |
| Rename / re-point a Combo | EDIT on the card |
| Take one out of service | DISABLE (it stops working for everyone, OWNER included) |
| Choose the fallback | MAKE DEFAULT |
| Remove one | DELETE — the backend writes the warning, you confirm it |
| Share with others | + GRANT → a role or a single user; click a granted chip to revoke |

`JARVIS-copy-2` … `JARVIS-copy-12` are seeded on first run as a starting point,
**not** a limit. `JARVIS-copy-13`, `JARVIS-copy-400`, `My Custom Combo` or any
future name works the moment you save it, with no code change. Whatever you
type is sent to OmniRoute byte-for-byte — JARVIS never prepends a provider name
or otherwise rewrites the identifier.

Non-OWNER accounts see only the Combos granted to them and get no management
controls; the backend re-checks the role on every request, so bypassing the UI
achieves nothing.

## 4. Stop

Press **Ctrl+C** in the JARVIS console window for a clean shutdown, or close the
window. If a backend is somehow left running in the background:

```
stop_jarvis.bat
```

---

## Everyday commands

| Task | Command |
|---|---|
| Start JARVIS | `start_jarvis.bat` |
| Stop a stray backend | `stop_jarvis.bat` |
| Run the test suite | `.venv\Scripts\python -m pytest` |
| Live end-to-end check | `.venv\Scripts\python scripts\verify_live.py` (needs a fresh DB — see below) |
| Rebuild the HUD after editing `frontend\` | `cd frontend && npm install && npm run build` |
| **Build `JARVIS.exe`** | `scripts\BUILD_EXE.bat` |
| Verify the built EXE | `scripts\verify_exe.bat` |

`verify_live.py` must be the OWNER to run every check: stop JARVIS, delete
`data\jarvis.db*`, start it again, then run the script.

---

## Building the Windows EXE

```cmd
scripts\BUILD_EXE.bat
```

It installs dependencies, builds the HUD, runs the tests, runs PyInstaller with
`scripts\jarvis.spec`, then **searches the tree for the real `JARVIS.exe`** and
prints its full path and size (rather than trusting a path it printed earlier).
Typical output location:

```
dist_win\JARVIS.exe
```

Then `scripts\verify_exe.bat` launches it, waits for `/api/health`, runs the
live checks against the running binary, and lists the four things only a human
can confirm: a single browser window on start, the spoken greeting, the global
`V` hotkey, and a clean exit.

### Optional: the Tauri desktop shell

`src-tauri\` is a Tauri 2 wrapper that gives JARVIS a real window, a tray icon,
and an OS-level `V` / `Escape` hotkey that works while the window is minimised.
It needs Rust + the MSVC build tools:

```cmd
rustup default stable
cd src-tauri
cargo tauri build
```

This is optional. The PyInstaller `JARVIS.exe` above works on its own.

---

## Configuration

Copy `.env.example` to `.env` only if you need to change defaults. Everything
has a working default and **no secret is required to run JARVIS**.

| Variable | Default | Meaning |
|---|---|---|
| `JARVIS_PORT` | `8420` | HTTP port |
| `JARVIS_HOST` | `127.0.0.1` (set by the launcher) | bind address; use `0.0.0.0` to accept your phone on the LAN |
| `JARVIS_HOME` | `.\data` | database and runtime files |
| `JARVIS_OPEN_BROWSER` | `1` from the launcher | open the HUD on start |
| `JARVIS_GLOBAL_HOTKEY` | `1` | OS-level `V` push-to-talk |
| `OMNIROUTE_BASE_URL` | `http://127.0.0.1:20128/v1` | your OmniRoute gateway |
| `OLLAMA_BASE_URL` | `http://127.0.0.1:11434` | local models |

Google OAuth (Gmail / Calendar) is the **only** place Google credentials are
used, and they are never required for JARVIS itself. Put them in `.env`, never
in source, and never in the EXE.

---

## Connecting your phone

1. Start JARVIS with `JARVIS_HOST=0.0.0.0` so the PC accepts LAN connections,
   and allow port 8420 through Windows Firewall (private networks only).
2. Find your PC's LAN address: `ipconfig` → IPv4, e.g. `192.168.1.50`.
3. In the Android app enter `http://192.168.1.50:8420` and tap **REQUEST PAIRING**.
4. The phone shows a code like `PAIR-7K4M-92PX`. Approve it in the HUD under
   **DEVICES → PAIRING REQUESTS** after checking the code matches.
5. The phone now has its own device token. The pairing code is dead — it was
   single-use and is not a password.

**Different networks:** put an HTTPS reverse proxy (Caddy, nginx, Cloudflare
Tunnel, Tailscale) in front of the backend and point the phone at that. The
control plane is one authenticated WebSocket, so any proxy that forwards
`/api/*` including WebSocket upgrades works. Do not expose port 8420 to the
internet without TLS in front of it.

The Android app itself is not built yet — the source is in `android-client\`
and `docs\ANDROID_BUILD.md` has the build commands.

---

## Troubleshooting

**“Python is not on PATH”** — reinstall Python with the PATH checkbox ticked, or
run the launcher from a shell where `python --version` works.

**Port 8420 already in use** — `stop_jarvis.bat`, or set another port:
`set JARVIS_PORT=8500 && start_jarvis.bat`.

**The HUD opens but says “Backend unreachable”** — the backend window has
probably exited; scroll up in it for the error.

**Voice does nothing** — `faster-whisper` and `pyttsx3` are optional. Install
them in the venv (`.venv\Scripts\pip install faster-whisper pyttsx3`); until
then JARVIS reports the missing engine rather than pretending to listen.

**AI says UNLINKED** — neither OmniRoute (`127.0.0.1:20128`) nor Ollama
(`127.0.0.1:11434`) is running. Start one; JARVIS in AUTO mode uses whichever
actually answers. Deterministic commands (“what’s my cpu”, “open youtube”) work
with no AI backend at all.

**Deleted `data\jarvis.db` and things look odd** — restart the backend. SQLite
holds the deleted file handle until the process ends.
