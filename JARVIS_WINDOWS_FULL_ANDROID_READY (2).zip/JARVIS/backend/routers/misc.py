"""/api/memory/*, /api/settings, /api/destinations, /api/integrations/*."""
from __future__ import annotations

import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .. import audit, config, db, memory_store
from ..deps import current_principal
from ..services.browser_tools import validate_url

router = APIRouter(prefix="/api", tags=["memory"])


# ------------------------------- memory ------------------------------------ #
class MemoryBody(BaseModel):
    key: str = Field(min_length=1, max_length=80)
    value: str = Field(min_length=1, max_length=4000)
    category: str = "fact"


@router.get("/memory")
def get_memory(principal: dict = Depends(current_principal)):
    return {"memories": memory_store.list_memories(principal["user_id"]),
            "categories": list(memory_store.CATEGORIES)}


@router.post("/memory")
def post_memory(body: MemoryBody, principal: dict = Depends(current_principal)):
    try:
        return memory_store.store_memory(principal["user_id"], body.key, body.value, body.category)
    except memory_store.MemoryGuardError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.delete("/memory/{mem_id}")
def delete_memory(mem_id: str, principal: dict = Depends(current_principal)):
    if not memory_store.delete_memory(principal["user_id"], mem_id):
        raise HTTPException(status_code=404, detail="No such memory.")
    return {"ok": True}


@router.delete("/memory")
def clear_memory(principal: dict = Depends(current_principal)):
    return {"ok": True, "removed": memory_store.clear_memories(principal["user_id"])}


# ----------------------------- destinations -------------------------------- #
class DestinationBody(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    url: str


@router.get("/destinations")
def get_destinations(principal: dict = Depends(current_principal)):
    rows = db.query("SELECT name, url FROM destinations ORDER BY name")
    return {"destinations": [dict(r) for r in rows]}


@router.post("/destinations")
def post_destination(body: DestinationBody, principal: dict = Depends(current_principal)):
    try:
        url = validate_url(body.url)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    db.execute("INSERT INTO destinations(name,url,user_id,created_at) VALUES (?,?,?,?)"
               " ON CONFLICT(name) DO UPDATE SET url=excluded.url",
               (body.name.strip().lower(), url, principal["user_id"], time.time()))
    audit.record("destination.save", "OK", user_id=principal["user_id"],
                 detail={"name": body.name, "url": url})
    return {"name": body.name.strip().lower(), "url": url}


@router.delete("/destinations/{name}")
def delete_destination(name: str, principal: dict = Depends(current_principal)):
    db.execute("DELETE FROM destinations WHERE name=?", (name.strip().lower(),))
    return {"ok": True}


# ------------------------------- settings ---------------------------------- #
@router.get("/settings")
def get_settings(principal: dict = Depends(current_principal)):
    from ..services.ai_client import AIConfig
    from ..services.voice_engine import hotkeys

    ai = AIConfig.load()
    return {
        "ai": {"mode": ai.mode, "combo": ai.combo, "ollama_model": ai.ollama_model,
               "temperature": ai.temperature, "max_tokens": ai.max_tokens},
        "voice": {**db.get_setting("voice", {"speak_replies": False, "mic_enabled": False}),
                  "hotkey": hotkeys.status()},
        "security": {
            "file_root": str(config.FILE_ROOT),
            "destructive_actions": "require AUTHORIZE",
            "shell_commands": "confirm + blocklist",
            "messages": "always confirmed",
        },
        "endpoints": {"omniroute": config.OMNIROUTE_BASE, "ollama": config.OLLAMA_NATIVE},
        "app": {"name": config.APP_NAME, "version": config.APP_VERSION},
    }


class SettingsBody(BaseModel):
    ai: dict | None = None
    voice: dict | None = None


@router.post("/settings")
def post_settings(body: SettingsBody, principal: dict = Depends(current_principal)):
    from ..services.ai_client import AIConfig

    if body.ai is not None:
        cfg = AIConfig.load()
        if "mode" in body.ai:
            mode = str(body.ai["mode"]).lower()
            if mode not in ("auto", "omniroute", "ollama"):
                raise HTTPException(status_code=400, detail="mode must be auto, omniroute or ollama.")
            cfg.mode = mode
        if "combo" in body.ai:
            requested = str(body.ai["combo"]).strip()      # EXACT, never rewritten
            # A non-OWNER may only point the setting at a Combo they are actually
            # allowed to use - this closes the "send a raw identifier" bypass.
            if requested and principal["role"] != "OWNER":
                from .. import combos as combo_store

                if not combo_store.may_use(principal["user_id"], principal["role"], requested):
                    audit.record("combo.use_denied", "DENIED", user_id=principal["user_id"],
                                 detail={"identifier": requested, "via": "settings"})
                    raise HTTPException(
                        status_code=403,
                        detail=f"You are not authorized to use the Combo '{requested}'. "
                               f"Ask the OWNER to assign it to you in COMBOS.")
                db.set_setting(f"ai_combo:{principal['user_id']}", requested)
            cfg.combo = requested
        if "ollama_model" in body.ai:
            cfg.ollama_model = str(body.ai["ollama_model"]).strip()
        if "temperature" in body.ai:
            cfg.temperature = max(0.0, min(2.0, float(body.ai["temperature"])))
        if "max_tokens" in body.ai:
            cfg.max_tokens = max(64, min(8192, int(body.ai["max_tokens"])))
        cfg.save()
        audit.record("settings.ai", "OK", user_id=principal["user_id"],
                     detail={"mode": cfg.mode, "combo": cfg.combo})
    if body.voice is not None:
        current = db.get_setting("voice", {}) or {}
        current.update({k: v for k, v in body.voice.items()
                        if k in ("speak_replies", "mic_enabled", "hotkey_enabled", "hotkey_key")})
        db.set_setting("voice", current)
    return get_settings(principal)


# ---------------------------- google integrations -------------------------- #
@router.get("/integrations/google/auth-url")
def google_auth_url(principal: dict = Depends(current_principal)):
    """Google OAuth is ONLY for Gmail/Calendar - never for JARVIS login (spec 19)."""
    if not config.GOOGLE_CLIENT_ID:
        raise HTTPException(
            status_code=503,
            detail="Gmail/Calendar are CREDENTIAL_BLOCKED: set GOOGLE_CLIENT_ID, "
                   "GOOGLE_CLIENT_SECRET and GOOGLE_REDIRECT_URI in backend/.env, then restart.")
    from urllib.parse import urlencode

    scopes = ("https://www.googleapis.com/auth/gmail.modify "
              "https://www.googleapis.com/auth/calendar")
    params = {"client_id": config.GOOGLE_CLIENT_ID, "redirect_uri": config.GOOGLE_REDIRECT_URI,
              "response_type": "code", "scope": scopes, "access_type": "offline",
              "prompt": "consent"}
    return {"url": "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params)}


@router.get("/integrations/status")
def integrations_status(principal: dict = Depends(current_principal)):
    linked = bool(db.get_setting("google_tokens"))
    blocked = not (config.GOOGLE_CLIENT_ID and config.GOOGLE_CLIENT_SECRET)
    state = "CREDENTIAL_BLOCKED" if blocked else ("LINKED" if linked else "NOT_LINKED")
    return {"gmail": {"status": state}, "calendar": {"status": state},
            "redirect_uri": config.GOOGLE_REDIRECT_URI}
