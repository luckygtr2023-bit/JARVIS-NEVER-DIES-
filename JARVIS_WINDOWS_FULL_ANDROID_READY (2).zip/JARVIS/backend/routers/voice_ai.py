"""/api/voice/* and /api/ai/* + /api/providers/* (kept for HUD compatibility)."""
from __future__ import annotations

import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel

from .. import audit, config, db
from ..deps import check_permission, current_principal
from ..services import ai_client, voice_engine

router = APIRouter(prefix="/api", tags=["voice", "ai"])


# --------------------------------- voice ----------------------------------- #
@router.get("/voice/state")
def voice_state(principal: dict = Depends(current_principal)):
    return {**voice_engine.get_state(), "stt": voice_engine.stt_status(),
            "tts": voice_engine.tts_status(), "states": list(voice_engine.STATES)}


class VoiceStateBody(BaseModel):
    state: str
    detail: str = ""


@router.post("/voice/state")
def set_voice_state(body: VoiceStateBody, principal: dict = Depends(current_principal)):
    try:
        return voice_engine.set_state(body.state.upper(), body.detail)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/voice/hotkey/state")
def hotkey_state(principal: dict = Depends(current_principal)):
    return voice_engine.hotkeys.status()


class HotkeyConfig(BaseModel):
    key: str | None = None
    enabled: bool | None = None


@router.post("/voice/hotkey/config")
def hotkey_config(body: HotkeyConfig, principal: dict = Depends(current_principal)):
    return voice_engine.hotkeys.configure(key=body.key, enabled=body.enabled)


@router.post("/voice/hotkey/toggle")
def hotkey_toggle(principal: dict = Depends(current_principal)):
    return voice_engine.hotkeys.toggle()


@router.post("/voice/hotkey/cancel")
def hotkey_cancel(principal: dict = Depends(current_principal)):
    return voice_engine.hotkeys.cancel()


@router.post("/voice/stt")
async def speech_to_text(audio: UploadFile = File(...),
                         principal: dict = Depends(current_principal)):
    check_permission(principal, "voice")
    status = voice_engine.stt_status()
    if not status.get("available"):
        raise HTTPException(status_code=501, detail=status.get("detail"))
    suffix = Path(audio.filename or "clip.webm").suffix or ".webm"
    tmp = Path(tempfile.gettempdir()) / f"jarvis_stt_{id(audio)}{suffix}"
    tmp.write_bytes(await audio.read())
    try:
        voice_engine.set_state(voice_engine.THINKING, "transcribing")
        result = voice_engine.transcribe(str(tmp))
    except Exception as exc:
        voice_engine.set_state(voice_engine.ERROR, str(exc))
        raise HTTPException(status_code=500, detail=f"Transcription failed: {exc}")
    finally:
        tmp.unlink(missing_ok=True)
        voice_engine.set_state(voice_engine.READY)
    audit.record("voice.stt", "OK", user_id=principal["user_id"],
                 detail={"chars": len(result.get("text", ""))})
    return result


class SpeakBody(BaseModel):
    text: str


@router.post("/voice/speak")
def speak(body: SpeakBody, principal: dict = Depends(current_principal)):
    return voice_engine.speak(body.text)


# ----------------------------------- AI ------------------------------------ #
@router.get("/ai/detect")
async def ai_detect(principal: dict = Depends(current_principal)):
    """Real probes - never claims a backend is up without touching it."""
    omni = await ai_client.probe_omniroute()
    olla = await ai_client.probe_ollama()
    return {"omniroute": omni, "ollama": olla, "config": vars(ai_client.AIConfig.load())}


@router.get("/ai/roles")
def ai_roles(principal: dict = Depends(current_principal)):
    cfg = ai_client.AIConfig.load()
    return {"roles": {"general": vars(cfg)},
            "modes": [ai_client.MODE_AUTO, ai_client.MODE_OMNIROUTE, ai_client.MODE_OLLAMA]}


class TestBody(BaseModel):
    prompt: str = "Reply with the single word: online"


@router.post("/ai/test")
async def ai_test(body: TestBody, principal: dict = Depends(current_principal)):
    try:
        result = await ai_client.chat([{"role": "user", "content": body.prompt}],
                                      cfg=ai_client.AIConfig.for_principal(principal), timeout=40)
        return {"ok": True, **result}
    except ai_client.AIError as exc:
        return {"ok": False, "error": exc.message, "provider": exc.provider}


@router.get("/providers/status")
async def providers_status(principal: dict = Depends(current_principal)):
    omni = await ai_client.probe_omniroute()
    olla = await ai_client.probe_ollama()
    cfg = ai_client.AIConfig.load()
    return {
        "providers": [
            {"id": "omniroute", "name": "OmniRoute", "endpoint": config.OMNIROUTE_BASE,
             "kind": "cloud router", "available": omni.get("available"),
             "detail": omni.get("error") or "reachable", "selected": cfg.mode in ("omniroute", "auto"),
             "combos": omni.get("combos", [])},
            {"id": "ollama", "name": "Ollama", "endpoint": config.OLLAMA_NATIVE,
             "kind": "local", "available": olla.get("available"),
             "detail": olla.get("error") or "reachable", "selected": cfg.mode in ("ollama", "auto"),
             "models": olla.get("models", [])},
        ],
        "mode": cfg.mode,
    }


@router.get("/providers/{provider_id}/models")
async def provider_models(provider_id: str, principal: dict = Depends(current_principal)):
    if provider_id == "ollama":
        info = await ai_client.probe_ollama()
        return {"models": info.get("models", []), "available": info.get("available"),
                "error": info.get("error")}
    if provider_id == "omniroute":
        info = await ai_client.probe_omniroute()
        return {"models": info.get("combos", []), "available": info.get("available"),
                "error": info.get("error"),
                "note": "Combo names are sent exactly as typed; this list is not a whitelist."}
    raise HTTPException(status_code=404, detail="Unknown provider.")
