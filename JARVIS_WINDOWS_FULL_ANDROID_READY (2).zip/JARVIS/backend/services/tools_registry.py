"""Deterministic tool layer (spec 11, 12, 18).

Every tool declares a risk level:
    SAFE    - runs immediately
    CONFIRM - the BACKEND refuses to run it until a confirmation token is presented

Tools that need a platform/library that is not present return a clear capability
error. They never pretend to have done the work.
"""
from __future__ import annotations

import asyncio
import os
import platform
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from .. import config

SAFE = "SAFE"
CONFIRM = "CONFIRM"


class ToolError(Exception):
    pass


class CapabilityError(ToolError):
    """The tool cannot run in this environment - reported honestly, never faked."""


@dataclass
class Tool:
    name: str
    category: str
    risk: str
    description: str
    handler: Callable[..., Any]
    params: dict = field(default_factory=dict)
    windows_only: bool = False

    def to_public(self) -> dict:
        return {"name": self.name, "category": self.category, "risk": self.risk,
                "description": self.description, "params": self.params,
                "available": self.available()[0], "unavailable_reason": self.available()[1]}

    def available(self) -> tuple[bool, Optional[str]]:
        if self.windows_only and not config.IS_WINDOWS:
            return False, f"Windows-only tool; this host is {platform.system()}."
        return True, None


REGISTRY: dict[str, Tool] = {}


def tool(name: str, category: str, risk: str, description: str, *,
         params: dict | None = None, windows_only: bool = False):
    def deco(fn):
        REGISTRY[name] = Tool(name=name, category=category, risk=risk, description=description,
                              handler=fn, params=params or {}, windows_only=windows_only)
        return fn
    return deco


async def run_tool(name: str, args: dict) -> Any:
    t = REGISTRY.get(name)
    if not t:
        raise ToolError(f"Unknown tool: {name}")
    ok, reason = t.available()
    if not ok:
        raise CapabilityError(reason or "Tool unavailable here.")
    result = t.handler(**(args or {}))
    if asyncio.iscoroutine(result):
        result = await result
    return result


# --------------------------------------------------------------------------- #
# system
# --------------------------------------------------------------------------- #
def _psutil():
    try:
        import psutil  # noqa
        return psutil
    except ImportError:
        raise CapabilityError("psutil is not installed; system metrics are unavailable.")


@tool("cpu_usage", "system", SAFE, "Get current CPU usage percentage (overall and per core).")
def cpu_usage():
    ps = _psutil()
    return {"overall": ps.cpu_percent(interval=0.2), "per_core": ps.cpu_percent(percpu=True),
            "cores": ps.cpu_count(logical=True)}


@tool("memory_usage", "system", SAFE, "Get RAM usage.")
def memory_usage():
    vm = _psutil().virtual_memory()
    return {"percent": vm.percent, "used_gb": round(vm.used / 1e9, 2),
            "total_gb": round(vm.total / 1e9, 2)}


@tool("disk_usage", "system", SAFE, "Get disk usage for the main drive.")
def disk_usage(path: str = "/"):
    if config.IS_WINDOWS and path == "/":
        path = "C:\\"
    du = _psutil().disk_usage(path)
    return {"path": path, "percent": du.percent, "used_gb": round(du.used / 1e9, 2),
            "total_gb": round(du.total / 1e9, 2), "free_gb": round(du.free / 1e9, 2)}


@tool("battery_status", "system", SAFE, "Get battery charge level and power status (if a battery exists).")
def battery_status():
    ps = _psutil()
    bat = getattr(ps, "sensors_battery", lambda: None)()
    if bat is None:
        return {"has_battery": False, "note": "No battery detected on this machine."}
    return {"has_battery": True, "percent": round(bat.percent), "plugged_in": bat.power_plugged,
            "seconds_left": None if bat.secsleft in (-1, -2) else bat.secsleft}


@tool("system_info", "system", SAFE, "Operating system, hostname, uptime and process count.")
def system_info():
    ps = _psutil()
    return {
        "os": platform.system(), "os_version": platform.version(), "release": platform.release(),
        "hostname": platform.node(), "python": sys.version.split()[0],
        "processes": len(ps.pids()),
        "uptime_minutes": round((time.time() - ps.boot_time()) / 60),
        "app_version": config.APP_VERSION,
    }


@tool("list_processes", "system", SAFE, "List the top processes by memory use.")
def list_processes(limit: int = 15):
    ps = _psutil()
    procs = []
    for p in ps.process_iter(["pid", "name", "memory_percent"]):
        try:
            procs.append({"pid": p.info["pid"], "name": p.info["name"],
                          "memory_percent": round(p.info["memory_percent"] or 0, 2)})
        except Exception:
            continue
    procs.sort(key=lambda x: x["memory_percent"], reverse=True)
    return procs[:limit]


# --------------------------------------------------------------------------- #
# files (rooted at the configured file access root)
# --------------------------------------------------------------------------- #
def _safe_path(path: str) -> Path:
    root = Path(config.FILE_ROOT).resolve()
    p = (root / path).resolve() if not os.path.isabs(path) else Path(path).resolve()
    if root not in p.parents and p != root:
        raise ToolError(f"Path is outside the permitted file root ({root}).")
    return p


@tool("list_directory", "files", SAFE, "List files and folders in a directory.")
def list_directory(path: str = "."):
    p = _safe_path(path)
    if not p.is_dir():
        raise ToolError(f"Not a directory: {p}")
    items = []
    for child in sorted(p.iterdir())[:300]:
        try:
            items.append({"name": child.name, "is_dir": child.is_dir(),
                          "size": child.stat().st_size if child.is_file() else None})
        except Exception:
            continue
    return {"path": str(p), "items": items}


@tool("read_file", "files", SAFE, "Read a UTF-8 text file.")
def read_file_tool(path: str, max_chars: int = 20000):
    p = _safe_path(path)
    if not p.is_file():
        raise ToolError(f"Not a file: {p}")
    return {"path": str(p), "content": p.read_text(encoding="utf-8", errors="replace")[:max_chars]}


@tool("create_file", "files", SAFE, "Create a new text file with given content.")
def create_file(path: str, content: str = ""):
    p = _safe_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return {"path": str(p), "bytes": p.stat().st_size, "verified": p.exists()}


@tool("copy_file", "files", SAFE, "Copy a file or folder to a new location.")
def copy_file(source: str, destination: str):
    s, d = _safe_path(source), _safe_path(destination)
    if s.is_dir():
        shutil.copytree(s, d, dirs_exist_ok=True)
    else:
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, d)
    return {"source": str(s), "destination": str(d), "verified": d.exists()}


@tool("delete_file", "files", CONFIRM, "Permanently delete a file or folder. Requires user authorization.")
def delete_file(path: str):
    p = _safe_path(path)
    if not p.exists():
        raise ToolError(f"Nothing to delete at {p}")
    if p.is_dir():
        shutil.rmtree(p)
    else:
        p.unlink()
    return {"deleted": str(p), "verified": not p.exists()}


# --------------------------------------------------------------------------- #
# clipboard / applications / windows automation
# --------------------------------------------------------------------------- #
@tool("clipboard_read", "system", SAFE, "Read the current clipboard text.")
def clipboard_read():
    try:
        import pyperclip
    except ImportError:
        raise CapabilityError("pyperclip is not installed.")
    try:
        return {"text": pyperclip.paste()}
    except Exception as exc:
        raise CapabilityError(f"Clipboard unavailable: {exc}")


@tool("clipboard_write", "system", SAFE, "Put text on the clipboard.")
def clipboard_write(text: str):
    try:
        import pyperclip
    except ImportError:
        raise CapabilityError("pyperclip is not installed.")
    pyperclip.copy(text)
    return {"ok": True, "chars": len(text)}


@tool("open_application", "applications", SAFE, "Launch an application by name.", windows_only=True)
def open_application(name: str):
    exe = name.strip()
    try:
        subprocess.Popen(["cmd", "/c", "start", "", exe], shell=False)
    except Exception as exc:
        raise ToolError(f"Could not launch {exe}: {exc}")
    time.sleep(1.0)
    ps = _psutil()
    running = [p.info["name"] for p in ps.process_iter(["name"])
               if p.info["name"] and exe.lower().split(".")[0] in p.info["name"].lower()]
    return {"launched": exe, "verified": bool(running), "matching_processes": running[:5]}


@tool("close_application", "applications", CONFIRM,
      "Close a running application/process by name. May lose unsaved work in that app.",
      windows_only=True)
def close_application(name: str):
    ps = _psutil()
    killed = []
    for p in ps.process_iter(["pid", "name"]):
        if p.info["name"] and name.lower() in p.info["name"].lower():
            try:
                p.terminate()
                killed.append(p.info["name"])
            except Exception:
                continue
    time.sleep(0.6)
    still = [p.info["name"] for p in ps.process_iter(["name"])
             if p.info["name"] and name.lower() in p.info["name"].lower()]
    return {"terminated": killed, "verified": not still, "still_running": still}


@tool("take_screenshot", "screen", SAFE, "Capture the screen to a PNG file.")
def take_screenshot(path: str = ""):
    try:
        import mss
    except ImportError:
        raise CapabilityError("mss is not installed; screen capture unavailable.")
    if not os.environ.get("DISPLAY") and not config.IS_WINDOWS:
        raise CapabilityError("No display available on this host; screen capture unavailable.")
    out = Path(path) if path else (config.DATA_DIR / f"screenshot_{int(time.time())}.png")
    with mss.mss() as sct:
        sct.shot(mon=-1, output=str(out))
    return {"path": str(out), "verified": out.exists(), "bytes": out.stat().st_size if out.exists() else 0}


@tool("click_mouse", "mouse", SAFE, "Click the mouse (optionally at coordinates).", windows_only=True)
def click_mouse(x: int | None = None, y: int | None = None):
    try:
        import pyautogui
    except ImportError:
        raise CapabilityError("pyautogui is not installed.")
    if x is not None and y is not None:
        pyautogui.click(x, y)
    else:
        pyautogui.click()
    return {"clicked_at": pyautogui.position()[:], "verified": True}


@tool("type_text", "keyboard", SAFE, "Type text with the keyboard.", windows_only=True)
def type_text(text: str):
    try:
        import pyautogui
    except ImportError:
        raise CapabilityError("pyautogui is not installed.")
    pyautogui.typewrite(text)
    return {"typed_chars": len(text)}


@tool("shutdown_pc", "system", CONFIRM, "Shut down this computer. Requires user authorization.",
      windows_only=True)
def shutdown_pc(delay_seconds: int = 20):
    subprocess.Popen(["shutdown", "/s", "/t", str(max(5, delay_seconds))])
    return {"scheduled_in_seconds": max(5, delay_seconds),
            "cancel_hint": "Run `shutdown /a` to abort."}


@tool("run_powershell", "shell", CONFIRM, "Run a PowerShell command. Requires user authorization.",
      windows_only=True)
def run_powershell(command: str, timeout: int = 30):
    blocked = ("format ", "remove-item -recurse -force c:\\", "diskpart", "vssadmin delete")
    if any(b in command.lower() for b in blocked):
        raise ToolError("This command is on the safety blocklist and will not be run.")
    proc = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
                          capture_output=True, text=True, timeout=timeout)
    return {"exit_code": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-2000:]}


def registry_public() -> list[dict]:
    return [t.to_public() for t in sorted(REGISTRY.values(), key=lambda x: x.name)]


def requires_confirmation(name: str) -> bool:
    t = REGISTRY.get(name)
    return bool(t and t.risk == CONFIRM)
