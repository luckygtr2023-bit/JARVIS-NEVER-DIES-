"""AI transport for OmniRoute (cloud router) and Ollama (local), spec 8.

Hard requirements implemented here:
  * the configured OmniRoute Combo name is sent EXACTLY as typed - never prefixed,
    never rewritten, never validated against a whitelist
  * Ollama models are discovered dynamically from /api/tags
  * NO response is assumed to be JSON. Text, HTML, empty bodies, malformed JSON,
    timeouts and connection errors all become clean, human-readable messages,
    so "Expecting value: line 1 column 1" can never reach the user
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import AsyncIterator, Optional

import httpx

from .. import config, db

MODE_OMNIROUTE = "omniroute"
MODE_OLLAMA = "ollama"
MODE_AUTO = "auto"


class AIError(Exception):
    """A user-presentable AI failure. Always carries a readable message."""

    def __init__(self, message: str, *, provider: str = "", status: int | None = None):
        super().__init__(message)
        self.message = message
        self.provider = provider
        self.status = status


@dataclass
class AIConfig:
    mode: str = MODE_AUTO
    combo: str = ""              # OmniRoute Combo name, sent verbatim
    ollama_model: str = ""       # discovered dynamically
    temperature: float = 0.4
    max_tokens: int = 1024

    @classmethod
    def load(cls) -> "AIConfig":
        raw = db.get_setting("ai", {}) or {}
        return cls(
            mode=raw.get("mode", MODE_AUTO),
            combo=raw.get("combo", ""),
            ollama_model=raw.get("ollama_model", ""),
            temperature=float(raw.get("temperature", 0.4)),
            max_tokens=int(raw.get("max_tokens", 1024)),
        )

    @classmethod
    def for_principal(cls, principal: dict | None) -> "AIConfig":
        """Config with the Combo this principal is actually allowed to use.

        Resolved server side from Combo Management, so a client cannot smuggle an
        unauthorized identifier in by any route (spec 7).
        """
        cfg = cls.load()
        if not principal:
            return cfg
        from .. import combos as combo_store

        identifier = combo_store.selected_for(principal["user_id"], principal.get("role", ""))
        if identifier:
            combo_store.assert_may_use(principal["user_id"], principal.get("role", ""), identifier)
            cfg.combo = identifier
        else:
            cfg.combo = ""
        return cfg

    def save(self) -> None:
        db.set_setting("ai", {
            "mode": self.mode, "combo": self.combo, "ollama_model": self.ollama_model,
            "temperature": self.temperature, "max_tokens": self.max_tokens,
        })


# --------------------------------------------------------------------------- #
# defensive response handling
# --------------------------------------------------------------------------- #
def describe_http_failure(resp: httpx.Response, provider: str) -> str:
    """Turn ANY error body (json / text / html / empty) into one clear sentence."""
    body = (resp.text or "").strip()
    detail = ""
    if body:
        ctype = resp.headers.get("content-type", "")
        if "json" in ctype or body[:1] in "{[":
            try:
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    err = parsed.get("error", parsed)
                    if isinstance(err, dict):
                        detail = str(err.get("message") or err.get("detail") or err)
                    else:
                        detail = str(err)
                else:
                    detail = str(parsed)
            except json.JSONDecodeError:
                detail = body[:300]
        elif "html" in ctype or body[:1] == "<":
            detail = "the endpoint returned an HTML page instead of an API response"
        else:
            detail = body[:300]
    else:
        detail = "empty response body"
    hint = ""
    if resp.status_code in (401, 403):
        hint = " Check the API key / Combo configuration."
    elif resp.status_code == 404:
        hint = " Check that the model or Combo name exists."
    elif resp.status_code == 429:
        hint = " The provider is rate-limiting or out of quota."
    return f"{provider} returned HTTP {resp.status_code}: {detail}.{hint}"


def parse_chat_payload(resp: httpx.Response, provider: str) -> str:
    """Extract assistant text from an OpenAI-compatible reply, defensively."""
    body = (resp.text or "").strip()
    if not body:
        raise AIError(f"{provider} returned an empty response body.", provider=provider)
    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        snippet = body[:200].replace("\n", " ")
        raise AIError(
            f"{provider} sent a non-JSON response ({snippet!r}). "
            f"The endpoint may be wrong or a proxy/login page is in the way.",
            provider=provider,
        )
    if not isinstance(data, dict):
        raise AIError(f"{provider} sent an unexpected response shape.", provider=provider)
    if "error" in data and data.get("error"):
        err = data["error"]
        msg = err.get("message") if isinstance(err, dict) else str(err)
        raise AIError(f"{provider} error: {msg}", provider=provider)
    choices = data.get("choices") or []
    if choices:
        msg = choices[0].get("message") or {}
        content = msg.get("content")
        if isinstance(content, list):  # some providers return content parts
            content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
        if content:
            return content
    # Ollama native shape
    if isinstance(data.get("message"), dict) and data["message"].get("content"):
        return data["message"]["content"]
    if data.get("response"):
        return str(data["response"])
    raise AIError(f"{provider} returned no assistant content.", provider=provider)


# --------------------------------------------------------------------------- #
# probes
# --------------------------------------------------------------------------- #
async def probe_omniroute(timeout: float = 3.0) -> dict:
    url = config.OMNIROUTE_BASE.rstrip("/") + "/models"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url)
        if resp.status_code >= 400:
            return {"available": False, "endpoint": config.OMNIROUTE_BASE,
                    "error": describe_http_failure(resp, "OmniRoute")}
        combos = []
        try:
            data = resp.json()
            combos = [m.get("id") for m in data.get("data", []) if isinstance(m, dict) and m.get("id")]
        except Exception:
            pass
        return {"available": True, "endpoint": config.OMNIROUTE_BASE, "combos": combos}
    except httpx.ConnectError:
        return {"available": False, "endpoint": config.OMNIROUTE_BASE,
                "error": "OmniRoute is not reachable at 127.0.0.1:20128 - is the gateway running?"}
    except Exception as exc:
        return {"available": False, "endpoint": config.OMNIROUTE_BASE, "error": str(exc)}


async def probe_ollama(timeout: float = 3.0) -> dict:
    url = config.OLLAMA_NATIVE.rstrip("/") + "/api/tags"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(url)
        if resp.status_code >= 400:
            return {"available": False, "endpoint": config.OLLAMA_NATIVE,
                    "error": describe_http_failure(resp, "Ollama")}
        models: list[str] = []
        try:
            models = [m["name"] for m in resp.json().get("models", []) if m.get("name")]
        except Exception:
            models = []
        return {"available": True, "endpoint": config.OLLAMA_NATIVE, "models": models}
    except httpx.ConnectError:
        return {"available": False, "endpoint": config.OLLAMA_NATIVE,
                "error": "Ollama is not reachable at 127.0.0.1:11434 - is `ollama serve` running?"}
    except Exception as exc:
        return {"available": False, "endpoint": config.OLLAMA_NATIVE, "error": str(exc)}


async def resolve_mode(cfg: AIConfig) -> tuple[str, str]:
    """AUTO picks the best AI that is actually up. Returns (mode, reason)."""
    if cfg.mode == MODE_OMNIROUTE:
        return MODE_OMNIROUTE, "configured"
    if cfg.mode == MODE_OLLAMA:
        return MODE_OLLAMA, "configured"
    omni = await probe_omniroute(timeout=1.5)
    if omni.get("available") and cfg.combo:
        return MODE_OMNIROUTE, "auto: OmniRoute online"
    olla = await probe_ollama(timeout=1.5)
    if olla.get("available"):
        return MODE_OLLAMA, "auto: Ollama online"
    if omni.get("available"):
        return MODE_OMNIROUTE, "auto: OmniRoute online (no Combo set)"
    raise AIError(
        "No AI backend is reachable. Start OmniRoute (127.0.0.1:20128) or Ollama "
        "(127.0.0.1:11434), then try again."
    )


async def pick_ollama_model(cfg: AIConfig) -> str:
    if cfg.ollama_model:
        return cfg.ollama_model
    info = await probe_ollama()
    models = info.get("models") or []
    if not models:
        raise AIError("Ollama has no models installed. Run e.g. `ollama pull qwen3:8b`.",
                      provider="Ollama")
    for preferred in ("qwen3:8b", "qwen3", "llama3.1", "llama3"):
        for m in models:
            if m.startswith(preferred):
                return m
    return models[0]


# --------------------------------------------------------------------------- #
# chat
# --------------------------------------------------------------------------- #
async def chat(messages: list[dict], *, cfg: Optional[AIConfig] = None,
               timeout: float = 90.0) -> dict:
    cfg = cfg or AIConfig.load()
    mode, reason = await resolve_mode(cfg)

    if mode == MODE_OMNIROUTE:
        if not cfg.combo:
            raise AIError("No OmniRoute Combo is configured. Set it in SETTINGS -> AI.",
                          provider="OmniRoute")
        base, model, provider = config.OMNIROUTE_BASE, cfg.combo, "OmniRoute"
    else:
        base, model, provider = config.OLLAMA_BASE, await pick_ollama_model(cfg), "Ollama"

    payload = {
        "model": model,                       # EXACT combo / model id, never modified
        "messages": messages,
        "temperature": cfg.temperature,
        "max_tokens": cfg.max_tokens,
        "stream": False,
    }
    url = base.rstrip("/") + "/chat/completions"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(url, json=payload)
    except httpx.ConnectError:
        raise AIError(f"{provider} is not reachable at {base}.", provider=provider)
    except httpx.ReadTimeout:
        raise AIError(f"{provider} timed out after {int(timeout)}s.", provider=provider)
    except Exception as exc:
        raise AIError(f"{provider} request failed: {exc}", provider=provider)

    if resp.status_code >= 400:
        raise AIError(describe_http_failure(resp, provider), provider=provider,
                      status=resp.status_code)
    content = parse_chat_payload(resp, provider)
    return {"content": content, "provider": provider, "model": model, "mode": mode, "reason": reason}


async def chat_stream(messages: list[dict], *, cfg: Optional[AIConfig] = None,
                      timeout: float = 120.0) -> AsyncIterator[str]:
    """Yield assistant text deltas. Falls back to a single chunk if the provider
    cannot stream - the caller never has to care."""
    cfg = cfg or AIConfig.load()
    mode, _ = await resolve_mode(cfg)
    if mode == MODE_OMNIROUTE:
        if not cfg.combo:
            raise AIError("No OmniRoute Combo is configured. Set it in SETTINGS -> AI.",
                          provider="OmniRoute")
        base, model, provider = config.OMNIROUTE_BASE, cfg.combo, "OmniRoute"
    else:
        base, model, provider = config.OLLAMA_BASE, await pick_ollama_model(cfg), "Ollama"

    payload = {"model": model, "messages": messages, "temperature": cfg.temperature,
               "max_tokens": cfg.max_tokens, "stream": True}
    url = base.rstrip("/") + "/chat/completions"
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            async with client.stream("POST", url, json=payload) as resp:
                if resp.status_code >= 400:
                    await resp.aread()
                    raise AIError(describe_http_failure(resp, provider), provider=provider,
                                  status=resp.status_code)
                got_any = False
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue          # never explode on a malformed SSE frame
                    for choice in chunk.get("choices", []):
                        delta = (choice.get("delta") or {}).get("content")
                        if delta:
                            got_any = True
                            yield delta
                if not got_any:
                    result = await chat(messages, cfg=cfg, timeout=timeout)
                    yield result["content"]
    except AIError:
        raise
    except httpx.ConnectError:
        raise AIError(f"{provider} is not reachable at {base}.", provider=provider)
    except httpx.ReadTimeout:
        raise AIError(f"{provider} timed out after {int(timeout)}s.", provider=provider)
