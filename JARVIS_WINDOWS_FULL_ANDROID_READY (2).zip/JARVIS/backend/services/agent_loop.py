"""The JARVIS agent loop (spec 9, 10, 18).

UNDERSTAND -> PLAN -> TOOL -> READ RESULT -> CONTINUE -> VERIFY -> RESPOND

Bounded by max steps, per-step timeout, retry limit, failure-streak detection and
cancellation. Deterministic intents are handled without spending AI quota; the AI
is used for language understanding, planning and conversation.
"""
from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Optional

from .. import audit, capabilities, config, db
from ..device_bus import bus, create_task, append_step, update_task
from . import browser_tools, tools_registry  # noqa: F401  (registers tools)
from .ai_client import AIConfig, AIError, chat
from .tools_registry import CapabilityError, ToolError, requires_confirmation, run_tool

MAX_STEPS = 8
STEP_TIMEOUT = 60.0
MAX_FAILURE_STREAK = 3

ORDINALS = {"first": 1, "1st": 1, "one": 1, "second": 2, "2nd": 2, "two": 2, "third": 3, "3rd": 3,
            "three": 3, "fourth": 4, "4th": 4, "fifth": 5, "5th": 5, "last": -1}

SYSTEM_PROMPT = (
    "You are JARVIS, a concise, precise desktop assistant. You address the user as Sir when it "
    "feels natural, never fawning. You never claim an action succeeded unless a tool result "
    "confirms it. If a capability is unavailable you say so plainly. Keep answers short."
)


# --------------------------------------------------------------------------- #
# pending confirmations (backend-enforced - spec 18)
# --------------------------------------------------------------------------- #
@dataclass
class PendingConfirmation:
    confirm_id: str
    user_id: str
    tool: str
    args: dict
    description: str
    task_id: str
    created_at: float = field(default_factory=time.time)


PENDING: dict[str, PendingConfirmation] = {}
CONFIRMATION_TTL = 300


def _prune_pending() -> None:
    now = time.time()
    for cid in [c for c, p in PENDING.items() if now - p.created_at > CONFIRMATION_TTL]:
        PENDING.pop(cid, None)


def create_confirmation(user_id: str, tool: str, args: dict, description: str,
                        task_id: str) -> PendingConfirmation:
    _prune_pending()
    pc = PendingConfirmation(f"cnf_{uuid.uuid4().hex[:12]}", user_id, tool, args, description, task_id)
    PENDING[pc.confirm_id] = pc
    update_task(task_id, status="WAITING_CONFIRMATION")
    audit.record("tool.confirmation_required", "WAITING", user_id=user_id, task_id=task_id,
                 detail={"tool": tool, "args": args})
    return pc


async def resolve_confirmation(confirm_id: str, approve: bool, user_id: str) -> dict:
    _prune_pending()
    pc = PENDING.pop(confirm_id, None)
    if pc is None:
        raise ToolError("That confirmation has expired or was already answered.")
    if pc.user_id != user_id:
        raise PermissionError("This confirmation belongs to another user.")
    if not approve:
        update_task(pc.task_id, status="CANCELLED", error="Cancelled by user.")
        audit.record("tool.cancelled", "CANCELLED", user_id=user_id, task_id=pc.task_id,
                     detail={"tool": pc.tool})
        db.log_activity("tool", f"Cancelled: {pc.tool}")
        return {"status": "CANCELLED", "tool": pc.tool,
                "message": f"Cancelled. {pc.tool} was not executed."}

    update_task(pc.task_id, status="RUNNING")
    try:
        result = await asyncio.wait_for(run_tool(pc.tool, pc.args), timeout=STEP_TIMEOUT)
    except Exception as exc:
        update_task(pc.task_id, status="FAILED", error=str(exc))
        audit.record("tool.execute", "FAILED", user_id=user_id, task_id=pc.task_id,
                     detail={"tool": pc.tool, "error": str(exc)})
        return {"status": "FAILED", "tool": pc.tool, "error": str(exc)}

    verified = _verified(result)
    update_task(pc.task_id, status="COMPLETED", result=json.dumps(result, default=str),
                verification="VERIFIED" if verified else "NOT_VERIFIED")
    audit.record("tool.execute", "OK", user_id=user_id, task_id=pc.task_id,
                 verification="VERIFIED" if verified else "NOT_VERIFIED",
                 detail={"tool": pc.tool})
    db.log_activity("tool", f"Executed: {pc.tool}")
    return {"status": "COMPLETED", "tool": pc.tool, "result": result, "verified": verified}


def _verified(result: Any) -> bool:
    if isinstance(result, dict) and "verified" in result:
        return bool(result["verified"])
    return result is not None


# --------------------------------------------------------------------------- #
# deterministic intent parsing (spec 8: do not waste AI on simple commands)
# --------------------------------------------------------------------------- #
def parse_intent(text: str) -> Optional[dict]:
    t = (text or "").strip()
    low = t.lower().rstrip(".!?")

    m = re.match(r"^(?:open|launch|go to|show me)\s+(?:the\s+)?(\w+)\s+(?:one|result|link)$", low)
    if m and m.group(1) in ORDINALS:
        return {"tool": "browser_open_result", "args": {"index": ORDINALS[m.group(1)]}}
    m = re.match(r"^(?:open|play)\s+(?:result\s+)?#?(\d+)$", low)
    if m:
        return {"tool": "browser_open_result", "args": {"index": int(m.group(1))}}

    m = re.match(r"^search\s+(?:for\s+)?(.+?)\s+on\s+(youtube|google|duckduckgo)$", low)
    if m:
        return {"tool": "browser_search", "args": {"query": m.group(1), "site": m.group(2)}}
    m = re.match(r"^(?:search|google)\s+(?:for\s+)?(.+)$", low)
    if m:
        return {"tool": "browser_search", "args": {"query": m.group(1), "site": "google"}}
    m = re.match(r"^(?:youtube|play)\s+(.+)$", low)
    if m:
        return {"tool": "browser_search", "args": {"query": m.group(1), "site": "youtube"}}

    m = re.match(r"^open\s+(?:my\s+)?(.+)$", low)
    if m:
        target = m.group(1).strip()
        if browser_tools.resolve_destination(target):
            return {"tool": "browser_open", "args": {"target": target}}
        if re.match(r"^[\w.-]+\.[a-z]{2,}(/\S*)?$", target):
            return {"tool": "browser_open", "args": {"target": target}}
        if config.IS_WINDOWS:
            return {"tool": "open_application", "args": {"name": target}}
        return {"tool": "browser_open", "args": {"target": target}}

    if re.match(r"^(?:what'?s\s+my\s+|show\s+|check\s+)?(?:cpu|processor)\b", low):
        return {"tool": "cpu_usage", "args": {}}
    if re.search(r"\b(ram|memory)\s*(usage|status)?\b", low) and "remember" not in low:
        return {"tool": "memory_usage", "args": {}}
    if re.search(r"\b(disk|storage|drive)\s*(usage|space|status)?\b", low):
        return {"tool": "disk_usage", "args": {}}
    if re.search(r"\bbattery\b", low):
        return {"tool": "battery_status", "args": {}}
    if re.search(r"\b(system|pc)\s+(info|status|information)\b", low):
        return {"tool": "system_info", "args": {}}
    if re.search(r"^take (a )?screenshot", low):
        return {"tool": "take_screenshot", "args": {}}

    m = re.match(r"^remember (?:that )?(.+?)\s+(?:is|are|=)\s+(.+)$", low)
    if m:
        return {"tool": "__memory_store", "args": {"key": m.group(1).strip().replace(" ", "_"),
                                                   "value": m.group(2).strip()}}
    m = re.match(r"^delete (?:the )?file\s+(.+)$", low)
    if m:
        return {"tool": "delete_file", "args": {"path": m.group(1).strip()}}
    return None


TARGET_RE = re.compile(r"\bon\s+(?:my\s+)?(pc|computer|desktop|laptop|phone|mobile|android|"
                       r"windows(?:\s+pc)?)\b", re.I)


def parse_target_device(text: str, user_id: str) -> Optional[dict]:
    """'... on my PC' / '... on my phone' -> the matching registered device."""
    m = TARGET_RE.search(text or "")
    if not m:
        return None
    word = m.group(1).lower()
    wanted = "android" if word in ("phone", "mobile", "android") else "windows"
    rows = db.query("SELECT * FROM devices WHERE user_id=? AND state='ACTIVE'", (user_id,))
    for r in rows:
        if r["device_type"].lower().startswith(wanted[:3]) or wanted in (r["device_type"] or "").lower():
            return dict(r)
    if wanted == "windows":
        for r in rows:
            if r["is_host"]:
                return dict(r)
    return None


# --------------------------------------------------------------------------- #
# the loop
# --------------------------------------------------------------------------- #
async def handle_command(text: str, principal: dict, *, source_device_id: str | None = None,
                         request_id: str | None = None) -> dict:
    """Run one user command end to end. Returns a structured, honest result."""
    user_id = principal["user_id"]
    task = create_task(user_id, "command", {"text": text}, source_device_id=source_device_id,
                       request_id=request_id, status="RUNNING")
    task_id = task["task_id"]
    steps: list[dict] = []

    def finish(status: str, **payload) -> dict:
        update_task(task_id, status=status, **{k: v for k, v in payload.items()
                                               if k in ("result", "error", "verification")})
        return {"task_id": task_id, "status": status, "steps": steps, **payload}

    # ---- cross-device routing -------------------------------------------- #
    target = parse_target_device(text, user_id)
    if target and not target["is_host"]:
        append_step(task_id, {"phase": "ROUTE", "target": target["device_id"]})
        update_task(task_id, target_device_id=target["device_id"])

        # --- security pipeline, in order (spec 9) -------------------------- #
        # AUTHENTICATE + IDENTIFY USER happened in the dependency that produced
        # `principal`; IDENTIFY TARGET DEVICE happened above. Now: state, device
        # permission, capability. Each failure is reported honestly and the task
        # is never marked as executed.
        if target.get("state") != "ACTIVE":
            audit.record("task.route", "DENIED", user_id=user_id,
                         target_device=target["device_id"], task_id=task_id,
                         detail={"reason": "device is not active"})
            return finish("FAILED", error=f"{target['name']} has been revoked.",
                          message=f"{target['name']} is revoked, Sir. I will not send it anything.")

        from ..deps import device_permissions
        if "chat" not in device_permissions(target["device_id"]):
            audit.record("task.route", "DENIED", user_id=user_id,
                         target_device=target["device_id"], task_id=task_id,
                         detail={"reason": "missing 'chat' permission"})
            return finish("FAILED", error="target device lacks the 'chat' permission",
                          message=f"{target['name']} is not permitted to accept commands. "
                                  f"The owner can grant that on the Devices screen.")

        needed = capabilities.capability_for_text(text)
        try:
            capabilities.assert_capable(target["device_id"], needed, target["name"])
        except capabilities.CapabilityMismatch as exc:
            audit.record("task.route", "DENIED", user_id=user_id,
                         target_device=target["device_id"], task_id=task_id,
                         detail={"reason": "capability", "capability": exc.capability})
            append_step(task_id, {"phase": "CAPABILITY", "missing": exc.capability})
            return finish("FAILED", error=str(exc), message=str(exc),
                          missing_capability=exc.capability)

        if not bus.is_online(target["device_id"]):
            audit.record("task.route", "OFFLINE", user_id=user_id, target_device=target["device_id"],
                         task_id=task_id)
            return finish("FAILED", error=f"{target['name']} is offline.",
                          message=f"{target['name']} is offline, Sir. I could not run that there.",
                          offline=True)
        routed = await bus.dispatch(task_id, target["device_id"], {"text": text}, timeout=45)
        if not routed.get("ok"):
            return finish("FAILED", error=routed.get("error"),
                          message=routed.get("error", "The target device did not complete the task."))
        return finish("COMPLETED", result=json.dumps(routed.get("result"), default=str),
                      verification="VERIFIED" if routed.get("verified") else "NOT_VERIFIED",
                      message=f"Done on {target['name']}.", result_data=routed.get("result"),
                      verified=bool(routed.get("verified")))

    # ---- deterministic intent --------------------------------------------- #
    intent = parse_intent(text)
    if intent:
        name, args = intent["tool"], intent["args"]

        if name == "__memory_store":
            from ..memory_store import store_memory
            try:
                mem = store_memory(user_id, args["key"], args["value"])
            except ValueError as exc:
                return finish("FAILED", error=str(exc), message=str(exc))
            steps.append({"phase": "TOOL", "tool": "memory_store", "ok": True})
            return finish("COMPLETED", message=f"Remembered: {mem['key']} = {mem['value']}",
                          verification="VERIFIED", verified=True, result_data=mem)

        if requires_confirmation(name):
            pc = create_confirmation(user_id, name, args,
                                     f"{name} {json.dumps(args)[:160]}", task_id)
            return {"task_id": task_id, "status": "WAITING_CONFIRMATION", "steps": steps,
                    "confirm_id": pc.confirm_id, "tool": name, "args": args,
                    "message": f"That is a consequential action. Authorize {name}?"}

        append_step(task_id, {"phase": "TOOL", "tool": name, "args": args})
        try:
            result = await asyncio.wait_for(run_tool(name, args), timeout=STEP_TIMEOUT)
        except CapabilityError as exc:
            audit.record("tool.execute", "BLOCKED", user_id=user_id, task_id=task_id,
                         detail={"tool": name, "reason": str(exc)})
            return finish("FAILED", error=str(exc), blocked=True,
                          message=f"I cannot do that here: {exc}")
        except asyncio.TimeoutError:
            return finish("FAILED", error="timeout", message=f"{name} timed out.")
        except (ToolError, Exception) as exc:
            audit.record("tool.execute", "FAILED", user_id=user_id, task_id=task_id,
                         detail={"tool": name, "error": str(exc)})
            return finish("FAILED", error=str(exc), message=f"{name} failed: {exc}")

        verified = _verified(result)
        steps.append({"phase": "TOOL", "tool": name, "ok": True, "verified": verified})
        audit.record("tool.execute", "OK", user_id=user_id, task_id=task_id,
                     verification="VERIFIED" if verified else "NOT_VERIFIED", detail={"tool": name})
        db.log_activity("tool", f"{name} executed", json.dumps(result, default=str)[:300])
        return finish("COMPLETED", result=json.dumps(result, default=str),
                      verification="VERIFIED" if verified else "NOT_VERIFIED",
                      message=summarize_tool_result(name, result), result_data=result,
                      verified=verified)

    # ---- conversational / AI path ----------------------------------------- #
    try:
        history = build_context(user_id, text)
        answer = await chat(history, cfg=AIConfig.for_principal(principal))
    except AIError as exc:
        audit.record("ai.chat", "FAILED", user_id=user_id, task_id=task_id,
                     detail={"error": exc.message})
        return finish("FAILED", error=exc.message, message=exc.message, ai_unavailable=True)
    steps.append({"phase": "RESPOND", "provider": answer["provider"]})
    audit.record("ai.chat", "OK", user_id=user_id, task_id=task_id,
                 detail={"provider": answer["provider"], "model": answer["model"]})
    return finish("COMPLETED", message=answer["content"], provider=answer["provider"],
                  model=answer["model"], verification="VERIFIED", verified=True)


def build_context(user_id: str, text: str) -> list[dict]:
    from ..memory_store import list_memories

    mems = list_memories(user_id)[:20]
    sys_prompt = SYSTEM_PROMPT
    if mems:
        facts = "; ".join(f"{m['key']}={m['value']}" for m in mems)
        sys_prompt += f"\nKnown facts about the user: {facts}"
    if browser_tools.LAST_RESULTS:
        listing = "; ".join(f"{r['index']}. {r['title']}" for r in browser_tools.LAST_RESULTS[:5])
        sys_prompt += f"\nCurrent browser results: {listing}"
    return [{"role": "system", "content": sys_prompt}, {"role": "user", "content": text}]


def summarize_tool_result(name: str, result: Any) -> str:
    if isinstance(result, dict):
        if name == "cpu_usage":
            return f"CPU is at {result.get('overall')}% across {result.get('cores')} logical cores."
        if name == "memory_usage":
            return f"RAM at {result.get('percent')}% ({result.get('used_gb')} of {result.get('total_gb')} GB)."
        if name == "disk_usage":
            return f"Disk {result.get('path')}: {result.get('percent')}% used, {result.get('free_gb')} GB free."
        if name == "battery_status":
            if not result.get("has_battery"):
                return "No battery on this machine, Sir."
            return f"Battery at {result.get('percent')}%" + (" and charging." if result.get("plugged_in") else ".")
        if name == "browser_search":
            top = result.get("results", [])[:3]
            listing = " ".join(f"{r['index']}. {r['title']}." for r in top)
            return f"{result.get('count')} results for '{result.get('query')}'. {listing}"
        if name in ("browser_open", "browser_open_result"):
            return f"Opened {result.get('title') or result.get('url')}."
        if name == "system_info":
            return (f"{result.get('os')} {result.get('release')} on {result.get('hostname')}, "
                    f"{result.get('processes')} processes, up {result.get('uptime_minutes')} min.")
    return f"{name} completed."
