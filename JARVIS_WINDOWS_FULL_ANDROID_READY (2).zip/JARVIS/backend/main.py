"""JARVIS backend entrypoint.

Hardened for PyInstaller --windowed:
  * sys.stdout / sys.stderr may be None -> they are replaced before anything logs
  * fastapi.middleware.cors and friends are imported explicitly so PyInstaller's
    static analysis actually packages them
"""
from __future__ import annotations

import io
import os
import sys


# --------------------------------------------------------------------------- #
# 1. stdio guards - MUST run before uvicorn/logging touch the streams (spec 30)
# --------------------------------------------------------------------------- #
def _guard_stdio() -> None:
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is None or not hasattr(stream, "write"):
            setattr(sys, name, io.TextIOWrapper(io.BytesIO(), encoding="utf-8", errors="replace"))
    if getattr(sys, "stdin", None) is None:
        sys.stdin = io.TextIOWrapper(io.BytesIO(), encoding="utf-8")


_guard_stdio()

# Explicit imports so PyInstaller sees them (they are otherwise resolved lazily).
import fastapi.middleware.cors  # noqa: E402,F401
import uvicorn.logging  # noqa: E402,F401
import uvicorn.loops.auto  # noqa: E402,F401
import uvicorn.protocols.http.auto  # noqa: E402,F401
import uvicorn.protocols.websockets.auto  # noqa: E402,F401
import uvicorn.lifespan.on  # noqa: E402,F401

from fastapi import FastAPI, Request  # noqa: E402
from fastapi.middleware.cors import CORSMiddleware  # noqa: E402
from fastapi.responses import FileResponse, JSONResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402

from . import config, db  # noqa: E402
from .routers import (agent, auth, bus, combos, crossdevice, devices, misc, system,
                      voice_ai)  # noqa: E402


def create_app() -> FastAPI:
    db.connect()
    # Import any pre-existing Combos (JARVIS-copy-2 .. -12 and whatever was already
    # configured) into Combo Management. Idempotent and never destructive.
    try:
        from . import combos as combo_store
        combo_store.ensure_seeded()
    except Exception as exc:                      # never block startup on migration
        print(f"Combo migration skipped: {exc}")
    app = FastAPI(title=config.APP_NAME, version=config.APP_VERSION, docs_url="/api/docs")

    app.add_middleware(
        CORSMiddleware,
        allow_origin_regex=r".*",      # the HUD, the Tauri shell and paired devices
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    for module in (auth, system, devices, agent, misc, voice_ai, bus, combos,
                   crossdevice):
        app.include_router(module.router)

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        """No raw tracebacks reach a client; everything is a readable message."""
        return JSONResponse(status_code=500,
                            content={"detail": f"Internal error: {exc.__class__.__name__}: {exc}"})

    @app.get("/api/greeting")
    def greeting():
        """Startup line. The HUD requests it exactly once per real session (spec 15)."""
        return {"text": f"Good to see you. JARVIS is online - all systems nominal. {config.AUTHOR_LINE}",
                "author": config.AUTHOR_LINE, "version": config.APP_VERSION}

    # ---- static HUD ------------------------------------------------------- #
    webui = config.WEBUI_DIR
    if webui.is_dir():
        assets = webui / "assets"
        if assets.is_dir():
            app.mount("/assets", StaticFiles(directory=str(assets)), name="assets")

        @app.get("/")
        def index():
            return FileResponse(str(webui / "index.html"))

        @app.get("/{full_path:path}")
        def spa(full_path: str):
            if full_path.startswith("api/"):
                return JSONResponse(status_code=404, content={"detail": "Unknown API route."})
            candidate = webui / full_path
            if candidate.is_file():
                return FileResponse(str(candidate))
            return FileResponse(str(webui / "index.html"))
    else:
        @app.get("/")
        def no_ui():
            return JSONResponse({
                "detail": "HUD bundle not found. Build it with: cd frontend && npm install && npm run build",
                "expected_at": str(webui)})

    return app


app = create_app()


def main() -> None:
    port = config.PORT
    host = config.HOST
    if os.environ.get("JARVIS_OPEN_BROWSER", "0") == "1":
        _open_browser_once(port)
    uvicorn.run(app, host=host, port=port, log_level="info", access_log=False)


_BROWSER_OPENED = False


def _open_browser_once(port: int) -> None:
    """Opens the HUD ONCE per real process start.

    A lock file keyed to this PID prevents the old bug where a backend reconnect
    or health poll spawned a new localhost tab every time (spec 29).
    """
    global _BROWSER_OPENED
    if _BROWSER_OPENED:
        return
    marker = config.DATA_DIR / "hud_opened.pid"
    try:
        if marker.exists() and marker.read_text().strip() == str(os.getpid()):
            return
        marker.write_text(str(os.getpid()))
    except Exception:
        pass
    _BROWSER_OPENED = True
    import threading
    import webbrowser

    threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:{port}")).start()


if __name__ == "__main__":
    main()
