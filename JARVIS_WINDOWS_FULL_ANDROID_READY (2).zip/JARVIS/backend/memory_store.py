"""Persistent memory with credential guards (spec 21).

JARVIS will refuse to store anything that looks like a password, API key, token,
OAuth secret, cookie or private key - in the key OR the value.
"""
from __future__ import annotations

import re
import time
import uuid

from . import audit, db

CATEGORIES = ("fact", "preference", "device", "destination", "context")

_KEY_GUARD = re.compile(
    r"(pass(word|wd)?|secret|api[_\s-]?key|token|oauth|credential|private[_\s-]?key|"
    r"cookie|session[_\s-]?id|cvv|pin\b|seed[_\s-]?phrase)", re.I)

_VALUE_GUARD = re.compile(
    r"("
    r"sk-[A-Za-z0-9]{16,}"                       # OpenAI-style
    r"|gsk_[A-Za-z0-9]{16,}"                     # Groq
    r"|AIza[0-9A-Za-z_\-]{30,}"                  # Google
    r"|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}"
    r"|jtk_[A-Za-z0-9_\-]{20,}|jsess_[A-Za-z0-9_\-]{20,}"
    r"|xox[baprs]-[A-Za-z0-9-]{10,}"             # Slack
    r"|-----BEGIN [A-Z ]*PRIVATE KEY-----"
    r"|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\."  # JWT
    r")")


class MemoryGuardError(ValueError):
    pass


def guard(key: str, value: str) -> None:
    if _KEY_GUARD.search(key or ""):
        raise MemoryGuardError(
            "Refused: that looks like a credential. JARVIS never stores passwords, "
            "API keys, tokens or secrets in memory.")
    if _VALUE_GUARD.search(value or ""):
        raise MemoryGuardError(
            "Refused: the value looks like an API key or token. JARVIS never stores secrets.")
    if _KEY_GUARD.search(value or "") and re.search(r"[:=]\s*\S{8,}", value or ""):
        raise MemoryGuardError("Refused: that value appears to contain a credential.")


def store_memory(user_id: str, key: str, value: str, category: str = "fact") -> dict:
    key = (key or "").strip()
    value = (value or "").strip()
    if not key or not value:
        raise ValueError("Both a key and a value are required.")
    if category not in CATEGORIES:
        category = "fact"
    guard(key, value)
    now = time.time()
    existing = db.one("SELECT id FROM memories WHERE user_id=? AND key=?", (user_id, key))
    if existing:
        db.execute("UPDATE memories SET value=?, category=?, updated_at=? WHERE id=?",
                   (value, category, now, existing["id"]))
        mem_id = existing["id"]
    else:
        mem_id = f"mem_{uuid.uuid4().hex[:12]}"
        db.execute("INSERT INTO memories(id,user_id,key,value,category,created_at,updated_at)"
                   " VALUES (?,?,?,?,?,?,?)", (mem_id, user_id, key, value, category, now, now))
    audit.record("memory.store", "OK", user_id=user_id, detail={"key": key, "category": category})
    db.log_activity("memory", f"Remembered: {key}")
    return {"id": mem_id, "key": key, "value": value, "category": category, "updated_at": now}


def list_memories(user_id: str) -> list[dict]:
    rows = db.query("SELECT * FROM memories WHERE user_id=? ORDER BY updated_at DESC", (user_id,))
    return [dict(r) for r in rows]


def delete_memory(user_id: str, mem_id: str) -> bool:
    cur = db.execute("DELETE FROM memories WHERE user_id=? AND id=?", (user_id, mem_id))
    audit.record("memory.delete", "OK", user_id=user_id, detail={"id": mem_id})
    return cur.rowcount > 0


def clear_memories(user_id: str) -> int:
    cur = db.execute("DELETE FROM memories WHERE user_id=?", (user_id,))
    audit.record("memory.clear", "OK", user_id=user_id, detail={"removed": cur.rowcount})
    return cur.rowcount
