Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
' Preserve the old entry-point name while using the checked JARVIS setup path.
shell.Run "wscript.exe " & Chr(34) & root & "\start_jarvis.vbs" & Chr(34), 1, False
