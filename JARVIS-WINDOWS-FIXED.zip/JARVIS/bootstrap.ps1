# Compatibility entry point retained for the Brahma foundation.
param([switch]$IsElevated = $false)
$ErrorActionPreference = "Stop"
& (Join-Path $PSScriptRoot "bootstrap_jarvis.ps1")
exit $LASTEXITCODE
