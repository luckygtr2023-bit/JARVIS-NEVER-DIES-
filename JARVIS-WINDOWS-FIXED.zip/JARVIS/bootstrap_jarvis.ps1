﻿# J.A.R.V.I.S. source launcher. Based on the retained Brahma foundation.
# Startup hotfix 2026-09-08b: direct Python, waited exit codes and verified venv/pip repair.
# No manual pip commands; no guessed live-provider/hardware success.
[CmdletBinding()]
param()
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
$Root = $PSScriptRoot
Set-Location -LiteralPath $Root
$LogDir = Join-Path $Root "config\logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir "launcher.log"
$env:BRAHMA_SKIP_UPDATE = "1"
$env:PYTHONUTF8 = "1"
$env:PIP_DISABLE_PIP_VERSION_CHECK = "1"
$env:QT_ENABLE_HIGHDPI_SCALING = "1"
Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue
Remove-Item Env:VIRTUAL_ENV -ErrorAction SilentlyContinue
$LockPath = Join-Path $LogDir "launcher.lock"
$Lock = $null

function Say([string]$Message) {
    Write-Host $Message -ForegroundColor Yellow
    Write-SetupLog ((Get-Date -Format s) + " " + $Message)
}
function Quote-NativeArgument([string]$Value) {
    return '"' + [regex]::Replace([regex]::Replace($Value, '(\\*)"', '$1$1\"'), '(\\+)$', '$1$1') + '"'
}
function Write-SetupLog([string]$Text) {
    if ($Log -and $Text) {
        # Avoid copying credentials embedded in custom package-index URLs into diagnostics.
        $Safe = [regex]::Replace($Text, '(https?://)[^\s/@:]+:[^\s/@]+@', '$1[REDACTED]@')
        [IO.File]::AppendAllText($Log, $Safe + [Environment]::NewLine, (New-Object Text.UTF8Encoding($false)))
    }
}
function Invoke-Captured([string]$Program, [string[]]$Arguments, [int]$TimeoutSeconds = 1800) {
    $Info = New-Object System.Diagnostics.ProcessStartInfo
    $Info.FileName = $Program
    $Info.Arguments = (($Arguments | ForEach-Object { Quote-NativeArgument $_ }) -join ' ')
    $Info.WorkingDirectory = $Root
    $Info.UseShellExecute = $false
    $Info.CreateNoWindow = $true
    $Info.RedirectStandardOutput = $true
    $Info.RedirectStandardError = $true
    $Info.StandardOutputEncoding = New-Object Text.UTF8Encoding($false)
    $Info.StandardErrorEncoding = New-Object Text.UTF8Encoding($false)
    # An unrelated Python/Conda installation must not poison this child process.
    [void]$Info.EnvironmentVariables.Remove('PYTHONHOME')
    [void]$Info.EnvironmentVariables.Remove('PYTHONPATH')
    [void]$Info.EnvironmentVariables.Remove('VIRTUAL_ENV')
    [void]$Info.EnvironmentVariables.Remove('PIP_USER')
    [void]$Info.EnvironmentVariables.Remove('PIP_TARGET')
    [void]$Info.EnvironmentVariables.Remove('PIP_PREFIX')
    $Info.EnvironmentVariables['PYTHONNOUSERSITE'] = '1'
    $Info.EnvironmentVariables['PYTHONUTF8'] = '1'
    $Info.EnvironmentVariables['PYTHONIOENCODING'] = 'utf-8'
    $Process = New-Object System.Diagnostics.Process
    $Process.StartInfo = $Info
    $Output = ''; $Errors = ''; $Code = 9009; $TimedOut = $false
    try {
        if (-not $Process.Start()) { throw 'The operating system did not start this executable.' }
        # Read BOTH pipes concurrently. Read ExitCode from our own waited process,
        # not a potentially unavailable Start-Process -PassThru wrapper property.
        $OutTask = $Process.StandardOutput.ReadToEndAsync()
        $ErrTask = $Process.StandardError.ReadToEndAsync()
        if (-not $Process.WaitForExit($TimeoutSeconds * 1000)) {
            $TimedOut = $true
            if ($env:OS -eq 'Windows_NT') {
                # Kill only this setup command's process tree, never unrelated Python processes.
                try {
                    $KillInfo = New-Object System.Diagnostics.ProcessStartInfo
                    $KillInfo.FileName = Join-Path $env:WINDIR 'System32\taskkill.exe'
                    $KillInfo.Arguments = '/PID ' + $Process.Id + ' /T /F'
                    $KillInfo.UseShellExecute = $false
                    $KillInfo.CreateNoWindow = $true
                    $KillInfo.RedirectStandardOutput = $true
                    $KillInfo.RedirectStandardError = $true
                    $Killer = [Diagnostics.Process]::Start($KillInfo)
                    [void]$Killer.WaitForExit(5000)
                    $Killer.Dispose()
                } catch { }
            }
            try { if (-not $Process.HasExited) { $Process.Kill() } } catch { }
            [void]$Process.WaitForExit(5000)
            $Code = 124
            $Errors = "Command timed out after $TimeoutSeconds seconds. No success is claimed."
        } else {
            $Process.WaitForExit()
            $Code = [int]$Process.ExitCode
        }
        if ($OutTask.Wait(5000)) { $Output = $OutTask.Result }
        if ($ErrTask.Wait(5000)) { $Errors = ($Errors + [Environment]::NewLine + $ErrTask.Result).Trim() }
    } catch {
        $Errors = $_.Exception.Message
        $Code = 9009
    } finally {
        $Process.Dispose()
    }
    $script:LastNativeResult = [pscustomobject]@{
        Program = $Program; ExitCode = [int]$Code; Stdout = $Output; Stderr = $Errors; TimedOut = $TimedOut
    }
    Write-SetupLog ("COMMAND: " + $Program + " | exit code: " + $Code)
    Write-SetupLog $Output
    Write-SetupLog $Errors
    return [int]$Code
}
function Show-NativeFailure([string]$Step) {
    Write-Host ($Step + ' failed (exit ' + $script:LastNativeResult.ExitCode + ').') -ForegroundColor Yellow
    $Text = ($script:LastNativeResult.Stderr + [Environment]::NewLine + $script:LastNativeResult.Stdout).Trim()
    $Safe = [regex]::Replace($Text, '(https?://)[^\s/@:]+:[^\s/@]+@', '$1[REDACTED]@')
    if ($Safe) {
        ($Safe -split '\r?\n' | Select-Object -Last 12) | ForEach-Object { Write-Host $_ -ForegroundColor Gray }
    }
}
function Checked([string]$Program, [string[]]$Arguments, [string]$Step = 'Setup command') {
    $Code = Invoke-Captured $Program $Arguments
    if ($Code -ne 0) {
        Show-NativeFailure $Step
        throw "$Step failed with exit code $Code. The actual Python/installer error is shown above and recorded in config\logs\launcher.log."
    }
}
function Get-PythonInfo([string]$Exe, [string[]]$Prefix = @()) {
    if (-not $Exe) { return $null }
    # Ignore only the Store alias stub, not a genuine installed interpreter.
    if (($Prefix.Count -eq 0) -and ($Exe -match 'Microsoft[\\/]WindowsApps[\\/]python(?:3(?:\.\d+)?)?\.exe$')) { return $null }
    $Probe = 'import sys,struct,json,venv,ensurepip; print(json.dumps(dict(executable=sys.executable,base_executable=getattr(sys,"_base_executable",sys.executable),prefix=sys.prefix,base_prefix=sys.base_prefix,version=list(sys.version_info[:2]),bits=struct.calcsize("P")*8))); raise SystemExit(0 if sys.version_info[:2] in [(3,11),(3,12)] and struct.calcsize("P")==8 else 3)'
    $Code = Invoke-Captured $Exe ($Prefix + @('-I','-c',$Probe)) 60
    if ($Code -ne 0) { return $null }
    try {
        $LastLine = ($script:LastNativeResult.Stdout.Trim() -split '\r?\n')[-1]
        $Details = $LastLine | ConvertFrom-Json
        if ($Details.bits -ne 64 -or -not $Details.executable) { return $null }
        return $Details
    } catch { return $null }
}
function Python-Is-Supported([string]$Exe, [string[]]$Prefix = @()) {
    return ($null -ne (Get-PythonInfo $Exe $Prefix))
}
function Resolve-BasePython([string]$Exe, [string[]]$Prefix = @()) {
    $Details = Get-PythonInfo $Exe $Prefix
    if (-not $Details) { return $null }
    $Actual = [string]$Details.base_executable
    if (-not (Test-Path -LiteralPath $Actual -PathType Leaf)) { $Actual = [string]$Details.executable }
    # Use the real executable directly. Do not create a venv through py.exe,
    # an active unrelated venv, or a Microsoft Store launcher shim.
    if ($null -eq (Get-PythonInfo $Actual @())) { return $null }
    return $Actual
}
function Get-VenvPython([string]$EnvironmentPath) {
    if ($env:OS -eq 'Windows_NT') { return (Join-Path $EnvironmentPath 'Scripts\python.exe') }
    return (Join-Path $EnvironmentPath 'bin/python') # Allows real helper tests on Linux, not a Windows success claim.
}
function Test-JarvisVenv([string]$EnvironmentPath) {
    $Exe = Get-VenvPython $EnvironmentPath
    if (-not (Test-Path -LiteralPath $Exe -PathType Leaf)) { return $false }
    $Details = Get-PythonInfo $Exe @()
    if (-not $Details -or $Details.prefix -eq $Details.base_prefix) { return $false }
    $Expected = [IO.Path]::GetFullPath($EnvironmentPath).TrimEnd([char[]]'\/')
    $Actual = [IO.Path]::GetFullPath([string]$Details.prefix).TrimEnd([char[]]'\/')
    return [string]::Equals($Expected, $Actual, [StringComparison]::OrdinalIgnoreCase)
}
function Backup-Venv([string]$EnvironmentPath) {
    if (Test-Path -LiteralPath $EnvironmentPath) {
        $Suffix = '.backup-' + (Get-Date -Format 'yyyyMMddHHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8)
        Move-Item -LiteralPath $EnvironmentPath -Destination ($EnvironmentPath + $Suffix)
        Say 'Preserved the incomplete/incompatible environment as a backup. Config and memory were not changed.'
    }
}
function Ensure-JarvisVenv([string]$BasePython, [string]$EnvironmentPath) {
    try {
        if (-not (Test-JarvisVenv $EnvironmentPath)) {
            Backup-Venv $EnvironmentPath
            Say ("Creating the virtual environment: " + $EnvironmentPath)
            # Split the stdlib venv and bundled pip steps. --copies avoids symlink
            # privileges/filesystem support, and each failure has a specific diagnostic.
            $Code = Invoke-Captured $BasePython @('-I','-m','venv','--copies','--without-pip',$EnvironmentPath) 180
            if ($Code -ne 0) { Show-NativeFailure 'Virtual environment creation'; return $null }
            if (-not (Test-JarvisVenv $EnvironmentPath)) {
                Say 'Python did not create a valid virtual environment at this location.'
                return $null
            }
        }
        $Exe = Get-VenvPython $EnvironmentPath
        $PipCode = Invoke-Captured $Exe @('-I','-m','pip','--version') 60
        if ($PipCode -ne 0) {
            Say 'Installing/repairing the bundled pip inside this environment...'
            $PipCode = Invoke-Captured $Exe @('-I','-m','ensurepip','--upgrade','--default-pip') 300
            if ($PipCode -ne 0) { Show-NativeFailure 'Bundled pip setup'; return $null }
            $PipCode = Invoke-Captured $Exe @('-I','-m','pip','--version') 60
            if ($PipCode -ne 0) { Show-NativeFailure 'pip verification'; return $null }
        }
        return [pscustomobject]@{ Path = $EnvironmentPath; Python = $Exe }
    } catch {
        Write-Host ('Environment setup error: ' + $_.Exception.Message) -ForegroundColor Yellow
        Write-SetupLog ('Environment setup error: ' + $_.Exception.Message)
        return $null
    }
}
function Select-JarvisVenv([string]$BasePython) {
    $ProjectEnvironment = Join-Path $Root '.venv'
    $Pointer = Join-Path $Root 'config\runtime-python.json'
    # Reuse a verified previously selected environment, including the fallback.
    if (Test-Path -LiteralPath $Pointer) {
        try {
            $Previous = Get-Content -LiteralPath $Pointer -Raw | ConvertFrom-Json
            if ($Previous.project -eq $Root -and $Previous.environment -and (Test-JarvisVenv $Previous.environment)) {
                $Ready = Ensure-JarvisVenv $BasePython $Previous.environment
                if ($Ready) { return $Ready }
            }
        } catch { }
    }
    $Ready = Ensure-JarvisVenv $BasePython $ProjectEnvironment
    if (-not $Ready -and $env:LOCALAPPDATA) {
        $Hasher = [Security.Cryptography.SHA256]::Create()
        try { $Id = ([BitConverter]::ToString($Hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($Root.ToLowerInvariant())))).Replace('-','').Substring(0,16) }
        finally { $Hasher.Dispose() }
        $Fallback = Join-Path $env:LOCALAPPDATA ("JARVIS\Environments\" + $Id)
        Say 'The project-folder environment could not be prepared. Trying a short per-user LocalAppData path instead...'
        $Ready = Ensure-JarvisVenv $BasePython $Fallback
    }
    if (-not $Ready) {
        throw 'Virtual environment setup failed. The specific Python/permission/pip error is above. Do not disable security software; share the launcher log if the error remains.'
    }
    [pscustomobject]@{ project=$Root; environment=$Ready.Path; python=$Ready.Python } | ConvertTo-Json | Set-Content -LiteralPath $Pointer -Encoding UTF8
    return $Ready
}

function Signed-Download([string]$Url,[string]$Destination,[string]$Publisher) {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Destination
    $Signature = Get-AuthenticodeSignature -LiteralPath $Destination
    if ($Signature.Status -ne "Valid" -or $Signature.SignerCertificate.Subject -notmatch $Publisher) {
        Remove-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
        throw "Installer signature verification failed. No downloaded executable was run."
    }
}
try {
    if ($env:OS -ne "Windows_NT") { throw "Windows 10/11 x64 is required for the native HUD." }
    $Lock = [IO.File]::Open($LockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    Say "J.A.R.V.I.S. - Just A Rather Very Intelligent System"
    Say "Preparing the existing foundation and one authoritative backend..."
    $Python = $null
    $Prefix = @()
    $PyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($PyLauncher) {
        foreach ($Version in @("-3.11", "-3.12")) {
            if (Python-Is-Supported $PyLauncher.Source @($Version)) { $Python=$PyLauncher.Source; $Prefix=@($Version); break }
        }
    }
    if (-not $Python) {
        $Candidates = @(
            (Join-Path $Root ".venv\Scripts\python.exe"),
            (Join-Path $env:ProgramFiles "Python311\python.exe"),
            (Join-Path $env:ProgramFiles "Python312\python.exe"),
            (Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"),
            (Join-Path $env:LOCALAPPDATA "Programs\Python\Python312\python.exe")
        )
        $OnPath = Get-Command python.exe -ErrorAction SilentlyContinue
        if ($OnPath) { $Candidates += $OnPath.Source }
        foreach ($Candidate in $Candidates) {
            if ((Test-Path -LiteralPath $Candidate) -and (Python-Is-Supported $Candidate @())) { $Python=$Candidate; break }
        }
    }
    if (-not $Python) {
        Say "Installing signed Python 3.11 x64 for the current user..."
        $Installer=Join-Path $env:TEMP "jarvis-python-3.11.9-amd64.exe"
        Signed-Download "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" $Installer "Python Software Foundation"
        $Process=Start-Process -FilePath $Installer -ArgumentList @("/quiet","InstallAllUsers=0","Include_pip=1","Include_test=0","Include_launcher=1","PrependPath=0") -Wait -PassThru
        if ($Process.ExitCode -notin @(0,3010)) { throw "Python installation failed." }
        $Python=Join-Path $env:LOCALAPPDATA "Programs\Python\Python311\python.exe"
        $Prefix=@()
        if (-not (Python-Is-Supported $Python $Prefix)) { throw "Supported Python was not found after installation." }
    }
    $Python = Resolve-BasePython $Python $Prefix
    if (-not $Python) { throw "No usable Python 3.11/3.12 x64 installation with venv and ensurepip was found." }
    $Prefix = @()
    Say ("Using Python: " + $Python)
    $Environment = Select-JarvisVenv $Python
    $Venv = $Environment.Path
    $VenvPython = $Environment.Python
    $env:VIRTUAL_ENV = $Venv
    $env:PATH = (Split-Path -Parent $VenvPython) + [IO.Path]::PathSeparator + $env:PATH
    Say ("Verified environment: " + $Venv)
    # Environment creation/pip repair is complete. Continue the existing setup pipeline.
    # Reuse an already-running instance only when it is the JARVIS backend.
    $HealthCode = Invoke-Captured $VenvPython @("-m","jarvis_core.launcher","health")
    if ($HealthCode -eq 0) {
        Checked $VenvPython @("-m","jarvis_core.launcher","show")
        Say "The existing JARVIS instance is open."
        exit 0
    }
    $Requirements=Join-Path $Root "requirements.txt"
    $Stamp=Join-Path $Venv ".jarvis-requirements.sha256"
    $Fingerprint=(Get-FileHash -LiteralPath $Requirements -Algorithm SHA256).Hash
    $NeedInstall=$true
    if ((Test-Path -LiteralPath $Stamp) -and ((Get-Content -LiteralPath $Stamp -Raw).Trim() -eq $Fingerprint)) {
        $PipCode = Invoke-Captured $VenvPython @("-m","pip","check")
        $NeedInstall=($PipCode -ne 0)
    }
    if ($NeedInstall) {
        Say "Installing/repairing inherited and JARVIS Python dependencies..."
        Checked $VenvPython @("-m","pip","install","--upgrade","pip","wheel")
        Checked $VenvPython @("-m","pip","install","-r",$Requirements)
        Set-Content -LiteralPath $Stamp -Value $Fingerprint
    }
    Say "Checking Playwright / Chromium..."
    Checked $VenvPython @("-m","playwright","install","chromium")
    Say "Verifying imports and required runtime components..."
    $PreflightCode = Invoke-Captured $VenvPython @("-m","jarvis_core.launcher","preflight")
    if ($PreflightCode -ne 0) {
        Say "Repairing dependencies and retrying import verification..."
        Checked $VenvPython @("-m","pip","install","--upgrade","--upgrade-strategy","only-if-needed","-r",$Requirements)
        $PreflightCode = Invoke-Captured $VenvPython @("-m","jarvis_core.launcher","preflight")
        if ($PreflightCode -ne 0) {
            if (-not (Test-Path "$env:WINDIR\System32\vcruntime140.dll")) {
                Say "A Microsoft runtime is missing. Windows may ask permission to install its signed redistributable."
                $Runtime=Join-Path $env:TEMP "jarvis-vc-redist-x64.exe"
                Signed-Download "https://aka.ms/vs/17/release/vc_redist.x64.exe" $Runtime "Microsoft"
                $Installed=Start-Process -FilePath $Runtime -ArgumentList @("/install","/quiet","/norestart") -Verb RunAs -Wait -PassThru
                if ($Installed.ExitCode -eq 3010) { throw "Windows needs a restart after the runtime install. Restart and double-click start_jarvis.bat again." }
                if ($Installed.ExitCode -ne 0) { throw "Microsoft runtime installation did not succeed." }
            }
            Checked $VenvPython @("-m","jarvis_core.launcher","preflight")
        }
    }
    Say "Starting the single backend with the native HUD initially hidden..."
    $Stdout=Join-Path $LogDir "runtime-stdout.log"
    $Stderr=Join-Path $LogDir "runtime-stderr.log"
    $Backend=Start-Process -FilePath $VenvPython -ArgumentList @("-m","jarvis_core.desktop","--wait-for-hud") -WorkingDirectory $Root -WindowStyle Hidden -RedirectStandardOutput $Stdout -RedirectStandardError $Stderr -PassThru
    $Healthy=$false
    for ($Attempt=0; $Attempt -lt 45; $Attempt++) {
        Start-Sleep -Seconds 2
        $Backend.Refresh()
        if ($Backend.HasExited) { throw "The runtime exited before becoming healthy. See config\logs\runtime-stderr.log." }
        $HealthCode = Invoke-Captured $VenvPython @("-m","jarvis_core.launcher","health")
        if ($HealthCode -eq 0) { $Healthy=$true; break }
    }
    if (-not $Healthy) { throw "Backend health did not become ready. The launcher did not claim success. Review the runtime logs before retrying." }
    Say "Backend healthy. Opening the JARVIS HUD..."
    Checked $VenvPython @("-m","jarvis_core.launcher","show")
    Say "JARVIS started. First run: create your OWNER account in the HUD, then configure providers and devices."
    Say "Live providers, actual Bluetooth/phone/voice and Windows action effects are NOT VERIFIED by this launcher."
    exit 0
} catch {
    Write-Host ("JARVIS could not start: " + $_.Exception.Message) -ForegroundColor Red
    Write-SetupLog ("FAILED: " + $_.Exception.Message)
    Write-Host ("Diagnostic log: " + $Log) -ForegroundColor Yellow
    exit 1
} finally {
    if ($Lock) { $Lock.Dispose() }
}
