@echo off
setlocal EnableExtensions DisableDelayedExpansion
title J.A.R.V.I.S. - Secure Foundation Launcher
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0bootstrap_jarvis.ps1"
set "JARVIS_EXIT=%ERRORLEVEL%"
if not "%JARVIS_EXIT%"=="0" (
  echo.
  echo JARVIS did not start successfully. Review the message and config\logs.
  pause
)
exit /b %JARVIS_EXIT%
