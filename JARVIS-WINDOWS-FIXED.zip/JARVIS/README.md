# J.A.R.V.I.S.
## Just A Rather Very Intelligent System

> **STARTUP FIX ALREADY APPLIED — full package.** Extract `JARVIS-WINDOWS-FIXED.zip` into a new folder, keep the old installation as a backup, and run **`start_jarvis.bat` only**. No individual replacements or manual pip commands are needed. See `START_HERE.txt`. This does not assert successful startup on the user's Windows machine before retrying.

Built on the **Brahma Echo foundation**, with JARVIS Brain, isolated Memory, AI routing, Combo permissions, Bluetooth trust, Android control and automated Windows startup.

**Release gate: NOT ACCEPTED YET.** The requested FINAL packages have build/integrity checks; unavailable Windows, live-provider and physical-device checks are **NOT VERIFIED — REQUIRES PHYSICAL TESTING**. See [the final report](release/FINAL_REPORT.md). Do not interpret the filenames as a production-readiness certificate.

## Windows

1. Extract the complete `JARVIS` folder from `JARVIS-WINDOWS-FINAL.zip` into a folder writable by your Windows account.
2. Double-click **`start_jarvis.bat`** and wait. First run needs internet access for dependency downloads.
3. The launcher detects Python, creates/repairs its venv, installs dependencies and Chromium, verifies imports, starts the single backend, checks health and opens the retained HUD. **No manual pip commands are part of this startup flow.**
4. Create your own local OWNER account, then sign in. There is **no supplied username/password**.
5. Use the JARVIS control center for provider keys/models, memory, Combos, users and device trust.

This sequence is implemented and its helper quoting/syntax is checked; actual Windows double-click execution remains unverified. Spaces/parentheses are handled using quoted arguments. Errors are written locally to `config/logs/` during use; no runtime logs are supplied in this archive.

No EXE is included because a native Windows executable build was not successfully performed. The application is supplied as runnable Windows Python source with automated setup. Prefer a currently patched compatible Python 3.11/3.12 x64 interpreter; the signed 3.11.9 compatibility-installer fallback is not a claim of current security patch level.

## Android and Bluetooth trust

`JARVIS-ANDROID-FINAL.apk` is supplied separately: **test-signed, non-debuggable release variant**. Its build/signature/manifest were checked. Installation, voice, Bluetooth and device-control behavior on a real phone remain unverified. Do not install over or erase a differently signed existing installation without protecting its data.

On the local OWNER HUD:

- Configure TLS/LAN transport using the PC's actual address; restart when requested. No firewall rule is opened automatically.
- Compare/scan the backend certificate QR from the local OWNER display. A QR/IP/login is not authorization.
- Sign in and register the Android/PWA device key.
- Pair the real phone in Windows Bluetooth settings. Compare its public-key fingerprint and bind the matching OS bond locally.
- Authenticate the device. The backend enforces fresh pairing state, device proof, roles, permissions and exact consequential confirmation.

**NOT PAIRED → DENIED · PAIRED + AUTHORIZED → ALLOWED · REVOKED/UNPAIRED → DENIED.** These rules have synthetic logic tests, not physical acceptance. Bluetooth bond state is not proximity proof. See [protocol](docs/CLIENT_PROTOCOL.md) and [security boundaries](docs/SECURITY_BOUNDARIES.md).

## AI and memory

Gemini and OpenRouter are retained; Ollama and configured OpenAI-compatible OmniRoute adapters are added. OmniRoute is disabled initially and is **NOT VERIFIED — REQUIRES PHYSICAL TESTING** until a real configured request succeeds. A real Linux Ollama generation/fallback/Brain-chat run is recorded separately; it does not verify Ollama on your Windows machine.

Keys belong in the local protected provider settings, not memory, task text, source or support logs. Memory supports short/session/long-term/workflow scopes, search/edit/delete/clear, enable/disable and import/export. Facts and task records remain user-scoped; task audit/history is distinct from memory clear/disable.

OWNER manages accounts and grants. OPERATOR manages permitted own/delegated Combos. USER uses assigned, enabled Combos only with the necessary underlying permissions. Names are fully configurable; production Combo names are not seeded.

## Clean package / source

Included: source, original actions/HUD, Brain/backend, memory/routing/permission systems, Android source, templates, startup scripts, tests and documentation. `RELEASE_MANIFEST.json` records the exact files and narrowly defined upstream omissions.

Excluded: real credentials, `.env` files, personal runtime state, databases, logs, caches, environments, node_modules, temporary files, private signing keys, downloaded model caches and superseded APK/manual mutation extras. Tests retain explicitly synthetic rejection fixtures, not operational passwords/API keys. `config/models/hand_landmarker.task` is an inherited runtime asset required by retained gesture functionality—not a downloaded cache.

All original runtime modules and original Brahma tests remain. Existing automatic/legacy integration parity and trusted-code boundaries still require native review. Do not launch old standalone network services as authorization bypasses. [Build/testing notes](release/BUILD_AND_TEST.md) describe limitations and remaining gates.

## Attribution and license

Upstream: https://github.com/titechprabhasolutions/Brahma-Echo · commit `41111af7b9d93e773a89f0bf2d5f9f44ca867642`.

Copyright (c) 2026 **Suryaansh Tiwari**. `LICENSE` and `TRADEMARK.md` are preserved. This is **source-available, not OSI open source**. The user confirmed written rebranding permission, but the permission instrument/broader distribution scope was not reviewed. No public/commercial distribution grant or endorsement is inferred. See `NOTICE.md` and retained dependency licenses.
