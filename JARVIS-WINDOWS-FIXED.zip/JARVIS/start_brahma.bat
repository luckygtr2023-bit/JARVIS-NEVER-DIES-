@echo off
setlocal EnableExtensions DisableDelayedExpansion
rem Compatibility entry point: use the same checked JARVIS bootstrap, not a second installer.
call "%~dp0start_jarvis.bat" %*
exit /b %ERRORLEVEL%
