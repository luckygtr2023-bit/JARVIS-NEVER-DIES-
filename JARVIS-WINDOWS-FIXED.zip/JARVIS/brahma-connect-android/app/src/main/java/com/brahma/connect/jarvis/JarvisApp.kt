package com.brahma.connect.jarvis

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.brahma.connect.ui.ChatScreen
import com.brahma.connect.ui.QrScannerScreen
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisApp(client: JarvisClient, onConnect: () -> Unit, onVoice: () -> Unit, onCamera: () -> Unit, onImport: () -> Unit, onExport: () -> Unit) {
    val state by client.state.collectAsState()
    var page by remember { mutableStateOf("Device") }
    var scanner by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf(client.configuredUrl()) }
    var pin by remember { mutableStateOf(client.configuredPin()) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    if (scanner) {
        QrScannerScreen(onBack={scanner=false},onRequestPermission=onCamera,errorText=state.error,onScanned={raw ->
            runCatching { val config=JSONObject(raw);require(config.optString("protocol")=="jarvis.v1");url=config.getString("backend_url");pin=config.optString("certificate_sha256") }.onFailure { client.launch { error("Use the authenticated JARVIS server-configuration QR, not a legacy network pairing token.") } }
            scanner=false
        })
        return
    }
    if(state.user==null){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(28.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
            Spacer(Modifier.height(20.dp));Text("J.A.R.V.I.S.",style=MaterialTheme.typography.headlineLarge,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)
            Text("Just A Rather Very Intelligent System",style=MaterialTheme.typography.bodyMedium)
            Text("Same backend. Bluetooth trust. No direct Windows execution.",style=MaterialTheme.typography.bodySmall)
            OutlinedTextField(url,{url=it},label={Text("HTTPS backend origin")},placeholder={Text("https://your-pc:8765")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(pin,{pin=it},label={Text("Certificate SHA-256 pin (for self-signed TLS)")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(username,{username=it},label={Text("Username")},modifier=Modifier.fillMaxWidth(),singleLine=true)
            OutlinedTextField(password,{password=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth(),singleLine=true)
            Button(onClick={val supplied=password;password="";client.launch{client.login(url,pin,username,supplied)}},modifier=Modifier.fillMaxWidth()){Text("Sign in & register device key")}
            OutlinedButton(onClick={onCamera();scanner=true},modifier=Modifier.fillMaxWidth()){Text("Scan backend settings QR")}
            state.error?.let { Text(it,color=MaterialTheme.colorScheme.error) }
            Text("Create your account on the Windows OWNER HUD. Login alone does not authorize control. Pair the phone in Windows, compare its public-key fingerprint and have the OWNER bind the matching OS bond.",style=MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(24.dp));Text("Based on Brahma Echo · © 2026 Suryaansh Tiwari\nSource-available. Physical Android/voice acceptance is not implied.",style=MaterialTheme.typography.labelSmall)
        }
        return
    }
    Scaffold(topBar={TopAppBar(title={Column{Text("J.A.R.V.I.S.",color=MaterialTheme.colorScheme.primary);Text("${state.user?.optString("username")} · ${state.user?.optString("role")}",style=MaterialTheme.typography.labelSmall)}},actions={TextButton(onClick={client.launch{client.refresh()}}){Text("Refresh")};TextButton(onClick={client.launch{client.logout()}}){Text("Logout")}})}){padding ->
        Column(Modifier.fillMaxSize().padding(padding)){
            Text(if(state.connected)"DEVICE AUTHENTICATED · fresh backend trust checks remain required" else "CONTROL DENIED · ${state.status}",color=if(state.connected)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(horizontal=16.dp,vertical=8.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())){listOf("Chat","Tasks","Memory","Combos","AI","Device").forEach { name -> TextButton(onClick={page=name}){Text(name,fontWeight=if(page==name)FontWeight.Bold else FontWeight.Normal)} }}
            state.error?.let{message -> Row(Modifier.padding(horizontal=16.dp)){Text(message,color=MaterialTheme.colorScheme.error,modifier=Modifier.weight(1f));TextButton(onClick=client::clearError){Text("Dismiss")}}}
            if(page=="Chat"){
                Row(Modifier.fillMaxWidth().padding(horizontal=12.dp)){OutlinedButton(onClick=onVoice,enabled=state.connected){Text("Voice → same backend")}}
                Box(Modifier.weight(1f)){ChatScreen(onBack={page="Device"},onSendMessage={text->client.launch{client.submit(text)}})}
            }else{
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
                    when(page){
                        "Tasks" -> TaskControls(client,state)
                        "Memory" -> MemoryControls(client,state,onImport,onExport)
                        "Combos" -> ComboControls(client,state)
                        "AI" -> ProviderControls(client,state)
                        "Device" -> DeviceControls(client,state,onConnect)
                    }
                }
            }
        }
    }
}

@Composable private fun Panel(title:String,content:@Composable ColumnScope.()->Unit){Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text(title,style=MaterialTheme.typography.titleMedium,color=MaterialTheme.colorScheme.primary);content()}}}

@Composable private fun TaskControls(client:JarvisClient,state:JarvisState){
    if(state.tasks.isEmpty())Text("No tasks yet. Send a goal in Chat or run an authorized Combo.")
    state.tasks.forEach{task->Panel(task.optString("request").ifBlank{"Explicit / Combo task"}){
        Text("${task.optString("state")} · ${task.optString("stage")}",fontWeight=FontWeight.Bold)
        Text(task.optString("final_response").ifBlank{"Waiting for the next authorized stage."})
        Text("Verification: ${task.optString("verification","NOT VERIFIED")}",style=MaterialTheme.typography.labelSmall)
        val confirmation=task.optJSONObject("confirmation")
        if(confirmation!=null){Text("CONSEQUENTIAL ACTION — exact step",color=MaterialTheme.colorScheme.error);Text(confirmation.optJSONObject("step")?.toString(2).orEmpty(),style=MaterialTheme.typography.bodySmall)
            var reviewing by remember(task.optString("id")){mutableStateOf(false)}
            Button(onClick={reviewing=true},enabled=state.connected){Text("Review approval")}
            if(reviewing)AlertDialog(onDismissRequest={reviewing=false},title={Text("Approve exact action?")},text={Text(confirmation.optString("warning"))},confirmButton={TextButton(onClick={reviewing=false;client.launch{client.api("/v1/tasks/${task.getString("id")}/confirm","POST",JSONObject().put("confirmation_id",confirmation.getString("id")).put("approved",true));client.refreshTasks()}}){Text("Approve")}},dismissButton={TextButton(onClick={reviewing=false;client.launch{client.api("/v1/tasks/${task.getString("id")}/confirm","POST",JSONObject().put("confirmation_id",confirmation.getString("id")).put("approved",false));client.refreshTasks()}}){Text("Deny")}})
        }
        if(task.optString("state") !in listOf("completed","failed","cancelled","interrupted"))TextButton(onClick={client.launch{client.api("/v1/tasks/${task.getString("id")}/cancel","POST",JSONObject());client.refreshTasks()}}){Text("Request cancellation")}
    }}
}

@Composable private fun MemoryControls(client:JarvisClient,state:JarvisState,onImport:()->Unit,onExport:()->Unit){
    var id by remember{mutableStateOf<String?>(null)};var label by remember{mutableStateOf("")};var value by remember{mutableStateOf("")};var kind by remember{mutableStateOf("long_term")};var query by remember{mutableStateOf("")};var filtered by remember{mutableStateOf<List<JSONObject>?>(null)};var clear by remember{mutableStateOf(false)}
    Panel("Private memory"){
        Text("Passwords, PINs, API keys and tokens must never enter memory. No local business database is created.",style=MaterialTheme.typography.bodySmall)
        Row{Switch(checked=state.memorySettings.optBoolean("enabled",true),onCheckedChange={enabled->client.launch{client.api("/v1/memory/settings","PUT",JSONObject().put("enabled",enabled).put("auto_context",state.memorySettings.optBoolean("auto_context")));client.refresh()}});Text("Memory enabled",modifier=Modifier.padding(12.dp))}
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton(onClick=onImport,enabled=state.connected){Text("Import")};OutlinedButton(onClick=onExport,enabled=state.connected){Text("Export")};TextButton(onClick={clear=true}){Text("Clear")}}
        if(clear)AlertDialog(onDismissRequest={clear=false},title={Text("Clear only your memory?")},text={Text("This removes your stored scopes. It cannot clear another user's memory.")},confirmButton={TextButton(onClick={clear=false;client.launch{client.api("/v1/memory/clear","POST",JSONObject().put("confirm",true));client.refresh()}}){Text("Clear mine")}},dismissButton={TextButton(onClick={clear=false}){Text("Cancel")}})
        OutlinedTextField(query,{query=it},label={Text("Search")},modifier=Modifier.fillMaxWidth())
        Button(onClick={client.launch{val result=client.api("/v1/memory?query="+URLEncoder.encode(query,"UTF-8")) as JSONArray;filtered=(0 until result.length()).map{result.getJSONObject(it)}}},enabled=state.connected){Text("Search my memory")}
    }
    Panel(if(id==null)"Add memory" else "Edit memory"){
        Row(Modifier.horizontalScroll(rememberScrollState())){listOf("short","session","long_term","workflow").forEach{k->TextButton(onClick={kind=k}){Text(k,fontWeight=if(kind==k)FontWeight.Bold else FontWeight.Normal)}}}
        OutlinedTextField(label,{label=it},label={Text("Label")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value,{value=it},label={Text("Value (text or JSON)")},modifier=Modifier.fillMaxWidth(),minLines=3)
        Button(onClick={client.launch{val content:Any=if(value.trim().startsWith("{")||value.trim().startsWith("["))org.json.JSONTokener(value).nextValue() else value;client.api("/v1/memory"+(id?.let{"/$it"}?:""),if(id==null)"POST" else "PATCH",JSONObject().put("kind",kind).put("label",label).put("value",content).put("tags",JSONArray()));id=null;label="";value="";filtered=null;client.refresh()}},enabled=state.connected){Text("Save")}
    }
    (filtered?:state.memories).forEach{item->Panel(item.optString("label")){
        Text(item.opt("value")?.toString().orEmpty());Text(item.optString("kind"),style=MaterialTheme.typography.labelSmall)
        Row{TextButton(onClick={id=item.getString("id");kind=item.optString("kind");label=item.optString("label");value=item.opt("value")?.toString().orEmpty()}){Text("Edit")};TextButton(onClick={client.launch{client.api("/v1/memory/${item.getString("id")}","DELETE");filtered=null;client.refresh()}}){Text("Delete")}}
    }}
}

@Composable private fun ComboControls(client:JarvisClient,state:JarvisState){
    var editing by remember{mutableStateOf(false)};var id by remember{mutableStateOf<String?>(null)};var version by remember{mutableStateOf(1)};var name by remember{mutableStateOf("")};var steps by remember{mutableStateOf("[]")};var enabled by remember{mutableStateOf(true)};var catalog by remember{mutableStateOf("")};var assignment by remember{mutableStateOf<JSONObject?>(null)};var targetUser by remember{mutableStateOf("")};var canUse by remember{mutableStateOf(true)};var canManage by remember{mutableStateOf(false)};var userOptions by remember{mutableStateOf("")}
    val role=state.user?.optString("role")
    Text("Names are entirely configurable. Assignment never inherits the author's role or bypasses tool permissions.",style=MaterialTheme.typography.bodySmall)
    if(role in listOf("OWNER","OPERATOR"))Button(onClick={editing=true;id=null;name="";steps="[]";enabled=true}){Text("Create Combo")}
    if(editing)Panel("Combo editor"){
        OutlinedTextField(name,{name=it},label={Text("Your chosen name")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(steps,{steps=it},label={Text("Ordered tool steps JSON")},modifier=Modifier.fillMaxWidth(),minLines=6)
        Row{Switch(enabled,{enabled=it});Text("Enabled",modifier=Modifier.padding(12.dp))}
        Text("Use \${workspace} for the executing user's files. No predefined final Combo names.",style=MaterialTheme.typography.bodySmall)
        Row{Button(onClick={client.launch{val body=JSONObject().put("name",name).put("steps",JSONArray(steps)).put("enabled",enabled);if(id!=null)body.put("version",version);client.api("/v1/combos"+(id?.let{"/$it"}?:""),if(id==null)"POST" else "PATCH",body);editing=false;client.refresh()}},enabled=state.connected){Text("Save")};TextButton(onClick={client.launch{catalog=(client.api("/v1/tools") as JSONObject).toString(2)}}){Text("Tool catalog")};TextButton(onClick={editing=false}){Text("Close")}}
        if(catalog.isNotBlank())Text(catalog,style=MaterialTheme.typography.bodySmall)
    }
    state.combos.forEach{combo->Panel(combo.optString("name")){
        Text("${if(combo.optBoolean("enabled"))"Enabled" else "Disabled"} · version ${combo.optInt("version")}")
        Text(combo.optJSONArray("steps")?.toString(2).orEmpty(),style=MaterialTheme.typography.bodySmall)
        Button(onClick={client.launch{client.api("/v1/tasks","POST",JSONObject().put("combo_id",combo.getString("id")));client.refreshTasks()}},enabled=state.connected&&combo.optBoolean("can_use")){Text("Run authorized Combo")}
        if(combo.optBoolean("can_manage"))Row{TextButton(onClick={editing=true;id=combo.getString("id");version=combo.optInt("version");name=combo.optString("name");steps=combo.getJSONArray("steps").toString(2);enabled=combo.optBoolean("enabled")}){Text("Edit / rename")};TextButton(onClick={client.launch{client.api("/v1/combos/${combo.getString("id")}","PATCH",JSONObject().put("version",combo.getInt("version")).put("enabled",!combo.optBoolean("enabled")));client.refresh()}}){Text("Toggle")};TextButton(onClick={client.launch{client.api("/v1/combos/${combo.getString("id")}","DELETE");client.refresh()}}){Text("Delete")}}
        if(role=="OWNER")TextButton(onClick={assignment=combo;client.launch{userOptions=(client.api("/v1/users") as JSONArray).toString(2)}}){Text("Assign / delegate")}
    }}
    if(assignment!=null)AlertDialog(onDismissRequest={assignment=null},title={Text("OWNER assignment")},text={Column{Text(userOptions,style=MaterialTheme.typography.labelSmall);OutlinedTextField(targetUser,{targetUser=it},label={Text("Backend user ID")});Row{Checkbox(canUse,{canUse=it});Text("Use")};Row{Checkbox(canManage,{canManage=it});Text("Delegate management (OPERATOR)")}}},confirmButton={TextButton(onClick={val combo=assignment!!;client.launch{client.api("/v1/combos/${combo.getString("id")}/assignment","PUT",JSONObject().put("user_id",targetUser).put("can_use",canUse).put("can_manage",canManage));assignment=null;client.refresh()}}){Text("Save grant")}},dismissButton={TextButton(onClick={assignment=null}){Text("Cancel")}})
}

@Composable private fun ProviderControls(client:JarvisClient,state:JarvisState){
    val role=state.user?.optString("role")
    Panel("My routing policy"){
        Text("Local-only never falls back to a cloud model. OmniRoute is treated as potentially cloud-backed, even on a local address.",style=MaterialTheme.typography.bodySmall)
        listOf("local_first","local_only","auto","cloud_first").forEach{mode->TextButton(onClick={client.launch{client.api("/v1/routing","PUT",JSONObject().put("mode",mode).put("preferred",JSONObject.NULL));client.refresh()}}){Text((if(state.routing.optString("mode")==mode)"• " else "")+mode)}}
    }
    state.providers.keys().forEach{name->val provider=state.providers.getJSONObject(name);Panel(name.uppercase()){
        Text(provider.optString("live_verification","NOT VERIFIED"),fontWeight=FontWeight.Bold)
        Text("Only a successful real generation verifies the configured provider. Contract tests are not live proof.",style=MaterialTheme.typography.bodySmall)
        var model by remember(provider.toString()){mutableStateOf(provider.optString("model"))};var base by remember(provider.toString()){mutableStateOf(provider.optString("base_url"))};var active by remember(provider.toString()){mutableStateOf(provider.optBoolean("enabled"))};var probe by remember{mutableStateOf(false)}
        OutlinedTextField(model,{model=it},label={Text("Model")},modifier=Modifier.fillMaxWidth(),enabled=role=="OWNER")
        if(name in listOf("ollama","omniroute"))OutlinedTextField(base,{base=it},label={Text("Configured API base URL")},modifier=Modifier.fillMaxWidth(),enabled=role=="OWNER")
        if(role=="OWNER"){
            Row{Switch(active,{active=it});Text("Enabled",modifier=Modifier.padding(12.dp))}
            Row{Button(onClick={client.launch{client.api("/v1/providers/$name","PATCH",JSONObject().put("enabled",active).put("model",model).put("base_url",base));client.refresh()}}){Text("Save")};TextButton(onClick={probe=true}){Text("REAL request")}}
            Text("Provider keys are set only on the local OWNER HUD; they never enter Android memory controls.",style=MaterialTheme.typography.labelSmall)
            if(probe)AlertDialog(onDismissRequest={probe=false},title={Text("Send a real request?")},text={Text("This may consume provider quota. Failure is not a verification pass.")},confirmButton={TextButton(onClick={probe=false;client.launch{client.api("/v1/providers/$name/probe","POST",JSONObject());client.refresh()}}){Text("Send")}},dismissButton={TextButton(onClick={probe=false}){Text("Cancel")}})
        }
    }}
}

@Composable private fun DeviceControls(client:JarvisClient,state:JarvisState,onConnect:()->Unit){
    val context=LocalContext.current
    Panel("Bluetooth trust"){
        Text(state.status)
        Text("NOT PAIRED → DENIED\nPAIRED + AUTHORIZED → ALLOWED\nREVOKED / UNPAIRED → DENIED",style=MaterialTheme.typography.bodyMedium)
        Text("The backend reads Windows OS pairing and validates this device's signing key. A LAN/IP/login/WebSocket connection alone grants no control.",style=MaterialTheme.typography.bodySmall)
        OutlinedButton(onClick={context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))}){Text("Open Android Bluetooth settings")}
        Text("Public key fingerprint — compare on the local Windows OWNER HUD:",style=MaterialTheme.typography.labelMedium)
        Text(state.device?.optString("fingerprint").orEmpty(),style=MaterialTheme.typography.bodySmall)
        Button(onClick=onConnect){Text("Authenticate & reconnect")}
        TextButton(onClick={client.disconnect()}){Text("Disconnect")}
        var reset by remember{mutableStateOf(false)}
        TextButton(onClick={reset=true}){Text("Revoke / reset this device")}
        if(reset)AlertDialog(onDismissRequest={reset=false},title={Text("Reset device identity?")},text={Text("The old key is revoked and removed. New OWNER binding is required. Login is not automatic authorization.")},confirmButton={TextButton(onClick={reset=false;client.launch{client.resetDevice()}}){Text("Reset")}},dismissButton={TextButton(onClick={reset=false}){Text("Cancel")}})
    }
    Panel("Preserved foundation"){
        Text("Existing Brahma chat rendering, encrypted pairing preference store, device command handlers, CameraX/ML Kit scanner, theme and foreground service are reused.")
        Text("The app executes Android-only handler actions sent by the authorized backend. Windows actions always run on the PC through Brain.")
        Text("© 2026 Suryaansh Tiwari · Brahma Source-Available License. Native/physical acceptance remains NOT VERIFIED until tested on a real device.",style=MaterialTheme.typography.labelSmall)
    }
}
