package com.brahma.connect.jarvis

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.Signature
import java.security.spec.ECGenParameterSpec

/** Device-only credential material. No memory/task/Combo database on Android. */
class JarvisDeviceKey(private val userId: String) {
    private val alias = "jarvis.device.$userId"
    private fun store(): KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private fun ensure() {
        require(userId.matches(Regex("[a-f0-9]{32}"))) { "Invalid backend user identity" }
        if (!store().containsAlias(alias)) {
            val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            generator.initialize(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                .setDigests(KeyProperties.DIGEST_SHA256).build())
            generator.generateKeyPair()
        }
    }
    fun publicKey(): String { ensure(); return Base64.encodeToString(store().getCertificate(alias).publicKey.encoded, Base64.NO_WRAP) }
    fun sign(message: String): String {
        ensure()
        val signature = Signature.getInstance("SHA256withECDSA")
        signature.initSign(store().getKey(alias, null) as java.security.PrivateKey)
        signature.update(message.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(signature.sign(), Base64.NO_WRAP)
    }
    fun remove() { store().deleteEntry(alias) }
    companion object {
        fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it.toInt() and 255) }
    }
}
