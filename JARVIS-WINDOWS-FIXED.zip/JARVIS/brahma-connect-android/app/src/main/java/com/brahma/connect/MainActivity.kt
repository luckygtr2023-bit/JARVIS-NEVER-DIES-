package com.brahma.connect

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.brahma.connect.jarvis.JarvisApp
import com.brahma.connect.jarvis.JarvisClient
import com.brahma.connect.jarvis.JarvisRuntime
import com.brahma.connect.ui.theme.BrahmaConnectTheme
import kotlinx.coroutines.*
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var client: JarvisClient
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    private var exportData: String?=null
    private var pendingVoice=false
    private var speaker:TextToSpeech?=null
    private val cameraPermission=registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val connectPermissions=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        if(Build.VERSION.SDK_INT<31 || ContextCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED) startGatewayService()
        else client.launch { error("Bluetooth permission denied; the client will not start control.") }
    }
    private val microphone=registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if(granted&&pendingVoice)recognizeVoice() else if(!granted)client.launch{error("Microphone permission denied. No recording was started.")}
        pendingVoice=false
    }
    private val voice=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){result->
        val text=result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if(result.resultCode==RESULT_OK&&!text.isNullOrBlank())client.launch{client.submit(text,voice=true)}
    }
    private val importMemory=registerForActivityResult(ActivityResultContracts.GetContent()){uri->
        if(uri!=null)client.launch{
            val raw=contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()} ?: error("Cannot read import")
            require(raw.length<=1_000_000){"Memory import is too large"}
            client.api("/v1/memory/import","POST",JSONObject(raw));client.refresh()
        }
    }
    private val exportMemory=registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->
        val data=exportData;exportData=null
        if(uri!=null&&data!=null)client.launch{contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(data)}}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        client=JarvisRuntime.client(this)
        speaker=TextToSpeech(this){status->if(status==TextToSpeech.SUCCESS)speaker?.language=Locale.getDefault()}
        client.onSpeak={text->runOnUiThread{val result=speaker?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"jarvis-reply");if(result==TextToSpeech.ERROR)client.launch{error("Speech playback unavailable. Voice output is NOT VERIFIED on this device.")}}}
        setContent { BrahmaConnectTheme { JarvisApp(client,onConnect={requestConnect()},onVoice={requestVoice()},onCamera={cameraPermission.launch(Manifest.permission.CAMERA)},onImport={importMemory.launch("application/json")},onExport={client.launch{val document=client.api("/v1/memory/export") as JSONObject;withContext(Dispatchers.Main){exportData=document.toString(2);exportMemory.launch("jarvis-memory.json")}}}) } }
        if(client.hasSession())client.launch{client.restore();withContext(Dispatchers.Main){if(Build.VERSION.SDK_INT<31 || ContextCompat.checkSelfPermission(this@MainActivity,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED)startGatewayService()}}
    }

    private fun requestConnect(){
        val permissions=buildList{
            if(Build.VERSION.SDK_INT>=31)add(Manifest.permission.BLUETOOTH_CONNECT)
            if(Build.VERSION.SDK_INT>=33)add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if(permissions.isEmpty())startGatewayService() else connectPermissions.launch(permissions.toTypedArray())
    }
    private fun startGatewayService(){
        if(client.hasSession())ContextCompat.startForegroundService(this,Intent(this,BrahmaConnectForegroundService::class.java))
    }
    private fun requestVoice(){
        if(!client.state.value.connected){client.launch{error("Authenticate Bluetooth trust before voice control.")};return}
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){pendingVoice=true;microphone.launch(Manifest.permission.RECORD_AUDIO)}else recognizeVoice()
    }
    private fun recognizeVoice(){
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT,"JARVIS — sent only through the authorized backend")
        if(intent.resolveActivity(packageManager)!=null)voice.launch(intent) else client.launch{error("No platform speech recognizer is installed. Voice is NOT VERIFIED on this device.")}
    }
    override fun onDestroy(){client.onSpeak=null;speaker?.shutdown();scope.cancel();super.onDestroy()}
}
