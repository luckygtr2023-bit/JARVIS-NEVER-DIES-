package com.brahma.connect.jarvis

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.brahma.connect.R
import com.brahma.connect.commands.DeviceCommandHandler
import com.brahma.connect.core.AgentStateStore
import com.brahma.connect.core.BrahmaProtocol
import com.brahma.connect.core.ChatMessage
import com.brahma.connect.core.ConnectionState
import com.brahma.connect.pairing.PairingStorage
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URI
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/** Same backend, same existing Android handlers. No direct Windows execution. */
data class JarvisState(
    val user: JSONObject? = null, val device: JSONObject? = null,
    val connected: Boolean = false, val status: String = "Signed out", val error: String? = null,
    val tasks: List<JSONObject> = emptyList(), val memories: List<JSONObject> = emptyList(),
    val combos: List<JSONObject> = emptyList(), val providers: JSONObject = JSONObject(),
    val routing: JSONObject = JSONObject(), val memorySettings: JSONObject = JSONObject(),
)

class JarvisClient(private val context: Context) {
    private val storage = PairingStorage(context)
    private val handler = DeviceCommandHandler(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutableState = MutableStateFlow(JarvisState())
    val state = mutableState.asStateFlow()
    private var socket: WebSocket? = null
    private var reconnect: Job? = null
    private var ping: Job? = null
    @Volatile private var manualDisconnect = false
    @Volatile private var epoch = 0L
    private var attempts = 0
    private var cachedClient: Pair<String, OkHttpClient>? = null
    var onSpeak: ((String) -> Unit)? = null
    private val voiceTasks = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    private fun session(): JSONObject = storage.loadJarvisSession() ?: JSONObject()
    fun configuredUrl(): String = session().optString("base_url")
    fun configuredPin(): String = session().optString("certificate_pin")
    fun hasSession(): Boolean = session().optString("token").isNotBlank()
    private fun key(): JarvisDeviceKey = JarvisDeviceKey(session().getJSONObject("user").getString("id"))

    private fun http(base: String, pin: String): OkHttpClient {
        val uri = URI(base)
        require(uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null && uri.rawQuery == null && uri.fragment == null && (uri.path.isNullOrBlank() || uri.path == "/")) { "Use the HTTPS backend origin, without credentials or /app paths." }
        require(pin.isBlank() || pin.matches(Regex("[0-9a-fA-F]{64}"))) { "Certificate pin must be 64 SHA-256 hexadecimal characters." }
        val cacheKey = "$base|$pin"
        cachedClient?.takeIf { it.first == cacheKey }?.let { return it.second }
        val builder = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(false).followSslRedirects(false).retryOnConnectionFailure(false).pingInterval(20, TimeUnit.SECONDS)
        if (pin.isNotBlank()) {
            // Optional self-signed deployment: exact leaf pin, validity check AND
            // OkHttp's normal hostname verifier. Never a trust-all manager.
            val manager = object : X509TrustManager {
                override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
                override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) { throw java.security.cert.CertificateException("Client certificates unsupported") }
                override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {
                    val leaf = chain?.firstOrNull() ?: throw java.security.cert.CertificateException("Missing certificate")
                    leaf.checkValidity()
                    if (!JarvisDeviceKey.sha256(leaf.encoded).equals(pin, ignoreCase = true)) throw java.security.cert.CertificateException("Backend certificate pin mismatch")
                }
            }
            val ssl = SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(manager), SecureRandom()) }
            builder.sslSocketFactory(ssl.socketFactory, manager)
        }
        return builder.build().also { cachedClient = cacheKey to it }
    }

    private suspend fun raw(base: String, pin: String, token: String, path: String, method: String, body: String?, extra: Map<String,String> = emptyMap()): Any = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(base.trimEnd('/') + path)
        if (token.isNotBlank()) request.header("Authorization", "Bearer $token")
        extra.forEach { (name,value) -> request.header(name,value) }
        val payload = body?.toRequestBody("application/json; charset=utf-8".toMediaType())
        request.method(method, if (method in listOf("GET","HEAD")) null else payload ?: "{}".toRequestBody("application/json".toMediaType()))
        http(base,pin).newCall(request.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val code = runCatching { JSONObject(text).optString("error", "HTTP_${response.code}") }.getOrDefault("HTTP_${response.code}")
                throw JarvisApiError(response.code, code)
            }
            JSONTokener(text).nextValue()
        }
    }

    suspend fun api(path: String, method: String = "GET", body: JSONObject? = null, control: Boolean = true): Any {
        val started = epoch
        val saved = session()
        val token = saved.optString("token")
        require(token.isNotBlank()) { "Login required" }
        val base = saved.getString("base_url"); val pin = saved.optString("certificate_pin")
        val encoded = body?.toString() ?: if (method in listOf("GET","HEAD")) null else "{}"
        val headers = mutableMapOf<String,String>()
        if (control) {
            val deviceId = saved.optJSONObject("device")?.optString("id").orEmpty()
            require(deviceId.isNotBlank()) { "Device registration and OWNER binding required" }
            val purpose = "HTTP:$method:$path:${JarvisDeviceKey.sha256(encoded.orEmpty().toByteArray(Charsets.UTF_8))}"
            val challenge = raw(base,pin,token,"/v1/devices/challenge","POST",JSONObject().put("device_id",deviceId).put("purpose",purpose).toString()) as JSONObject
            headers["X-Jarvis-Challenge"] = challenge.getString("id")
            headers["X-Jarvis-Signature"] = JarvisDeviceKey(saved.getJSONObject("user").getString("id")).sign(challenge.getString("message"))
        }
        val result = raw(base,pin,token,path,method,encoded,headers)
        if (epoch != started) throw CancellationException("Account changed; stale response discarded")
        return result
    }

    suspend fun login(baseUrl: String, certificatePin: String, username: String, password: String) {
        disconnect(); epoch++
        storage.clearJarvisSession(); AgentStateStore.setChatHistory(emptyList())
        val base = baseUrl.trim().trimEnd('/'); val pin = certificatePin.replace(":", "").trim().lowercase()
        http(base,pin) // Validate before sending credentials; never reuse a token on a different host.
        val result = raw(base,pin,"","/v1/auth/login","POST",JSONObject().put("username",username).put("password",password).toString()) as JSONObject
        require(result.getString("channel") == "remote") { "Android must be a device-authenticated remote client" }
        result.put("base_url",base).put("certificate_pin",pin)
        storage.saveJarvisSession(result)
        mutableState.value = JarvisState(user=result.getJSONObject("user"),status="Logged in. Registration/pairing required.")
        registerDevice()
    }

    suspend fun restore() {
        if (!hasSession()) return
        val saved = session()
        mutableState.update { it.copy(user=saved.optJSONObject("user"),device=saved.optJSONObject("device"),status="Revalidating session") }
        val me = api("/v1/auth/me", control=false) as JSONObject
        mutableState.update { it.copy(user=me.getJSONObject("user")) }
        if (saved.optJSONObject("device")==null) registerDevice()
    }

    suspend fun registerDevice() {
        val device = api("/v1/devices/register","POST",JSONObject().put("name",Build.MODEL ?: "Android").put("platform","android").put("public_key",key().publicKey()),false) as JSONObject
        val saved = session().put("device",device)
        storage.saveJarvisSession(saved)
        mutableState.update { it.copy(device=device,status="Registered, not trusted. Pair in Windows and compare the fingerprint with the local OWNER.") }
    }

    suspend fun connect() {
        if (!hasSession()) return
        manualDisconnect = false
        if (reconnect != currentCoroutineContext()[Job]) reconnect?.cancel()
        reconnect = null
        ping?.cancel()
        val saved = session(); val device = saved.optJSONObject("device") ?: return
        val started = epoch
        try {
            val challenge = api("/v1/devices/challenge","POST",JSONObject().put("device_id",device.getString("id")).put("purpose","bus"),false) as JSONObject
            val signature = key().sign(challenge.getString("message"))
            socket?.close(1000,"Authenticated reconnect")
            mutableState.update { it.copy(connected=false,status="Checking Bluetooth trust and key authentication",error=null) }
            AgentStateStore.setConnectionState(ConnectionState.CONNECTING)
            val url = saved.getString("base_url").replaceFirst("https://","wss://") + "/v1/device-bus"
            val listener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) {
                    if (epoch!=started || manualDisconnect) { webSocket.close(1000,"Session changed"); return }
                    webSocket.send(JSONObject().put("type","authenticate").put("token",saved.getString("token")).put("challenge_id",challenge.getString("id")).put("signature",signature).toString())
                }
                override fun onMessage(webSocket: WebSocket, text: String) {
                    if (epoch!=started || socket!==webSocket) return
                    scope.launch { if (epoch==started && socket===webSocket) runCatching { handleMessage(webSocket, JSONObject(text)) } }
                }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { if (socket===webSocket && epoch==started) disconnected("Connection unavailable; control denied") }
                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(code, reason) }
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (socket===webSocket && epoch==started) disconnected("Connection closed; trust must be revalidated") }
            }
            socket = http(saved.getString("base_url"),saved.optString("certificate_pin")).newWebSocket(Request.Builder().url(url).build(),listener)
        } catch (error: Exception) { if (error !is CancellationException) disconnected(error.message ?: "Trust check failed") }
    }

    private suspend fun handleMessage(webSocket: WebSocket, message: JSONObject) {
        when (message.optString("type")) {
            "authenticated" -> {
                attempts=0
                mutableState.update { it.copy(connected=true,status="Backend-authenticated device; OS Bluetooth checked",error=null) }
                AgentStateStore.setConnectionState(ConnectionState.CONNECTED)
                AgentStateStore.setStatus("JARVIS Bluetooth-bound authentication complete")
                ping=scope.launch { while (isActive) { delay(20000); webSocket.send(JSONObject().put("type","ping").put("payload",JSONObject()).toString()); runCatching { reportStatus() } } }
                runCatching { refresh(); reportStatus() }
            }
            "task_status" -> {
                val payload=message.optJSONObject("payload") ?: return
                val status=payload.optString("state")
                val answer=payload.optString("final_response")
                if (answer.isNotBlank()) AgentStateStore.addChatMessage(ChatMessage(id=payload.getString("id"),text=answer,role="assistant",timestamp=System.currentTimeMillis(),status="received"))
                if (status == "completed" && voiceTasks.remove(payload.optString("id")) && answer.isNotBlank()) onSpeak?.invoke(answer.take(4000))
                if (status in listOf("awaiting_confirmation","completed","failed")) notifyTask(status,answer)
                runCatching { refreshTasks() }
            }
            "execute" -> {
                if (!state.value.connected) return
                val payload=message.optJSONObject("payload") ?: return
                val action=payload.optString("action")
                // Only the existing ANDROID handlers are callable. No Windows shell,
                // command line, arbitrary code, or backend execution inside this app.
                val allowed=setOf("get_device_info","get_battery","flashlight_on","flashlight_off","launch_app","open_url","volume_get","volume_set","file_list","file_read","file_write","file_delete")
                val result=if(action in allowed){
                    val params=payload.optJSONObject("parameters") ?: JSONObject()
                    handler.handle(action,params.keys().asSequence().associateWith { params.opt(it) }).toJson()
                }else JSONObject().put("success",false).put("error_code","UNSUPPORTED_ANDROID_ACTION").put("error","Windows/arbitrary commands are never executed by Android.")
                webSocket.send(BrahmaProtocol.envelope(BrahmaProtocol.RESULT,result,message.optString("request_id")).toString())
            }
            "error" -> {
                val code=message.optJSONObject("payload")?.optString("error").orEmpty()
                mutableState.update { it.copy(connected=false,status="Control denied",error=code) }
            }
        }
    }

    private fun disconnected(reason: String) {
        ping?.cancel()
        mutableState.update { it.copy(connected=false,status=reason) }
        AgentStateStore.setConnectionState(ConnectionState.RECONNECTING)
        if (!manualDisconnect && hasSession()) {
            attempts++
            reconnect=scope.launch { delay(minOf(30000L,1000L * (1L shl minOf(attempts,5)))); connect() }
        }
    }
    fun disconnect() {
        manualDisconnect=true;reconnect?.cancel();ping?.cancel();socket?.close(1000,"Disconnected");socket=null
        mutableState.update { it.copy(connected=false,status="Disconnected; control denied") }
        AgentStateStore.setConnectionState(ConnectionState.DISCONNECTED)
    }
    suspend fun logout() {
        runCatching { api("/v1/auth/logout","POST",JSONObject(),false) }
        disconnect();epoch++;voiceTasks.clear();storage.clearJarvisSession();mutableState.value=JarvisState();AgentStateStore.setChatHistory(emptyList())
    }
    suspend fun onLocalUnpair() {
        // A client can remove its own authority, never grant it. Windows also
        // queries its own OS bond before every protected control operation.
        val id=session().optJSONObject("device")?.optString("id")
        if (!id.isNullOrBlank()) runCatching { api("/v1/devices/$id/revoke","POST",JSONObject(),false) }
        disconnect();mutableState.update { it.copy(status="Local unpair observed. Control denied; fresh OWNER registration required.") }
    }
    suspend fun resetDevice() { val old=session();runCatching { onLocalUnpair() };if(old.optJSONObject("user")!=null)JarvisDeviceKey(old.getJSONObject("user").getString("id")).remove();logout() }

    suspend fun submit(text: String, voice: Boolean=false) {
        require(state.value.connected) { "Authenticate Bluetooth trust first" }
        val result=api(if(voice)"/v1/voice/transcript" else "/v1/tasks","POST",JSONObject().put("text",text)) as JSONObject
        if (voice) voiceTasks.add(result.getString("id"))
        AgentStateStore.addChatMessage(ChatMessage(id=UUID.randomUUID().toString(),text=text,role="user",timestamp=System.currentTimeMillis(),status="sent"))
        mutableState.update { it.copy(status="Task ${result.optString("id").take(8)} accepted by backend") };refreshTasks()
        if (voice) state.value.tasks.firstOrNull { it.optString("id")==result.optString("id") && it.optString("state")=="completed" }?.let { task ->
            if (voiceTasks.remove(task.getString("id"))) onSpeak?.invoke(task.optString("final_response").take(4000))
        }
    }
    suspend fun refreshTasks() { val array=api("/v1/tasks") as JSONArray;mutableState.update { it.copy(tasks=array.objects()) } }
    suspend fun refresh() {
        if (!state.value.connected) return
        refreshTasks()
        val memories=api("/v1/memory") as JSONArray
        val combos=api("/v1/combos") as JSONArray
        val providers=api("/v1/providers") as JSONObject
        val routing=api("/v1/routing") as JSONObject
        val memorySettings=api("/v1/memory/settings") as JSONObject
        mutableState.update { it.copy(memories=memories.objects(),combos=combos.objects(),providers=providers,routing=routing,memorySettings=memorySettings) }
    }
    fun launch(block: suspend () -> Unit) { scope.launch { try { block() } catch(error:Exception) { if(error !is CancellationException) { mutableState.update { it.copy(error=error.message ?: "Request failed") }; if(error is JarvisApiError && error.status==401){ disconnect();epoch++;storage.clearJarvisSession();mutableState.value=JarvisState(error="Session expired. Sign in again.");AgentStateStore.setChatHistory(emptyList()) } } } } }
    fun clearError() { mutableState.update { it.copy(error=null) } }
    private suspend fun reportStatus() {
        val battery=handler.handle("get_battery",emptyMap()).data
        val bt=runCatching { (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.bondedDevices?.size ?: 0 }.getOrDefault(-1)
        api("/v1/devices/status","POST",JSONObject().put("battery",battery["percentage"]).put("charging",battery["charging"]).put("bluetooth_reported",if(bt<0)"permission unavailable" else "$bt local bonds; informational only").put("app_version","0.2.0").put("microphone_permission",ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED).put("notification_permission",Build.VERSION.SDK_INT<33 || ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED))
    }
    private fun notifyTask(status: String, text: String) {
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("jarvis_tasks","JARVIS task status",NotificationManager.IMPORTANCE_DEFAULT))
        manager.notify(5302,NotificationCompat.Builder(context,"jarvis_tasks").setSmallIcon(R.drawable.ic_jarvis_launcher).setContentTitle(if(status=="awaiting_confirmation")"JARVIS: confirmation required" else "JARVIS: $status").setContentText(text.take(120).ifBlank { "Review the exact action in Tasks." }).setAutoCancel(true).build())
    }
    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
}
class JarvisApiError(val status:Int, code:String): Exception(code)
object JarvisRuntime {
    @Volatile private var instance: JarvisClient?=null
    fun client(context:Context):JarvisClient = instance ?: synchronized(this) { instance ?: JarvisClient(context.applicationContext).also { instance=it } }
}
