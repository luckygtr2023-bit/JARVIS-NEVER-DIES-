"""Exercise the inherited updater against temporary local Git repositories only."""
import subprocess
from unittest.mock import Mock

import updater


def git(cwd, *args):
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout


def test_fast_forward_update_preserved_and_dirty_files_protected(tmp_path, monkeypatch):
    monkeypatch.delenv("BRAHMA_SKIP_UPDATE", raising=False)
    remote, source, checkout = tmp_path / "remote.git", tmp_path / "source", tmp_path / "checkout"
    remote.mkdir()
    source.mkdir()
    git(remote, "init", "--bare", "--initial-branch=main")
    git(source, "init", "--initial-branch=main")
    git(source, "config", "user.name", "Foundation test")
    git(source, "config", "user.email", "fixture@example.invalid")
    (source / "content.txt").write_text("baseline")
    git(source, "add", "content.txt")
    git(source, "commit", "-m", "baseline")
    git(source, "remote", "add", "origin", str(remote))
    git(source, "push", "-u", "origin", "main")
    git(tmp_path, "clone", str(remote), str(checkout))
    (source / "content.txt").write_text("fast-forward")
    git(source, "commit", "-am", "update")
    git(source, "push", "origin", "main")
    assert updater.update_from_github(checkout)
    assert (checkout / "content.txt").read_text() == "fast-forward"
    (checkout / "content.txt").write_text("private adaptation")
    assert not updater.update_from_github(checkout)
    assert (checkout / "content.txt").read_text() == "private adaptation"


def test_gui_updater_delegates_to_safe_upstream_implementation(monkeypatch):
    import core.updater as gui
    update, restart = Mock(return_value=False), Mock()
    monkeypatch.setattr(gui, "update_from_github", update)
    monkeypatch.setattr(gui, "restart_application", restart)
    gui.apply_update_and_restart()
    update.assert_called_once_with(gui.BASE_DIR)
    restart.assert_not_called()
    update.return_value = True
    gui.apply_update_and_restart()
    restart.assert_called_once_with(gui.BASE_DIR)


def test_update_opt_out_is_respected(tmp_path):
    import core.updater as gui
    assert not updater.update_from_github(tmp_path)
    checker = gui.UpdateChecker()
    checker.start()
    assert checker._check_thread is None
