import importlib
import io
import os

import pytest
from PIL import Image


def test_real_browser_navigation_forms_tabs_and_reopen(monkeypatch):
    if os.environ.get("RUN_BROWSER_TESTS") != "1":
        pytest.skip("Set RUN_BROWSER_TESTS=1 after playwright install chromium, with a display")
    browser = importlib.import_module("actions.browser_control")
    bt = browser._BrowserThread()
    monkeypatch.setattr(browser, "_bt", bt)
    monkeypatch.setattr(browser, "_bt_started", False)
    html = """<!doctype html><title>Foundation fixture</title><h1>Browser baseline</h1>
    <input id='name'><button id='submit' onclick="document.querySelector('h1').textContent='Hello '+document.querySelector('input').value">Apply</button>"""

    async def setup_fixture():
        page = await bt._get_page()
        await page.route("**/*", lambda route: route.fulfill(status=200, content_type="text/html", body=html))

    try:
        browser._ensure_started()
        bt.run(setup_fixture())
        assert "Opened:" in browser.browser_control({"action": "navigate", "url": "http://foundation.test"})
        assert "Text typed" in browser.browser_control({"action": "type", "selector": "#name", "text": "Foundation"})
        assert "Clicked" in browser.browser_control({"action": "click", "selector": "#submit"})
        assert "Hello Foundation" in browser.browser_control({"action": "get_text"})
        assert "Opened new tab" in browser.browser_control({"action": "open_tab"})
        assert "Switched to tab 1" in browser.browser_control({"action": "switch_tab", "tab": 1})
        assert "Foundation fixture" in browser.browser_control({"action": "list_tabs"})
        assert browser.browser_control({"action": "close"}) == "Browser closed."
        assert "Opened new tab" in browser.browser_control({"action": "open_tab"})
    finally:
        if bt._loop and bt._loop.is_running():
            bt.run(bt._close_browser())
            bt._loop.call_soon_threadsafe(bt._loop.stop)
            bt._thread.join(timeout=5)
            if not bt._thread.is_alive():
                bt._loop.close()


def test_real_virtual_display_capture():
    if os.environ.get("RUN_QT_TESTS") != "1":
        pytest.skip("Requires an interactive or virtual display")
    screen = importlib.import_module("actions.screen_processor")
    data = screen._capture_screenshot()
    img = Image.open(io.BytesIO(data))
    assert img.format == "JPEG"
    assert 0 < img.width <= screen.IMG_MAX_W
    assert 0 < img.height <= screen.IMG_MAX_H


def test_voice_notification_sink_without_audio_hardware(monkeypatch):
    from actions import attention_monitor as voice
    seen = []
    monkeypatch.setattr(voice, "_speech_sink", None)
    voice.set_speech_sink(seen.append)
    voice.speak_native(" Foundation voice route ")
    voice.speak_native(" ")
    assert seen == ["Foundation voice route"]
