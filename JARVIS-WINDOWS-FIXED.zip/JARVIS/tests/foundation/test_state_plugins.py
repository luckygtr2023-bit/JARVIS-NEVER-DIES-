import json
from pathlib import Path

from plugin_manager import PluginManager


def test_memory_persistence_and_prompt(isolated_state):
    from memory import memory_manager as m
    m.update_memory({"preferences": {"output": "Concise reports"}})
    assert m.load_memory()["preferences"]["output"]["value"] == "Concise reports"
    assert "Concise reports" in m.format_memory_for_prompt(m.load_memory())
    m.MEMORY_PATH.write_text("invalid json")
    assert m.load_memory() == m._empty_memory()


def test_workspace_chat_roundtrip(isolated_state):
    from workspace_store import WorkspaceStore
    db = isolated_state / "config" / "workspace.sqlite3"
    store = WorkspaceStore(db)
    cid = store.create_conversation("Foundation conversation")
    store.append_message(cid, "user", "Preserve my workflows")
    store.append_message(cid, "assistant", "Foundation retained")
    reopened = WorkspaceStore(db)
    payloads = reopened.get_message_payloads(cid)
    assert [x["content"] for x in payloads] == ["Preserve my workflows", "Foundation retained"]
    export = isolated_state / "conversation.json"
    reopened.export_conversation(cid, export)
    assert "Foundation retained" in export.read_text()


def test_identity_keeps_existing_owner_and_custom_name(isolated_state):
    import core.identity as m
    m.identity.set_owner_name("Test Owner")
    m.identity.set_assistant_name("Custom assistant")
    reloaded = m.IdentityService()
    assert reloaded.get_owner_name() == "Test Owner"
    assert reloaded.get_assistant_name() == "Custom assistant"


def test_plugins_legacy_hooks_and_error_isolation(tmp_path):
    plugins = tmp_path / "plugins"
    plugins.mkdir()
    (plugins / "00_broken.py").write_text("raise RuntimeError('fixture failure')\n")
    (plugins / "01_good.py").write_text('''events = []
def on_brahma_created(brahma):
    events.append("created")
def on_startup(brahma):
    events.append("started")
def on_text_command(text, source, brahma_echo=None):
    events.append((text, source, brahma_echo))
    return text == "handle me"
''')
    manager = PluginManager(tmp_path)
    manager.load_plugins()
    assert len(manager.plugins) == 1
    assistant = object()
    manager.register_brahma(assistant)
    manager.dispatch("on_startup", assistant)
    assert manager.dispatch("on_text_command", "handle me", "test") is True
    assert manager.plugins[0].events == ["created", "started", ("handle me", "test", assistant)]
