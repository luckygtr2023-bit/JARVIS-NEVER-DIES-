"""Offline regression checks. Paths and external boundaries are isolated, not engines."""
import os
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture(autouse=True)
def no_provider_network(monkeypatch):
    import requests

    def denied(*args, **kwargs):
        raise AssertionError("Live HTTP is not allowed in offline foundation tests")

    monkeypatch.setattr(requests.sessions.Session, "request", denied)
    monkeypatch.setenv("BRAHMA_SKIP_UPDATE", "1")


@pytest.fixture
def isolated_state(tmp_path, monkeypatch):
    import core.identity as identity_module
    import workspace_store
    import memory.memory_manager as memory
    import smart_home.storage as home_storage

    config = tmp_path / "config"
    config.mkdir()
    monkeypatch.setattr(identity_module, "get_base_dir", lambda: tmp_path)
    monkeypatch.setattr(identity_module, "identity", identity_module.IdentityService())
    monkeypatch.setattr(workspace_store, "CONFIG_DIR", config)
    monkeypatch.setattr(workspace_store, "STORE_FILE", config / "workspace_store.sqlite3")
    monkeypatch.setattr(memory, "MEMORY_PATH", tmp_path / "memory" / "long_term.json")
    monkeypatch.setattr(home_storage, "CONFIG_DIR", config)
    monkeypatch.setattr(home_storage, "DB_FILE", config / "smart_home.sqlite3")
    monkeypatch.setattr(home_storage.CredentialVault.__init__, "__defaults__", (config / "smart_home.key",))
    return tmp_path


@pytest.fixture
def qt_app():
    if os.environ.get("RUN_QT_TESTS") != "1":
        pytest.skip("Set RUN_QT_TESTS=1 with an interactive or virtual display")
    from PyQt6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    yield app
    for window in app.topLevelWidgets():
        window.hide()
        window.deleteLater()
    app.processEvents()


@pytest.fixture
def qt_ui(qt_app, isolated_state, monkeypatch):
    import ui
    import core.identity
    from core.updater import UpdateChecker

    config = isolated_state / "config"
    monkeypatch.setattr(ui, "CONFIG_DIR", config)
    monkeypatch.setattr(ui, "API_FILE", config / "api_keys.json")
    monkeypatch.setattr(ui, "APP_SETTINGS_FILE", config / "app_settings.json")
    monkeypatch.setattr(ui, "DISCORD_SETTINGS_FILE", config / "discord_bot.json")
    monkeypatch.setattr(ui, "identity", core.identity.identity)
    # Exercise the inherited native Qt fallback, not Chromium/WebGL in this test.
    monkeypatch.setattr(ui, "WEB_ENGINE_AVAILABLE", False)
    monkeypatch.setattr(UpdateChecker, "start", lambda self: None)
    # UI construction must not rewrite a real Windows startup registry value.
    monkeypatch.setattr(ui.MainWindow, "_startup_enabled", lambda self: False)
    return ui
