"""Rebrand guardrails: notices, public symbols, tool schemas and legacy protocols."""
import ast
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = json.loads((ROOT / "foundation" / "UPSTREAM.json").read_text())


def omitted_release_artifact(path):
    """Cleaning a release removes only documented non-runtime artifacts.

    This is not an exemption for actions/UI/core/license files. The source-tree
    test still requires every original path when no release manifest is present.
    """
    manifest = ROOT / "RELEASE_MANIFEST.json"
    if not manifest.exists() or (ROOT / path).exists():
        return False
    allowed = path.startswith(("extra/", "brahma-connect-android/.gradle/")) or path == "test_ig.py"
    excluded = json.loads(manifest.read_text()).get("excluded_upstream_artifacts", [])
    assert allowed and path in excluded, f"Undocumented or runtime source removal: {path}"
    return True


def test_original_notices_and_brand_assets_are_retained():
    paths = {"LICENSE", "TRADEMARK.md", "assets/Brahma_Lite_Logo.png", "assets/Brahma_Lite_Logo.ico",
             "assets/web_background/three.min.js", "brahma-connect-android/gradlew", "brahma-connect-android/gradlew.bat"}
    for item in MANIFEST["files"]:
        if omitted_release_artifact(item["path"]):
            continue
        assert (ROOT / item["path"]).exists(), f"Inherited file removed: {item['path']}"
        if item["path"] in paths:
            assert hashlib.sha256((ROOT / item["path"]).read_bytes()).hexdigest() == item["sha256"]


def test_all_inherited_python_symbols_remain():
    for item in MANIFEST["files"]:
        if not item["path"].endswith(".py") or omitted_release_artifact(item["path"]):
            continue
        before = Counter((n["kind"], n["name"]) for n in item["symbols"])
        tree = ast.parse((ROOT / item["path"]).read_text(encoding="utf-8-sig"))
        after = Counter((type(n).__name__, n.name) for n in ast.walk(tree)
                        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)))
        assert not before - after, f"Removed symbols in {item['path']}: {before - after}"


def test_tool_names_and_parameter_contracts_are_retained():
    def contract(value):
        if isinstance(value, list):
            return [contract(x) for x in value]
        if isinstance(value, dict):
            return {k: contract(v) for k, v in value.items() if not (k == "description" and isinstance(v, str))}
        return value
    tree = ast.parse((ROOT / "main.py").read_text(encoding="utf-8"))
    value = next(n.value for n in tree.body if isinstance(n, ast.Assign)
                 and any(isinstance(t, ast.Name) and t.id == "TOOL_DECLARATIONS" for t in n.targets))
    expected = json.loads((ROOT / "foundation" / "TOOL_CONTRACT.json").read_text())
    assert contract(ast.literal_eval(value)) == contract(expected)


def test_brand_defaults_and_expansion(isolated_state):
    from core.identity import identity, APPLICATION_NAME, ASSISTANT_TITLE
    assert APPLICATION_NAME == "J.A.R.V.I.S."
    assert ASSISTANT_TITLE == "Just A Rather Very Intelligent System"
    assert identity.get_assistant_name() == APPLICATION_NAME
    assert identity.get_application_name() == APPLICATION_NAME
    assert identity.get_assistant_title() == ASSISTANT_TITLE


@pytest.mark.parametrize("text", ["Jarvis", "Hey Jarvis", "J.A.R.V.I.S.", "Brahma Echo", "hello"])
def test_rebranded_and_legacy_wake_cues(text):
    tree = ast.parse((ROOT / "main.py").read_text(encoding="utf-8"))
    fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "_wakeword_detected")
    ns = {"re": re}
    exec(compile(ast.Module(body=[fn], type_ignores=[]), "main.py", "exec"), ns)
    assert ns["_wakeword_detected"](text)
    assert not ns["_wakeword_detected"]("this is an ordinary sentence")


def test_qt_brand_and_legacy_history(qt_ui, qt_app):
    from core.identity import APPLICATION_NAME
    for prefix in ("J.A.R.V.I.S.", "Brahma Echo"):
        assert qt_ui.LogWidget._parse(None, f"{prefix}: Retained history") == ("assistant", APPLICATION_NAME, "Retained history")
    shell = qt_ui.BrahmaUI(face_path="", show_immediately=False)
    assert shell._win.windowTitle() == APPLICATION_NAME
    assert shell._app.applicationDisplayName() == APPLICATION_NAME
    assert shell._tray.toolTip() == APPLICATION_NAME
    shell._discord_service.stop()
    shell._updater.stop()


def test_android_and_desktop_keep_discovery_and_storage_contracts():
    config = json.loads((ROOT / "config" / "brahma_connect.json").read_text())
    assert config["service_name"] == "_BRAHMA._tcp.local."
    android = ROOT / "brahma-connect-android" / "app"
    assert 'applicationId = "com.brahma.connect"' in (android / "build.gradle.kts").read_text()
    code = android / "src/main/java/com/brahma/connect"
    assert '"brahma_connect_secure"' in (code / "pairing/PairingStorage.kt").read_text()
    assert '"_BRAHMA._tcp."' in (code / "network/BrahmaGatewayDiscovery.kt").read_text()
    assert '"shutdown_brahma"' in (ROOT / "main.py").read_text()
    assert '"Brahma Echo"' in (ROOT / "ui.py").read_text()  # Existing Windows Run registry value.
