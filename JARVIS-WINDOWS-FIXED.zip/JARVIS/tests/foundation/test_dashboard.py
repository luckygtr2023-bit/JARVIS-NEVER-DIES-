import base64
import os

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from fastapi.testclient import TestClient


def test_dashboard_one_time_login_encrypted_command_and_upload(tmp_path, monkeypatch):
    import dashboard.server as m
    monkeypatch.setattr(m, "_local_ip", lambda: "127.0.0.1")
    monkeypatch.setattr(m, "UPLOADS_DIR", tmp_path)
    server = m.DashboardServer()
    key = server.new_key()
    with TestClient(server.app) as client:
        assert client.post("/api/command", json={}).status_code == 401
        response = client.post("/login", json={"pin": key})
        assert response.status_code == 200
        token = response.json()["token"]
        assert client.post("/login", json={"pin": key}).status_code == 401
        assert m._AES_SALT == b"BRAHMA-DASHBOARD-v1"
        assert m._AES_SALT.decode() in server._app_html  # Wire salt must not be rebranded.
        iv = os.urandom(16)
        padder = padding.PKCS7(128).padder()
        plaintext = b"Read only synthetic command"
        padded = padder.update(plaintext) + padder.finalize()
        encryptor = Cipher(algorithms.AES(m._derive_key(key)), modes.CBC(iv)).encryptor()
        encrypted = base64.b64encode(iv + encryptor.update(padded) + encryptor.finalize()).decode()
        assert server._decrypt(token, encrypted) == plaintext.decode()
        headers = {"Authorization": f"Bearer {token}"}
        uploaded = client.post("/api/upload", headers=headers, files={"file": ("fixture.txt", b"fixture", "text/plain")})
        assert uploaded.status_code == 200
        assert (tmp_path / "fixture.txt").read_text() == "fixture"


def test_public_background_route_cannot_escape_assets(tmp_path, monkeypatch):
    import dashboard.server as m
    monkeypatch.setattr(m, "_local_ip", lambda: "127.0.0.1")
    monkeypatch.setattr(m, "BASE_DIR", tmp_path)
    assets = tmp_path / "assets" / "web_background"
    assets.mkdir(parents=True)
    (assets / "index.html").write_text("Public background")
    config = tmp_path / "config"
    config.mkdir()
    (config / "fixture.txt").write_text("Synthetic private fixture")
    server = m.DashboardServer()
    with TestClient(server.app) as client:
        assert client.get("/web_background/index.html").status_code == 200
        response = client.get("/web_background/..%2f..%2fconfig/fixture.txt")
        assert response.status_code == 404
        assert "Synthetic private fixture" not in response.text


def test_actual_cryptojs_browser_ciphertext_is_accepted(monkeypatch):
    import json
    from pathlib import Path
    import shutil
    import subprocess
    import pytest
    import dashboard.server as m
    if not shutil.which("node"):
        pytest.skip("Node.js is required for the real inherited CryptoJS integration probe")
    monkeypatch.setattr(m, "_local_ip", lambda: "127.0.0.1")
    server = m.DashboardServer()
    key = server.new_key()
    html = server._app_html
    # Run the actual frontend encryption code, not a Python equivalent of the server.
    crypto_code = html[html.index("    const _AES_SALT"):html.index("    const _encReady")]
    text = "Synthetic browser-to-server encrypted command"
    script = f"const CryptoJS = require({json.dumps(str(m._CRYPTOJS_FILE))});\n{crypto_code}\n_initCrypto({json.dumps(key)});process.stdout.write(_encrypt({json.dumps(text)}));"
    ciphertext = subprocess.check_output(["node", "-e", script], text=True, timeout=15).strip()
    with TestClient(server.app) as client:
        token = client.post("/login", json={"pin": key}).json()["token"]
        response = client.post("/api/command", headers={"Authorization": f"Bearer {token}"}, json={"enc": ciphertext})
        assert response.status_code == 200, response.text
        assert server._command_queue.get_nowait() == text
