"""Real file generation and read-back; no AI, Office installation or mocks."""
from pathlib import Path

import pytest
from docx import Document
from openpyxl import load_workbook
from pptx import Presentation
from pypdf import PdfReader

from actions.docx_tools import word_document
from actions.pdf_tools import create_pdf
from actions.office_builder import create_presentation, create_spreadsheet


@pytest.mark.parametrize("action", ["create", "create_report", "create_letter"])
def test_docx_create_and_read_back(tmp_path, action):
    path = tmp_path / f"{action}.docx"
    result = word_document({"action": action, "title": "Foundation check", "content": "Inherited Word engine.",
                            "output_path": str(path), "open_after": False, "author": "Test fixture"})
    assert "created" in result.lower()
    doc = Document(path)
    assert "Inherited Word engine." in "\n".join(p.text for p in doc.paragraphs)
    assert "Inherited Word engine." in word_document({"action": "read", "file_path": str(path)})


def test_docx_edit_and_extract(tmp_path):
    source, edited = tmp_path / "original.docx", tmp_path / "edited.docx"
    word_document({"title": "Edit check", "content": "Original phrase", "output_path": str(source), "open_after": False})
    word_document({"action": "replace_text", "file_path": str(source), "output_path": str(edited),
                   "replacements": {"Original phrase": "Retained workflow"}, "open_after": False})
    assert "Retained workflow" in "\n".join(p.text for p in Document(edited).paragraphs)
    text = tmp_path / "extracted.txt"
    word_document({"action": "extract_text", "file_path": str(edited), "output_path": str(text)})
    assert "Retained workflow" in text.read_text()


@pytest.mark.parametrize("chart", [None, "bar", "line", "pie"])
def test_spreadsheet_values_formulas_charts(tmp_path, chart):
    path = tmp_path / "workbook.xlsx"
    spec = {"name": "Data", "headers": ["Item", "Value"], "rows": [["Alpha", "12"], ["Beta", "=B2*2"]]}
    if chart:
        spec["chart"] = {"type": chart, "title": "Original chart engine"}
    create_spreadsheet({"title": "Foundation workbook", "sheets": [spec], "output_path": str(path), "auto_open": False})
    wb = load_workbook(path)
    ws = wb["Data"]
    assert ws["B2"].value == 12
    assert ws["B3"].value == "=B2*2"  # Stored, not calculated by openpyxl.
    assert ws.freeze_panes == "A2"
    assert len(ws._charts) == bool(chart)
    wb.close()


def test_presentation_original_fallback(tmp_path):
    path = tmp_path / "slides.pptx"
    result = create_presentation({"title": "Foundation deck", "slides": [
        {"title": "Preservation", "bullets": ["Existing engine", "Editable output"]}],
        "output_path": str(path), "auto_open": False})
    assert "created" in result.lower()
    prs = Presentation(path)
    assert len(prs.slides) == 2
    texts = "\n".join(shape.text for slide in prs.slides for shape in slide.shapes if shape.has_text_frame)
    assert "Existing engine" in texts


@pytest.mark.parametrize("source_type", [None, "txt", "docx"])
def test_pdf_create_and_convert(tmp_path, source_type):
    path = tmp_path / "report.pdf"
    params = {"title": "Foundation PDF", "content": "Preserved PDF content.", "output_path": str(path), "auto_open": False}
    if source_type:
        source = tmp_path / f"source.{source_type}"
        if source_type == "txt":
            source.write_text("Preserved PDF content.")
        else:
            word_document({"title": "Source", "content": "Preserved PDF content.", "output_path": str(source), "open_after": False})
        params.update(action="convert", file_path=str(source))
    result = create_pdf(params)
    assert "created" in result.lower()
    reader = PdfReader(path)
    assert len(reader.pages) >= 1
    assert "Preserved PDF content." in "\n".join(p.extract_text() or "" for p in reader.pages)
