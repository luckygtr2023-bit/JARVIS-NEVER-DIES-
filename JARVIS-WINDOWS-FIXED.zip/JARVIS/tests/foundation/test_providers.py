"""Mocked HTTP/SDK boundaries verify adapters, not live provider availability."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
import or_client
import llm_client

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setattr(or_client, "_load_api_key", lambda: "sk-or-test-not-a-secret")
    monkeypatch.setattr(or_client, "_rate_limited", {})
    monkeypatch.setattr(or_client.time, "sleep", lambda _: None)
    return or_client.OpenRouterClient()


def response(status, content="ok"):
    return SimpleNamespace(status_code=status, json=lambda: {"choices": [{"message": {"content": content}}]})


def test_openrouter_text_and_headers(client, monkeypatch):
    post = Mock(return_value=response(200, " Reply "))
    monkeypatch.setattr(or_client.requests, "post", post)
    assert client.chat("Hello") == "Reply"
    payload = post.call_args.kwargs
    assert payload["json"]["messages"][-1] == {"role": "user", "content": "Hello"}
    assert payload["headers"]["Authorization"] == "Bearer sk-or-test-not-a-secret"


def test_openrouter_key_saved_after_import_is_used(client, monkeypatch):
    monkeypatch.setattr(or_client, "_load_api_key", lambda: "sk-or-new-test-key")
    post = Mock(return_value=response(200))
    monkeypatch.setattr(or_client.requests, "post", post)
    assert client.chat("Hello") == "ok"
    assert post.call_args.kwargs["headers"]["Authorization"] == "Bearer sk-or-new-test-key"


@pytest.mark.parametrize("status", [401, 403])
def test_openrouter_auth_errors_do_not_retry(client, monkeypatch, status):
    post = Mock(return_value=response(status))
    monkeypatch.setattr(or_client.requests, "post", post)
    with pytest.raises(PermissionError):
        client.chat("Hello")
    assert post.call_count == 1


def test_openrouter_rate_limit_fallback_and_json(client, monkeypatch):
    post = Mock(side_effect=[response(429), response(200, '```json\n{"retained": true}\n```')])
    monkeypatch.setattr(or_client.requests, "post", post)
    assert client.chat_json("Return JSON") == {"retained": True}
    assert len(or_client._rate_limited) == 1
    assert post.call_count == 2


def test_openrouter_vision_payload(client, monkeypatch):
    post = Mock(return_value=response(200, "Image described"))
    monkeypatch.setattr(or_client.requests, "post", post)
    assert client.vision("Describe", "TEST_IMAGE_BYTES") == "Image described"
    content = post.call_args.kwargs["json"]["messages"][-1]["content"]
    assert content[0]["image_url"]["url"] == "data:image/png;base64,TEST_IMAGE_BYTES"


def test_local_provider_is_preserved(tmp_path, monkeypatch):
    settings = tmp_path / "settings.json"
    settings.write_text(json.dumps({"default_ai_provider": "Local", "local_ai_url": "http://local-model.test/v1", "local_ai_model": "fixture-model"}))
    monkeypatch.setattr(llm_client, "SETTINGS_PATH", settings)
    post = Mock(return_value=response(200, "Local reply"))
    monkeypatch.setattr(llm_client.requests, "post", post)
    client = llm_client.UnifiedAIClient()
    assert client.chat("Hello") == "Local reply"
    assert post.call_args.args[0] == "http://local-model.test/v1/chat/completions"
    assert post.call_args.kwargs["json"]["model"] == "fixture-model"


def test_gemini_live_config_against_installed_sdk(isolated_state):
    """Load unchanged method bodies by AST to avoid importing Windows-only actions."""
    from google.genai import types
    from memory.memory_manager import load_memory, format_memory_for_prompt
    tree = ast.parse((ROOT / "main.py").read_text(encoding="utf-8"))
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "BrahmaLive")
    method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == "_build_config")
    module = ast.Module(body=[method], type_ignores=[])
    declarations = next(n.value for n in tree.body if isinstance(n, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == "TOOL_DECLARATIONS" for t in n.targets))
    ns = {"types": types, "load_memory": load_memory, "format_memory_for_prompt": format_memory_for_prompt,
          "_load_system_prompt": lambda: "Foundation test", "TOOL_DECLARATIONS": ast.literal_eval(declarations)}
    exec(compile(module, str(ROOT / "main.py"), "exec"), ns)
    config = ns["_build_config"](None)
    assert isinstance(config, types.LiveConnectConfig)
    assert len(config.tools[0].function_declarations) == len(ns["TOOL_DECLARATIONS"])
    assert config.response_modalities == [types.Modality.AUDIO]
    assert config.speech_config.voice_config.prebuilt_voice_config.voice_name == "Charon"
