import json
from types import SimpleNamespace
from unittest.mock import Mock


def test_native_qt_wrapper_starts(qt_ui, qt_app):
    shell = qt_ui.BrahmaUI(face_path="", show_immediately=False)
    assert shell.root is not None
    assert shell._win._center_stack.count() >= 6
    assert shell._win._overlay is not None
    assert shell._win._overlay._stack.count() == 8
    qt_app.processEvents()
    shell._discord_service.stop()
    shell._updater.stop()


def test_onboarding_existing_navigation(qt_ui, qt_app):
    overlay = qt_ui.SetupOverlay(defaults={})
    assert overlay._stack.count() == 8
    overlay._finish_stage1()
    assert overlay._stack.currentIndex() == 1
    overlay._save_identity_and_next()
    assert overlay._stack.currentIndex() == 2
    overlay._save_owner_and_next()
    assert overlay._stack.currentIndex() == 3
    overlay._save_behavior_and_next()
    assert overlay._stack.currentIndex() == 4
    overlay._save_shared_and_next(False)
    assert overlay._stack.currentIndex() == 5
    overlay._goto_stage3()
    assert overlay._stack.currentIndex() == 6
    overlay._start_ignition()
    assert overlay._stack.currentIndex() == 7


def test_saving_provider_keys_preserves_other_settings(qt_ui):
    existing = {"instagram_username": "fixture", "instagram_password": "not-a-secret", "camera_index": 3,
                "gemini_api_key": "old", "anthropic_api_key": "retained"}
    fake = SimpleNamespace(_load_api_defaults=lambda: dict(existing), _overlay=None, _log=Mock(), _apply_state=Mock())
    qt_ui.MainWindow._on_setup_done(fake, "new-gemini-test", "sk-or-fixture", "windows")
    saved = json.loads(qt_ui.API_FILE.read_text())
    assert saved["instagram_username"] == "fixture"
    assert saved["instagram_password"] == "not-a-secret"
    assert saved["camera_index"] == 3
    assert saved["gemini_api_key"] == "new-gemini-test"
    assert fake._ready is True
