"""Actual in-process FastAPI/WebSocket protocol; synthetic peer, no physical phone."""
from fastapi.testclient import TestClient

from brahma_connect.gateway.server import BrahmaGateway
from brahma_connect.gateway.protocol import ProtocolTypes as P, build_message


def test_gateway_pair_authenticate_chat_and_disconnect(tmp_path):
    gateway = BrahmaGateway(tmp_path)
    seen = []
    gateway.on_chat_message = seen.append
    offer = gateway.create_pairing_offer()
    with TestClient(gateway.app) as client:
        assert client.get("/health").status_code == 200
        with client.websocket_connect("/ws") as ws:
            ws.send_json(build_message(P.PAIR_REQUEST, {"pairing_token": offer["pairing_token"],
                         "device_name": "Foundation peer", "platform": "android", "capabilities": ["battery"]}))
            paired = ws.receive_json()
            assert paired["type"] == P.PAIR_APPROVED
            data = paired["payload"]
            ws.send_json(build_message(P.AUTHENTICATE, {"device_id": data["device"]["device_id"], "device_secret": data["device_secret"]}))
            assert ws.receive_json()["type"] == P.DEVICE_ONLINE
            assert ws.receive_json()["type"] == P.CAPABILITIES
            ws.send_json(build_message(P.CHAT_MESSAGE, {"text": "Read only test command"}))
            ws.send_json(build_message(P.PING, {}))
            assert ws.receive_json()["type"] == P.PONG
            assert seen == ["Read only test command"]
        assert not gateway.device_manager.get(data["device"]["device_id"]).online


def test_pairing_offer_is_single_use(tmp_path):
    gateway = BrahmaGateway(tmp_path)
    offer = gateway.create_pairing_offer()
    with TestClient(gateway.app) as client, client.websocket_connect("/ws") as ws:
        message = build_message(P.PAIR_REQUEST, {"pairing_token": offer["pairing_token"], "device_name": "Fixture"})
        ws.send_json(message)
        assert ws.receive_json()["type"] == P.PAIR_APPROVED
        ws.send_json(message)
        assert ws.receive_json()["type"] == P.ERROR


def test_unauthenticated_chat_never_reaches_desktop(tmp_path):
    gateway = BrahmaGateway(tmp_path)
    seen = []
    gateway.on_chat_message = seen.append
    with TestClient(gateway.app) as client, client.websocket_connect("/ws") as ws:
        ws.send_json(build_message(P.CHAT_MESSAGE, {"text": "Synthetic unauthenticated command"}))
        ws.send_json(build_message(P.PING, {}))
        first = ws.receive_json()
        if first["type"] == P.ERROR:
            assert ws.receive_json()["type"] == P.PONG
        assert seen == []
        assert first["type"] == P.ERROR


def test_gateway_rejects_invalid_device_secret(tmp_path):
    gateway = BrahmaGateway(tmp_path)
    with TestClient(gateway.app) as client, client.websocket_connect("/ws") as ws:
        ws.send_json(build_message(P.AUTHENTICATE, {"device_id": "missing", "device_secret": "not-a-secret"}))
        assert ws.receive_json()["type"] == P.ERROR


def test_gateway_command_roundtrip_with_synthetic_authenticated_device(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    gateway = BrahmaGateway(tmp_path)
    offer = gateway.create_pairing_offer()
    with TestClient(gateway.app) as client, client.websocket_connect("/ws") as ws:
        ws.send_json(build_message(P.PAIR_REQUEST, {"pairing_token": offer["pairing_token"],
                     "device_name": "Command fixture", "capabilities": ["battery"]}))
        data = ws.receive_json()["payload"]
        device_id = data["device"]["device_id"]
        ws.send_json(build_message(P.AUTHENTICATE, {"device_id": device_id, "device_secret": data["device_secret"]}))
        assert ws.receive_json()["type"] == P.DEVICE_ONLINE
        assert ws.receive_json()["type"] == P.CAPABILITIES
        with ThreadPoolExecutor(max_workers=1) as executor:
            result_future = executor.submit(client.portal.call, gateway.route_command, device_id, "get_battery", {})
            command = ws.receive_json()
            assert command["type"] == P.EXECUTE
            assert command["payload"]["action"] == "get_battery"
            ws.send_json(build_message(P.RESULT, {"success": True, "data": {"level": 73}}, request_id=command["request_id"]))
            result = result_future.result(timeout=5)
            assert result["success"]
            assert result["data"] == {"level": 73}
