import base64
import pytest
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from jarvis_core.types import DomainError
from .conftest import account, run


def steps():
    return [{"tool": "web_search", "parameters": {"query": "synthetic fixture"}}]


def test_configurable_names_and_owner_crud(core, owner):
    combo = core.combos.create(owner, "任意の名前 — 37", steps())
    new = core.combos.update(
        owner, combo["id"], name="Any new name", version=1, enabled=False
    )
    assert new["name"] == "Any new name" and not new["enabled"] and new["version"] == 2
    with pytest.raises(DomainError):
        core.combos.execution(owner, combo["id"])
    core.combos.delete(owner, combo["id"])
    assert core.combos.list(owner) == []


def test_user_requires_assignment_enabled_and_tool_permission(core, owner):
    user, _ = account(core, owner, permissions=["tool:web_search"])
    combo = core.combos.create(owner, "Caller-configured", steps())
    with pytest.raises(DomainError):
        core.combos.execution(user, combo["id"])
    core.combos.assign(owner, combo["id"], user.user_id, can_use=True, can_manage=False)
    assert core.combos.execution(user, combo["id"])[1] == steps()
    with pytest.raises(DomainError):
        core.combos.update(user, combo["id"], version=1, name="hijacked")
    with pytest.raises(DomainError):
        core.combos.create(user, "not permitted", steps())
    core.combos.update(owner, combo["id"], version=1, enabled=False)
    with pytest.raises(DomainError):
        core.combos.execution(user, combo["id"])


def test_assignment_does_not_inherit_owner_power(core, owner):
    user, _ = account(core, owner)
    combo = core.combos.create(owner, "Owner choice", steps())
    core.combos.assign(owner, combo["id"], user.user_id, can_use=True, can_manage=False)
    with pytest.raises(DomainError) as error:
        core.combos.execution(user, combo["id"])
    assert error.value.code == "PERMISSION_DENIED"


def test_operator_owned_and_delegated_not_global(core, owner):
    operator, _ = account(core, owner, "operator", "OPERATOR")
    own = core.combos.create(operator, "Operator's choice", steps())
    other = core.combos.create(owner, "Owner's choice", steps())
    with pytest.raises(DomainError):
        core.combos.delete(operator, other["id"])
    with pytest.raises(DomainError):
        core.combos.assign(
            operator, own["id"], owner.user_id, can_use=True, can_manage=False
        )
    core.combos.assign(
        owner, other["id"], operator.user_id, can_use=False, can_manage=True
    )
    changed = core.combos.update(
        operator, other["id"], name="Delegated rename", version=1
    )
    assert changed["owner_id"] == owner.user_id
    with pytest.raises(DomainError):
        core.combos.execution(operator, other["id"])
    core.combos.delete(operator, own["id"])


def test_combo_version_prevents_stale_execution(core, owner):
    combo = core.combos.create(owner, "Versioned", steps())
    core.combos.update(owner, combo["id"], version=1, name="Changed")
    with pytest.raises(DomainError):
        core.combos.execution(owner, combo["id"], expected_version=1)


def register(core, actor):
    key = ec.generate_private_key(ec.SECP256R1())
    public = base64.b64encode(
        key.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        )
    ).decode()
    device = core.devices.register(actor, "Synthetic phone", "android", public)
    return device, key


def bind_and_auth(core, owner, actor, device, key):
    async def go():
        await core.devices.bind(
            owner,
            device["id"],
            "windows-bond-fixture",
            device["fingerprint"],
            [
                "chat",
                "tasks",
                "memory",
                "combos",
                "ai",
                "notifications",
                "device_actions",
            ],
        )
        challenge = core.devices.challenge(actor, device["id"])
        signature = base64.b64encode(
            key.sign(challenge["message"].encode(), ec.ECDSA(hashes.SHA256()))
        ).decode()
        result = await core.devices.authorize(actor, challenge["id"], signature)
        return core.auth.revalidate(actor), result, challenge, signature

    return run(go())


def test_network_login_and_registration_do_not_authorize_control(core, owner):
    user, _ = account(core, owner, desktop=False)
    register(core, user)
    with pytest.raises(DomainError) as error:
        run(core.devices.enforce(user))
    assert error.value.code == "DEVICE_AUTHENTICATION_REQUIRED"


def test_paired_authorized_allowed_unpaired_revoked_denied(core, owner):
    user, _ = account(core, owner, desktop=False)
    device, key = register(core, user)
    actor, result, _, _ = bind_and_auth(core, owner, user, device, key)
    assert "test adapter" in result["verification_source"]
    assert run(core.devices.enforce(actor)).device_id == device["id"]
    core.devices.radio.paired.clear()
    with pytest.raises(DomainError) as error:
        run(core.devices.enforce(actor))
    assert error.value.code == "BLUETOOTH_NOT_PAIRED"
    core.devices.radio.paired.add("windows-bond-fixture")
    actor, _, _, _ = bind_and_auth(core, owner, user, device, key)
    run(core.devices.revoke(owner, device["id"]))
    with pytest.raises(DomainError):
        run(core.devices.enforce(actor))


def test_radio_unavailable_never_becomes_paired(core, owner):
    user, _ = account(core, owner, desktop=False)
    device, key = register(core, user)
    actor, _, _, _ = bind_and_auth(core, owner, user, device, key)
    core.devices.radio.available = False
    with pytest.raises(DomainError) as error:
        run(core.devices.enforce(actor))
    assert error.value.code == "BLUETOOTH_NOT_VERIFIED"


def test_signature_replay_and_other_user_device_rejected(core, owner):
    user, _ = account(core, owner, desktop=False)
    other, _ = account(core, owner, "other", desktop=False)
    device, key = register(core, user)
    actor, _, challenge, signature = bind_and_auth(core, owner, user, device, key)
    with pytest.raises(DomainError):
        run(core.devices.authorize(actor, challenge["id"], signature))
    with pytest.raises(DomainError):
        core.devices.challenge(other, device["id"])
    challenge2 = core.devices.challenge(actor, device["id"])
    with pytest.raises(DomainError):
        run(
            core.devices.authorize(
                actor, challenge2["id"], base64.b64encode(b"bad signature").decode()
            )
        )


def test_client_telemetry_cannot_grant_pairing(core, owner):
    user, _ = account(core, owner, desktop=False)
    device, key = register(core, user)
    actor, _, _, _ = bind_and_auth(core, owner, user, device, key)
    with pytest.raises(DomainError):
        run(core.devices.update_status(actor, {"paired": True, "role": "OWNER"}))


def test_real_adapter_fails_closed_off_windows():
    import sys
    from jarvis_core.bluetooth import WindowsBluetooth

    if sys.platform != "win32":
        with pytest.raises(DomainError):
            run(WindowsBluetooth().is_paired("not-an-os-bond"))
