import json
import pytest
from jarvis_core.types import DomainError
from .conftest import account, PASSWORD


def test_owner_bootstrap_requires_local_proof(tmp_path):
    from jarvis_core.database import Database
    from jarvis_core.auth import Auth

    auth = Auth(Database(tmp_path / "workspace_store.sqlite3"))
    with pytest.raises(DomainError, match="Local owner setup"):
        auth.bootstrap("attacker", PASSWORD, local_proof=False)
    assert auth.needs_setup()


def test_no_predefined_credentials_and_passwords_are_hashed(core):
    row = core.db.one("SELECT * FROM j_users")
    assert row["password_hash"].startswith("pbkdf2-sha256$600000$")
    assert PASSWORD not in core.db.path.read_bytes().decode(errors="ignore")
    with pytest.raises(DomainError):
        core.auth.bootstrap("other", PASSWORD, local_proof=True)


def test_sessions_revocable_and_roles_rechecked(core, owner):
    member, token = account(core, owner)
    core.auth.update_user(owner, member.user_id, active=False)
    with pytest.raises(DomainError):
        core.auth.authenticate(token)
    with pytest.raises(DomainError):
        core.memory.write(member, "long_term", "preference", "quiet mode")


def test_last_owner_protected(core, owner):
    with pytest.raises(DomainError):
        core.auth.update_user(owner, owner.user_id, active=False)


def test_login_rate_limit(core):
    for _ in range(5):
        with pytest.raises(DomainError) as error:
            core.auth.login("owner", "incorrect", rate_key="test")
        assert error.value.code == "INVALID_LOGIN"
    with pytest.raises(DomainError) as error:
        core.auth.login("owner", PASSWORD, rate_key="test")
    assert error.value.code == "LOGIN_THROTTLED"


def test_memory_isolation_applies_to_owner_too(core, owner):
    member, _ = account(core, owner)
    item = core.memory.write(member, "long_term", "Language", "Hindi", ["preference"])
    assert core.memory.list(owner) == []
    with pytest.raises(DomainError):
        core.memory.delete(owner, item["id"])
    with pytest.raises(DomainError):
        core.memory.write(owner, "long_term", "forged", "changed", item_id=item["id"])
    assert core.memory.list(member)[0]["value"] == "Hindi"


@pytest.mark.parametrize("kind", ["short", "session", "long_term", "workflow"])
def test_memory_search_update_delete_all_kinds(core, owner, kind):
    item = core.memory.write(owner, kind, "Focus", "quiet workspace", ["preference"])
    assert core.memory.list(owner, "quiet", kind)[0]["id"] == item["id"]
    core.memory.write(owner, kind, "Focus", "music workspace", item_id=item["id"])
    assert core.memory.list(owner, "quiet") == []
    assert core.memory.list(owner, "music")[0]["value"] == "music workspace"
    core.memory.delete(owner, item["id"])
    assert core.memory.list(owner) == []


def test_memory_disabled_and_session_isolation(core, owner):
    core.memory.write(owner, "session", "temporary", "session one")
    second = core.auth.authenticate(
        core.auth.login("owner", PASSWORD, local_proof=True)["token"]
    )
    assert core.memory.list(second) == []
    core.memory.configure(owner, False)
    assert core.memory.context(owner) == []
    with pytest.raises(DomainError) as error:
        core.memory.write(owner, "long_term", "blocked", "value")
    assert error.value.code == "MEMORY_DISABLED"
    core.memory.configure(owner, True)
    core.memory.clear(owner)
    assert core.memory.list(owner) == []


@pytest.mark.parametrize(
    "value",
    [
        "password: hunter42",
        "api_key=sk-synthetickey1234567890",
        "Bearer abcdef1234567890",
        "-----BEGIN PRIVATE KEY-----",
        {"refresh_token": "anything"},
        "https://user:password@example.test",
        "eyJabcdefghijklm.abcdefghijklmno.abcdefghijklmno",
    ],
)
def test_secrets_never_written(core, owner, value):
    with pytest.raises(DomainError) as error:
        core.memory.write(owner, "long_term", "Do not store", value)
    assert error.value.code == "SECRET_REJECTED"
    assert core.db.one("SELECT COUNT(*) n FROM j_memory")["n"] == 0


def test_known_secret_and_atomic_import_export(core, owner):
    core.guard.register("custom-opaque-secret-value")
    with pytest.raises(DomainError):
        core.memory.write(owner, "long_term", "label", "custom-opaque-secret-value")
    doc = {
        "format": "jarvis.memory.v1",
        "items": [
            {"kind": "long_term", "label": "one", "value": "quiet", "tags": []},
            {
                "kind": "workflow",
                "label": "two",
                "value": {"api_key": "forbidden"},
                "tags": [],
            },
        ],
    }
    with pytest.raises(DomainError):
        core.memory.import_items(owner, doc)
    assert core.memory.list(owner) == []
    doc["items"].pop()
    assert core.memory.import_items(owner, doc)["imported"] == 1
    exported = core.memory.export(owner)
    assert exported["items"][0]["value"] == "quiet"
    assert "user_id" not in json.dumps(exported)
    assert "quiet" not in str(core.db.one("SELECT content FROM j_memory")["content"])


def test_import_cannot_assign_foreign_user_id(core, owner):
    doc = {
        "format": "jarvis.memory.v1",
        "items": [
            {
                "kind": "long_term",
                "label": "bad",
                "value": "value",
                "tags": [],
                "user_id": "forged",
            }
        ],
    }
    with pytest.raises(DomainError):
        core.memory.import_items(owner, doc)


def test_redaction_never_retains_private_key_body(core):
    value = "-----BEGIN PRIVATE KEY-----\nSYNTHETIC_SENSITIVE_KEY_BODY\n-----END PRIVATE KEY-----"
    result = core.guard.redact(value)
    assert "SYNTHETIC_SENSITIVE_KEY_BODY" not in result and "REDACTED" in result
    result = core.guard.redact('{"password":"synthetic private password"}')
    assert "synthetic private password" not in result
