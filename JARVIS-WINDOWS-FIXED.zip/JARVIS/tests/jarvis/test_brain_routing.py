import asyncio
import json
import httpx
import pytest
from jarvis_core.routing import Providers, ProviderFailure
from jarvis_core.types import Completion, DomainError, ToolResult, Status
from .conftest import account, run


def test_brain_executes_ordered_steps_and_verifies_final(core, owner):
    called = []

    def search(actor, params):
        called.append(params["query"])
        return ToolResult(
            "actual fixture output",
            Status.VERIFIED,
            "Fixture assertion, not live web search.",
        )

    core.actions.register("web_search", search)

    async def go():
        task = await core.brain.submit(
            owner,
            steps=[
                {"tool": "web_search", "parameters": {"query": "first"}},
                {"tool": "web_search", "parameters": {"query": "Use ${step.0}"}},
            ],
        )
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    task = run(go())
    assert task["state"] == "completed"
    assert called == ["first", "Use actual fixture output"]
    assert task["verification"] == "VERIFIED"
    assert {"authorization", "execution", "verification"} <= {
        s["name"] for s in task["stages"]
    }


def test_consequential_action_cannot_self_confirm_or_replay(core, owner):
    calls = []
    core.actions.register(
        "open_app", lambda a, p: calls.append(p) or "Launched fixture"
    )

    async def go():
        task = await core.brain.submit(
            owner,
            steps=[
                {
                    "tool": "open_app",
                    "parameters": {"app_name": "Fixture", "confirmed": "yes"},
                }
            ],
        )
        await core.brain.wait(task["id"])
        pending = core.brain.get(owner, task["id"])
        assert pending["state"] == "awaiting_confirmation" and not calls
        cid = pending["confirmation"]["id"]
        await core.brain.confirm(owner, task["id"], cid, True)
        await core.brain.wait(task["id"])
        with pytest.raises(DomainError):
            await core.brain.confirm(owner, task["id"], cid, True)
        return core.brain.get(owner, task["id"])

    result = run(go())
    assert len(calls) == 1 and calls[0]["confirmed"] == "yes"
    assert result["state"] == "completed" and result["verification"] == "NOT VERIFIED"


def test_changed_combo_invalidates_pending_execution(core, owner):
    calls = []
    core.actions.register("open_app", lambda a, p: calls.append(p) or "done")
    combo = core.combos.create(
        owner,
        "Mutable fixture",
        [{"tool": "open_app", "parameters": {"app_name": "Fixture"}}],
    )

    async def go():
        task = await core.brain.submit(owner, combo_id=combo["id"])
        await core.brain.wait(task["id"])
        pending = core.brain.get(owner, task["id"])
        core.combos.update(owner, combo["id"], version=1, enabled=False)
        await core.brain.confirm(owner, task["id"], pending["confirmation"]["id"], True)
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    result = run(go())
    assert (
        not calls
        and result["state"] == "failed"
        and result["error"] == "COMBO_DISABLED"
    )


def test_plan_cannot_invent_tool_or_escalate_role(core, owner):
    user, _ = account(core, owner)
    with pytest.raises(DomainError):
        run(
            core.brain.submit(
                user,
                steps=[{"tool": "cmd_control", "parameters": {"task": "anything"}}],
            )
        )
    with pytest.raises(DomainError):
        run(
            core.brain.submit(
                user, steps=[{"tool": "shutdown_brahma", "parameters": {}}]
            )
        )


def test_owner_cannot_read_another_users_task(core, owner):
    user, _ = account(core, owner, permissions=["tool:web_search"])
    core.actions.register("web_search", lambda a, p: "private member fixture")

    async def go():
        task = await core.brain.submit(
            user, steps=[{"tool": "web_search", "parameters": {"query": "fixture"}}]
        )
        await core.brain.wait(task["id"])
        with pytest.raises(DomainError):
            core.brain.get(owner, task["id"])

    run(go())


def test_real_inherited_pdf_engine_used_by_brain(core, owner, tmp_path):
    path = tmp_path / "from-original-engine.pdf"

    async def go():
        task = await core.brain.submit(
            owner,
            steps=[
                {
                    "tool": "pdf_document",
                    "parameters": {
                        "action": "create",
                        "title": "Brahma engine retained",
                        "content": "A real PDF artifact",
                        "output_path": str(path),
                        "auto_open": False,
                    },
                }
            ],
        )
        await core.brain.wait(task["id"])
        pending = core.brain.get(owner, task["id"])
        await core.brain.confirm(owner, task["id"], pending["confirmation"]["id"], True)
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    result = run(go())
    assert result["state"] == "completed", result
    assert result["verification"] == "VERIFIED"
    assert path.read_bytes().startswith(b"%PDF-")


def test_nonowner_file_paths_cannot_escape_workspace(core, owner):
    user, _ = account(core, owner, permissions=["tool:file_controller"])
    with pytest.raises(DomainError):
        core.policy.prepare(
            user,
            {
                "tool": "file_controller",
                "parameters": {"action": "read", "path": "/outside"},
            },
        )
    with pytest.raises(DomainError):
        core.policy.prepare(
            user,
            {
                "tool": "file_controller",
                "parameters": {
                    "action": "read",
                    "path": "${workspace}",
                    "name": "../../outside",
                },
            },
        )


class ScriptedProviders:
    def __init__(self, core):
        self.secrets = core.secrets
        self.calls = []
        self.fail = set()
        self.response = '{"intent":"chat","response":"Fixture reply","summary":"Text only","steps":[]}'

    def key(self, name):
        return "fixture provider credential"

    async def complete(self, name, cfg, messages, max_tokens=2048):
        self.calls.append(name)
        if name in self.fail:
            raise ProviderFailure("SCRIPTED_FAILURE")
        return Completion(self.response, name, cfg["model"], 12, 7, live=False)


def configure_fake(core, owner):
    provider = ScriptedProviders(core)
    core.router.providers = provider
    core.router.configure(owner, "ollama", {"enabled": True, "model": "fixture-local"})
    core.router.configure(
        owner, "openrouter", {"enabled": True, "model": "fixture-cloud"}
    )
    return provider


def test_local_first_cloud_fallback_and_usage(core, owner):
    provider = configure_fake(core, owner)
    provider.fail.add("ollama")
    reply = run(core.router.complete(owner, [{"role": "user", "content": "Hello"}]))
    assert provider.calls == ["ollama", "gemini"]
    assert reply.fallback_from == ["ollama"] and not reply.live
    usage = core.router.usage(owner)
    assert sum(r["calls"] for r in usage) == 2
    assert sum(r["live_successes"] for r in usage) == 0
    assert (
        core.router.diagnostics(owner)["gemini"]["live_verification"] == "NOT VERIFIED"
    )


def test_local_only_never_leaks_to_cloud(core, owner):
    provider = configure_fake(core, owner)
    provider.fail.add("ollama")
    core.router.set_preferences(owner, "local_only", preferred="gemini")
    with pytest.raises(DomainError):
        run(
            core.router.complete(
                owner, [{"role": "user", "content": "Private local request"}]
            )
        )
    assert provider.calls == ["ollama"]


def test_brain_planning_and_final_response(core, owner):
    provider = configure_fake(core, owner)

    async def go():
        task = await core.brain.submit(owner, text="Hello")
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    task = run(go())
    assert task["state"] == "completed" and task["final_response"] == "Fixture reply"
    assert task["provider"]["live"] is False
    assert "reasoning" in {s["name"] for s in task["stages"]}


def test_malicious_model_plan_has_no_authority(core, owner):
    user, _ = account(core, owner)
    provider = configure_fake(core, owner)
    provider.response = (
        '{"intent":"task","steps":[{"tool":"shutdown_brahma","parameters":{}}]}'
    )

    async def go():
        task = await core.brain.submit(user, text="Tell me the weather")
        await core.brain.wait(task["id"])
        return core.brain.get(user, task["id"])

    task = run(go())
    assert task["state"] == "failed" and task["error"] == "PERMISSION_DENIED"


@pytest.mark.parametrize("name", ["ollama", "omniroute"])
def test_real_adapter_http_contract_without_live_claim(core, owner, name):
    requests = []

    def respond(request):
        requests.append(request)
        if name == "ollama":
            return httpx.Response(
                200,
                json={
                    "message": {"content": "Fixture"},
                    "prompt_eval_count": 9,
                    "eval_count": 3,
                },
            )
        return httpx.Response(
            200,
            json={
                "choices": [{"message": {"content": "Fixture"}}],
                "usage": {"prompt_tokens": 9, "completion_tokens": 3},
            },
        )

    async def go():
        async with httpx.AsyncClient(transport=httpx.MockTransport(respond)) as client:
            provider = Providers(core.secrets, core.root, http_client=client)
            core.router.providers = provider
            core.router.configure(
                owner,
                name,
                {
                    "enabled": True,
                    "model": "fixture",
                    "base_url": "http://127.0.0.1:11434"
                    if name == "ollama"
                    else "http://127.0.0.1:20128/v1",
                },
            )
            return await core.router.complete(
                owner, [{"role": "user", "content": "Hello"}], exact_provider=name
            )

    reply = run(go())
    assert len(requests) == 1
    assert requests[0].url.path == (
        "/api/chat" if name == "ollama" else "/v1/chat/completions"
    )
    assert reply.input_tokens == 9 and reply.output_tokens == 3 and not reply.live
    assert core.router.diagnostics(owner)[name]["live_verification"] == "NOT VERIFIED"


def test_omniroute_disabled_until_configured(core, owner):
    diagnostic = core.router.diagnostics(owner)["omniroute"]
    assert (
        not diagnostic["enabled"] and diagnostic["live_verification"] == "NOT VERIFIED"
    )
    with pytest.raises(DomainError):
        run(
            core.router.complete(
                owner,
                [{"role": "user", "content": "Hello"}],
                exact_provider="omniroute",
            )
        )


def test_provider_endpoint_secrets_and_plain_remote_http_rejected(core, owner):
    for url in [
        "http://user:pass@127.0.0.1/v1",
        "http://remote.example/v1",
        "https://provider.example/v1?api_key=bad",
    ]:
        with pytest.raises(DomainError):
            core.router.configure(
                owner,
                "omniroute",
                {"enabled": True, "model": "fixture", "base_url": url},
            )


def test_permission_revocation_while_waiting_for_host_lock_wins(core, owner):
    user, _ = account(core, owner, permissions=["tool:web_search"])
    calls = []
    core.actions.register(
        "web_search", lambda a, p: calls.append(a.user_id) or "should not run"
    )

    async def go():
        await core.actions._host_lock.acquire()
        task = await core.brain.submit(
            user, steps=[{"tool": "web_search", "parameters": {"query": "fixture"}}]
        )
        for _ in range(50):
            if core.brain.get(user, task["id"])["stage"] == "execution":
                break
            await asyncio.sleep(0)
        core.auth.update_user(owner, user.user_id, active=False)
        core.actions._host_lock.release()
        await core.brain.wait(task["id"])
        return core.db.one("SELECT state FROM j_tasks WHERE id=?", (task["id"],))

    result = run(go())
    assert result["state"] == "failed" and not calls


def test_cancellation_while_waiting_for_host_lock_wins(core, owner):
    calls = []
    core.actions.register(
        "web_search", lambda a, p: calls.append(True) or "should not run"
    )

    async def go():
        await core.actions._host_lock.acquire()
        task = await core.brain.submit(
            owner, steps=[{"tool": "web_search", "parameters": {"query": "fixture"}}]
        )
        for _ in range(50):
            if core.brain.get(owner, task["id"])["stage"] == "execution":
                break
            await asyncio.sleep(0)
        await core.brain.cancel(owner, task["id"])
        core.actions._host_lock.release()
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    result = run(go())
    assert result["state"] == "cancelled" and not calls


def test_forward_dependencies_rejected_before_any_execution(core, owner):
    with pytest.raises(DomainError) as error:
        run(
            core.brain.submit(
                owner,
                steps=[
                    {"tool": "web_search", "parameters": {"query": "${step.1}"}},
                    {"tool": "web_search", "parameters": {"query": "fixture"}},
                ],
            )
        )
    assert error.value.code == "INVALID_STEP_DEPENDENCY"


def test_nonowner_cannot_use_workspace_file_permission_for_desktop_cleanup(core, owner):
    user, _ = account(core, owner, permissions=["tool:file_controller"])
    with pytest.raises(DomainError) as error:
        core.policy.prepare(
            user,
            {
                "tool": "file_controller",
                "parameters": {"action": "organize_desktop", "path": "${workspace}"},
            },
        )
    assert error.value.code == "OWNER_TOOL_ACTION_REQUIRED"


def test_cancel_during_uninterruptible_step_never_starts_later_step(core, owner):
    calls = []

    async def go():
        entered, release = asyncio.Event(), asyncio.Event()

        async def action(actor, params):
            calls.append(params["query"])
            if params["query"] == "first":
                entered.set()
                await release.wait()
            return "fixture completed"

        core.actions.register("web_search", action)
        task = await core.brain.submit(
            owner,
            steps=[
                {"tool": "web_search", "parameters": {"query": "first"}},
                {"tool": "web_search", "parameters": {"query": "second"}},
            ],
        )
        await entered.wait()
        await core.brain.cancel(owner, task["id"])
        release.set()
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    result = run(go())
    assert result["state"] == "cancelled" and calls == ["first"]
    assert result["results"][0]["value"] == "fixture completed"


def test_authorized_combo_runs_real_pdf_engine_for_assigned_user(core, owner):
    user, _ = account(core, owner, permissions=["tool:pdf_document"])
    combo = core.combos.create(
        owner,
        "Acceptance name chosen by caller",
        [
            {
                "tool": "pdf_document",
                "parameters": {
                    "action": "create",
                    "title": "Local combo acceptance",
                    "content": "Real inherited PDF output from a permission-checked Combo.",
                    "output_path": "${workspace}/combo-acceptance.pdf",
                    "auto_open": False,
                },
            }
        ],
    )
    core.combos.assign(owner, combo["id"], user.user_id, can_use=True, can_manage=False)

    async def go():
        task = await core.brain.submit(user, combo_id=combo["id"])
        await core.brain.wait(task["id"])
        pending = core.brain.get(user, task["id"])
        assert pending["state"] == "awaiting_confirmation"
        await core.brain.confirm(user, task["id"], pending["confirmation"]["id"], True)
        await core.brain.wait(task["id"])
        return core.brain.get(user, task["id"])

    task = run(go())
    assert task["state"] == "completed" and task["verification"] == "VERIFIED"
    artifact = core.policy.workspace(user) / "combo-acceptance.pdf"
    assert artifact.read_bytes().startswith(b"%PDF-")
    core.combos.update(owner, combo["id"], version=1, enabled=False)
    with pytest.raises(DomainError):
        run(core.brain.submit(user, combo_id=combo["id"]))
