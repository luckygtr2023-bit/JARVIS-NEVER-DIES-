import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from jarvis_core.api import create_app
from jarvis_core.runtime import network_config, local_url
from jarvis_core.network import configure, info
from jarvis_core.types import DomainError
from .conftest import account, run


def test_tls_lan_settings_require_local_owner_and_explicit_confirmation(core, owner):
    user, _ = account(core, owner)
    with pytest.raises(DomainError):
        configure(core, user, enabled=True, public_host="192.168.1.9", confirm=True)
    with pytest.raises(DomainError):
        configure(core, owner, enabled=True, public_host="192.168.1.9", confirm=False)
    result = configure(
        core, owner, enabled=True, public_host="192.168.1.9", confirm=True
    )
    assert result["restart_required"] and result["tls"]
    payload = result["qr_payload"]
    assert (
        payload["protocol"] == "jarvis.v1"
        and payload["backend_url"] == "https://192.168.1.9:8765"
    )
    certificate = x509.load_pem_x509_certificate(
        (core.data_dir / "private/transport-cert.pem").read_bytes()
    )
    assert (
        certificate.fingerprint(hashes.SHA256()).hex() == payload["certificate_sha256"]
    )
    cfg = network_config(core.data_dir.parent)
    assert cfg["host"] == "0.0.0.0" and local_url(cfg) == "https://127.0.0.1:8765"
    configure(core, owner, enabled=False, public_host="localhost", confirm=True)
    assert info(core)["enabled"] is False


def test_non_loopback_bind_without_tls_fails_closed(tmp_path):
    path = tmp_path / "config"
    path.mkdir()
    (path / "jarvis_network.json").write_text(json.dumps({"host": "0.0.0.0"}))
    with pytest.raises(DomainError) as error:
        network_config(tmp_path)
    assert error.value.code == "LAN_TLS_REQUIRED"


def test_protected_provider_keys_are_visible_to_inherited_getters(core, monkeypatch):
    from core.provider_keys import read_provider_key

    config = core.data_dir / "api_keys.json"
    config.write_text(json.dumps({"gemini_api_key": "old-fixture-value"}))
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    assert read_provider_key("gemini", config) == "old-fixture-value"
    core.secrets.set("provider_gemini", "new-private-fixture-value")
    assert read_provider_key("gemini", config) == "new-private-fixture-value"
    assert "new-private-fixture-value" not in config.read_text()


def test_local_only_blocks_opaque_legacy_ai_helper(core, owner):
    calls = []
    core.actions.register("screen_process", lambda a, p: calls.append(True) or "never")
    core.router.set_preferences(owner, "local_only")

    async def go():
        task = await core.brain.submit(
            owner, steps=[{"tool": "screen_process", "parameters": {"text": "fixture"}}]
        )
        await core.brain.wait(task["id"])
        return core.brain.get(owner, task["id"])

    task = run(go())
    assert task["error"] == "LOCAL_ONLY_LEGACY_TOOL_BLOCKED" and not calls


def test_launcher_path_and_authority_contracts():
    root = Path(__file__).resolve().parents[2]
    batch = (root / "start_jarvis.bat").read_text()
    script = (root / "bootstrap_jarvis.ps1").read_text()
    assert '-File "%~dp0bootstrap_jarvis.ps1"' in batch
    assert "DisableDelayedExpansion" in batch
    assert "Set-Location -LiteralPath $Root" in script
    assert "Quote-NativeArgument" in script and "Invoke-Captured" in script
    assert "$Info.RedirectStandardError = $true" in script
    assert "ReadToEndAsync" in script and "WaitForExit" in script
    assert "Get-AuthenticodeSignature" in script
    assert script.index('"jarvis_core.launcher","preflight"') < script.index(
        '"jarvis_core.desktop","--wait-for-hud"'
    )
    assert '"jarvis_core.launcher","show"' in script
    assert "Invoke-Expression" not in script
    assert "--force" not in script


def test_android_client_security_and_single_backend_contract():
    root = Path(__file__).resolve().parents[2] / "brahma-connect-android/app/src/main"
    manifest = (root / "AndroidManifest.xml").read_text()
    assert 'android:usesCleartextTraffic="false"' in manifest
    assert "android.permission.BLUETOOTH_CONNECT" in manifest
    assert "android.permission.RECORD_AUDIO" in manifest
    client = (root / "java/com/brahma/connect/jarvis/JarvisClient.kt").read_text()
    assert 'uri.scheme == "https"' in client
    assert "X-Jarvis-Signature" in client and "HTTP:$method:$path:" in client
    assert "/v1/device-bus" in client and "/v1/tasks" in client
    assert "handler.handle(action" in client
    assert "Runtime.getRuntime().exec" not in client and "ProcessBuilder" not in client
    assert "Windows/arbitrary commands are never executed" in client
    key = (root / "java/com/brahma/connect/jarvis/JarvisDeviceKey.kt").read_text()
    assert "AndroidKeyStore" in key and "secp256r1" in key
    assert "privateKey.encoded" not in key


def test_explicit_legacy_memory_migration_is_scoped_and_non_destructive(
    core, owner, tmp_path
):
    from .conftest import account

    path = tmp_path / "long_term.json"
    original = json.dumps({"preferences": {"tone": {"value": "concise"}}})
    path.write_text(original)
    result = core.memory.import_legacy(owner, path)
    assert result["imported"] == 1 and path.read_text() == original
    assert core.memory.list(owner)[0]["value"] == "concise"
    other, _ = account(core, owner)
    assert core.memory.list(other) == []
    with pytest.raises(DomainError):
        core.memory.import_legacy(other, path)


def test_legacy_native_view_timers_are_safe_after_logout(core):
    from jarvis_core.desktop import ConnectFacade

    def logged_out():
        raise DomainError("SESSION_EXPIRED", status=401)

    facade = ConnectFacade(core, logged_out)
    assert facade.list_devices() == [] and facade.logs() == []
    with pytest.raises(DomainError):
        facade.rename_device("unknown", "attempt")


def test_preflight_does_not_require_an_unused_undeclared_openai_sdk():
    import ast

    root = Path(__file__).resolve().parents[2]
    tree = ast.parse((root / "jarvis_core/launcher.py").read_text())
    preflight = next(
        n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "preflight"
    )
    strings = {
        n.value
        for n in ast.walk(preflight)
        if isinstance(n, ast.Constant) and isinstance(n.value, str)
    }
    assert "openai" not in strings
    assert {
        "google.genai",
        "PyQt6.QtWebEngineWidgets",
        "winrt.windows.devices.bluetooth",
    } <= strings


def test_legacy_launch_aliases_use_the_same_checked_startup():
    root = Path(__file__).resolve().parents[2]
    assert "start_jarvis.bat" in (root / "start_brahma.bat").read_text()
    assert "bootstrap_jarvis.ps1" in (root / "bootstrap.ps1").read_text()
    assert "start_jarvis.vbs" in (root / "start_brahma.vbs").read_text()
    assert "Verb runAs" not in (root / "bootstrap.ps1").read_text()
