"""Real Chromium rendering/forms/WebCrypto against the actual in-process backend.

No external provider or physical Bluetooth is simulated as a live verification.
The HTTP transport bridge avoids exposing a development server on the network.
"""

import asyncio
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

import pytest
from fastapi.testclient import TestClient
from jarvis_core.api import create_app
from .conftest import PASSWORD


def test_pwa_manifest_cache_and_same_origin_contract():
    root = Path(__file__).resolve().parents[2]
    manifest = json.loads((root / "pwa/manifest.webmanifest").read_text())
    assert manifest["scope"] == "/app/" and manifest["start_url"] == "/app/"
    service_worker = (root / "pwa/sw.js").read_text()
    assert "!ASSETS.includes(url.pathname)" in service_worker
    assert "'/v1/" not in service_worker.split("const ASSETS=")[1].split(";")[0]
    code = (root / "pwa/app.js").read_text()
    assert "jarvis-device-keystore" in code
    assert "state.key.privateKey" in code
    assert "X-Jarvis-Signature" in code
    assert "innerHTML" not in code
    assert "http://localhost" not in code


@pytest.fixture
def browser_app(core):
    if os.environ.get("RUN_BROWSER_TESTS") != "1":
        pytest.skip("Enable RUN_BROWSER_TESTS=1 with installed Playwright Chromium")
    from playwright.sync_api import sync_playwright

    app = create_app(core.root, core=core)
    with TestClient(
        app, base_url="http://127.0.0.1:8765", client=("127.0.0.1", 52100)
    ) as client:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(
                headless=True, args=["--disable-dev-shm-usage"]
            )
            context = browser.new_context(
                viewport={"width": 1440, "height": 1040}, service_workers="block"
            )
            context.add_cookies(
                [
                    {
                        "name": "jarvis_local",
                        "value": core.local_proof,
                        "url": "http://127.0.0.1:8765",
                        "httpOnly": True,
                    }
                ]
            )
            errors = []
            page = context.new_page()
            page.on("pageerror", lambda error: errors.append(str(error)))

            def bridge(route):
                request = route.request
                url = urlsplit(request.url)
                if url.netloc != "127.0.0.1:8765":
                    route.abort()
                    return
                path = url.path + ("?" + url.query if url.query else "")
                client.cookies.clear()  # The browser, not the test client's cookie jar, owns its session.
                response = client.request(
                    request.method,
                    path,
                    content=request.post_data_buffer,
                    headers=dict(request.headers),
                    follow_redirects=False,
                )
                for name, value in response.cookies.items():
                    context.add_cookies(
                        [
                            {
                                "name": name,
                                "value": value,
                                "url": "http://127.0.0.1:8765",
                                "httpOnly": name == "jarvis_session",
                            }
                        ]
                    )
                headers = {
                    k: v
                    for k, v in response.headers.items()
                    if k.lower()
                    not in {"set-cookie", "content-length", "content-encoding"}
                }
                route.fulfill(
                    status=response.status_code, headers=headers, body=response.content
                )

            context.route("**/*", bridge)
            page.goto("http://127.0.0.1:8765/app/")
            yield page, context, client, errors
            context.close()
            browser.close()


def login(page, username="owner"):
    page.locator("#username").fill(username)
    page.locator("#password").fill(PASSWORD)
    page.locator("#sign-in").click()
    page.locator("#shell").wait_for(state="visible")
    page.wait_for_function("() => state.user !== null")


def test_pwa_real_forms_memory_combos_and_diagnostics(core, browser_app):
    page, context, client, errors = browser_app
    login(page)
    page.locator('[data-page="memory"]').click()
    page.locator("#memory-label").fill("Browser fixture preference")
    page.locator("#memory-value").fill("Quiet mornings")
    page.locator('#memory-form button[type="submit"]').click()
    page.locator("#memory-list").get_by_text("Quiet mornings", exact=True).wait_for()
    page.locator('[data-page="combos"]').click()
    page.locator("#new-combo").click()
    page.locator("#combo-name").fill("Name chosen in the browser")
    page.locator("#combo-steps").fill(
        json.dumps([{"tool": "web_search", "parameters": {"query": "fixture"}}])
    )
    page.locator('#combo-form button[type="submit"]').click()
    page.locator("#combo-list").get_by_text(
        "Name chosen in the browser", exact=True
    ).wait_for()
    page.locator('[data-page="ai"]').click()
    page.locator("#provider-list").get_by_text("omniroute", exact=True).wait_for()
    assert (
        page.locator("#provider-list").get_by_text("NOT VERIFIED", exact=True).count()
        == 4
    )
    page.locator('[data-page="overview"]').click()
    page.wait_for_function(
        "() => document.querySelector('#stat-combos').textContent === '1'"
    )
    if os.environ.get("CAPTURE_JARVIS_UI") == "1":
        page.screenshot(
            path=str(core.root / "docs/evidence/jarvis-control-center.png"),
            full_page=True,
        )
    assert not errors, errors
    page.locator("#logout").click()
    page.locator("#login-view").wait_for(state="visible")
    assert page.locator("#memory-list").text_content() == ""


def test_pwa_webcrypto_key_signs_real_api_requests_and_unpaired_is_denied(
    core, owner, browser_app
):
    page, context, client, errors = browser_app
    core.auth.create_user(owner, "browseruser", PASSWORD, "USER")
    context.clear_cookies()  # This is a remote logical client, not the trusted desktop profile.
    page.reload()
    login(page, "browseruser")
    page.once("dialog", lambda dialog: dialog.accept("Browser crypto fixture"))
    page.locator("#register-device").click()
    page.wait_for_function("() => state.device !== null")
    device = page.evaluate(
        "({id:state.device.id,fingerprint:state.device.fingerprint})"
    )
    denied = page.evaluate(
        "async () => {try {await request('/v1/memory'); return false;} catch(e) {return true;}}"
    )
    assert denied
    client.portal.call(
        core.devices.bind,
        owner,
        device["id"],
        "windows-bond-fixture",
        device["fingerprint"],
        ["chat", "memory", "tasks", "notifications", "combos", "ai"],
    )
    result = page.evaluate("async () => request('/v1/memory')")
    assert result == []
    assert page.evaluate("state.key.privateKey.extractable") is False
    core.devices.radio.paired.clear()
    denied = page.evaluate(
        "async () => {try {await request('/v1/memory'); return false;} catch(e) {return e.message;}}"
    )
    assert denied and isinstance(denied, str)
    assert not errors, errors
