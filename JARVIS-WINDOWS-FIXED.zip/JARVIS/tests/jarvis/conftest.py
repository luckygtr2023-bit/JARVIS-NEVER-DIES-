from pathlib import Path
import asyncio
import socket

import pytest
from jarvis_core.bluetooth import Bond
from jarvis_core.core import Core
from jarvis_core.types import Completion, DomainError

ROOT = Path(__file__).resolve().parents[2]
PASSWORD = "fixture password for tests only 2026"


class Radio:
    live = False

    def __init__(self):
        self.paired = {"windows-bond-fixture"}
        self.available = True

    async def is_paired(self, bond_id):
        if not self.available:
            raise DomainError("BLUETOOTH_NOT_VERIFIED", status=403)
        return bond_id in self.paired

    async def list_bonds(self):
        if not self.available:
            raise DomainError("BLUETOOTH_NOT_VERIFIED", status=403)
        return [Bond(v, "Synthetic test phone") for v in self.paired]


@pytest.fixture(autouse=True)
def deny_external_network(monkeypatch):
    original = socket.socket.connect

    def connect(self, address):
        if self.family in (socket.AF_INET, socket.AF_INET6):
            raise AssertionError("Live network is forbidden in unit/contract tests")
        return original(self, address)

    monkeypatch.setattr(socket.socket, "connect", connect)


@pytest.fixture
def core(tmp_path):
    service = Core(ROOT, data_dir=tmp_path / "config", radio=Radio())
    service.auth.bootstrap("owner", PASSWORD, local_proof=True)
    return service


@pytest.fixture
def owner(core):
    result = core.auth.login("owner", PASSWORD, local_proof=True)
    return core.auth.authenticate(result["token"])


def account(core, owner, name="member", role="USER", permissions=None, desktop=True):
    core.auth.create_user(owner, name, PASSWORD, role, permissions)
    result = core.auth.login(name, PASSWORD, local_proof=desktop)
    return core.auth.authenticate(result["token"]), result["token"]


def run(coroutine):
    return asyncio.run(coroutine)
