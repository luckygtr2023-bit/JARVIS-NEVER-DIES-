"""JARVIS extension tests; original Brahma tests remain unchanged."""
