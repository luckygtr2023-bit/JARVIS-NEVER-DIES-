import base64
import hashlib
import json
import pytest
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from jarvis_core.api import create_app
from .conftest import PASSWORD


@pytest.fixture
def client(core):
    app = create_app(core.root, core=core)
    with TestClient(
        app, base_url="http://127.0.0.1:8765", client=("127.0.0.1", 52000)
    ) as client:
        yield client


def owner_headers(client, core):
    result = client.post(
        "/v1/auth/login",
        headers={"X-Jarvis-Local": core.local_proof},
        json={"username": "owner", "password": PASSWORD},
    )
    assert result.status_code == 200, result.text
    return {
        "Authorization": "Bearer " + result.json()["token"],
        "X-Jarvis-Local": core.local_proof,
    }


def test_one_existing_server_and_one_database(client, core):
    assert (
        client.get("/v1/health").json()["database"] == "shared workspace_store.sqlite3"
    )
    assert client.app is client.app.state.gateway.app
    assert list(core.data_dir.glob("*.sqlite3")) == [core.db.path]


@pytest.mark.parametrize(
    "path",
    [
        "/v1/tasks",
        "/v1/memory",
        "/v1/combos",
        "/v1/users",
        "/gateway/pair",
        "/gateway/devices",
        "/gateway/logs",
    ],
)
def test_anonymous_requests_cannot_control_or_read(client, path):
    response = client.get(
        path,
        headers={"X-Role": "OWNER", "X-User-ID": "owner", "X-Device-Paired": "true"},
    )
    assert response.status_code in {401, 403}


def test_legacy_websocket_is_not_an_authentication_backdoor(client):
    with pytest.raises(Exception):
        with client.websocket_connect("/ws") as ws:
            ws.send_json({"type": "chat_message", "payload": {"text": "ignored"}})
            ws.receive_json()


def test_desktop_token_requires_local_process_proof(client, core):
    headers = owner_headers(client, core)
    client.cookies.clear()
    response = client.get(
        "/v1/tasks", headers={"Authorization": headers["Authorization"]}
    )
    assert (
        response.status_code == 403
        and response.json()["error"] == "LOCAL_PROCESS_PROOF_REQUIRED"
    )


def test_payload_cannot_choose_user_role_or_trust(client, core):
    headers = owner_headers(client, core)
    response = client.post(
        "/v1/tasks",
        headers=headers,
        json={"text": "hello", "role": "OWNER", "user_id": "forged", "paired": True},
    )
    assert response.status_code == 422
    assert response.json()["error"] == "INVALID_REQUEST"


def test_validation_does_not_echo_private_input(client, core):
    secret = "private-fixture-that-must-not-be-echoed"
    response = client.post("/v1/auth/login", json={"password": secret})
    assert response.status_code == 422 and secret not in response.text


def test_cookie_csrf_and_origin_enforced(client, core):
    owner_headers(client, core)
    response = client.post(
        "/v1/memory",
        headers={"X-Jarvis-Local": core.local_proof},
        json={"kind": "long_term", "label": "fixture", "value": "quiet"},
    )
    assert response.status_code == 403 and response.json()["error"] == "CSRF_REJECTED"
    response = client.get("/v1/health", headers={"Origin": "https://attacker.example"})
    assert response.status_code == 403


def remote_registration(client, core):
    admin = owner_headers(client, core)
    created = client.post(
        "/v1/users",
        headers=admin,
        json={
            "username": "phoneuser",
            "password": PASSWORD,
            "role": "USER",
            "permissions": ["tool:web_search"],
        },
    )
    assert created.status_code == 200
    client.cookies.clear()
    login = client.post(
        "/v1/auth/login", json={"username": "phoneuser", "password": PASSWORD}
    ).json()
    remote = {"Authorization": "Bearer " + login["token"]}
    key = ec.generate_private_key(ec.SECP256R1())
    public = base64.b64encode(
        key.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo
        )
    ).decode()
    device = client.post(
        "/v1/devices/register",
        headers=remote,
        json={"name": "Test phone", "platform": "android", "public_key": public},
    ).json()
    bound = client.post(
        f"/v1/devices/{device['id']}/bind",
        headers=admin,
        json={
            "bond_id": "windows-bond-fixture",
            "fingerprint": device["fingerprint"],
            "permissions": [
                "chat",
                "tasks",
                "memory",
                "combos",
                "ai",
                "notifications",
                "device_actions",
            ],
        },
    )
    assert bound.status_code == 200, bound.text
    return login["token"], device, key


def signed(client, token, device, key, method, path, raw=b""):
    purpose = f"HTTP:{method}:{path}:{hashlib.sha256(raw).hexdigest()}"
    challenge = client.post(
        "/v1/devices/challenge",
        headers={"Authorization": "Bearer " + token},
        json={"device_id": device["id"], "purpose": purpose},
    ).json()
    signature = base64.b64encode(
        key.sign(challenge["message"].encode(), ec.ECDSA(hashes.SHA256()))
    ).decode()
    return {
        "Authorization": "Bearer " + token,
        "X-Jarvis-Challenge": challenge["id"],
        "X-Jarvis-Signature": signature,
        "Content-Type": "application/json",
    }


def test_bearer_alone_never_authorizes_remote_control_even_after_device_login(
    client, core
):
    token, device, key = remote_registration(client, core)
    valid = signed(client, token, device, key, "GET", "/v1/tasks")
    assert client.get("/v1/tasks", headers=valid).status_code == 200
    assert (
        client.get(
            "/v1/tasks", headers={"Authorization": "Bearer " + token}
        ).status_code
        == 403
    )
    assert client.get("/v1/tasks", headers=valid).status_code == 403  # replay


def test_request_signature_binds_method_path_body_and_current_bluetooth(client, core):
    token, device, key = remote_registration(client, core)
    body = json.dumps(
        {
            "text": "Fixture",
            "steps": [{"tool": "web_search", "parameters": {"query": "fixture"}}],
        },
        separators=(",", ":"),
    ).encode()
    headers = signed(client, token, device, key, "POST", "/v1/tasks", body)
    assert (
        client.post(
            "/v1/tasks", headers=headers, content=body.replace(b"Fixture", b"Tampered")
        ).status_code
        == 403
    )
    core.devices.radio.paired.clear()
    headers = signed(client, token, device, key, "GET", "/v1/tasks")
    result = client.get("/v1/tasks", headers=headers)
    assert (
        result.status_code == 403 and result.json()["error"] == "BLUETOOTH_NOT_PAIRED"
    )


def test_android_bus_uses_same_backend_and_never_accepts_windows_execute(client, core):
    token, device, key = remote_registration(client, core)
    challenge = client.post(
        "/v1/devices/challenge",
        headers={"Authorization": "Bearer " + token},
        json={"device_id": device["id"], "purpose": "bus"},
    ).json()
    signature = base64.b64encode(
        key.sign(challenge["message"].encode(), ec.ECDSA(hashes.SHA256()))
    ).decode()
    with client.websocket_connect("/v1/device-bus") as ws:
        ws.send_json(
            {
                "type": "authenticate",
                "token": token,
                "challenge_id": challenge["id"],
                "signature": signature,
            }
        )
        assert ws.receive_json()["type"] == "authenticated"
        ws.send_json({"type": "ping", "payload": {}})
        assert ws.receive_json()["type"] == "pong"
        ws.send_json(
            {
                "type": "execute",
                "payload": {"action": "windows_shell", "command": "never run"},
            }
        )
        assert ws.receive_json()["payload"]["error"] == "UNSUPPORTED_BUS_MESSAGE"


def test_live_provider_diagnostics_do_not_claim_unrun_service(client, core):
    data = client.get("/v1/providers", headers=owner_headers(client, core)).json()
    assert data["omniroute"]["live_verification"] == "NOT VERIFIED"
    assert data["omniroute"]["enabled"] is False
    assert data["ollama"]["live_verification"] == "NOT VERIFIED"
