# JARVIS client protocol v1

## One backend, one authority

The API extends `BrahmaGateway.app`. A single uvicorn listener serves `/v1/*` and `/app/`. JARVIS domain state lives in prefixed tables of the inherited `config/workspace_store.sqlite3`. The Android and PWA clients do not maintain a second application database. Their credential stores contain device key/session material only; browser offline cache contains static assets only.

## Provisioning

1. First OWNER creation: `POST /v1/auth/bootstrap`, accepted only with the protected local-process proof from the native HUD and an empty account store.
2. Login: `POST /v1/auth/login`. Identity, role, user ID, active state and permissions come from the backend. Returned bearer sessions are stored as hashes server-side. Browser sessions also use HttpOnly/SameSite cookies plus CSRF.
3. Register: `POST /v1/devices/register` with name, platform (`android`/`pwa`), and base64 DER SubjectPublicKeyInfo for an ECDSA P-256 key. Registration grants **no control**.
4. Local OWNER binds this public-key fingerprint to a real Windows OS bond using `POST /v1/devices/{id}/bind`. The backend queries Windows before approving. No `paired:true` payload is authority.

## HTTP proof of possession

For each protected remote HTTP operation:

- Serialize the exact request bytes (UTF-8 JSON, empty bytes for GET, or raw upload bytes).
- Compute `purpose = HTTP:<METHOD>:<raw path and query>:<lowercase SHA-256 of bytes>`.
- Request `POST /v1/devices/challenge` with `device_id` and `purpose`, using the authenticated session.
- Sign the returned UTF-8 `message` with ECDSA/SHA-256 and the registered private key.
- Send `X-Jarvis-Challenge` and `X-Jarvis-Signature` (base64 signature) with the protected request and its session.

The message is:

```text
JARVIS-DEVICE-AUTH-v1
<challenge ID>
<device ID>
<random nonce>
<purpose>
```

Android signatures are ASN.1 DER; browser WebCrypto P1363 `r||s` signatures are accepted and converted. Challenges expire in 60 seconds and are consumed atomically. User/session/device/purpose match, key proof, account/session state, current Windows bond and permissions must all pass. A stolen bearer token alone is not sufficient for a protected operation.

Local desktop sessions instead require the protected local-process proof **and** valid account credentials/session; loopback IP alone does not create that authority. Self-logout/self-revocation are recovery operations that remove authority, not ways to gain it.

## Device bus

Connect to `/v1/device-bus` over WSS after requesting a challenge with purpose `bus`. The first frame is:

```json
{"type":"authenticate","token":"<session>","challenge_id":"<ID>","signature":"<base64 signature>"}
```

The browser may use its HttpOnly session cookie when `token` is empty. Origin checks still apply. After `authenticated`, clients send `ping`, `chat_message`, `voice_transcript`, `device_status` or correlated `result` messages. Text goes to Brain; Android never executes Windows code. The backend can send the inherited `execute` envelope for the explicitly allowed Android-only device handlers. Results are correlated with the authenticated socket identity, never a payload's claimed device ID.

Private task events are published by user ID, not through the inherited global broadcast. Heartbeat checks close invalid/revoked/unpaired sessions. Reconnect authenticates a new one-use challenge. Legacy `/ws` secret-only authentication is not accepted by the secure runtime.

## Core resources

- `/v1/tasks`: submit, inspect, cancel, confirm exact consequential steps.
- `/v1/memory`: scoped CRUD/search/settings/import/export; explicit local OWNER legacy import.
- `/v1/combos`: CRUD, versioned edits, enabled state and OWNER assignment/delegation.
- `/v1/providers`, `/v1/routing`, `/v1/usage`: configuration, per-user routing, diagnostics and measurements.
- `/v1/network`: local OWNER-only transport/certificate configuration; restart required.
- `/v1/files`: raw-byte uploads and user-workspace downloads.
- `/v1/users`, `/v1/audit`: authoritative account administration and metadata-only audit.

API tests are executable examples. Synthetic peers/test radios verify contracts, not real Bluetooth hardware, Android permissions, microphone behavior or provider availability.
