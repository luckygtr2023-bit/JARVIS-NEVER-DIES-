# Hermetic test: load helper definitions only, never run the Windows installer.
param([string]$Python)
$ErrorActionPreference = "Stop"
$Project = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Tokens=$null; $ParseErrors=$null
$Ast=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $Project "bootstrap_jarvis.ps1"),[ref]$Tokens,[ref]$ParseErrors)
if($ParseErrors.Count) { throw "Launcher syntax errors" }
foreach($Name in @("Quote-NativeArgument","Write-SetupLog","Invoke-Captured","Show-NativeFailure","Checked")) {
    $Definition=$Ast.Find({param($Node) $Node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $Node.Name -eq $Name},$true)
    . ([ScriptBlock]::Create($Definition.Extent.Text))
}
$Root=Join-Path $Project ".cache/launcher space (parentheses)"
$LogDir=Join-Path $Root "logs"
New-Item -ItemType Directory -Force $LogDir | Out-Null
$Log=Join-Path $LogDir "test.log"
$Script=Join-Path $Root "echo arguments.py"
[IO.File]::WriteAllText($Script,"import sys,json; print(json.dumps(sys.argv[1:])); print('harmless stderr warning',file=sys.stderr)")
$Arguments=@("spaces (and parentheses)", 'literal"quote', 'trailing\', '$not_expanded', "Unicode sample")
$Code=Invoke-Captured $Python (@($Script)+$Arguments)
if($Code -ne 0) { throw "Native argument test failed" }
$Result=$script:LastNativeResult.Stdout | ConvertFrom-Json
if(($Result | ConvertTo-Json -Compress) -ne ($Arguments | ConvertTo-Json -Compress)) { throw "Arguments changed during quoting" }
"PowerShell helper argument round-trip: PASS (Linux PowerShell; Windows execution remains NOT VERIFIED)"
