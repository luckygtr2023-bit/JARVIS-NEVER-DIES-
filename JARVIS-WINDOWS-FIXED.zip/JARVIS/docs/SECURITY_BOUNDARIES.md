# Security boundaries and remaining risks

**This is a candidate implementation, not a penetration-test certificate or native/hardware sign-off.**

## Enforced and regression-tested

- Backend-issued identity, role and user IDs; PBKDF2-SHA256 password hashes, hashed expiring/revocable sessions, login throttling, CSRF/origin/transport checks.
- First OWNER setup and sensitive local administration require a protected local-process capability plus appropriate authentication. Loopback alone is not authority.
- Remote registration is not authorization. OWNER approval binds a registered public key to a Windows OS Bluetooth bond. Unavailable/unpaired/revoked checks fail closed.
- One-use ECDSA challenges bind remote HTTP requests to method, raw path/query and body hash. WebSocket handshakes require a separate signed challenge. Client-supplied role/user/pairing fields do not grant access.
- Backend Combo role/ownership/assignment/enabled/version/tool permissions; no author-role inheritance. User-scoped memory and task reads apply even to OWNER through ordinary APIs.
- Exact consequential-action confirmation, current permission/trust checks, and revalidation after waiting for the serialized host-action lock. Cancellation is sticky and stops later steps; it does not undo an already-running action.
- Memory rejects credential-shaped/known-secret content; imports validate atomically. Private content uses AES-GCM with user/resource-associated data. Metadata-only audit and provider usage records do not contain prompts/headers/keys.
- New provider keys use Windows current-user DPAPI. The compatibility bridge reads them from retained AI helpers. Linux development storage is permission-restricted files, **not DPAPI**.
- Strict local-only routing never falls back to cloud AI; potentially cloud-calling opaque legacy helpers are blocked under that mode. It is not a whole-system offline/network sandbox.
- TLS is required for non-loopback clients; Android rejects cleartext. Optional exact certificate pinning is not a trust-all manager. TLS/certificate QR does not grant device control.

## Deliberate limits / release gates

1. **Physical trust: NOT VERIFIED — REQUIRES PHYSICAL TESTING.** Windows OS bond queries and current-user DPAPI/ACL behavior have not run on Windows here. An OS bond is a pairing-state gate, not proof of physical proximity or a continuously encrypted Bluetooth transport channel. OWNER must compare/bind the correct physical device key. Android observes local unpairing and self-revokes; no client assertion can grant pairing.
2. **Trusted local code is outside a sandbox.** The original plugins and privileged agent/generated-code tools remain capable of arbitrary execution. OWNER-only tool gates/confirmation do not turn that code into a sandbox. A hostile process already running as the Windows account can defeat an application-level boundary. Do not install untrusted plugins.
3. **Hardware side effects cannot be universally verified or cancelled.** A running inherited action may finish after cancellation. Results explicitly distinguish artifact checks, a returned tool result and unverified physical effects. No transactional rollback of Windows/device actions is claimed.
4. **Secret detection is conservative, not omniscient.** Arbitrary unlabeled passwords cannot be recognized reliably. Never intentionally supply credentials to memory/task text. New paths do not automatically ingest transcripts; short-term task context is opt-in. Legacy fields/files may contain pre-existing secrets and need review/migration.
5. **Not all legacy automatic integration startup has been accepted.** Clipboard/Instagram/standalone dashboard startup composition remains in the reference code, not automatically enabled under the new launcher. Existing useful actions/UI remain, but every autonomous integration needs explicit authority/privacy review before asserting full behavioral parity.
6. **Native Windows, audio/camera and mobile permissions remain open.** A non-debuggable Android release APK now built and passed signature/alignment checks with a test signing identity. Installation and all phone/voice/Bluetooth effects are NOT VERIFIED — REQUIRES PHYSICAL TESTING.
7. **Provider metrics cover the routed adapter calls.** Some retained autonomous/media SDK paths may have their own usage characteristics. A successful generation verifies a specific request/configuration, not every capability, billing total or factual answer. Gemini/OpenRouter/Ollama/OmniRoute live generation was not exercised in this handoff.
8. **Transport/admin exposure still needs deployment review.** Restrict firewall rules to trusted private networks. Self-signed PWA deployments need explicit browser/OS trust. The old standalone gateway/dashboard classes are retained as libraries/reference and must not be separately launched as an alternate authorization path.
9. **Installer/dependency maintenance needs native validation.** The automatic fallback installer is the signed Python 3.11.9 compatibility binary, not a claim of current security patch level. Prefer a currently patched compatible interpreter. The inherited SDK/audio deprecations, PyAutoGUI fail-safe choices, Android API/Gradle warnings and unverified downloads/native interactions remain maintenance items.
10. **Licensing is not waived.** Retain Suryaansh Tiwari's notices and the original source-available/trademark terms. User-confirmed rebranding permission was not reviewed as a document and does not imply public/commercial redistribution grants. Review Qt GPL/commercial compatibility and bundled asset/model/APK provenance before distribution.

Do not start a public deployment on the strength of the automated pass count alone. Run the native acceptance checklist and obtain an independent security review for the intended threat model.
