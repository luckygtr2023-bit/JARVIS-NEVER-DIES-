# Native acceptance — extension candidate

Current overall status: **NOT VERIFIED — REQUIRES PHYSICAL TESTING** for Windows/phone and unavailable providers. Actual Linux Ollama requests and APK build/signature checks are reported separately.

Use a controlled Windows 10/11 x64 machine and a consenting test phone. Back up existing data first. Keep unrelated devices off the test network, protect logs, and do not use destructive commands or real personal messages as initial fixtures.

| Gate | Required evidence | Current status |
|---|---|---|
| First-run launcher | Extract into a path containing spaces and parentheses; double-click BAT with/without compatible Python and with healthy/broken venv. Confirm automatic deps/imports/Chromium, meaningful errors, backend health then HUD. No manual pip. | NOT VERIFIED |
| Interpreter/runtime | Validate a patched compatible Python build, native wheels/DLLs, signed installer/UAC behavior, restricted state ACLs, DPAPI under the actual account. | NOT VERIFIED |
| Single server/database | Check one listener, one active `workspace_store.sqlite3`; verify non-destructive legacy smart-home migration and no old port-8000/secret-only parallel service. | IMPLEMENTED; portable boundary tests VERIFIED |
| Existing Qt functionality | Dashboard/chat/settings/tray/launcher, legacy controls, owner login/logout, startup/restart/DPI/GPU, updated protected key controls and original action dispatch. | Native Windows NOT VERIFIED |
| Brain and consequence gates | Real safe multi-step task, changing roles/Combo version, expired approvals, revoke while queued, cancellation during action. Verify actual artifacts/effects, not just messages. | Logic VERIFIED; Windows effects NOT VERIFIED |
| Memory | Separate two accounts; import only reviewed old facts, disable/clear, CRUD/workflows/import/export, no secret entries, no cross-user access. | Portable logic VERIFIED; real migration needs review |
| Gemini/OpenRouter/Ollama | Configure privately; invoke real diagnostics and harmless task. Check current models, fallback/privacy policy, reported tokens and latency. | NOT VERIFIED — REQUIRES PHYSICAL TESTING |
| OmniRoute | Configure the actual OpenAI-compatible endpoint/model/key and complete a real generation. Failed/mocked responses must stay NOT VERIFIED. | IMPLEMENTED, disabled initially; NOT VERIFIED — REQUIRES PHYSICAL TESTING |
| Bluetooth trust | Register client key, OS-pair phone, compare fingerprint, locally bind correct OS bond. Verify not-paired, wrong-user/key, stale/replayed proof, denied permission, unpair on each OS and revoke. | Logic VERIFIED with test adapter; physical NOT VERIFIED |
| Android build/install | Build full APK with SDK35/JDK17+, inspect signing/license obligations, install on a test phone. Do not use the preserved old APK as new-build evidence. | Release APK build/signature PASS (test-signed); installation NOT VERIFIED — REQUIRES PHYSICAL TESTING |
| Android client | Real login, Keystore signature, TLS pin/hostname mismatch, registration, chat, task status, memory, Combo/AI controls, notifications, permissions, reconnect, local unpair. Confirm no Windows execution on phone. | IMPLEMENTED; physical NOT VERIFIED |
| Voice / screen | Real mic/headphones, STT/TTS, Gemini Live, mute/unmute, unavailable/denied camera, deliberate non-sensitive screen fixture, latency and interruption. | NOT VERIFIED physically |
| PWA | Install over a properly trusted HTTPS origin; verify platform speech/notifications, offline behavior, device key persistence, logout/account switch and signed requests on target browsers. | Chromium forms/WebCrypto contract VERIFIED; installed-device behavior NOT VERIFIED |
| Security / license | Resolve trusted-code/legacy autonomous integration boundaries, current dependency security, installer fallback maintenance and intended redistribution rights. | Review required |

Only mark a row **VERIFIED** with a specific evidence reference. **IMPLEMENTED** means source exists, not that a real service or physical effect succeeded. Automated/mock passes must be labelled as such, never promoted to live/hardware VERIFIED. Preserve **NOT VERIFIED** rather than hiding failed/unavailable tests.

Reviewer: ______  Windows/device versions: ______  Evidence paths: ______
