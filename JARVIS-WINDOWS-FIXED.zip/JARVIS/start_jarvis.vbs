Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
' First run must show dependency progress/errors; do not silently swallow setup failures.
shell.Run Chr(34) & root & "\start_jarvis.bat" & Chr(34), 1, False
