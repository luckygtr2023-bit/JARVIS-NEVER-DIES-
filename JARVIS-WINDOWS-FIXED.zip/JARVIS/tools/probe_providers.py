"""Explicitly opt-in live provider probe. Uses existing adapters, never prints keys.

Run privately on the configured Windows workstation. Sends a fixed test sentence
and the inherited application system prompt. It can consume provider quota.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main() -> int:
    if sys.platform != "win32":
        print("BLOCKED: run this probe in the configured Windows foundation environment.")
        return 2
    import main as application
    from or_client import client

    failures = 0
    for name, call in (
        ("Gemini text", lambda: application._gemini_text_reply("Reply with the words Foundation check.")),
        ("OpenRouter text", lambda: client.chat("Reply with the words Foundation check.")),
    ):
        try:
            text = call()
            if not isinstance(text, str) or not text.strip():
                raise RuntimeError("Empty provider reply")
            print(f"PASS: {name} returned non-empty text ({len(text)} characters).")
        except Exception as exc:
            # Do not dump exception bodies, headers, request objects, keys, or prompts.
            print(f"FAIL: {name} ({type(exc).__name__}); inspect configuration privately.")
            failures += 1
    print("This does not verify Gemini Live audio, voice hardware, or tool execution.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
