param([switch]$LiveProviders)
$ErrorActionPreference = "Stop"
if ($env:OS -ne "Windows_NT") { throw "Run this verification script on Windows 10/11." }
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Python = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Create .venv and install requirements-dev.txt first; see README.md." }
$Evidence = Join-Path $Root "foundation\evidence\windows-local"
New-Item -ItemType Directory -Force -Path $Evidence | Out-Null
$env:BRAHMA_SKIP_UPDATE = "1"
$env:RUN_QT_TESTS = "1"
$env:RUN_BROWSER_TESTS = "1"
& $Python -c "import main; print('Native Windows main.py import: PASS')"
if ($LASTEXITCODE -ne 0) { throw "Native Windows import failed." }
& $Python -m pip check
if ($LASTEXITCODE -ne 0) { throw "Dependency compatibility check failed." }
& $Python -m pytest tests -q "--junitxml=$Evidence\tests.xml"
if ($LASTEXITCODE -ne 0) { throw "Windows regression suite failed." }
if ($LiveProviders) {
    & $Python tools/probe_providers.py
    if ($LASTEXITCODE -ne 0) { throw "Live provider checks failed; see local credentials, quota, and model availability." }
}
Write-Host "Automated checks finished. This is NOT complete Windows/hardware acceptance." -ForegroundColor Yellow
Write-Host "Complete foundation/WINDOWS_ACCEPTANCE.md for startup, real audio/screen/actions, and a paired Android device."
