"""Compatibility bridge: existing Brahma AI helpers can read JARVIS protected keys.

No API keys are copied into memory records or a replacement database. Existing
per-installation JSON remains a fallback for users who have not migrated yet.
"""

from __future__ import annotations
import json
import os
from pathlib import Path


def read_provider_key(provider: str, config_path: str | Path) -> str:
    path = Path(config_path)
    private = path.parent / "private"
    stored = private / ("provider_" + provider + ".sealed")
    if stored.exists():
        from jarvis_core.secrets import SecretStore, SecretGuard

        return SecretStore(private, SecretGuard()).get("provider_" + provider)
    env = {
        "gemini": "GEMINI_API_KEY",
        "openrouter": "OPENROUTER_API_KEY",
        "omniroute": "OMNIROUTE_API_KEY",
        "ollama": "OLLAMA_API_KEY",
    }
    value = os.getenv(env.get(provider, "JARVIS_UNUSED_PROVIDER_KEY"), "")
    if value:
        return value
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return str(data.get(provider + "_api_key", "") or "").strip()
    except (OSError, ValueError, TypeError):
        return ""
