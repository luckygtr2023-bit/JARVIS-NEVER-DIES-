import os
import sys
import subprocess
import threading
import time
import requests
from pathlib import Path
from updater import update_from_github, restart_application

BASE_DIR = Path(__file__).resolve().parent.parent
from PyQt6.QtCore import QObject, pyqtSignal

class UpdateChecker(QObject):
    update_available_sig = pyqtSignal(str)

    def __init__(self, repo_owner="titechprabhasolutions", repo_name="Brahma-Echo", branch="main"):
        super().__init__()
        self.repo_owner = repo_owner
        self.repo_name = repo_name
        self.branch = branch
        self._stop_event = threading.Event()
        self._check_thread = None

    def start(self):
        if os.environ.get("BRAHMA_SKIP_UPDATE") == "1":
            return
        if self._check_thread is None:
            self._check_thread = threading.Thread(target=self._check_loop, daemon=True, name="updater-thread")
            self._check_thread.start()

    def stop(self):
        self._stop_event.set()
        if self._check_thread:
            self._check_thread.join(timeout=1.0)

    def _get_local_hash(self):
        try:
            output = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=BASE_DIR, stderr=subprocess.DEVNULL)
            return output.decode("utf-8").strip()
        except Exception:
            return None

    def _get_remote_hash(self):
        url = f"https://api.github.com/repos/{self.repo_owner}/{self.repo_name}/commits/{self.branch}"
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                data = response.json()
                return data.get("sha")
        except Exception as e:
            print(f"[Updater] Error fetching remote hash: {e}")
        return None

    def _check_loop(self):
        while not self._stop_event.is_set():
            local_hash = self._get_local_hash()
            remote_hash = self._get_remote_hash()

            if local_hash and remote_hash and local_hash != remote_hash:
                print(f"[Updater] Update detected! Local: {local_hash[:7]}, Remote: {remote_hash[:7]}")
                self.update_available_sig.emit(remote_hash)
                break # Stop checking once an update is detected

            # Check every hour
            for _ in range(3600):
                if self._stop_event.is_set():
                    break
                time.sleep(1)

def apply_update_and_restart():
    """Reuse the inherited clean-checkout, fast-forward updater; never reset a fork."""
    print("[Updater] Checking for a safe fast-forward update...")
    try:
        if update_from_github(BASE_DIR):
            restart_application(BASE_DIR)
        else:
            print("[Updater] No safe update applied. Local files were left unchanged.")
    except Exception as e:
        print(f"[Updater] Failed to apply update: {e}")
