# JARVIS security and release status

Read [docs/SECURITY_BOUNDARIES.md](docs/SECURITY_BOUNDARIES.md) and [release/FINAL_REPORT.md](release/FINAL_REPORT.md).

A successful source build, test fixture or signature check is not a physical/production acceptance certificate. Unavailable hardware and provider checks remain **NOT VERIFIED — REQUIRES PHYSICAL TESTING**.

Use only a controlled test environment until the listed gates are completed. Keep provider/signing keys private. Do not use legacy standalone gateway/dashboard entry points as a substitute for the authoritative JARVIS identity, device, Bluetooth, role and confirmation checks.
