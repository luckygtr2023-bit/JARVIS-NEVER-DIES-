# Attribution and permission notice

**J.A.R.V.I.S. — Just A Rather Very Intelligent System** is a modified, foundation-first adaptation of **Brahma Echo**.

- Upstream: https://github.com/titechprabhasolutions/Brahma-Echo
- Inspected baseline: `41111af7b9d93e773a89f0bf2d5f9f44ca867642`
- Copyright (c) 2026 **Suryaansh Tiwari**.
- Governing upstream documents: unchanged `LICENSE` (Brahma Source-Available License v1.0) and `TRADEMARK.md`.
- This adaptation does not claim original authorship of Brahma Echo, and does not imply endorsement by its author.

On 7 September 2026, the requesting user selected **“Yes, permission obtained”** when asked whether prior written permission from Suryaansh Tiwari had been obtained for the J.A.R.V.I.S. rename and replacement of Brahma branding. The actual permission instrument was not supplied or reviewed. Work proceeded on that confirmation for this adaptation. Do not infer permission for public distribution, sale, sublicensing, trademark use beyond that scope, or any other reserved right.

This notice does not replace, amend or expand the upstream license. The software is source-available; it is not licensed as OSI open source. Existing copyright/trademark notices, upstream branding assets and historical documentation are retained. `foundation/UPSTREAM_README.md` is the original README, and `foundation/UPSTREAM.json` records every original tracked file.

The new J.A.R.V.I.S. monogram files were created locally for this adaptation; they do not use Marvel/Iron Man artwork or imply a third-party affiliation. Availability of the requested product name as a trademark has not been assessed.

## Third-party obligations

- The bundled desktop/Android `three.min.js` files identify **Three.js r128**, Copyright 2010–2021 Three.js Authors, MIT. Their headers remain unchanged. The r128 license is copied to `foundation/licenses/Threejs-r128-MIT.txt`.
- The retained `dashboard/static/crypto-js.min.js` is the inherited **CryptoJS 4.2.0** dependency. Its MIT notice is copied to `foundation/licenses/CryptoJS-4.2.0-MIT.txt` from the upstream release.
- Android Gradle wrapper scripts retain their Apache-2.0 notices. Android/JavaScript dependency manifests and locks remain present.
- The installed PyQt6 and PyQt6-WebEngine wheels identify **GPL-3.0-only**. Their license texts are copied to `foundation/licenses/`. Commercial licensing is a separate option from the vendor; none has been evidenced here. Do not assume that a source-available application can be redistributed with GPL Qt binaries under additional restrictions. Review the intended distribution and obtain compatible permissions/licenses before packaging.
- `foundation/evidence/dependency-licenses.json` records installed Python package license metadata. This is an inventory, not a complete transitive legal clearance or an endorsement of every metadata entry.
- No independent provenance, redistribution grant, APK signature verification, or license clearance has been established for every bundled image/model/APK. Preserve existing notices and resolve those questions before release. ZIP-integrity checking is not a trust/signature check.

This handoff contains source, tests and evidence; it is not a new open-source license grant or a statement that public/commercial redistribution is permitted.
