J.A.R.V.I.S. — FULL WINDOWS PACKAGE WITH STARTUP FIX ALREADY APPLIED

You do NOT need to replace individual BAT/VBS/PowerShell files.

1. Close the old failed launcher window.
2. Extract this entire ZIP to a NEW folder. Keep the old folder as a backup.
3. Open the extracted JARVIS folder.
4. Double-click start_jarvis.bat ONLY and wait for automatic setup.

Do not launch bootstrap_jarvis.ps1 separately. Do not copy the old .venv into
this new folder. The patched launcher repairs its environment automatically
and can use a per-user LocalAppData environment if the project drive fails.

If you already configured accounts, keys, memory or paired devices, retain
the old installation and its data; do not overwrite or delete it blindly.

This package contains the applied 2026-09-08b startup hotfix. Its 19 helper
checks passed using real PowerShell/Python execution on Linux. The exact
underlying error on your Windows machine was not visible in the screenshot.
A successful complete Windows launch is therefore not claimed yet.

If it still stops, the new launcher shows the underlying error. Send the
new config\logs\launcher.log after removing private information.
