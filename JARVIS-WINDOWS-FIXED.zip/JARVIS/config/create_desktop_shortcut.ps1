# Portable equivalent of the existing per-user shortcut, with no author-specific paths.
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Desktop = [Environment]::GetFolderPath("Desktop")
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop "JARVIS.lnk"))
$Shortcut.TargetPath = Join-Path $env:WINDIR "System32\wscript.exe"
$Shortcut.Arguments = '"' + (Join-Path $Root "start_jarvis.vbs") + '"'
$Shortcut.WorkingDirectory = $Root
$Shortcut.WindowStyle = 7
$Shortcut.Description = "J.A.R.V.I.S. - Just A Rather Very Intelligent System; based on Brahma Echo"
$Shortcut.IconLocation = (Join-Path $Root "assets\jarvis_logo.ico") + ",0"
$Shortcut.Save()
