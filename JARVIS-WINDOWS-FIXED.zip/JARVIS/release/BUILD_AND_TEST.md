# Build and test notes

This package is named FINAL as requested, but its **release-acceptance gate remains open** where native/live/physical testing is unavailable. A filename is not a verification claim.

## Windows startup

Extract the complete `JARVIS` folder and double-click `start_jarvis.bat`. The checked launcher detects compatible Python, creates/repairs the environment, installs dependencies and Chromium, checks imports, starts the single backend, checks health and opens the retained HUD. Legacy launcher names delegate to this same path.

The pipeline has source/PowerShell helper checks, **not a real Windows execution result in this session**. Windows startup, voice, screen awareness and Windows action effects are **NOT VERIFIED — REQUIRES PHYSICAL TESTING**. No EXE is included because no native Windows executable build was successfully performed.

For first-run dependency downloads, keep internet access available. Create your own OWNER account in the local HUD; there is no default login. Configure provider keys locally, never in memory or source. Current compatibility fallback: signed Python 3.11.9 installer; this is not a guarantee of the latest interpreter security patch level. Prefer a currently patched compatible 3.11/3.12 installation for deployment.

## Android build

Source remains in `brahma-connect-android`, package `com.brahma.connect`, min SDK26 / target35. A real Gradle `assembleRelease` completed with JDK21/SDK35. The supplied APK is a non-debuggable release variant signed with a **test signing identity**, not a production key.

Rebuild with JDK17+, SDK35 and build-tools35:

```powershell
cd brahma-connect-android
.\gradlew.bat --no-daemon --max-workers=1 :app:assembleRelease
```

That produces an unsigned release APK unless your own signing configuration is supplied. Signing keys/passwords are intentionally not included. Use your own production signing identity for any real release. The test-signed APK cannot update an existing app signed by another key; use a test device/profile and protect existing data.

The build used bounded workers and additional temporary swap after low-memory failures. APK signature, ZIP integrity, manifest and alignment were checked; none proves phone installation, JNI compatibility, voice, Bluetooth or cross-device behavior. Those remain **NOT VERIFIED — REQUIRES PHYSICAL TESTING**.

## Tests and reports

`tests/` preserves the 13 original Brahma cases, the foundation regressions and extension tests. Package-aware retention guards permit only the documented omission of cache/manual-mutation/old-APK artifacts, never runtime modules or license files.

The final package was tested from a separate extracted staging tree. Synthetic account/device/provider fixtures are labelled as tests; their success is **not live-provider or hardware verification**. The final report and JSON summaries distinguish actual local integration/provider requests from offline checks.

The real Ollama run used a temporary Linux CPU service and `qwen2.5:0.5b`; model/runtime downloads and service logs are not included. The fallback test used a deliberately closed local endpoint followed by a real Ollama response. It does **not** verify an OmniRoute deployment.
