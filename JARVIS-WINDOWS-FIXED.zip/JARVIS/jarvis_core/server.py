"""Single backend entry point. Desktop startup normally uses jarvis_core.desktop."""

from pathlib import Path
import argparse
import uvicorn

from .api import create_app
from .core import Core
from .runtime import (
    network_config,
    server_options,
    allowed_origins,
    prepare_shared_storage,
)


def main():
    parser = argparse.ArgumentParser(
        description="JARVIS shared backend; no native HUD or physical verification implied"
    )
    parser.add_argument("--data-dir", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    config = network_config(root)
    core = Core(root, data_dir=args.data_dir)
    prepare_shared_storage(core)
    app = create_app(
        root,
        core=core,
        host=config["host"],
        port=config["port"],
        origins=allowed_origins(config),
    )
    uvicorn.run(app, **server_options(root, config))


if __name__ == "__main__":
    main()
