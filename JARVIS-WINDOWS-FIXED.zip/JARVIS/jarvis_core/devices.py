from __future__ import annotations

import base64
import hashlib
import json
import secrets
import time
import uuid

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from .auth import Auth
from .database import Database
from .types import DomainError, Principal


class Devices:
    def __init__(self, db: Database, auth: Auth, radio, clock=time.time):
        self.db, self.auth, self.radio, self.clock = db, auth, radio, clock
        self.on_revoke = None

    def register(self, actor: Principal, name: str, platform: str, public_key: str):
        actor = self.auth.revalidate(actor)
        actor.require("device:register")
        if not 1 <= len(name.strip()) <= 80 or platform not in {"android", "pwa"}:
            raise DomainError("INVALID_DEVICE")
        try:
            raw = base64.b64decode(public_key, validate=True)
            key = serialization.load_der_public_key(raw)
            if not isinstance(key, ec.EllipticCurvePublicKey) or not isinstance(
                key.curve, ec.SECP256R1
            ):
                raise ValueError()
        except Exception:
            raise DomainError(
                "INVALID_DEVICE_KEY",
                "Use an ECDSA P-256 SubjectPublicKeyInfo public key.",
            )
        fingerprint = hashlib.sha256(raw).hexdigest()
        old = self.db.one("SELECT * FROM j_devices WHERE fingerprint=?", (fingerprint,))
        if old:
            if old["user_id"] != actor.user_id or old["revoked"]:
                raise DomainError("DEVICE_REGISTRATION_REJECTED", status=403)
            return self.public(old)
        if (
            self.db.one(
                "SELECT COUNT(*) n FROM j_devices WHERE user_id=?", (actor.user_id,)
            )["n"]
            >= 20
        ):
            raise DomainError("DEVICE_LIMIT", status=409)
        did = uuid.uuid4().hex
        self.db.execute(
            "INSERT INTO j_devices(id,user_id,name,platform,public_key,fingerprint,created) VALUES(?,?,?,?,?,?,?)",
            (
                did,
                actor.user_id,
                name.strip(),
                platform,
                public_key,
                fingerprint,
                self.clock(),
            ),
        )
        self.db.audit(actor.user_id, "device_register", did, "pending_owner_binding")
        return self.get(actor, did)

    def public(self, row):
        return {
            "id": row["id"],
            "user_id": row["user_id"],
            "name": row["name"],
            "platform": row["platform"],
            "fingerprint": row["fingerprint"],
            "bond_id": row["bond_id"],
            "approved": bool(row["approved"]),
            "revoked": bool(row["revoked"]),
            "permissions": json.loads(row["permissions"]),
            "status": json.loads(row["status"]),
            "last_seen": row["last_seen"],
        }

    def get(self, actor: Principal, device_id: str):
        actor = self.auth.revalidate(actor)
        row = self.db.one("SELECT * FROM j_devices WHERE id=?", (device_id,))
        if not row or (row["user_id"] != actor.user_id and actor.role != "OWNER"):
            raise DomainError("DEVICE_NOT_FOUND", status=404)
        return self.public(row)

    def list(self, actor: Principal):
        actor = self.auth.revalidate(actor)
        rows = (
            self.db.all("SELECT * FROM j_devices ORDER BY created DESC")
            if actor.role == "OWNER"
            else self.db.all(
                "SELECT * FROM j_devices WHERE user_id=? ORDER BY created DESC",
                (actor.user_id,),
            )
        )
        return [self.public(row) for row in rows]

    async def bind(
        self,
        actor: Principal,
        device_id: str,
        bond_id: str,
        fingerprint: str,
        permissions: list[str],
    ):
        actor = self.auth.revalidate(actor)
        actor.owner()
        if actor.channel != "desktop":
            raise DomainError("LOCAL_OWNER_BINDING_REQUIRED", status=403)
        device = self.get(actor, device_id)
        if device["revoked"] or not secrets.compare_digest(
            device["fingerprint"], fingerprint
        ):
            raise DomainError("DEVICE_FINGERPRINT_MISMATCH", status=403)
        if not await self.radio.is_paired(bond_id):
            raise DomainError(
                "BLUETOOTH_NOT_PAIRED",
                "Pair this phone in Windows first; control remains denied.",
                403,
            )
        allowed = {
            "chat",
            "tasks",
            "memory",
            "combos",
            "ai",
            "device_actions",
            "notifications",
        }
        if not permissions or not set(permissions) <= allowed:
            raise DomainError("INVALID_DEVICE_PERMISSIONS")
        self.db.execute(
            "UPDATE j_devices SET bond_id=?,approved=1,permissions=? WHERE id=? AND revoked=0",
            (bond_id, json.dumps(sorted(set(permissions))), device_id),
        )
        # A changed binding/grant must be authenticated afresh, not inherited by old sessions.
        self.db.execute(
            "UPDATE j_sessions SET device_id=NULL,proof_until=0 WHERE device_id=?",
            (device_id,),
        )
        self.db.audit(
            actor.user_id, "device_bind", device_id, "os_paired_owner_approved"
        )
        return self.get(actor, device_id)

    def challenge(self, actor: Principal, device_id: str, purpose: str = "session"):
        actor = self.auth.revalidate(actor)
        row = self.db.one(
            "SELECT * FROM j_devices WHERE id=? AND user_id=?",
            (device_id, actor.user_id),
        )
        if not row or row["revoked"]:
            raise DomainError("DEVICE_NOT_AUTHORIZED", status=403)
        if (
            not isinstance(purpose, str)
            or len(purpose) > 2400
            or not (purpose in {"session", "bus"} or purpose.startswith("HTTP:"))
        ):
            raise DomainError("INVALID_CHALLENGE_PURPOSE")
        if actor.device_id and actor.device_id != device_id:
            raise DomainError("SESSION_DEVICE_MISMATCH", status=403)
        self.db.execute(
            "DELETE FROM j_challenges WHERE expires<? OR consumed=1", (self.clock(),)
        )
        if (
            self.db.one(
                "SELECT COUNT(*) n FROM j_challenges WHERE session_id=?",
                (actor.session_id,),
            )["n"]
            >= 40
        ):
            raise DomainError("CHALLENGE_RATE_LIMIT", status=429)
        challenge_id, nonce = uuid.uuid4().hex, secrets.token_urlsafe(40)
        self.db.execute(
            "INSERT INTO j_challenges VALUES(?,?,?,?,?,0,?)",
            (
                challenge_id,
                actor.session_id,
                device_id,
                nonce,
                self.clock() + 60,
                purpose,
            ),
        )
        return {
            "id": challenge_id,
            "device_id": device_id,
            "message": self.signing_message(challenge_id, device_id, nonce, purpose),
            "expires": self.clock() + 60,
        }

    @staticmethod
    def signing_message(challenge_id, device_id, nonce, purpose="session"):
        return f"JARVIS-DEVICE-AUTH-v1\n{challenge_id}\n{device_id}\n{nonce}\n{purpose}"

    async def authorize(
        self,
        actor: Principal,
        challenge_id: str,
        signature: str,
        expected_purpose: str = "session",
    ):
        actor = self.auth.revalidate(actor)
        challenge = self.db.one(
            "SELECT * FROM j_challenges WHERE id=? AND session_id=?",
            (challenge_id, actor.session_id),
        )
        if (
            not challenge
            or challenge["consumed"]
            or challenge["expires"] <= self.clock()
        ):
            raise DomainError("CHALLENGE_EXPIRED", status=403)
        if challenge["purpose"] != expected_purpose:
            raise DomainError("DEVICE_PROOF_PURPOSE_MISMATCH", status=403)
        if actor.channel != "remote" or (
            actor.device_id and actor.device_id != challenge["device_id"]
        ):
            raise DomainError("SESSION_DEVICE_MISMATCH", status=403)
        row = self.db.one(
            "SELECT * FROM j_devices WHERE id=? AND user_id=?",
            (challenge["device_id"], actor.user_id),
        )
        if not row or row["revoked"] or not row["approved"]:
            raise DomainError("DEVICE_NOT_AUTHORIZED", status=403)
        try:
            key = serialization.load_der_public_key(base64.b64decode(row["public_key"]))
            raw = base64.b64decode(signature, validate=True)
            # Android returns ASN.1 DER; WebCrypto browsers return IEEE-P1363 r||s.
            if len(raw) == 64:
                raw = encode_dss_signature(
                    int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big")
                )
            key.verify(
                raw,
                self.signing_message(
                    challenge_id, row["id"], challenge["nonce"], challenge["purpose"]
                ).encode(),
                ec.ECDSA(hashes.SHA256()),
            )
        except (ValueError, InvalidSignature, TypeError):
            raise DomainError("DEVICE_PROOF_REJECTED", status=403)
        if not await self.radio.is_paired(row["bond_id"]):
            raise DomainError("BLUETOOTH_NOT_PAIRED", status=403)
        self.auth.revalidate(actor)
        with self.db.transaction() as conn:
            current = conn.execute(
                "SELECT * FROM j_devices WHERE id=? AND user_id=?",
                (row["id"], actor.user_id),
            ).fetchone()
            session = conn.execute(
                "SELECT * FROM j_sessions WHERE id=?", (actor.session_id,)
            ).fetchone()
            if (
                not current
                or current["revoked"]
                or not current["approved"]
                or current["bond_id"] != row["bond_id"]
                or not session
                or session["revoked"]
                or (session["device_id"] and session["device_id"] != row["id"])
            ):
                raise DomainError("DEVICE_NOT_AUTHORIZED", status=403)
            changed = conn.execute(
                "UPDATE j_challenges SET consumed=1 WHERE id=? AND consumed=0 AND expires>?",
                (challenge_id, self.clock()),
            ).rowcount
            if not changed:
                raise DomainError("CHALLENGE_REPLAY", status=403)
            conn.execute(
                "UPDATE j_sessions SET device_id=?,proof_until=? WHERE id=?",
                (row["id"], self.clock() + 300, actor.session_id),
            )
            conn.execute(
                "UPDATE j_devices SET last_seen=? WHERE id=? AND revoked=0",
                (self.clock(), row["id"]),
            )
        return {
            "authorized": True,
            "device_id": row["id"],
            "proof_expires": self.clock() + 300,
            "bluetooth": "PAIRED",
            "verification_source": "Windows OS"
            if getattr(self.radio, "live", False)
            else "test adapter (NOT physical verification)",
        }

    async def enforce(self, actor: Principal, capability: str = "chat") -> Principal:
        actor = self.auth.revalidate(actor)
        if actor.channel == "desktop":
            return actor  # HTTP boundary separately requires the protected local-process proof.
        if not actor.device_id or actor.proof_until <= self.clock():
            raise DomainError(
                "DEVICE_AUTHENTICATION_REQUIRED",
                "Authenticate the registered device key before control.",
                403,
            )
        row = self.db.one(
            "SELECT * FROM j_devices WHERE id=? AND user_id=?",
            (actor.device_id, actor.user_id),
        )
        if not row or row["revoked"] or not row["approved"] or not row["bond_id"]:
            raise DomainError("DEVICE_NOT_AUTHORIZED", status=403)
        if capability not in json.loads(row["permissions"]):
            raise DomainError("DEVICE_PERMISSION_DENIED", status=403)
        if not await self.radio.is_paired(row["bond_id"]):
            self.db.execute(
                "UPDATE j_sessions SET proof_until=0 WHERE device_id=?",
                (actor.device_id,),
            )
            raise DomainError(
                "BLUETOOTH_NOT_PAIRED",
                "Unpaired: all cross-device control denied.",
                403,
            )
        actor = self.auth.revalidate(actor)
        current = self.db.one(
            "SELECT approved,revoked,bond_id,permissions FROM j_devices WHERE id=? AND user_id=?",
            (actor.device_id, actor.user_id),
        )
        if (
            not current
            or current["revoked"]
            or not current["approved"]
            or current["bond_id"] != row["bond_id"]
            or capability not in json.loads(current["permissions"])
        ):
            raise DomainError("DEVICE_NOT_AUTHORIZED", status=403)
        return actor

    async def revoke(self, actor: Principal, device_id: str):
        actor = self.auth.revalidate(actor)
        device = self.get(actor, device_id)
        if device["user_id"] != actor.user_id:
            actor.owner()
            await self.enforce(actor, "device_actions")
        with self.db.transaction() as conn:
            conn.execute(
                "UPDATE j_devices SET revoked=1,approved=0 WHERE id=?", (device_id,)
            )
            conn.execute(
                "UPDATE j_sessions SET revoked=1,proof_until=0 WHERE device_id=?",
                (device_id,),
            )
            conn.execute("DELETE FROM j_challenges WHERE device_id=?", (device_id,))
        if self.on_revoke:
            await self.on_revoke(device_id)
        self.db.audit(actor.user_id, "device_revoke", device_id, "control_denied")

    async def update_status(self, actor: Principal, status: dict):
        actor = await self.enforce(actor, "notifications")
        if not actor.device_id:
            raise DomainError("DEVICE_REQUIRED")
        # Client-reported telemetry cannot write trust, permissions or ownership.
        allowed = {
            "battery",
            "charging",
            "network",
            "app_version",
            "bluetooth_reported",
            "microphone_permission",
            "notification_permission",
        }
        if not set(status) <= allowed or len(json.dumps(status)) > 2000:
            raise DomainError("INVALID_DEVICE_TELEMETRY")
        self.db.execute(
            "UPDATE j_devices SET status=?,last_seen=? WHERE id=? AND user_id=?",
            (json.dumps(status), self.clock(), actor.device_id, actor.user_id),
        )
