from __future__ import annotations

import asyncio
import json
import time
from uuid import uuid4

from brahma_connect.gateway.protocol import build_message, ProtocolTypes
from brahma_connect.gateway.websocket import ConnectionHub
from .types import DomainError


class DeviceBus:
    """Reuse the inherited hub/protocol, adding authoritative scoped connections."""

    def __init__(self, devices, auth, guard, hub: ConnectionHub | None = None):
        self.devices, self.auth, self.guard = devices, auth, guard
        self.hub = hub or ConnectionHub()
        self.sessions: dict[str, str] = {}
        self._send_locks: dict[str, asyncio.Lock] = {}

    async def connect(self, websocket, actor):
        actor = await self.devices.enforce(actor, "notifications")
        if not actor.device_id:
            raise DomainError("DEVICE_REQUIRED", status=403)
        await self.hub.close_device(
            actor.device_id, 4000, "Replaced by authenticated reconnect"
        )
        await self.hub.register(websocket, actor.device_id)
        self.sessions[actor.device_id] = actor.session_id
        self._send_locks.setdefault(actor.device_id, asyncio.Lock())

    async def disconnect(self, websocket):
        state_id = self.hub._socket_index.get(id(websocket), "")
        state = await self.hub.get(state_id) if state_id else None
        if state and state.websocket is websocket:
            for future in list(state.pending.values()):
                if not future.done():
                    future.cancel()
            self.sessions.pop(state_id, None)
            self._send_locks.pop(state_id, None)
        await self.hub.unregister(websocket)

    async def close_device(self, device_id):
        await self.hub.close_device(device_id, 4403, "Trust or authorization revoked")
        self.sessions.pop(device_id, None)

    async def _send(self, device_id, message):
        lock = self._send_locks.get(device_id)
        if not lock:
            return False
        async with lock:
            return await asyncio.wait_for(
                self.hub.send_to_device(device_id, message), 5
            )

    async def publish(self, user_id, event):
        # Never use the inherited global broadcast for private chat/memory/task data.
        for did, sid in list(self.sessions.items()):
            try:
                actor = self.auth.from_session(sid)
                if actor.user_id != user_id:
                    continue
                await self.devices.enforce(actor, "notifications")
                await self._send(did, event)
            except DomainError:
                await self.close_device(did)
            except Exception:
                pass

    async def heartbeat(self):
        while True:
            await asyncio.sleep(2)
            for did, sid in list(self.sessions.items()):
                try:
                    await self.devices.enforce(
                        self.auth.from_session(sid), "notifications"
                    )
                except DomainError:
                    await self.close_device(did)

    async def execute_android(self, actor, target, action, parameters=None):
        actor = await self.devices.enforce(actor, "device_actions")
        actor.require("tool:connect_execute")
        device = self.devices.get(actor, target)
        if device["user_id"] != actor.user_id:
            raise DomainError("TARGET_DEVICE_OWNERSHIP_REQUIRED", status=403)
        if (
            not device["approved"]
            or device["revoked"]
            or not await self.devices.radio.is_paired(device["bond_id"])
        ):
            raise DomainError("TARGET_DEVICE_NOT_TRUSTED", status=403)
        allowed = {
            "get_battery",
            "get_device_info",
            "launch_app",
            "close_app",
            "open_url",
            "capture_screen",
            "take_photo",
            "clipboard_get",
            "clipboard_set",
            "media_play",
            "media_pause",
            "volume_set",
            "notification_list",
            "list_files",
            "read_file",
            "flashlight_on",
            "flashlight_off",
            "volume_get",
            "file_list",
            "file_read",
            "file_write",
            "file_delete",
        }
        if action not in allowed:
            raise DomainError(
                "UNSUPPORTED_ANDROID_ACTION",
                "No Windows/shell command is sent to Android.",
            )
        if "device_actions" not in device["permissions"]:
            raise DomainError("DEVICE_PERMISSION_DENIED", status=403)
        sid = self.sessions.get(target)
        if not sid:
            raise DomainError("DEVICE_OFFLINE", status=409)
        await self.devices.enforce(self.auth.from_session(sid), "device_actions")
        request_id = uuid4().hex
        future = await self.hub.set_pending(target, request_id)
        message = build_message(
            ProtocolTypes.EXECUTE,
            {"device": target, "action": action, "parameters": parameters or {}},
            request_id=request_id,
        )
        try:
            if not await self._send(target, message):
                raise DomainError("DEVICE_OFFLINE", status=409)
            return await asyncio.wait_for(future, 30)
        except asyncio.TimeoutError:
            raise DomainError(
                "DEVICE_TIMEOUT",
                "No device result arrived; no action success is claimed.",
                504,
            )
        finally:
            state = await self.hub.get(target)
            if state:
                state.pending.pop(request_id, None)
            if not future.done():
                future.cancel()

    async def result(self, actor, request_id, payload):
        actor = await self.devices.enforce(actor, "device_actions")
        if len(json.dumps(payload)) > 256_000:
            raise DomainError("DEVICE_RESULT_TOO_LARGE")
        # Identity comes from the verified connection, not payload['device'].
        await self.hub.resolve_pending(actor.device_id, request_id, payload)
