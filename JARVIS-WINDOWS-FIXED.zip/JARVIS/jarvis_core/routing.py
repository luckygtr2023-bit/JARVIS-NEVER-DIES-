from __future__ import annotations

import asyncio
import hashlib
import json
import os
import time
from pathlib import Path
from urllib.parse import urlsplit

import httpx

from .types import Completion, DomainError, Principal, Status

DEFAULTS = {
    "gemini": {
        "enabled": True,
        "model": "gemini-2.5-flash",
        "base_url": "",
        "timeout": 45,
        "revision": 1,
    },
    "openrouter": {
        "enabled": True,
        "model": "",
        "base_url": "https://openrouter.ai/api/v1",
        "timeout": 45,
        "revision": 1,
    },
    "ollama": {
        "enabled": False,
        "model": "",
        "base_url": "http://127.0.0.1:11434",
        "timeout": 90,
        "revision": 1,
    },
    "omniroute": {
        "enabled": False,
        "model": "",
        "base_url": "",
        "timeout": 60,
        "revision": 1,
    },
}


class ProviderFailure(DomainError):
    def __init__(self, code="PROVIDER_FAILED"):
        super().__init__(
            code,
            "Provider request failed. Review configuration and diagnostics; no private response body is logged.",
            502,
        )


class Providers:
    """Gemini SDK + existing OpenRouter engine + optional Ollama/OmniRoute.

    Injected HTTP/SDK clients are deliberately NOT counted as live verification.
    """

    def __init__(
        self,
        secrets,
        root: Path,
        *,
        http_client=None,
        gemini_factory=None,
        openrouter_factory=None,
    ):
        self.secrets, self.root = secrets, Path(root)
        self.http = http_client
        self.gemini_factory, self.openrouter_factory = (
            gemini_factory,
            openrouter_factory,
        )

    def key(self, name):
        env = {
            "gemini": "GEMINI_API_KEY",
            "openrouter": "OPENROUTER_API_KEY",
            "omniroute": "OMNIROUTE_API_KEY",
            "ollama": "OLLAMA_API_KEY",
        }[name]
        value = self.secrets.get("provider_" + name) or os.getenv(env, "")
        if not value and name in {"gemini", "openrouter"}:
            # Compatibility only: new credentials go to the protected store.
            try:
                value = str(
                    json.loads((self.root / "config/api_keys.json").read_text()).get(
                        name + "_api_key"
                    )
                    or ""
                )
            except (OSError, ValueError):
                value = ""
        self.secrets.guard.register(value)
        return value

    async def complete(self, name, cfg, messages, max_tokens=2048) -> Completion:
        model = cfg["model"]
        if not model:
            raise ProviderFailure("MODEL_NOT_CONFIGURED")
        key = self.key(name)
        if name in {"gemini", "openrouter"} and not key:
            raise ProviderFailure("PROVIDER_KEY_MISSING")
        try:
            if name == "openrouter":
                if self.openrouter_factory is None:
                    from or_client import OpenRouterClient

                    client = OpenRouterClient()
                else:
                    client = self.openrouter_factory()
                response = await asyncio.to_thread(
                    client.completion_once,
                    messages,
                    model,
                    key,
                    max_tokens,
                    0.3,
                    cfg["timeout"],
                )
                usage = response.get("usage") or {}
                return Completion(
                    response["text"],
                    name,
                    model,
                    usage.get("prompt_tokens"),
                    usage.get("completion_tokens"),
                    live=self.openrouter_factory is None,
                )
            if name == "gemini":
                from google import genai
                from google.genai import types

                factory = self.gemini_factory or genai.Client
                client = factory(
                    api_key=key, http_options={"timeout": int(cfg["timeout"] * 1000)}
                )
                system = "\n".join(
                    m["content"] for m in messages if m["role"] == "system"
                )
                content = [
                    types.Content(
                        role="model" if m["role"] == "assistant" else "user",
                        parts=[types.Part(text=m["content"])],
                    )
                    for m in messages
                    if m["role"] != "system"
                ]
                try:
                    response = await client.aio.models.generate_content(
                        model=model,
                        contents=content,
                        config=types.GenerateContentConfig(
                            system_instruction=system,
                            max_output_tokens=max_tokens,
                            temperature=0.3,
                        ),
                    )
                finally:
                    if hasattr(client.aio, "aclose"):
                        await client.aio.aclose()
                    if hasattr(client, "close"):
                        client.close()
                usage = getattr(response, "usage_metadata", None)
                return Completion(
                    response.text or "",
                    name,
                    model,
                    getattr(usage, "prompt_token_count", None),
                    getattr(usage, "candidates_token_count", None),
                    live=self.gemini_factory is None,
                )
            if name not in {"ollama", "omniroute"}:
                raise ProviderFailure("UNKNOWN_PROVIDER")
            headers = {"Authorization": "Bearer " + key} if key else {}
            if name == "ollama":
                url = cfg["base_url"].rstrip("/") + "/api/chat"
                body = {
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "options": {"num_predict": max_tokens, "temperature": 0.3},
                }
            else:
                url = cfg["base_url"].rstrip("/") + "/chat/completions"
                body = {
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    "max_tokens": max_tokens,
                    "temperature": 0.3,
                }

            async def perform(client):
                response = await client.post(
                    url, json=body, headers=headers, timeout=cfg["timeout"]
                )
                if response.status_code >= 400:
                    raise ProviderFailure(f"PROVIDER_HTTP_{response.status_code}")
                data = response.json()
                if name == "ollama":
                    return Completion(
                        str(data.get("message", {}).get("content", "")),
                        name,
                        model,
                        data.get("prompt_eval_count"),
                        data.get("eval_count"),
                        live=self.http is None,
                    )
                usage = data.get("usage") or {}
                return Completion(
                    str(
                        data.get("choices", [{}])[0]
                        .get("message", {})
                        .get("content", "")
                    ),
                    name,
                    model,
                    usage.get("prompt_tokens"),
                    usage.get("completion_tokens"),
                    live=self.http is None,
                )

            if self.http:
                return await perform(self.http)
            async with httpx.AsyncClient(
                follow_redirects=False, trust_env=False
            ) as client:
                return await perform(client)
        except ProviderFailure:
            raise
        except PermissionError:
            raise ProviderFailure("PROVIDER_AUTH_REJECTED")
        except (httpx.TimeoutException, TimeoutError):
            raise ProviderFailure("PROVIDER_TIMEOUT")
        except Exception:
            raise ProviderFailure()


class Router:
    def __init__(self, db, auth, providers: Providers, guard):
        self.db, self.auth, self.providers, self.guard = db, auth, providers, guard
        self._cooldowns: dict[tuple[str, str], float] = {}

    def configurations(self):
        return {
            name: self.db.setting("provider:" + name, dict(default))
            for name, default in DEFAULTS.items()
        }

    def _hash(self, cfg):
        return hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest()

    def configure(self, actor: Principal, name: str, values: dict):
        actor = self.auth.revalidate(actor)
        actor.owner()
        if name not in DEFAULTS or not set(values) <= {
            "enabled",
            "model",
            "base_url",
            "timeout",
        }:
            raise DomainError("INVALID_PROVIDER_CONFIG")
        cfg = {**self.configurations()[name], **values}
        if (
            not isinstance(cfg["model"], str)
            or len(cfg["model"]) > 200
            or any(c in cfg["model"] for c in "\r\n")
        ):
            raise DomainError("INVALID_MODEL")
        if (
            not isinstance(cfg["enabled"], bool)
            or not isinstance(cfg["timeout"], (int, float))
            or not 5 <= cfg["timeout"] <= 180
        ):
            raise DomainError("INVALID_PROVIDER_CONFIG")
        url = urlsplit(cfg["base_url"])
        if name == "gemini" and cfg["base_url"]:
            raise DomainError("GEMINI_SDK_ENDPOINT_MANAGED")
        if name == "openrouter" and cfg["base_url"] != DEFAULTS[name]["base_url"]:
            raise DomainError("OPENROUTER_ENDPOINT_FIXED")
        if name in {"ollama", "omniroute"} and cfg["base_url"]:
            if (
                url.scheme not in {"http", "https"}
                or not url.hostname
                or url.username
                or url.password
                or url.query
                or url.fragment
            ):
                raise DomainError("INVALID_PROVIDER_URL")
            if url.scheme == "http" and url.hostname not in {
                "127.0.0.1",
                "localhost",
                "::1",
            }:
                raise DomainError(
                    "PROVIDER_TLS_REQUIRED",
                    "Non-loopback provider endpoints must use HTTPS.",
                )
        if cfg["enabled"] and (
            not cfg["model"]
            or (name in {"ollama", "omniroute"} and not cfg["base_url"])
        ):
            raise DomainError("PROVIDER_CONFIGURATION_INCOMPLETE")
        self.guard.check(cfg)
        cfg["revision"] = cfg.get("revision", 0) + 1
        self.db.set_setting("provider:" + name, cfg)
        self.db.audit(
            actor.user_id, "provider_configure", name, "updated_not_live_verified"
        )
        return self.diagnostics(actor)[name]

    def set_key(self, actor, name, value):
        actor = self.auth.revalidate(actor)
        actor.owner()
        if actor.channel != "desktop" or name not in DEFAULTS:
            raise DomainError("LOCAL_OWNER_REQUIRED", status=403)
        if len(value) > 4096 or any(c.isspace() for c in value):
            raise DomainError("INVALID_API_KEY")
        self.providers.secrets.set("provider_" + name, value)
        cfg = self.configurations()[name]
        cfg["revision"] = cfg.get("revision", 0) + 1
        self.db.set_setting("provider:" + name, cfg)
        self.db.audit(actor.user_id, "provider_secret_change", name, "stored_privately")

    def preferences(self, actor):
        self.auth.revalidate(actor)
        return self.db.setting(
            "routing:" + actor.user_id, {"mode": "local_first", "preferred": None}
        )

    def set_preferences(self, actor, mode, preferred=None):
        actor = self.auth.revalidate(actor)
        if mode not in {
            "auto",
            "local_first",
            "local_only",
            "cloud_first",
        } or preferred not in {None, *DEFAULTS}:
            raise DomainError("INVALID_ROUTING_PREFERENCE")
        self.db.set_setting(
            "routing:" + actor.user_id, {"mode": mode, "preferred": preferred}
        )
        return self.preferences(actor)

    def order(self, actor, complexity="simple"):
        prefs = self.preferences(actor)
        cloud_first = prefs["mode"] == "cloud_first" or (
            prefs["mode"] == "auto" and complexity == "complex"
        )
        choices = (
            ["gemini", "openrouter", "omniroute", "ollama"]
            if cloud_first
            else ["ollama", "gemini", "openrouter", "omniroute"]
        )
        preferred = prefs.get("preferred")
        if preferred in choices:
            choices.remove(preferred)
            choices.insert(0, preferred)
        cfgs = self.configurations()
        result = []
        for name in choices:
            local = (
                name == "ollama"
            )  # OmniRoute may forward to clouds; never silently classify it as private/local.
            if prefs["mode"] == "local_only" and not local:
                continue
            if not actor.permits("ai:local" if local else "ai:cloud"):
                continue
            cfg = cfgs[name]
            if not cfg["enabled"] or not cfg["model"]:
                continue
            if name in {"gemini", "openrouter"} and not self.providers.key(name):
                continue
            result.append(name)
        return result

    async def complete(
        self, actor, messages, *, task_id=None, complexity="simple", exact_provider=None
    ):
        actor = self.auth.revalidate(actor)
        actor.require("chat")
        self.guard.check(messages)
        choices = self.order(actor, complexity)
        if exact_provider:
            if exact_provider not in choices:
                raise DomainError("PROVIDER_NOT_AVAILABLE", status=409)
            choices = [exact_provider]
        failures = []
        for name in choices:
            cfg = self.configurations()[name]
            config_hash = self._hash(cfg)
            if (
                not exact_provider
                and self._cooldowns.get((name, config_hash), 0) > time.time()
            ):
                failures.append(name)
                continue
            actor = self.auth.revalidate(actor)
            started = time.perf_counter()
            try:
                reply = await self.providers.complete(name, cfg, messages)
                if not reply.text.strip():
                    raise ProviderFailure("EMPTY_COMPLETION")
                reply.text = self.guard.redact(reply.text)
                reply.latency_ms = round((time.perf_counter() - started) * 1000, 2)
                reply.fallback_from = list(failures)
                self._record(actor, task_id, reply, True, None, config_hash)
                return reply
            except ProviderFailure as error:
                reply = Completion(
                    "",
                    name,
                    cfg["model"],
                    latency_ms=round((time.perf_counter() - started) * 1000, 2),
                    live=False,
                )
                self._record(actor, task_id, reply, False, error.code, config_hash)
                self._cooldowns[(name, config_hash)] = time.time() + 15
                failures.append(name)
        raise DomainError(
            "NO_PROVIDER_SUCCEEDED",
            "No permitted configured provider succeeded. Nothing was represented as a live success.",
            503,
        )

    def _record(self, actor, task_id, reply, success, error_code, config_hash):
        def number(value):
            return (
                value
                if isinstance(value, int) and not isinstance(value, bool) and value >= 0
                else None
            )

        self.db.execute(
            "INSERT INTO j_usage(user_id,task_id,provider,model,success,input_tokens,output_tokens,latency_ms,live,error_code,configuration_hash,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                actor.user_id,
                task_id,
                reply.provider,
                reply.model,
                int(success),
                number(reply.input_tokens),
                number(reply.output_tokens),
                reply.latency_ms,
                int(reply.live and success),
                error_code,
                config_hash,
                time.time(),
            ),
        )

    def diagnostics(self, actor):
        actor = self.auth.revalidate(actor)
        result = {}
        for name, cfg in self.configurations().items():
            live = self.db.one(
                "SELECT MAX(created) last FROM j_usage WHERE provider=? AND configuration_hash=? AND live=1 AND success=1",
                (name, self._hash(cfg)),
            )
            result[name] = {
                **cfg,
                "credential_configured": bool(self.providers.key(name)),
                "implementation": Status.IMPLEMENTED.value,
                "live_verification": Status.VERIFIED.value
                if live["last"]
                else Status.NOT_VERIFIED.value,
                "last_live_success": live["last"],
                "note": "Only a non-empty real generation response verifies this exact configuration. Mocks do not.",
            }
        return result

    def usage(self, actor):
        actor = self.auth.revalidate(actor)
        where, params = (
            ("", ()) if actor.role == "OWNER" else ("WHERE user_id=?", (actor.user_id,))
        )
        return self.db.all(
            f"SELECT provider,model,COUNT(*) calls,SUM(success) successes,SUM(input_tokens) input_tokens,SUM(output_tokens) output_tokens,AVG(latency_ms) avg_latency_ms,SUM(live) live_successes FROM j_usage {where} GROUP BY provider,model",
            params,
        )
