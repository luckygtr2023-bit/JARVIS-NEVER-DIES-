from __future__ import annotations

import json
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any

# New namespaces coexist with the original workspace tables in ONE SQLite file.
SCHEMA = """
CREATE TABLE IF NOT EXISTS j_schema(version INTEGER PRIMARY KEY, applied REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_users(
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('OWNER','OPERATOR','USER')),
 permissions TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_sessions(
 id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL, user_id TEXT NOT NULL REFERENCES j_users(id),
 csrf_hash TEXT NOT NULL, channel TEXT NOT NULL, device_id TEXT, proof_until REAL NOT NULL DEFAULT 0,
 expires REAL NOT NULL, revoked INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_login_limits(key TEXT PRIMARY KEY, attempts INTEGER NOT NULL, until REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS j_memory(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES j_users(id), kind TEXT NOT NULL,
 session_id TEXT NOT NULL DEFAULT '', label TEXT NOT NULL, content BLOB NOT NULL,
 tags TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL);
CREATE INDEX IF NOT EXISTS j_memory_owner ON j_memory(user_id,kind,session_id);
CREATE TABLE IF NOT EXISTS j_combos(
 id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES j_users(id), name TEXT NOT NULL,
 name_key TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, steps BLOB NOT NULL,
 version INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL, updated REAL NOT NULL,
 UNIQUE(owner_id,name_key));
CREATE TABLE IF NOT EXISTS j_combo_grants(
 combo_id TEXT NOT NULL REFERENCES j_combos(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL REFERENCES j_users(id), can_use INTEGER NOT NULL DEFAULT 0,
 can_manage INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(combo_id,user_id));
CREATE TABLE IF NOT EXISTS j_devices(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES j_users(id), name TEXT NOT NULL, platform TEXT NOT NULL,
 public_key TEXT NOT NULL, fingerprint TEXT NOT NULL UNIQUE, bond_id TEXT,
 approved INTEGER NOT NULL DEFAULT 0, revoked INTEGER NOT NULL DEFAULT 0,
 permissions TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT '{}',
 created REAL NOT NULL, last_seen REAL);
CREATE TABLE IF NOT EXISTS j_challenges(
 id TEXT PRIMARY KEY, session_id TEXT NOT NULL, device_id TEXT NOT NULL,
 nonce TEXT NOT NULL, expires REAL NOT NULL, consumed INTEGER NOT NULL DEFAULT 0, purpose TEXT NOT NULL DEFAULT 'session');
CREATE TABLE IF NOT EXISTS j_tasks(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL, session_id TEXT NOT NULL, device_id TEXT,
 state TEXT NOT NULL, data BLOB NOT NULL, combo_id TEXT, combo_version INTEGER,
 created REAL NOT NULL, updated REAL NOT NULL);
CREATE INDEX IF NOT EXISTS j_task_owner ON j_tasks(user_id,created);
CREATE TABLE IF NOT EXISTS j_confirmations(
 id TEXT PRIMARY KEY, task_id TEXT NOT NULL, user_id TEXT NOT NULL, device_id TEXT,
 step_index INTEGER NOT NULL, step_hash TEXT NOT NULL, approved INTEGER NOT NULL DEFAULT 0,
 consumed INTEGER NOT NULL DEFAULT 0, expires REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_usage(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, task_id TEXT,
 provider TEXT NOT NULL, model TEXT NOT NULL, success INTEGER NOT NULL,
 input_tokens INTEGER, output_tokens INTEGER, latency_ms REAL NOT NULL,
 live INTEGER NOT NULL DEFAULT 0, error_code TEXT, configuration_hash TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_audit(
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, event TEXT NOT NULL,
 resource_id TEXT, outcome TEXT NOT NULL, created REAL NOT NULL);
CREATE TABLE IF NOT EXISTS j_legacy_devices(id TEXT PRIMARY KEY, record TEXT NOT NULL);
"""


class Database:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        with self.connect() as conn:
            conn.executescript(SCHEMA)
            columns = {
                row[1] for row in conn.execute("PRAGMA table_info(j_challenges)")
            }
            if "purpose" not in columns:
                conn.execute(
                    "ALTER TABLE j_challenges ADD COLUMN purpose TEXT NOT NULL DEFAULT 'session'"
                )
            usage_columns = {
                row[1] for row in conn.execute("PRAGMA table_info(j_usage)")
            }
            if "configuration_hash" not in usage_columns:
                conn.execute(
                    "ALTER TABLE j_usage ADD COLUMN configuration_hash TEXT NOT NULL DEFAULT ''"
                )
            conn.execute("INSERT OR IGNORE INTO j_schema VALUES(2,?)", (time.time(),))
        try:
            self.path.chmod(0o600)
        except OSError:
            pass

    def connect(self):
        conn = sqlite3.connect(self.path, timeout=15, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=15000")
        return conn

    @contextmanager
    def transaction(self):
        with self._lock:
            conn = self.connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                yield conn
                conn.commit()
            except BaseException:
                conn.rollback()
                raise
            finally:
                conn.close()

    def one(self, query: str, params: tuple = ()) -> dict | None:
        with self._lock, self.connect() as conn:
            row = conn.execute(query, params).fetchone()
            return dict(row) if row else None

    def all(self, query: str, params: tuple = ()) -> list[dict]:
        with self._lock, self.connect() as conn:
            return [dict(row) for row in conn.execute(query, params).fetchall()]

    def execute(self, query: str, params: tuple = ()) -> int:
        with self.transaction() as conn:
            return conn.execute(query, params).rowcount

    def setting(self, key: str, default: Any = None):
        row = self.one("SELECT value FROM j_settings WHERE key=?", (key,))
        return json.loads(row["value"]) if row else default

    def set_setting(self, key: str, value: Any):
        self.execute(
            "INSERT INTO j_settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, json.dumps(value)),
        )

    def audit(
        self, user_id: str | None, event: str, resource_id: str | None, outcome: str
    ):
        # Deliberately no arbitrary payload, prompts, credentials, headers or results.
        self.execute(
            "INSERT INTO j_audit(user_id,event,resource_id,outcome,created) VALUES(?,?,?,?,?)",
            (user_id, event, resource_id, outcome, time.time()),
        )
