from __future__ import annotations

import json
import sqlite3
import time
import unicodedata
import uuid

from .types import Principal, DomainError


class Combos:
    def __init__(self, db, auth, cipher, guard, policy):
        self.db, self.auth, self.cipher, self.guard, self.policy = (
            db,
            auth,
            cipher,
            guard,
            policy,
        )

    def _name(self, name):
        if not isinstance(name, str):
            raise DomainError("INVALID_COMBO_NAME")
        name = unicodedata.normalize("NFC", name.strip())
        self.guard.check(name)
        if not 1 <= len(name) <= 100 or any(ord(c) < 32 for c in name):
            raise DomainError("INVALID_COMBO_NAME")
        return name

    def _row(self, combo_id):
        row = self.db.one("SELECT * FROM j_combos WHERE id=?", (combo_id,))
        if not row:
            raise DomainError("COMBO_NOT_FOUND", status=404)
        return row

    def _grant(self, actor, row):
        return (
            self.db.one(
                "SELECT * FROM j_combo_grants WHERE combo_id=? AND user_id=?",
                (row["id"], actor.user_id),
            )
            or {}
        )

    def _manage(self, actor, row):
        if actor.role == "OWNER":
            return
        if actor.role != "OPERATOR":
            raise DomainError("COMBO_MANAGEMENT_DENIED", status=403)
        if row["owner_id"] == actor.user_id and actor.permits("combo:manage_own"):
            return
        if self._grant(actor, row).get("can_manage"):
            return
        raise DomainError("COMBO_MANAGEMENT_DENIED", status=403)

    def _validate_steps(self, actor, steps):
        self.policy.catalog.validate(steps)
        self.guard.check(steps)
        for step in steps:
            self.policy.prepare(actor, step)

    def create(self, actor: Principal, name: str, steps: list, enabled=True):
        actor = self.auth.revalidate(actor)
        if actor.role not in {"OWNER", "OPERATOR"}:
            raise DomainError("COMBO_CREATE_DENIED", status=403)
        actor.require("combo:create")
        name = self._name(name)
        self._validate_steps(actor, steps)
        cid, now = uuid.uuid4().hex, time.time()
        try:
            self.db.execute(
                "INSERT INTO j_combos VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    cid,
                    actor.user_id,
                    name,
                    name.casefold(),
                    int(enabled),
                    self.cipher.seal(actor.user_id, cid, steps),
                    1,
                    now,
                    now,
                ),
            )
        except sqlite3.IntegrityError:
            raise DomainError("COMBO_NAME_EXISTS", status=409)
        self.db.audit(actor.user_id, "combo_create", cid, "created")
        return self.get(actor, cid)

    def _public(self, actor, row):
        grant = self._grant(actor, row)
        manage = actor.role == "OWNER" or (
            actor.role == "OPERATOR"
            and (
                (row["owner_id"] == actor.user_id and actor.permits("combo:manage_own"))
                or grant.get("can_manage")
            )
        )
        result = {
            k: row[k]
            for k in ("id", "owner_id", "name", "version", "created", "updated")
        }
        result.update(
            enabled=bool(row["enabled"]),
            can_manage=bool(manage),
            can_use=bool(
                row["enabled"]
                and (
                    actor.role == "OWNER"
                    or row["owner_id"] == actor.user_id
                    or grant.get("can_use")
                )
            ),
        )
        # Authorized users can inspect the exact steps before running/confirming them.
        result["steps"] = self.cipher.open(row["owner_id"], row["id"], row["steps"])
        return result

    def get(self, actor, combo_id):
        actor = self.auth.revalidate(actor)
        row = self._row(combo_id)
        grant = self._grant(actor, row)
        if (
            actor.role != "OWNER"
            and row["owner_id"] != actor.user_id
            and not (grant.get("can_use") or grant.get("can_manage"))
        ):
            raise DomainError("COMBO_NOT_FOUND", status=404)
        return self._public(actor, row)

    def list(self, actor):
        actor = self.auth.revalidate(actor)
        rows = self.db.all(
            "SELECT DISTINCT c.* FROM j_combos c LEFT JOIN j_combo_grants g ON g.combo_id=c.id WHERE c.owner_id=? OR (g.user_id=? AND (g.can_use=1 OR g.can_manage=1)) OR ?='OWNER' ORDER BY c.name",
            (actor.user_id, actor.user_id, actor.role),
        )
        return [self._public(actor, row) for row in rows]

    def update(
        self, actor, combo_id, *, name=None, steps=None, enabled=None, version=None
    ):
        actor = self.auth.revalidate(actor)
        row = self._row(combo_id)
        self._manage(actor, row)
        if version is None or version != row["version"]:
            raise DomainError("COMBO_VERSION_CONFLICT", status=409)
        name = self._name(name if name is not None else row["name"])
        if steps is None:
            steps = self.cipher.open(row["owner_id"], row["id"], row["steps"])
        self._validate_steps(actor, steps)
        try:
            changed = self.db.execute(
                "UPDATE j_combos SET name=?,name_key=?,steps=?,enabled=?,version=version+1,updated=? WHERE id=? AND version=?",
                (
                    name,
                    name.casefold(),
                    self.cipher.seal(row["owner_id"], combo_id, steps),
                    int(row["enabled"] if enabled is None else enabled),
                    time.time(),
                    combo_id,
                    version,
                ),
            )
        except sqlite3.IntegrityError:
            raise DomainError("COMBO_NAME_EXISTS", status=409)
        if not changed:
            raise DomainError("COMBO_VERSION_CONFLICT", status=409)
        self.db.audit(actor.user_id, "combo_update", combo_id, "updated")
        return self.get(actor, combo_id)

    def delete(self, actor, combo_id):
        actor = self.auth.revalidate(actor)
        self._manage(actor, self._row(combo_id))
        self.db.execute("DELETE FROM j_combos WHERE id=?", (combo_id,))
        self.db.audit(actor.user_id, "combo_delete", combo_id, "deleted")

    def assign(self, actor, combo_id, user_id, *, can_use: bool, can_manage: bool):
        actor = self.auth.revalidate(actor)
        actor.owner()
        self._row(combo_id)
        target = self.auth.user(user_id)
        if not target["active"] or (can_manage and target["role"] != "OPERATOR"):
            raise DomainError("INVALID_COMBO_ASSIGNMENT")
        self.db.execute(
            "INSERT INTO j_combo_grants VALUES(?,?,?,?) ON CONFLICT(combo_id,user_id) DO UPDATE SET can_use=excluded.can_use,can_manage=excluded.can_manage",
            (combo_id, user_id, int(can_use), int(can_manage)),
        )
        self.db.audit(actor.user_id, "combo_assign", combo_id, "permissions_updated")
        return {
            "combo_id": combo_id,
            "user_id": user_id,
            "can_use": can_use,
            "can_manage": can_manage,
        }

    def execution(self, actor, combo_id, expected_version=None):
        actor = self.auth.revalidate(actor)
        actor.require("combo:use")
        row = self._row(combo_id)
        grant = self._grant(actor, row)
        if not row["enabled"]:
            raise DomainError("COMBO_DISABLED", status=403)
        if (
            actor.role != "OWNER"
            and row["owner_id"] != actor.user_id
            and not grant.get("can_use")
        ):
            raise DomainError("COMBO_NOT_ASSIGNED", status=403)
        if expected_version is not None and expected_version != row["version"]:
            raise DomainError(
                "COMBO_CHANGED", "The Combo changed; start a new task.", 409
            )
        steps = self.cipher.open(row["owner_id"], row["id"], row["steps"])
        # Assignment never grants arbitrary tool privileges or the author's role.
        self._validate_steps(actor, steps)
        return row["version"], steps
