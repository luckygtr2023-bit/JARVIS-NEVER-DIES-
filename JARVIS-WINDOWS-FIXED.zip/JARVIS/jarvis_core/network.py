"""Local OWNER transport configuration. Pairing/authorization is never inferred from TLS or discovery."""

from __future__ import annotations

import base64
import hashlib
import io
import ipaddress
import json
import re
import socket
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID

from .runtime import network_config, secure_windows_directory
from .types import DomainError


def info(core):
    root = core.data_dir.parent
    cfg = network_config(root)
    host = cfg.get("public_host") or "localhost"
    url = f"{'https' if cfg['tls'] else 'http'}://{host}:{cfg['port']}"
    pin = ""
    if cfg["tls"]:
        cert_path = Path(cfg["tls_cert"])
        if not cert_path.is_absolute():
            cert_path = root / cert_path
        if cert_path.exists():
            cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
            pin = cert.fingerprint(hashes.SHA256()).hex()
    payload = {"protocol": "jarvis.v1", "backend_url": url, "certificate_sha256": pin}
    import qrcode

    image = qrcode.make(json.dumps(payload, separators=(",", ":"))).convert("RGB")
    stream = io.BytesIO()
    image.save(stream, format="PNG")
    return {
        "enabled": cfg["host"] not in {"127.0.0.1", "localhost", "::1"},
        "public_host": host,
        "port": cfg["port"],
        "tls": cfg["tls"],
        "qr_payload": payload,
        "qr_image": "data:image/png;base64,"
        + base64.b64encode(stream.getvalue()).decode(),
        "note": "This QR identifies the backend certificate, not device trust. Compare it on the local OWNER HUD. Bluetooth pairing and key authorization remain mandatory.",
    }


def configure(
    core,
    actor,
    *,
    enabled: bool,
    public_host: str,
    port: int = 8765,
    confirm: bool = False,
):
    actor = core.auth.revalidate(actor)
    actor.owner()
    if actor.channel != "desktop":
        raise DomainError("LOCAL_OWNER_REQUIRED", status=403)
    if not confirm:
        raise DomainError("NETWORK_CONFIRMATION_REQUIRED")
    if not 1024 <= port <= 65535:
        raise DomainError("INVALID_PORT")
    root = core.data_dir.parent
    if not enabled:
        cfg = {
            "host": "127.0.0.1",
            "public_host": "localhost",
            "port": port,
            "tls_cert": "",
            "tls_key": "",
            "origins": [],
            "advertise": False,
        }
    else:
        host = public_host.strip()
        if (
            not host
            or len(host) > 253
            or host in {"0.0.0.0", "::", "localhost", "127.0.0.1"}
        ):
            raise DomainError(
                "LAN_HOST_REQUIRED",
                "Enter the PC's actual LAN IP or DNS name, not a wildcard/loopback address.",
            )
        sans = [
            x509.DNSName("localhost"),
            x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
        ]
        try:
            address = ipaddress.ip_address(host)
            if address.version != 4 or address.is_unspecified or address.is_multicast:
                raise DomainError(
                    "INVALID_LAN_HOST", "Use a LAN IPv4 address or DNS name."
                )
            sans.append(x509.IPAddress(address))
        except ValueError:
            if not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?", host):
                raise DomainError("INVALID_LAN_HOST")
            sans.append(x509.DNSName(host))
        private = core.data_dir / "private"
        private.mkdir(exist_ok=True)
        secure_windows_directory(private)
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        subject = x509.Name(
            [x509.NameAttribute(NameOID.COMMON_NAME, "JARVIS local backend")]
        )
        now = datetime.now(timezone.utc)
        certificate = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(subject)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(minutes=5))
            .not_valid_after(now + timedelta(days=365))
            .add_extension(x509.SubjectAlternativeName(sans), critical=False)
            .add_extension(
                x509.BasicConstraints(ca=False, path_length=None), critical=True
            )
            .add_extension(
                x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False
            )
            .add_extension(
                x509.SubjectKeyIdentifier.from_public_key(key.public_key()),
                critical=False,
            )
            .sign(key, hashes.SHA256())
        )
        cert_path, key_path = (
            private / "transport-cert.pem",
            private / "transport-key.pem",
        )
        cert_path.write_bytes(certificate.public_bytes(serialization.Encoding.PEM))
        key_path.write_bytes(
            key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            )
        )
        cert_path.chmod(0o600)
        key_path.chmod(0o600)
        cfg = {
            "host": "0.0.0.0",
            "public_host": host,
            "port": port,
            "tls_cert": str(cert_path.relative_to(root)),
            "tls_key": str(key_path.relative_to(root)),
            "origins": [f"https://{host}:{port}"],
            "advertise": False,
        }
    path = core.data_dir / "jarvis_network.json"
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(cfg, indent=2) + "\n")
    temporary.replace(path)
    core.db.audit(actor.user_id, "network_configure", None, "restart_required")
    return {
        **info(core),
        "restart_required": True,
        "warning": "Restart JARVIS to apply. No firewall rule is opened automatically. Restrict any Windows firewall exception to your trusted private LAN. Browser/PWA use of a self-signed certificate also requires explicit OS/browser trust.",
    }
