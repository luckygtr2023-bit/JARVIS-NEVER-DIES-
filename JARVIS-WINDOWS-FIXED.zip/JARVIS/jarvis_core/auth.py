from __future__ import annotations

import base64
import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import time
import uuid

from .database import Database
from .types import Principal, DomainError

BASE_PERMISSIONS = {
    "chat",
    "memory",
    "combo:use",
    "ai:local",
    "ai:cloud",
    "device:register",
}
OPERATOR_PERMISSIONS = BASE_PERMISSIONS | {
    "combo:create",
    "combo:manage_own",
    "tool:web_search",
    "tool:weather_report",
    "tool:word_document",
    "tool:pdf_document",
    "tool:spreadsheet_builder",
    "tool:presentation_builder",
}


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def password_hash(password: str) -> str:
    if len(password) < 12 or len(password) > 256:
        raise DomainError("PASSWORD_LENGTH", "Use a password of 12–256 characters.")
    salt = secrets.token_bytes(16)
    derived = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 600_000)
    return (
        "pbkdf2-sha256$600000$"
        + base64.b64encode(salt).decode()
        + "$"
        + base64.b64encode(derived).decode()
    )


def verify_password(password: str, encoded: str) -> bool:
    try:
        _, rounds, salt, expected = encoded.split("$")
        computed = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), base64.b64decode(salt), int(rounds)
        )
        return hmac.compare_digest(computed, base64.b64decode(expected))
    except (ValueError, TypeError):
        return False


class Auth:
    def __init__(self, db: Database, clock=time.time):
        self.db, self.clock = db, clock
        self._dummy = password_hash(secrets.token_urlsafe(24))

    def needs_setup(self):
        return self.db.one("SELECT COUNT(*) AS n FROM j_users")["n"] == 0

    def _new_user(self, username, password, role, permissions=None):
        username = username.strip()
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,48}", username) or role not in {
            "OWNER",
            "OPERATOR",
            "USER",
        }:
            raise DomainError("INVALID_ACCOUNT")
        perms = (
            {"*"}
            if role == "OWNER"
            else (OPERATOR_PERMISSIONS if role == "OPERATOR" else BASE_PERMISSIONS)
        )
        if permissions is not None and role != "OWNER":
            if "*" in permissions:
                raise DomainError("WILDCARD_RESERVED_FOR_OWNER", status=403)
            perms = set(permissions) | BASE_PERMISSIONS
        return (
            uuid.uuid4().hex,
            username,
            password_hash(password),
            role,
            json.dumps(sorted(perms)),
            1,
            self.clock(),
        )

    def bootstrap(self, username: str, password: str, *, local_proof: bool):
        if not local_proof:
            raise DomainError("LOCAL_OWNER_SETUP_REQUIRED", status=403)
        data = self._new_user(username, password, "OWNER")
        with self.db.transaction() as conn:
            if conn.execute("SELECT COUNT(*) FROM j_users").fetchone()[0]:
                raise DomainError("ALREADY_INITIALIZED", status=409)
            conn.execute("INSERT INTO j_users VALUES(?,?,?,?,?,?,?)", data)
        self.db.audit(data[0], "owner_bootstrap", data[0], "created")
        return self.user(data[0])

    def user(self, user_id):
        row = self.db.one(
            "SELECT id,username,role,permissions,active,created FROM j_users WHERE id=?",
            (user_id,),
        )
        if not row:
            raise DomainError("USER_NOT_FOUND", status=404)
        row["permissions"] = json.loads(row["permissions"])
        return row

    def create_user(
        self, actor: Principal, username, password, role="USER", permissions=None
    ):
        self.revalidate(actor).owner()
        data = self._new_user(username, password, role, permissions)
        try:
            self.db.execute("INSERT INTO j_users VALUES(?,?,?,?,?,?,?)", data)
        except sqlite3.IntegrityError:
            raise DomainError("ACCOUNT_EXISTS", status=409)
        self.db.audit(actor.user_id, "user_create", data[0], "created")
        return self.user(data[0])

    def update_user(
        self,
        actor: Principal,
        user_id,
        *,
        role=None,
        active=None,
        permissions=None,
        password=None,
    ):
        self.revalidate(actor).owner()
        target = self.user(user_id)
        new_role = role or target["role"]
        if new_role not in {"OWNER", "OPERATOR", "USER"}:
            raise DomainError("INVALID_ROLE")
        enabled = int(target["active"] if active is None else active)
        if permissions is not None and new_role != "OWNER" and "*" in permissions:
            raise DomainError("WILDCARD_RESERVED_FOR_OWNER", status=403)
        perms = (
            ["*"]
            if new_role == "OWNER"
            else sorted(
                (
                    set(permissions)
                    if permissions is not None
                    else (
                        OPERATOR_PERMISSIONS
                        if new_role == "OPERATOR"
                        else BASE_PERMISSIONS
                    )
                )
                | BASE_PERMISSIONS
            )
        )
        new_hash = password_hash(password) if password is not None else None
        with self.db.transaction() as conn:
            if (
                target["role"] == "OWNER"
                and target["active"]
                and (new_role != "OWNER" or not enabled)
            ):
                if (
                    conn.execute(
                        "SELECT COUNT(*) FROM j_users WHERE role='OWNER' AND active=1"
                    ).fetchone()[0]
                    <= 1
                ):
                    raise DomainError("LAST_OWNER_PROTECTED", status=409)
            conn.execute(
                "UPDATE j_users SET role=?,active=?,permissions=? WHERE id=?",
                (new_role, enabled, json.dumps(perms), user_id),
            )
            if new_hash:
                conn.execute(
                    "UPDATE j_users SET password_hash=? WHERE id=?", (new_hash, user_id)
                )
            conn.execute("UPDATE j_sessions SET revoked=1 WHERE user_id=?", (user_id,))
        self.db.audit(actor.user_id, "user_update", user_id, "sessions_revoked")
        return self.user(user_id)

    def login(
        self, username: str, password: str, *, local_proof=False, rate_key="local"
    ):
        key, now = digest(rate_key + ":" + username.casefold()), self.clock()
        limit = self.db.one("SELECT * FROM j_login_limits WHERE key=?", (key,))
        if limit and limit["attempts"] >= 5 and limit["until"] > now:
            raise DomainError("LOGIN_THROTTLED", "Try again later.", 429)
        user = self.db.one(
            "SELECT * FROM j_users WHERE username=? COLLATE NOCASE", (username,)
        )
        valid = (
            verify_password(
                password[:256], user["password_hash"] if user else self._dummy
            )
            and len(password) <= 256
        )
        if not valid or not user or not user["active"]:
            attempts = limit["attempts"] + 1 if limit and limit["until"] > now else 1
            self.db.execute(
                "INSERT INTO j_login_limits VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET attempts=excluded.attempts,until=excluded.until",
                (key, attempts, now + 300),
            )
            raise DomainError("INVALID_LOGIN", "Invalid username or password.", 401)
        self.db.execute("DELETE FROM j_login_limits WHERE key=?", (key,))
        token, csrf, sid = (
            secrets.token_urlsafe(40),
            secrets.token_urlsafe(32),
            uuid.uuid4().hex,
        )
        self.db.execute(
            "INSERT INTO j_sessions(id,token_hash,user_id,csrf_hash,channel,expires,created) VALUES(?,?,?,?,?,?,?)",
            (
                sid,
                digest(token),
                user["id"],
                digest(csrf),
                "desktop" if local_proof else "remote",
                now + 8 * 3600,
                now,
            ),
        )
        self.db.audit(user["id"], "login", sid, "authenticated")
        return {
            "token": token,
            "csrf": csrf,
            "expires": now + 8 * 3600,
            "user": self.user(user["id"]),
            "channel": "desktop" if local_proof else "remote",
        }

    def authenticate(self, token: str) -> Principal:
        if not token or len(token) > 512:
            raise DomainError("AUTHENTICATION_REQUIRED", status=401)
        row = self.db.one(
            "SELECT id FROM j_sessions WHERE token_hash=?", (digest(token),)
        )
        if not row:
            raise DomainError("AUTHENTICATION_REQUIRED", status=401)
        return self.from_session(row["id"])

    def from_session(self, sid: str) -> Principal:
        row = self.db.one(
            "SELECT s.*,u.username,u.role,u.permissions,u.active FROM j_sessions s JOIN j_users u ON u.id=s.user_id WHERE s.id=?",
            (sid,),
        )
        if (
            not row
            or row["revoked"]
            or not row["active"]
            or row["expires"] <= self.clock()
        ):
            raise DomainError("SESSION_EXPIRED", status=401)
        return Principal(
            row["user_id"],
            row["username"],
            row["role"],
            frozenset(json.loads(row["permissions"])),
            row["id"],
            row["channel"],
            row["device_id"],
            row["proof_until"],
        )

    def revalidate(self, actor: Principal) -> Principal:
        current = self.from_session(actor.session_id)
        if current.user_id != actor.user_id:
            raise DomainError("IDENTITY_MISMATCH", status=403)
        return current

    def check_csrf(self, actor: Principal, token: str):
        row = self.db.one(
            "SELECT csrf_hash FROM j_sessions WHERE id=?", (actor.session_id,)
        )
        if not row or not hmac.compare_digest(row["csrf_hash"], digest(token)):
            raise DomainError("CSRF_REJECTED", status=403)

    def logout(self, actor: Principal):
        self.db.execute(
            "UPDATE j_sessions SET revoked=1 WHERE id=? AND user_id=?",
            (actor.session_id, actor.user_id),
        )
        self.db.execute(
            "DELETE FROM j_memory WHERE user_id=? AND session_id=? AND kind='session'",
            (actor.user_id, actor.session_id),
        )
        self.db.audit(actor.user_id, "logout", actor.session_id, "revoked")
