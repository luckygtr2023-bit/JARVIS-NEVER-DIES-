from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Status(str, Enum):
    VERIFIED = "VERIFIED"
    IMPLEMENTED = "IMPLEMENTED"
    NOT_VERIFIED = "NOT VERIFIED"


class DomainError(Exception):
    def __init__(self, code: str, message: str = "", status: int = 400):
        self.code, self.message, self.status = (
            code,
            message or code.replace("_", " ").capitalize(),
            status,
        )
        super().__init__(self.message)


@dataclass(frozen=True)
class Principal:
    user_id: str
    username: str
    role: str
    permissions: frozenset[str]
    session_id: str
    channel: str = "remote"
    device_id: str | None = None
    proof_until: float = 0

    def permits(self, permission: str) -> bool:
        return "*" in self.permissions or permission in self.permissions

    def require(self, permission: str) -> None:
        if not self.permits(permission):
            raise DomainError(
                "PERMISSION_DENIED", f"Permission required: {permission}", 403
            )

    def owner(self) -> None:
        if self.role != "OWNER":
            raise DomainError("OWNER_REQUIRED", status=403)


@dataclass
class Completion:
    text: str
    provider: str
    model: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    latency_ms: float = 0
    live: bool = False
    fallback_from: list[str] = field(default_factory=list)


@dataclass
class ToolResult:
    value: Any
    verification: Status = Status.NOT_VERIFIED
    detail: str = "The inherited tool returned; its physical/external effect was not independently verified."
