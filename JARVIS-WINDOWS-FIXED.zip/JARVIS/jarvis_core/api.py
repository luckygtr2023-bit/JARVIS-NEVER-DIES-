from __future__ import annotations

import asyncio
import contextlib
import hmac
import hashlib
import ipaddress
import json
import time
from collections import OrderedDict
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit

from fastapi import (
    APIRouter,
    Depends,
    Request,
    Response,
    WebSocket,
    WebSocketDisconnect,
    UploadFile,
    File,
)
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field

from brahma_connect.gateway.server import BrahmaGateway, BrahmaGatewayConfig
from . import __version__
from .core import Core
from .types import DomainError, Status


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class Login(StrictModel):
    username: str = Field(min_length=3, max_length=48)
    password: str = Field(min_length=1, max_length=256)


class UserCreate(Login):
    role: str = "USER"
    permissions: list[str] | None = None


class UserUpdate(StrictModel):
    role: str | None = None
    active: bool | None = None
    permissions: list[str] | None = None
    password: str | None = Field(default=None, min_length=12, max_length=256)


class MemoryItem(StrictModel):
    kind: str
    label: str = Field(min_length=1, max_length=120)
    value: object
    tags: list[str] = Field(default_factory=list, max_length=20)


class MemorySettings(StrictModel):
    enabled: bool
    auto_context: bool = False


class Clear(StrictModel):
    confirm: bool


class ComboCreate(StrictModel):
    name: str = Field(min_length=1, max_length=100)
    steps: list[dict] = Field(min_length=1, max_length=12)
    enabled: bool = True


class ComboUpdate(StrictModel):
    version: int = Field(ge=1)
    name: str | None = None
    steps: list[dict] | None = None
    enabled: bool | None = None


class Assignment(StrictModel):
    user_id: str = Field(min_length=1, max_length=64)
    can_use: bool = False
    can_manage: bool = False


class RegisterDevice(StrictModel):
    name: str = Field(min_length=1, max_length=80)
    platform: str
    public_key: str = Field(min_length=20, max_length=1024)


class BindDevice(StrictModel):
    bond_id: str = Field(min_length=1, max_length=2048)
    fingerprint: str = Field(min_length=64, max_length=64)
    permissions: list[str] = Field(min_length=1, max_length=16)


class Challenge(StrictModel):
    device_id: str = Field(min_length=1, max_length=64)
    purpose: str = Field(default="session", max_length=2400)


class DeviceProof(StrictModel):
    challenge_id: str = Field(min_length=1, max_length=64)
    signature: str = Field(min_length=20, max_length=512)


class TaskInput(StrictModel):
    text: str = Field(default="", max_length=12000)
    steps: list[dict] | None = None
    combo_id: str | None = None


class Confirmation(StrictModel):
    confirmation_id: str = Field(min_length=1, max_length=64)
    approved: bool


class RoutingPreference(StrictModel):
    mode: str
    preferred: str | None = None


class ProviderConfig(StrictModel):
    enabled: bool | None = None
    model: str | None = None
    base_url: str | None = None
    timeout: int | None = None


class ProviderKey(StrictModel):
    value: str = Field(max_length=4096)


class NetworkConfig(StrictModel):
    enabled: bool
    public_host: str = Field(default="localhost", max_length=253)
    port: int = Field(default=8765, ge=1024, le=65535)
    confirm: bool = False


def loopback(host):
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return host == "localhost"


class Boundary:
    def __init__(self, core: Core, origins):
        self.core, self.origins = core, set(origins)

    def local(self, request):
        supplied = request.headers.get("x-jarvis-local") or request.cookies.get(
            "jarvis_local", ""
        )
        return bool(
            request.client
            and loopback(request.client.host)
            and supplied
            and hmac.compare_digest(supplied, self.core.local_proof)
        )

    def transport(self, request):
        origin = request.headers.get("origin")
        if origin and origin not in self.origins:
            raise DomainError("ORIGIN_REJECTED", status=403)
        if request.url.scheme not in {"https", "wss"} and not (
            request.client and loopback(request.client.host)
        ):
            raise DomainError(
                "TLS_REQUIRED",
                "Remote clients must use TLS; HTTP is limited to loopback.",
                403,
            )

    async def actor(self, request: Request, *, capability=None, owner=False):
        self.transport(request)
        bearer = request.headers.get("authorization", "")
        token = (
            bearer[7:]
            if bearer.startswith("Bearer ")
            else request.cookies.get("jarvis_session", "")
        )
        actor = self.core.auth.authenticate(token)
        if actor.channel == "desktop" and not self.local(request):
            raise DomainError("LOCAL_PROCESS_PROOF_REQUIRED", status=403)
        if not bearer and request.method not in {"GET", "HEAD", "OPTIONS"}:
            self.core.auth.check_csrf(actor, request.headers.get("x-jarvis-csrf", ""))
        if owner:
            actor.owner()
        if capability:
            if actor.channel == "remote":
                raw_path = request.scope.get(
                    "raw_path", request.url.path.encode()
                ).decode("ascii")
                query = request.scope.get("query_string", b"").decode("ascii")
                target = raw_path + ("?" + query if query else "")
                purpose = f"HTTP:{request.method}:{target}:{hashlib.sha256(await request.body()).hexdigest()}"
                await self.core.devices.authorize(
                    actor,
                    request.headers.get("x-jarvis-challenge", ""),
                    request.headers.get("x-jarvis-signature", ""),
                    expected_purpose=purpose,
                )
                actor = self.core.auth.revalidate(actor)
            actor = await self.core.devices.enforce(actor, capability)
        return actor


class SecurityMiddleware:
    """One boundary for the extended and retained routes, including old backdoors."""

    def __init__(self, app, boundary: Boundary):
        self.app, self.boundary = app, boundary
        self._rates = OrderedDict()

    async def __call__(self, scope, receive, send):
        if scope["type"] not in {"http", "websocket"}:
            return await self.app(scope, receive, send)
        path = scope.get("path", "")
        if scope["type"] == "websocket":
            # Legacy secret-only sockets cannot prove Bluetooth-bound JARVIS identity.
            if path != "/v1/device-bus":
                return await send(
                    {
                        "type": "websocket.close",
                        "code": 4403,
                        "reason": "Use the authenticated Bluetooth-gated JARVIS device bus",
                    }
                )
            return await self.app(scope, receive, send)
        request = Request(scope, receive)
        try:
            self.boundary.transport(request)
            key = (scope.get("client") or ("", 0))[0]
            now = time.monotonic()
            count, start = self._rates.get(key, (0, now))
            if now - start > 60:
                count, start = 0, now
            self._rates[key] = (count + 1, start)
            self._rates.move_to_end(key)
            while len(self._rates) > 2000:
                self._rates.popitem(last=False)
            if count > 600:
                raise DomainError("REQUEST_THROTTLED", status=429)
            if path.startswith("/gateway/") or path.startswith("/dashboard"):
                actor = await self.boundary.actor(
                    request, capability="device_actions", owner=True
                )
                if actor.channel != "desktop":
                    raise DomainError("LEGACY_LOCAL_OWNER_ONLY", status=403)
            total = 0
            max_body = 20 * 1024 * 1024 if path == "/v1/files" else 1024 * 1024

            async def limited_receive():
                nonlocal total
                event = await receive()
                total += len(event.get("body", b""))
                if total > max_body:
                    raise DomainError("REQUEST_TOO_LARGE", status=413)
                return event

            async def secure_send(event):
                if event["type"] == "http.response.start":
                    headers = list(event.get("headers", []))
                    headers += [
                        (b"x-content-type-options", b"nosniff"),
                        (b"referrer-policy", b"no-referrer"),
                        (
                            b"cache-control",
                            b"no-store"
                            if path.startswith(("/v1/", "/gateway/"))
                            else b"no-cache",
                        ),
                        (
                            b"content-security-policy",
                            b"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; media-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'self'",
                        ),
                    ]
                    event["headers"] = headers
                await send(event)

            await self.app(scope, limited_receive, secure_send)
        except DomainError as error:
            response = JSONResponse(
                {"error": error.code, "message": error.message},
                status_code=error.status,
            )
            await response(scope, receive, send)


def create_app(
    root: Path, *, core: Core | None = None, host="127.0.0.1", port=8765, origins=None
):
    root = Path(root).resolve()
    core = core or Core(root)
    origins = origins or {
        f"http://127.0.0.1:{port}",
        f"http://localhost:{port}",
        f"https://127.0.0.1:{port}",
        f"https://localhost:{port}",
    }
    boundary = Boundary(core, origins)
    cfg = BrahmaGatewayConfig(
        host=host,
        port=port,
        enabled=True,
        advertise=False,
        registry_path=core.data_dir / "brahma_connect/devices.json",
    )
    gateway = BrahmaGateway(root, cfg)
    app = gateway.app  # Extend the existing FastAPI application: no second backend.
    app.state.jarvis = core
    app.state.gateway = gateway
    app.state.boundary = boundary
    core.bus.hub = gateway.hub

    @asynccontextmanager
    async def lifespan(app):
        core.loop = asyncio.get_running_loop()
        gateway._running = True
        heartbeat = asyncio.create_task(core.bus.heartbeat())
        try:
            yield
        finally:
            heartbeat.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await heartbeat
            await core.brain.close()
            gateway._running = False

    app.router.lifespan_context = lifespan

    from fastapi.exceptions import RequestValidationError

    @app.exception_handler(RequestValidationError)
    async def invalid_request(request, error):
        # FastAPI's default validation response can echo passwords/API keys in `input`.
        return JSONResponse(
            {
                "error": "INVALID_REQUEST",
                "fields": [".".join(str(x) for x in e["loc"]) for e in error.errors()],
            },
            status_code=422,
        )

    @app.exception_handler(DomainError)
    async def domain_error(request, error):
        return JSONResponse(
            {"error": error.code, "message": error.message}, status_code=error.status
        )

    router = APIRouter(prefix="/v1")

    async def control(request: Request):
        return await boundary.actor(request, capability="chat")

    @router.get("/health")
    async def health():
        return {
            "ok": True,
            "application": "JARVIS",
            "version": __version__,
            "setup_required": core.auth.needs_setup(),
            "database": "shared workspace_store.sqlite3",
            "native_hud_ready": core.native_ready,
            "bluetooth_physical_verification": Status.NOT_VERIFIED.value,
        }

    @router.post("/auth/bootstrap")
    async def bootstrap(body: Login, request: Request):
        return core.auth.bootstrap(
            body.username, body.password, local_proof=boundary.local(request)
        )

    @router.post("/auth/login")
    async def login(body: Login, request: Request, response: Response):
        result = core.auth.login(
            body.username,
            body.password,
            local_proof=boundary.local(request),
            rate_key=request.client.host if request.client else "unknown",
        )
        secure = request.url.scheme == "https"
        response.set_cookie(
            "jarvis_session",
            result["token"],
            httponly=True,
            secure=secure,
            samesite="strict",
            max_age=8 * 3600,
            path="/",
        )
        response.set_cookie(
            "jarvis_csrf",
            result["csrf"],
            httponly=False,
            secure=secure,
            samesite="strict",
            max_age=8 * 3600,
            path="/",
        )
        return result

    @router.get("/auth/me")
    async def me(request: Request):
        actor = await boundary.actor(request)
        return {
            "user": core.auth.user(actor.user_id),
            "channel": actor.channel,
            "device_id": actor.device_id,
            "proof_expires": actor.proof_until,
        }

    @router.post("/auth/logout")
    async def logout(request: Request, response: Response):
        actor = await boundary.actor(request)
        core.auth.logout(actor)
        core.memory.forget_context(actor.user_id, actor.session_id)
        if actor.device_id:
            await core.bus.close_device(actor.device_id)
        if core.on_native_logout and actor.channel == "desktop":
            core.on_native_logout()
        response.delete_cookie("jarvis_session", path="/")
        response.delete_cookie("jarvis_csrf", path="/")
        return {"ok": True}

    @router.get("/users")
    async def users(request: Request):
        await boundary.actor(request, capability="combos", owner=True)
        return [
            core.auth.user(r["id"])
            for r in core.db.all("SELECT id FROM j_users ORDER BY username")
        ]

    @router.post("/users")
    async def create_user(body: UserCreate, request: Request):
        actor = await boundary.actor(request, capability="combos", owner=True)
        return core.auth.create_user(actor, **body.model_dump())

    @router.patch("/users/{user_id}")
    async def update_user(user_id: str, body: UserUpdate, request: Request):
        actor = await boundary.actor(request, capability="combos", owner=True)
        result = core.auth.update_user(
            actor, user_id, **body.model_dump(exclude_unset=True)
        )
        for device in core.db.all(
            "SELECT id FROM j_devices WHERE user_id=?", (user_id,)
        ):
            await core.bus.close_device(device["id"])
        return result

    @router.get("/memory/settings")
    async def memory_settings(request: Request):
        return core.memory.settings(await boundary.actor(request, capability="memory"))

    @router.put("/memory/settings")
    async def set_memory_settings(body: MemorySettings, request: Request):
        return core.memory.configure(
            await boundary.actor(request, capability="memory"), **body.model_dump()
        )

    @router.get("/memory")
    async def memory_list(request: Request, query: str = "", kind: str | None = None):
        return core.memory.list(
            await boundary.actor(request, capability="memory"),
            query=query[:200],
            kind=kind,
        )

    @router.post("/memory")
    async def memory_add(body: MemoryItem, request: Request):
        return core.memory.write(
            await boundary.actor(request, capability="memory"), **body.model_dump()
        )

    @router.patch("/memory/{item_id}")
    async def memory_update(item_id: str, body: MemoryItem, request: Request):
        return core.memory.write(
            await boundary.actor(request, capability="memory"),
            **body.model_dump(),
            item_id=item_id,
        )

    @router.delete("/memory/{item_id}")
    async def memory_delete(item_id: str, request: Request):
        core.memory.delete(await boundary.actor(request, capability="memory"), item_id)
        return {"deleted": True}

    @router.post("/memory/clear")
    async def memory_clear(body: Clear, request: Request):
        actor = await boundary.actor(request, capability="memory")
        if not body.confirm:
            raise DomainError("CLEAR_CONFIRMATION_REQUIRED")
        core.memory.clear(actor)
        return {"cleared": True}

    @router.get("/memory/export")
    async def memory_export(request: Request):
        return core.memory.export(await boundary.actor(request, capability="memory"))

    @router.post("/memory/import")
    async def memory_import(document: dict, request: Request):
        return core.memory.import_items(
            await boundary.actor(request, capability="memory"), document
        )

    @router.post("/memory/import-legacy")
    async def memory_import_legacy(body: Clear, request: Request):
        actor = await boundary.actor(request, capability="memory", owner=True)
        if not body.confirm:
            raise DomainError("IMPORT_CONFIRMATION_REQUIRED")
        return core.memory.import_legacy(
            actor, core.data_dir.parent / "memory" / "long_term.json"
        )

    @router.get("/tools")
    async def tools(request: Request):
        actor = await boundary.actor(request, capability="tasks")
        return {
            "tools": core.catalog.for_actor(actor),
            "workspace": str(core.policy.workspace(actor)),
            "note": "Tool permission and consequential confirmation are enforced again at execution.",
        }

    @router.get("/combos")
    async def combos(request: Request):
        return core.combos.list(await boundary.actor(request, capability="combos"))

    @router.post("/combos")
    async def create_combo(body: ComboCreate, request: Request):
        return core.combos.create(
            await boundary.actor(request, capability="combos"), **body.model_dump()
        )

    @router.patch("/combos/{combo_id}")
    async def update_combo(combo_id: str, body: ComboUpdate, request: Request):
        return core.combos.update(
            await boundary.actor(request, capability="combos"),
            combo_id,
            **body.model_dump(exclude_unset=True),
        )

    @router.delete("/combos/{combo_id}")
    async def delete_combo(combo_id: str, request: Request):
        core.combos.delete(await boundary.actor(request, capability="combos"), combo_id)
        return {"deleted": True}

    @router.put("/combos/{combo_id}/assignment")
    async def assign_combo(combo_id: str, body: Assignment, request: Request):
        return core.combos.assign(
            await boundary.actor(request, capability="combos", owner=True),
            combo_id,
            **body.model_dump(),
        )

    @router.post("/tasks")
    async def tasks_submit(body: TaskInput, request: Request):
        return await core.brain.submit(await control(request), **body.model_dump())

    @router.post("/voice/transcript")
    async def voice_submit(body: TaskInput, request: Request):
        # Android/PWA speech recognition produces text; ALL execution stays in this backend.
        if body.steps is not None or body.combo_id:
            raise DomainError("VOICE_TRANSCRIPT_ONLY")
        return await core.brain.submit(await control(request), text=body.text)

    @router.get("/tasks")
    async def tasks_list(request: Request):
        return core.brain.list(await boundary.actor(request, capability="tasks"))

    @router.get("/tasks/{task_id}")
    async def task_get(task_id: str, request: Request):
        return core.brain.get(
            await boundary.actor(request, capability="tasks"), task_id
        )

    @router.post("/tasks/{task_id}/confirm")
    async def task_confirm(task_id: str, body: Confirmation, request: Request):
        return await core.brain.confirm(
            await boundary.actor(request, capability="tasks"),
            task_id,
            body.confirmation_id,
            body.approved,
        )

    @router.post("/tasks/{task_id}/cancel")
    async def task_cancel(task_id: str, request: Request):
        return await core.brain.cancel(
            await boundary.actor(request, capability="tasks"), task_id
        )

    @router.get("/routing")
    async def routing(request: Request):
        return core.router.preferences(await boundary.actor(request, capability="ai"))

    @router.put("/routing")
    async def set_routing(body: RoutingPreference, request: Request):
        return core.router.set_preferences(
            await boundary.actor(request, capability="ai"), **body.model_dump()
        )

    @router.get("/providers")
    async def provider_diagnostics(request: Request):
        return core.router.diagnostics(await boundary.actor(request, capability="ai"))

    @router.patch("/providers/{name}")
    async def provider_configure(name: str, body: ProviderConfig, request: Request):
        return core.router.configure(
            await boundary.actor(request, capability="ai", owner=True),
            name,
            body.model_dump(exclude_unset=True),
        )

    @router.put("/providers/{name}/key")
    async def provider_key(name: str, body: ProviderKey, request: Request):
        core.router.set_key(
            await boundary.actor(request, capability="ai", owner=True), name, body.value
        )
        return {"stored": True, "verification": Status.NOT_VERIFIED.value}

    @router.post("/providers/{name}/probe")
    async def provider_probe(name: str, request: Request):
        actor = await boundary.actor(request, capability="ai", owner=True)
        reply = await core.router.complete(
            actor,
            [
                {
                    "role": "user",
                    "content": "Reply with the words JARVIS provider check.",
                }
            ],
            exact_provider=name,
        )
        return {
            "provider": name,
            "verification": Status.VERIFIED.value
            if reply.live
            else Status.NOT_VERIFIED.value,
            "live": reply.live,
            "latency_ms": reply.latency_ms,
            "input_tokens": reply.input_tokens,
            "output_tokens": reply.output_tokens,
            "note": "A real generation request succeeded."
            if reply.live
            else "Injected/test transport: not live provider verification.",
        }

    @router.get("/usage")
    async def usage(request: Request):
        return core.router.usage(await boundary.actor(request, capability="ai"))

    @router.get("/network")
    async def network_info(request: Request):
        actor = await boundary.actor(request, owner=True)
        if actor.channel != "desktop":
            raise DomainError("LOCAL_OWNER_REQUIRED", status=403)
        from .network import info

        return info(core)

    @router.put("/network")
    async def network_configure(body: NetworkConfig, request: Request):
        actor = await boundary.actor(request, owner=True)
        from .network import configure

        return configure(core, actor, **body.model_dump())

    @router.get("/bluetooth/bonds")
    async def bluetooth_bonds(request: Request):
        actor = await boundary.actor(request, owner=True)
        if actor.channel != "desktop":
            raise DomainError("LOCAL_OWNER_REQUIRED", status=403)
        return {
            "bonds": [
                {"id": b.id, "name": b.name}
                for b in await core.devices.radio.list_bonds()
            ],
            "source": "Windows OS"
            if getattr(core.devices.radio, "live", False)
            else "test adapter (NOT physical verification)",
        }

    @router.post("/devices/register")
    async def register_device(body: RegisterDevice, request: Request):
        return core.devices.register(await boundary.actor(request), **body.model_dump())

    @router.get("/devices")
    async def list_devices(request: Request):
        # Registration/own pending state is visible before trust so provisioning can finish.
        return core.devices.list(await boundary.actor(request))

    @router.post("/devices/{device_id}/bind")
    async def bind_device(device_id: str, body: BindDevice, request: Request):
        return await core.devices.bind(
            await boundary.actor(request, owner=True), device_id, **body.model_dump()
        )

    @router.post("/devices/challenge")
    async def device_challenge(body: Challenge, request: Request):
        return core.devices.challenge(
            await boundary.actor(request), body.device_id, body.purpose
        )

    @router.post("/devices/authorize")
    async def authorize_device(body: DeviceProof, request: Request):
        return await core.devices.authorize(
            await boundary.actor(request), body.challenge_id, body.signature
        )

    @router.post("/devices/{device_id}/revoke")
    async def revoke_device(device_id: str, request: Request):
        actor = await boundary.actor(request)
        # Self-revocation/logout remove authority and remain available for recovery.
        # Revoking somebody else's device is an admin control and requires fresh proof.
        target = core.devices.get(actor, device_id)
        if target["user_id"] != actor.user_id:
            actor = await boundary.actor(
                request, capability="device_actions", owner=True
            )
        await core.devices.revoke(actor, device_id)
        return {"revoked": True}

    @router.post("/devices/status")
    async def device_status(status: dict, request: Request):
        await core.devices.update_status(
            await boundary.actor(request, capability="notifications"), status
        )
        return {"received": True, "note": "Client telemetry is not pairing authority."}

    @router.get("/audit")
    async def audit(request: Request):
        actor = await boundary.actor(request, capability="tasks", owner=True)
        return core.db.all("SELECT * FROM j_audit ORDER BY created DESC LIMIT 150")

    @router.post("/internal/hud/show")
    async def show_hud(request: Request):
        if not boundary.local(request):
            raise DomainError("LOCAL_PROCESS_PROOF_REQUIRED", status=403)
        if not core.on_hud_show:
            raise DomainError("NATIVE_HUD_NOT_RUNNING", status=503)
        core.on_hud_show()
        return {"requested": True}

    @router.post("/internal/hud/activate")
    async def activate_hud(request: Request):
        actor = await boundary.actor(request, owner=True)
        if actor.channel != "desktop" or not core.on_native_activate:
            raise DomainError("LOCAL_OWNER_HUD_REQUIRED", status=403)
        core.on_native_activate(actor.session_id)
        return {"activated": True}

    @router.post("/files")
    async def upload_file(request: Request, filename: str = "upload.bin"):
        # Raw bytes permit an exact content-bound signature (including filename query),
        # unlike a browser-generated multipart boundary.
        actor = await boundary.actor(request, capability="tasks")
        import re, uuid

        name = (
            re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", filename).strip(". ")[:120]
            or "upload.bin"
        )
        body = await request.body()
        if len(body) > 18 * 1024 * 1024:
            raise DomainError("UPLOAD_TOO_LARGE", status=413)
        path = core.policy.workspace(actor) / (uuid.uuid4().hex[:10] + "-" + name)
        with path.open("xb") as stream:
            stream.write(body)
        return {"name": path.name, "path": str(path), "size": len(body)}

    @router.get("/files/{filename}")
    async def download_file(filename: str, request: Request):
        actor = await boundary.actor(request, capability="tasks")
        base = core.policy.workspace(actor)
        path = (base / filename).resolve()
        if not path.is_relative_to(base) or not path.is_file():
            raise DomainError("FILE_NOT_FOUND", status=404)
        return FileResponse(
            path, filename=path.name, media_type="application/octet-stream"
        )

    @app.websocket("/v1/device-bus")
    async def device_bus(websocket: WebSocket):
        actor = None
        try:
            boundary.transport(websocket)
            await websocket.accept()
            hello = await asyncio.wait_for(websocket.receive_json(), 10)
            if (
                set(hello) != {"type", "token", "challenge_id", "signature"}
                or hello["type"] != "authenticate"
            ):
                raise DomainError("DEVICE_AUTHENTICATION_REQUIRED", status=403)
            actor = core.auth.authenticate(
                hello["token"] or websocket.cookies.get("jarvis_session", "")
            )
            if actor.channel != "remote":
                raise DomainError("REMOTE_DEVICE_SESSION_REQUIRED", status=403)
            await core.devices.authorize(
                actor, hello["challenge_id"], hello["signature"], expected_purpose="bus"
            )
            actor = core.auth.revalidate(actor)
            await core.bus.connect(websocket, actor)
            await websocket.send_json(
                {
                    "type": "authenticated",
                    "payload": {
                        "device_id": actor.device_id,
                        "proof_expires": actor.proof_until,
                    },
                }
            )
            count, epoch = 0, time.monotonic()
            while True:
                event = await asyncio.wait_for(websocket.receive_json(), 65)
                if len(json.dumps(event)) > 256000:
                    raise DomainError("MESSAGE_TOO_LARGE")
                if time.monotonic() - epoch > 60:
                    count, epoch = 0, time.monotonic()
                count += 1
                if count > 120:
                    raise DomainError("DEVICE_RATE_LIMIT", status=429)
                actor = await core.devices.enforce(actor, "notifications")
                kind, payload = event.get("type"), event.get("payload", {})
                if kind == "ping":
                    await websocket.send_json(
                        {"type": "pong", "payload": {"time": time.time()}}
                    )
                elif kind in {"chat_message", "voice_transcript"}:
                    if (
                        not isinstance(payload, dict)
                        or set(payload) != {"text"}
                        or not isinstance(payload["text"], str)
                    ):
                        raise DomainError("INVALID_CHAT_MESSAGE")
                    task = await core.brain.submit(actor, text=payload["text"])
                    await websocket.send_json(
                        {"type": "task_accepted", "payload": {"id": task["id"]}}
                    )
                elif kind == "result":
                    await core.bus.result(
                        actor, str(event.get("request_id", "")), payload
                    )
                elif kind == "device_status":
                    await core.devices.update_status(actor, payload)
                else:
                    raise DomainError("UNSUPPORTED_BUS_MESSAGE")
        except (WebSocketDisconnect, asyncio.TimeoutError):
            pass
        except DomainError as error:
            with contextlib.suppress(Exception):
                await websocket.send_json(
                    {"type": "error", "payload": {"error": error.code}}
                )
                await websocket.close(code=4403)
        except Exception:
            with contextlib.suppress(Exception):
                await websocket.close(code=4400)
        finally:
            await core.bus.disconnect(websocket)

    app.include_router(router)
    pwa = root / "pwa"
    if pwa.exists():
        app.mount("/app", StaticFiles(directory=pwa, html=True), name="jarvis-pwa")

    @app.get("/")
    async def index():
        from fastapi.responses import RedirectResponse

        return RedirectResponse("/app/")

    app.add_middleware(SecurityMiddleware, boundary=boundary)
    return app
