from __future__ import annotations

import json
import os
import socket
import sqlite3
import subprocess
import sys
from pathlib import Path

from .types import DomainError


def secure_windows_directory(path: Path):
    """Restrict runtime state to the current Windows user and SYSTEM; fail on ACL error."""
    if sys.platform != "win32":
        return
    import csv

    try:
        output = subprocess.run(
            ["whoami.exe", "/user", "/fo", "csv", "/nh"],
            capture_output=True,
            text=True,
            check=True,
            creationflags=0x08000000,
        )
        sid = next(csv.reader(output.stdout.splitlines()))[1]
        if not sid.startswith("S-1-"):
            raise ValueError()
        subprocess.run(
            [
                "icacls.exe",
                str(path),
                "/inheritance:r",
                "/grant:r",
                f"*{sid}:(OI)(CI)F",
                "*S-1-5-18:(OI)(CI)F",
            ],
            check=True,
            capture_output=True,
            creationflags=0x08000000,
        )
    except Exception:
        raise DomainError(
            "PRIVATE_DIRECTORY_ACL_FAILED",
            "Unable to secure runtime state. Extract to a folder writable by your Windows account.",
            503,
        )


def prepare_shared_storage(core):
    """Point retained stores at one DB and non-destructively migrate old smart-home rows."""
    secure_windows_directory(core.data_dir)
    import workspace_store
    import smart_home.storage as home

    workspace_store.CONFIG_DIR = core.data_dir
    workspace_store.STORE_FILE = core.db.path
    workspace_store.WorkspaceStore(core.db.path)
    home.CONFIG_DIR = core.data_dir
    home.DB_FILE = core.db.path
    home.KEY_FILE = core.data_dir / "smart_home.key"
    home.CredentialVault.__init__.__defaults__ = (home.KEY_FILE,)
    home.SmartHomeStorage(core.db.path)
    old = core.data_dir / "smart_home.sqlite3"
    if (
        old.exists()
        and old.resolve() != core.db.path
        and not core.db.setting("legacy_smart_home_migrated", False)
    ):
        with core.db.transaction() as target:
            with sqlite3.connect(f"file:{old.as_posix()}?mode=ro", uri=True) as source:
                for table in ("provider_accounts", "devices", "activities", "scenes"):
                    if not source.execute(
                        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                        (table,),
                    ).fetchone():
                        continue
                    source_columns = [
                        r[1] for r in source.execute(f'PRAGMA table_info("{table}")')
                    ]
                    target_columns = {
                        r[1] for r in target.execute(f'PRAGMA table_info("{table}")')
                    }
                    columns = [c for c in source_columns if c in target_columns]
                    quoted = ",".join('"' + c.replace('"', '""') + '"' for c in columns)
                    values = source.execute(
                        f'SELECT {quoted} FROM "{table}"'
                    ).fetchall()
                    if values:
                        target.executemany(
                            f'INSERT OR IGNORE INTO "{table}" ({quoted}) VALUES({",".join("?" for _ in columns)})',
                            values,
                        )
        core.db.set_setting("legacy_smart_home_migrated", True)
        # The original file remains a backup, not an active second database.
        core.db.audit(
            None,
            "smart_home_migration",
            None,
            "copied_into_shared_database_original_retained",
        )


def network_config(root: Path):
    defaults = {
        "host": "127.0.0.1",
        "port": 8765,
        "tls_cert": "",
        "tls_key": "",
        "origins": [],
        "advertise": False,
        "public_host": "localhost",
    }
    path = Path(root) / "config/jarvis_network.json"
    if path.exists():
        data = json.loads(path.read_text())
        if not set(data) <= set(defaults):
            raise DomainError("INVALID_NETWORK_CONFIG")
        defaults.update(data)
    if defaults["host"] not in {"127.0.0.1", "localhost", "::1", "0.0.0.0", "::"}:
        try:
            import ipaddress

            ipaddress.ip_address(defaults["host"])
        except ValueError:
            raise DomainError("INVALID_BIND_ADDRESS")
    if not isinstance(defaults["port"], int) or not 1024 <= defaults["port"] <= 65535:
        raise DomainError("INVALID_PORT")
    tls = bool(defaults["tls_cert"] and defaults["tls_key"])
    if defaults["host"] not in {"127.0.0.1", "localhost", "::1"} and not tls:
        raise DomainError(
            "LAN_TLS_REQUIRED",
            "Configure a TLS certificate/key before enabling LAN transport. Bluetooth and device authorization remain mandatory.",
            503,
        )
    defaults["tls"] = tls
    return defaults


def server_options(root: Path, config: dict):
    result = {
        "host": config["host"],
        "port": config["port"],
        "log_level": "warning",
        "access_log": False,
        "proxy_headers": False,
        "ws_max_size": 256000,
    }
    if config["tls"]:
        for field, option in (("tls_cert", "ssl_certfile"), ("tls_key", "ssl_keyfile")):
            path = Path(config[field])
            if not path.is_absolute():
                path = Path(root) / path
            if not path.is_file():
                raise DomainError("TLS_FILE_MISSING", status=503)
            result[option] = str(path)
    return result


def local_url(config):
    return f"{'https' if config['tls'] else 'http'}://127.0.0.1:{config['port']}"


def allowed_origins(config):
    protocol = "https" if config["tls"] else "http"
    defaults = {
        f"{protocol}://127.0.0.1:{config['port']}",
        f"{protocol}://localhost:{config['port']}",
    }
    defaults.update(config.get("origins", []))
    return defaults
