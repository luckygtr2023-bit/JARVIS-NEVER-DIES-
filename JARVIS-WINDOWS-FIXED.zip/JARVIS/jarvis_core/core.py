from __future__ import annotations

import json
import asyncio
from pathlib import Path

from .auth import Auth
from .bluetooth import WindowsBluetooth
from .brain import Brain
from .bus import DeviceBus
from .combos import Combos
from .database import Database
from .devices import Devices
from .memory import Memory
from .routing import Providers, Router
from .secrets import ContentCipher, SecretGuard, SecretStore
from .tools import Catalog, ActionPolicy, BrahmaActions
from .types import DomainError, ToolResult, Status


class Core:
    def __init__(
        self,
        root: Path,
        *,
        data_dir: Path | None = None,
        radio=None,
        providers=None,
        actions=None,
    ):
        self.root = Path(root).resolve()
        self.data_dir = Path(data_dir or self.root / "config").resolve()
        self.guard = SecretGuard()
        self.secrets = SecretStore(self.data_dir / "private", self.guard)
        self.local_proof = self.secrets.get_or_create("local_process")
        self.cipher = ContentCipher.from_store(self.secrets)
        self.db = Database(self.data_dir / "workspace_store.sqlite3")
        self.auth = Auth(self.db)
        self.memory = Memory(self.db, self.auth, self.cipher, self.guard)
        self.catalog = Catalog(self.root)
        self.policy = ActionPolicy(self.data_dir.parent, self.catalog)
        self.devices = Devices(self.db, self.auth, radio or WindowsBluetooth())
        self.providers = providers or Providers(self.secrets, self.root)
        self.router = Router(self.db, self.auth, self.providers, self.guard)
        self.combos = Combos(self.db, self.auth, self.cipher, self.guard, self.policy)
        self.actions = actions or BrahmaActions()
        self.bus = DeviceBus(self.devices, self.auth, self.guard)
        self.devices.on_revoke = self.bus.close_device
        self.brain = Brain(
            self.db,
            self.auth,
            self.devices,
            self.memory,
            self.router,
            self.combos,
            self.policy,
            self.actions,
            self.cipher,
            self.guard,
        )
        self.brain.publish = self.bus.publish
        self.on_hud_show = None
        self.on_native_activate = None
        self.on_native_logout = None
        self.native_ready = False
        self.loop = None
        self._install_existing_tool_boundaries()

    def _install_existing_tool_boundaries(self):
        async def save_memory(actor, params):
            actor = await self.devices.enforce(actor, "memory")
            value = params.get("value", "")
            item = self.memory.write(
                actor,
                "long_term",
                str(params.get("key") or "User fact"),
                value,
                [str(params.get("category") or "notes")],
            )
            return ToolResult(
                {"saved": item["id"]},
                Status.VERIFIED,
                "Scoped memory write committed in the shared database; credential guard applied.",
            )

        self.actions.register("save_memory", save_memory)

        async def file_control(actor, params):
            target = str(params.get("target") or "").strip()
            if target and target.lower() not in {"pc", "computer", "local"}:
                mappings = {
                    "list": "file_list",
                    "read": "file_read",
                    "write": "file_write",
                    "delete": "file_delete",
                }
                action = mappings.get(str(params.get("action") or ""))
                if not action:
                    raise DomainError("UNSUPPORTED_ANDROID_ACTION")
                own = [
                    d
                    for d in self.devices.list(actor)
                    if d["user_id"] == actor.user_id and target in {d["id"], d["name"]}
                ]
                if len(own) != 1:
                    raise DomainError(
                        "TARGET_DEVICE_REQUIRED",
                        "Choose an exact registered device ID owned by this user.",
                        403,
                    )
                path = str(params.get("path") or "")
                if params.get("name"):
                    path = str(Path(path) / str(params["name"]))
                return await self.bus.execute_android(
                    actor,
                    own[0]["id"],
                    action,
                    {
                        "path": path,
                        "content": params.get("content", ""),
                        "append": bool(params.get("append", False)),
                    },
                )
            from actions.file_controller import file_controller

            return await asyncio.to_thread(
                file_controller, parameters=params, player=None
            )

        self.actions.register("file_controller", file_control)

        self.actions.register(
            "connect_list_devices", lambda a, p: {"devices": self.devices.list(a)}
        )
        self.actions.register(
            "connect_get_device", lambda a, p: self.devices.get(a, self._target(p))
        )
        self.actions.register(
            "connect_get_capabilities",
            lambda a, p: {
                "device": self._target(p),
                "permissions": self.devices.get(a, self._target(p))["permissions"],
            },
        )

        async def execute(actor, params):
            values = params.get("parameters") or params.get("parameters_json") or {}
            if isinstance(values, str):
                try:
                    values = json.loads(values)
                except ValueError:
                    raise DomainError("INVALID_DEVICE_PARAMETERS")
            return await self.bus.execute_android(
                actor, self._target(params), str(params.get("action") or ""), values
            )

        self.actions.register("connect_execute", execute)

        async def disconnect(actor, params):
            await self.devices.revoke(actor, self._target(params))
            return {"revoked": True}

        self.actions.register("connect_disconnect_device", disconnect)

        def pair(actor, params):
            actor.owner()
            return {
                "status": "LOCAL_OWNER_BINDING_REQUIRED",
                "instructions": "Use Devices in the JARVIS control center: register the client key, pair the actual phone in Windows, compare fingerprints, then bind its OS bond. Network presence never pairs a device.",
            }

        self.actions.register("connect_pair_device", pair)

    @staticmethod
    def _target(params):
        return str(
            params.get("device_id")
            or params.get("device")
            or params.get("target")
            or ""
        )
