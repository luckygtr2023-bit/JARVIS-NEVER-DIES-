from __future__ import annotations

import json
import threading
import time
import uuid
from collections import OrderedDict

from .auth import Auth
from .database import Database
from .secrets import ContentCipher, SecretGuard
from .types import Principal, DomainError

KINDS = {"short", "session", "long_term", "workflow"}


class Memory:
    def __init__(
        self,
        db: Database,
        auth: Auth,
        cipher: ContentCipher,
        guard: SecretGuard,
        clock=time.time,
    ):
        self.db, self.auth, self.cipher, self.guard, self.clock = (
            db,
            auth,
            cipher,
            guard,
            clock,
        )
        self._short: OrderedDict[tuple[str, str], list[dict]] = OrderedDict()
        self._lock = threading.RLock()

    def settings(self, actor: Principal):
        self.auth.revalidate(actor).require("memory")
        return self.db.setting(
            "memory:" + actor.user_id, {"enabled": True, "auto_context": False}
        )

    def configure(self, actor: Principal, enabled: bool, auto_context: bool = False):
        self.auth.revalidate(actor).require("memory")
        self.db.set_setting(
            "memory:" + actor.user_id,
            {"enabled": bool(enabled), "auto_context": bool(auto_context)},
        )
        if not enabled:
            self.forget_context(actor.user_id)
        self.db.audit(
            actor.user_id,
            "memory_configure",
            None,
            "enabled" if enabled else "disabled",
        )
        return self.settings(actor)

    def _validate(self, kind, label, value, tags):
        if (
            kind not in KINDS
            or not isinstance(label, str)
            or not 1 <= len(label.strip()) <= 120
        ):
            raise DomainError("INVALID_MEMORY_ITEM")
        if (
            not isinstance(tags, list)
            or len(json.dumps(value, ensure_ascii=False)) > 12000
            or len(tags) > 20
            or any(not isinstance(t, str) or len(t) > 50 for t in tags)
        ):
            raise DomainError("MEMORY_ITEM_TOO_LARGE")
        self.guard.check({"label": label, "value": value, "tags": tags})
        self.guard.check({label: value})

    def write(
        self, actor: Principal, kind: str, label: str, value, tags=None, *, item_id=None
    ):
        actor = self.auth.revalidate(actor)
        actor.require("memory")
        if not self.settings(actor)["enabled"]:
            raise DomainError("MEMORY_DISABLED", status=409)
        tags = tags or []
        self._validate(kind, label, value, tags)
        now, resource = self.clock(), item_id or uuid.uuid4().hex
        entry = {
            "id": resource,
            "kind": kind,
            "label": label.strip(),
            "value": value,
            "tags": tags,
            "created": now,
            "updated": now,
        }
        if kind == "short":
            if item_id:
                self.delete(actor, item_id)
            with self._lock:
                key = (actor.user_id, actor.session_id)
                items = self._short.setdefault(key, [])
                items.append({**entry, "expires": now + 900})
                self._short[key] = items[-30:]
                self._short.move_to_end(key)
                while len(self._short) > 1000:
                    self._short.popitem(last=False)
            return entry
        if item_id:
            old = self.db.one(
                "SELECT * FROM j_memory WHERE id=? AND user_id=?",
                (item_id, actor.user_id),
            )
            if not old or (
                old["kind"] == "session" and old["session_id"] != actor.session_id
            ):
                raise DomainError("MEMORY_NOT_FOUND", status=404)
            entry["created"] = old["created"]
            count = self.db.execute(
                "UPDATE j_memory SET kind=?,session_id=?,label=?,content=?,tags=?,updated=? WHERE id=? AND user_id=?",
                (
                    kind,
                    actor.session_id if kind == "session" else "",
                    entry["label"],
                    self.cipher.seal(actor.user_id, resource, value),
                    json.dumps(tags),
                    now,
                    resource,
                    actor.user_id,
                ),
            )
            if not count:
                raise DomainError("MEMORY_NOT_FOUND", status=404)
        else:
            if (
                self.db.one(
                    "SELECT COUNT(*) n FROM j_memory WHERE user_id=?", (actor.user_id,)
                )["n"]
                >= 3000
            ):
                raise DomainError("MEMORY_QUOTA", status=409)
            self.db.execute(
                "INSERT INTO j_memory VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    resource,
                    actor.user_id,
                    kind,
                    actor.session_id if kind == "session" else "",
                    entry["label"],
                    self.cipher.seal(actor.user_id, resource, value),
                    json.dumps(tags),
                    now,
                    now,
                ),
            )
        self.db.audit(
            actor.user_id,
            "memory_update" if item_id else "memory_create",
            resource,
            "saved",
        )
        return entry

    def list(self, actor: Principal, query="", kind: str | None = None, limit=100):
        actor = self.auth.revalidate(actor)
        actor.require("memory")
        if kind and kind not in KINDS:
            raise DomainError("INVALID_MEMORY_KIND")
        entries = []
        if not kind or kind != "short":
            rows = self.db.all(
                "SELECT * FROM j_memory WHERE user_id=? AND (kind!='session' OR session_id=?) ORDER BY updated DESC",
                (actor.user_id, actor.session_id),
            )
            for row in rows:
                if kind and row["kind"] != kind:
                    continue
                entries.append(
                    {
                        "id": row["id"],
                        "kind": row["kind"],
                        "label": row["label"],
                        "value": self.cipher.open(
                            actor.user_id, row["id"], row["content"]
                        ),
                        "tags": json.loads(row["tags"]),
                        "created": row["created"],
                        "updated": row["updated"],
                    }
                )
        if not kind or kind == "short":
            with self._lock:
                key = (actor.user_id, actor.session_id)
                fresh = [
                    e for e in self._short.get(key, []) if e["expires"] > self.clock()
                ]
                self._short[key] = fresh
                entries += [
                    {k: v for k, v in e.items() if k != "expires"} for e in fresh
                ]
        terms = query.casefold().split()
        if terms:
            entries = [
                e
                for e in entries
                if all(t in json.dumps(e, ensure_ascii=False).casefold() for t in terms)
            ]
        return sorted(entries, key=lambda e: e["updated"], reverse=True)[
            : max(1, min(3000, limit))
        ]

    def context(self, actor: Principal, query="", limit=8):
        if not self.settings(actor)["enabled"]:
            return []
        # Explicit stored memories only; never mine raw conversations automatically.
        return [
            {"kind": e["kind"], "label": e["label"], "value": e["value"]}
            for e in self.list(actor, query=query, limit=limit)
        ]

    def forget_context(self, user_id: str, session_id: str | None = None):
        with self._lock:
            for key in list(self._short):
                if key[0] == user_id and (session_id is None or key[1] == session_id):
                    del self._short[key]

    def delete(self, actor: Principal, item_id: str):
        actor = self.auth.revalidate(actor)
        actor.require("memory")
        changed = self.db.execute(
            "DELETE FROM j_memory WHERE id=? AND user_id=? AND (kind!='session' OR session_id=?)",
            (item_id, actor.user_id, actor.session_id),
        )
        with self._lock:
            key = (actor.user_id, actor.session_id)
            items = self._short.get(key, [])
            new = [e for e in items if e["id"] != item_id]
            changed += len(items) - len(new)
            self._short[key] = new
        if not changed:
            raise DomainError("MEMORY_NOT_FOUND", status=404)
        self.db.audit(actor.user_id, "memory_delete", item_id, "deleted")

    def clear(self, actor: Principal):
        actor = self.auth.revalidate(actor)
        actor.require("memory")
        self.db.execute("DELETE FROM j_memory WHERE user_id=?", (actor.user_id,))
        self.forget_context(actor.user_id)
        self.db.audit(actor.user_id, "memory_clear", None, "cleared")

    def export(self, actor: Principal):
        items = [
            {k: e[k] for k in ("kind", "label", "value", "tags")}
            for e in self.list(actor, limit=3000)
            if e["kind"] in {"long_term", "workflow"}
        ]
        self.guard.check(items)
        return {"format": "jarvis.memory.v1", "items": items}

    def import_items(self, actor: Principal, document: dict):
        actor = self.auth.revalidate(actor)
        actor.require("memory")
        if not self.settings(actor)["enabled"]:
            raise DomainError("MEMORY_DISABLED", status=409)
        if (
            set(document) != {"format", "items"}
            or document.get("format") != "jarvis.memory.v1"
        ):
            raise DomainError("INVALID_MEMORY_IMPORT")
        items = document["items"]
        if (
            not isinstance(items, list)
            or len(items) > 500
            or len(json.dumps(document)) > 1_000_000
        ):
            raise DomainError("IMPORT_TOO_LARGE")
        for item in items:
            if (
                not isinstance(item, dict)
                or set(item) != {"kind", "label", "value", "tags"}
                or item["kind"] not in {"long_term", "workflow"}
            ):
                raise DomainError("INVALID_MEMORY_IMPORT")
            self._validate(**item)
        with self.db.transaction() as conn:
            count = conn.execute(
                "SELECT COUNT(*) FROM j_memory WHERE user_id=?", (actor.user_id,)
            ).fetchone()[0]
            if count + len(items) > 3000:
                raise DomainError("MEMORY_QUOTA", status=409)
            for item in items:
                iid, now = uuid.uuid4().hex, self.clock()
                conn.execute(
                    "INSERT INTO j_memory VALUES(?,?,?,?,?,?,?,?,?)",
                    (
                        iid,
                        actor.user_id,
                        item["kind"],
                        "",
                        item["label"],
                        self.cipher.seal(actor.user_id, iid, item["value"]),
                        json.dumps(item["tags"]),
                        now,
                        now,
                    ),
                )
        self.db.audit(actor.user_id, "memory_import", None, "imported")
        return {"imported": len(items)}

    def import_legacy(self, actor: Principal, path):
        """Explicit local OWNER migration; anonymous legacy facts are never shared automatically."""
        actor = self.auth.revalidate(actor)
        actor.owner()
        if actor.channel != "desktop":
            raise DomainError("LOCAL_OWNER_REQUIRED", status=403)
        from pathlib import Path

        source = Path(path)
        if not source.is_file() or source.stat().st_size > 1_000_000:
            raise DomainError("LEGACY_MEMORY_UNAVAILABLE", status=404)
        raw = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise DomainError("INVALID_MEMORY_IMPORT")
        items = []
        for category, records in raw.items():
            if not isinstance(records, dict):
                continue
            for label, record in records.items():
                value = (
                    record.get("value")
                    if isinstance(record, dict) and "value" in record
                    else record
                )
                items.append(
                    {
                        "kind": "long_term",
                        "label": f"{category}/{label}"[:120],
                        "value": value,
                        "tags": ["legacy", str(category)[:50]],
                    }
                )
        result = self.import_items(
            actor, {"format": "jarvis.memory.v1", "items": items}
        )
        self.db.audit(
            actor.user_id, "legacy_memory_import", None, "copied_original_retained"
        )
        return {
            **result,
            "original_retained": True,
            "note": "Copied only into this OWNER's isolated memory. Original legacy file was not changed.",
        }
