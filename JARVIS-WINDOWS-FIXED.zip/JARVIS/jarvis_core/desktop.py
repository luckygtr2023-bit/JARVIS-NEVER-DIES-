from __future__ import annotations

import argparse
import asyncio
import copy
import json
import os
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4

from .core import Core
from .types import DomainError
from .runtime import (
    network_config,
    server_options,
    local_url,
    allowed_origins,
    prepare_shared_storage,
)


class ScopedUI:
    """Remote tool output goes only to that user's bus; it never enters global HUD history."""

    muted = True
    current_file = None

    def __init__(self, core, actor):
        self.core, self.actor = core, actor
        self.root = SimpleNamespace(
            after=lambda ms, callback=None: callback() if callback else None
        )

    def write_log(self, text):
        try:
            self.core.auth.revalidate(self.actor)
            if self.core.loop:
                asyncio.run_coroutine_threadsafe(
                    self.core.bus.publish(
                        self.actor.user_id,
                        {
                            "type": "task_log",
                            "payload": {
                                "text": self.core.guard.redact(str(text))[:2000]
                            },
                        },
                    ),
                    self.core.loop,
                )
        except DomainError:
            pass

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


class ConnectFacade:
    """Existing Qt device controls read the authoritative store; unsafe old pairing is not a bypass."""

    def __init__(self, core, actor_getter):
        self.core, self.actor_getter = core, actor_getter

    def _actor(self):
        actor = self.actor_getter()
        actor.owner()
        return actor

    def is_running(self):
        return bool(self.core.loop and self.core.loop.is_running())

    def list_devices(self):
        try:
            actor = self._actor()
        except DomainError:
            return []  # A hidden legacy Qt refresh timer must not abort on logout.
        return [
            {
                **d,
                "device_id": d["id"],
                "online": d["id"] in self.core.bus.sessions,
                "capabilities": d["permissions"],
                "ip": "authenticated device bus",
            }
            for d in self.core.devices.list(actor)
            if d["approved"] and not d["revoked"]
        ]

    def get_device(self, target):
        return next(
            (d for d in self.list_devices() if target in {d["device_id"], d["name"]}),
            None,
        )

    def resolve_devices(self, query):
        return [
            d
            for d in self.list_devices()
            if query.casefold() in d["name"].casefold() or query == d["device_id"]
        ]

    def gateway_info(self):
        config = network_config(self.core.root)
        return {
            "running": self.is_running(),
            "host": config["host"],
            "port": config["port"],
            "devices": len(self.list_devices()),
            "advertise": config["advertise"],
        }

    def logs(self):
        try:
            self._actor()
        except DomainError:
            return []
        return self.core.db.all(
            "SELECT event type,created timestamp,outcome FROM j_audit ORDER BY created DESC LIMIT 100"
        )

    def list_pending_requests(self):
        return []  # Registration/bond binding happens in the authenticated control center.

    def create_pairing_offer(self, **kwargs):
        self._actor()
        from .network import info

        details = info(self.core)
        cfg = network_config(self.core.root)
        return {
            **details["qr_payload"],
            "uri": details["qr_payload"]["backend_url"] + "/app/",
            "url": details["qr_payload"]["backend_url"] + "/app/",
            "service": "_BRAHMA._tcp.local.",
            "host": cfg.get("public_host", "localhost"),
            "port": cfg["port"],
            "pairing_code": "KEY + OS BOND",
            "pairing_token": "",
            "expires_at": time.time(),
            "instructions": details["note"],
        }

    async def approve_pending_request(self, pending_id):
        return {
            "success": False,
            "error": "Use the local JARVIS Devices panel to verify the OS Bluetooth bond and public-key fingerprint.",
        }

    async def reject_pending_request(self, pending_id):
        return False

    def rename_device(self, target, new_name):
        actor = self._actor()
        device = self.get_device(target)
        if not device or not new_name.strip() or len(new_name) > 80:
            return {"success": False, "error": "Invalid device or name"}
        self.core.db.execute(
            "UPDATE j_devices SET name=? WHERE id=?",
            (new_name.strip(), device["device_id"]),
        )
        return {"success": True, "device": self.get_device(device["device_id"])}

    def get_capabilities(self, target):
        device = self.get_device(target)
        return {
            "success": bool(device),
            "capabilities": device.get("capabilities", []) if device else [],
        }

    def route_command(self, target, action, parameters=None):
        actor = self._actor()
        device = self.get_device(target)
        if not device:
            return {"success": False, "error": "Device not found"}

        async def dispatch():
            task = await self.core.brain.submit(
                actor,
                steps=[
                    {
                        "tool": "connect_execute",
                        "parameters": {
                            "device": device["device_id"],
                            "action": action,
                            "parameters": parameters or {},
                        },
                    }
                ],
            )
            await self.core.brain.wait(task["id"], timeout=40)
            outcome = self.core.brain.get(actor, task["id"])
            if outcome["state"] == "awaiting_confirmation":
                return {
                    "success": False,
                    "error_code": "CONFIRMATION_REQUIRED",
                    "error": "Confirm the exact device action in JARVIS Brain.",
                    "task_id": task["id"],
                }
            if outcome["state"] != "completed":
                return {
                    "success": False,
                    "error": outcome.get("final_response", "Device action failed"),
                }
            try:
                return json.loads(outcome["results"][-1]["value"])
            except (ValueError, IndexError):
                return {"success": True, "data": outcome.get("final_response", "")}

        return asyncio.run_coroutine_threadsafe(dispatch(), self.core.loop).result(
            timeout=45
        )

    async def disconnect_device(self, target, **kwargs):
        actor = self._actor()
        device = self.get_device(target)
        if not device:
            return {"success": False, "error": "Device not found"}
        await self.core.devices.revoke(actor, device["device_id"])
        return {"success": True}

    async def reconnect_device(self, target):
        return {
            "success": False,
            "error": "The client must reauthenticate its signing key; a network connection does not restore trust.",
        }


def launch():
    if sys.platform != "win32":
        print(
            "Native Windows HUD/startup is NOT VERIFIED on this host. Use jarvis_core.server for isolated portable backend tests."
        )
        return 2
    os.environ["BRAHMA_SKIP_UPDATE"] = "1"
    root = Path(__file__).resolve().parents[1]
    config = network_config(root)
    core = Core(root)
    prepare_shared_storage(core)
    # Use the existing Qt runtime, not a replacement application window.
    from PyQt6.QtCore import QObject, pyqtSignal, QUrl, QTimer, Qt
    from PyQt6.QtWidgets import QDialog, QVBoxLayout, QPushButton
    from PyQt6.QtNetwork import QNetworkCookie
    from PyQt6.QtWebEngineCore import QWebEngineProfile
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    import ui as inherited_ui
    import main as inherited
    from .api import create_app
    import uvicorn

    # Keep the existing credential controls functional with the protected key store.
    original_defaults = inherited_ui.MainWindow._load_api_defaults

    def protected_defaults(window):
        data = original_defaults(window)
        for provider in ("gemini", "openrouter"):
            data[provider + "_api_key"] = core.providers.key(provider)
        return data

    inherited_ui.MainWindow._load_api_defaults = protected_defaults
    original_saved = inherited_ui.MainWindow._on_setup_done

    def protected_saved(window, key, or_key, os_system):
        # Save privately first. Preserve the inherited config fields and UI flow.
        core.secrets.set("provider_gemini", key.strip())
        core.secrets.set("provider_openrouter", or_key.strip())
        original_saved(window, key, or_key, os_system)
        path = inherited_ui.API_FILE
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            data["gemini_api_key"] = ""
            data["openrouter_api_key"] = ""
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    inherited_ui.MainWindow._on_setup_done = protected_saved

    shell = inherited_ui.BrahmaUI(
        str(root / "assets/jarvis_logo.png"), show_immediately=False
    )
    shell.hide_main()
    shell._win.centralWidget().setEnabled(False)
    core.native_ready = True
    state = {
        "sid": None,
        "live": None,
        "voice": None,
        "plugins": None,
        "web_loaded": False,
    }

    class Signals(QObject):
        show = pyqtSignal()
        activate = pyqtSignal(str)
        logout = pyqtSignal()
        task = pyqtSignal(dict)

    signals = Signals()
    panel = QDialog(shell._win)
    panel.setWindowTitle("J.A.R.V.I.S. — Identity & Control Center")
    panel.resize(1180, 820)
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(0, 0, 0, 0)
    web = QWebEngineView(panel)
    profile = web.page().profile()
    profile.setPersistentCookiesPolicy(
        QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies
    )
    proof = QNetworkCookie(b"jarvis_local", core.local_proof.encode())
    proof.setHttpOnly(True)
    proof.setSecure(config["tls"])
    proof.setPath("/")
    profile.cookieStore().setCookie(proof, QUrl(local_url(config)))
    web.loadFinished.connect(lambda ok: state.update(web_loaded=bool(ok)))
    if config["tls"]:
        import hashlib
        from cryptography import x509

        cert_path = Path(config["tls_cert"])
        if not cert_path.is_absolute():
            cert_path = root / cert_path
        pinned = hashlib.sha256(
            x509.load_pem_x509_certificate(cert_path.read_bytes()).public_bytes(
                __import__(
                    "cryptography.hazmat.primitives.serialization",
                    fromlist=["Encoding"],
                ).Encoding.DER
            )
        ).digest()

        def certificate_error(error):
            chain = error.certificateChain()
            if chain and hashlib.sha256(bytes(chain[0].toDer())).digest() == pinned:
                error.acceptCertificate()
            else:
                error.rejectCertificate()

        web.page().certificateError.connect(certificate_error)
    layout.addWidget(web)

    def current_actor():
        if not state["sid"]:
            raise DomainError("LOCAL_OWNER_LOGIN_REQUIRED", status=401)
        actor = core.auth.from_session(state["sid"])
        actor.owner()
        return actor

    def show_panel():
        panel.show()
        panel.raise_()
        panel.activateWindow()
        if web.url().isEmpty() or not state["web_loaded"]:
            web.setUrl(QUrl(local_url(config) + "/app/"))

    signals.show.connect(show_panel)
    core.on_hud_show = signals.show.emit
    core.on_native_activate = signals.activate.emit
    core.on_native_logout = signals.logout.emit
    control_button = QPushButton(
        "JARVIS · Brain / Memory / AI / Combos / Trust", shell._win
    )
    control_button.setStyleSheet(
        "QPushButton {color:#ffbd52;background:#111820;border:1px solid #6b512d;border-radius:6px;padding:9px 16px;font-weight:600;}"
    )
    control_button.clicked.connect(show_panel)
    # Append to the retained layout; no original controls/pages are removed.
    central_layout = shell._win.centralWidget().layout()
    if central_layout is not None:
        central_layout.addWidget(control_button)
    shell.on_remote_clicked = show_panel
    facade = ConnectFacade(core, current_actor)
    # Attach only after authenticated activation; an unready UI cannot read authority state.

    def submit_text(text):
        try:
            actor = current_actor()
            asyncio.run_coroutine_threadsafe(
                core.brain.submit(actor, text=str(text)), core.loop
            )
        except DomainError:
            show_panel()

    shell.on_text_command = submit_text

    async def publish(user_id, event):
        await core.bus.publish(user_id, event)
        try:
            if (
                current_actor().user_id == user_id
                and event.get("type") == "task_status"
            ):
                signals.task.emit(event["payload"])
        except DomainError:
            pass

    core.brain.publish = publish

    def update_task(task):
        shell.update_task_workspace(
            title="JARVIS Brain",
            status=task.get("stage") or task["state"],
            output=task.get("final_response") or task["state"],
            percent=100 if task["state"] == "completed" else 50,
        )
        if task["state"] == "awaiting_confirmation":
            show_panel()
        if task.get("final_response"):
            shell.write_log("J.A.R.V.I.S.: " + task["final_response"])

    signals.task.connect(update_task)

    async def dispatch(actor, name, parameters):
        if not state["live"]:
            raise DomainError("NATIVE_OWNER_NOT_ACTIVE", status=503)
        live = state["live"]
        target = live
        remote = actor.channel != "desktop" or actor.user_id != current_actor().user_id
        local_only = core.router.preferences(actor)["mode"] == "local_only"
        if remote or local_only:
            target = copy.copy(live)
            target.ui = ScopedUI(core, actor) if remote else live.ui
            target.speak = lambda *a, **k: None
            target.speak_error = lambda *a, **k: None
        fc = SimpleNamespace(name=name, args=parameters, id=uuid4().hex)
        response = await inherited.BrahmaLive._execute_tool(target, fc)
        return (response.response or {}).get("result", response.response)

    core.actions.legacy_dispatch = dispatch

    def activate(sid):
        try:
            actor = core.auth.from_session(sid)
            actor.owner()
            if actor.channel != "desktop":
                return
            state["sid"] = sid
            if state["live"] is None:
                shell.muted = True
                live = inherited.BrahmaLive(shell, enable_dashboard=False)
                state["live"] = live

                async def guarded_voice_tool(fc):
                    owner = current_actor()
                    task = await core.brain.submit(
                        owner,
                        steps=[{"tool": fc.name, "parameters": dict(fc.args or {})}],
                    )
                    await core.brain.wait(task["id"], timeout=180)
                    outcome = core.brain.get(owner, task["id"])
                    return inherited.types.FunctionResponse(
                        id=fc.id,
                        name=fc.name,
                        response={
                            "task_id": task["id"],
                            "state": outcome["state"],
                            "result": outcome["final_response"]
                            or "Awaiting explicit confirmation in the JARVIS HUD. Nothing has been self-confirmed.",
                        },
                    )

                live._execute_tool = guarded_voice_tool
                # New secure memory replaces unscoped automatic transcript mining,
                # while the inherited module remains available for explicit migration.
                inherited._update_memory_async = lambda *a, **k: None
                inherited.load_memory = lambda: {
                    "jarvis_user": {
                        item["label"]: {"value": item["value"]}
                        for item in core.memory.context(current_actor(), limit=8)
                    }
                }
                inherited._memory_context_for_request = lambda text: json.dumps(
                    core.memory.context(current_actor(), text, limit=5)
                )
                inherited._get_api_key = lambda: core.providers.key("gemini")
                # Existing plugins are trusted local extensions, not remote permission grants.
                manager = inherited.PluginManager(root)
                manager.load_plugins()
                manager.register_brahma(live)
                manager.dispatch("on_startup", live)
                live.plugin_manager = manager
                state["plugins"] = manager
            shell.set_brahma_connect_service(facade)
            shell.on_text_command = submit_text
            shell.on_remote_clicked = show_panel
            shell._win._ready = True
            if getattr(shell._win, "_overlay", None):
                shell._win._overlay.hide()
            shell._win.centralWidget().setEnabled(True)
            shell.show_main()
            panel.hide()
            shell.write_log(
                "SYS: JARVIS backend authority active. Tools require backend permission and consequential confirmation. Remote devices require Bluetooth trust."
            )
        except Exception as error:
            shell.write_log(
                "ERR: Native activation failed ("
                + type(error).__name__
                + "). No verification is claimed."
            )
            show_panel()

    signals.activate.connect(activate)

    def logout():
        state["sid"] = None
        if state["voice"]:
            state["voice"].cancel()
            state["voice"] = None
        shell._win.centralWidget().setEnabled(False)
        shell.hide_main()
        show_panel()

    signals.logout.connect(logout)

    def monitor():
        if not state["sid"]:
            return
        try:
            actor = current_actor()
            prefs = core.router.preferences(actor)
            # A local-only AI policy cannot silently start Gemini Live.
            permit_voice = (
                prefs["mode"] != "local_only"
                and bool(core.providers.key("gemini"))
                and not shell.muted
            )
            if permit_voice and state["live"] and state["voice"] is None:
                state["voice"] = asyncio.run_coroutine_threadsafe(
                    state["live"].run(), core.loop
                )
            elif not permit_voice and state["voice"] is not None:
                state["voice"].cancel()
                state["voice"] = None
        except DomainError:
            logout()

    timer = QTimer(shell._win)
    timer.timeout.connect(monitor)
    timer.start(1000)
    app = create_app(
        root,
        core=core,
        host=config["host"],
        port=config["port"],
        origins=allowed_origins(config),
    )
    server = uvicorn.Server(uvicorn.Config(app, **server_options(root, config)))
    thread = threading.Thread(
        target=server.run, name="JARVIS-single-backend", daemon=True
    )
    thread.start()
    shell._app.aboutToQuit.connect(lambda: setattr(server, "should_exit", True))
    if "--wait-for-hud" not in sys.argv:
        QTimer.singleShot(800, show_panel)
    shell.root.mainloop()
    server.should_exit = True
    thread.join(timeout=8)
    return 0


if __name__ == "__main__":
    raise SystemExit(launch())
