"""J.A.R.V.I.S. extensions over the preserved Brahma Echo foundation.

Upstream copyright (c) 2026 Suryaansh Tiwari. See LICENSE and NOTICE.md.
"""

__version__ = "0.2.0-foundation-extension"
