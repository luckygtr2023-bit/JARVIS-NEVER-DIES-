from __future__ import annotations

import ast
import asyncio
import hashlib
import importlib
import inspect
import json
import re
import zipfile
from pathlib import Path
from typing import Callable

from .types import DomainError, Principal, ToolResult, Status


class Catalog:
    """Read the existing tool declarations without importing Windows-only main.py."""

    def __init__(self, root: Path):
        self.root = Path(root)
        tree = ast.parse((self.root / "main.py").read_text(encoding="utf-8-sig"))
        assignment = next(
            n
            for n in tree.body
            if isinstance(n, ast.Assign)
            and any(
                isinstance(t, ast.Name) and t.id == "TOOL_DECLARATIONS"
                for t in n.targets
            )
        )
        self.declarations = ast.literal_eval(assignment.value)
        self.tools = {}
        for entry in self.declarations:
            name = entry["name"]
            if name not in self.tools:
                self.tools[name] = entry
            else:
                # Keep the upstream array untouched; Brain sees the union of duplicate metadata.
                self.tools[name]["parameters"]["properties"].update(
                    entry.get("parameters", {}).get("properties", {})
                )

    def validate(self, steps: list[dict], *, dependencies=True):
        if not isinstance(steps, list) or not 1 <= len(steps) <= 12:
            raise DomainError("INVALID_PLAN", "A plan must contain 1–12 steps.")
        for index, step in enumerate(steps):
            if not isinstance(step, dict) or not set(step) <= {
                "tool",
                "parameters",
                "purpose",
            }:
                raise DomainError("INVALID_PLAN_STEP")
            name = step.get("tool")
            if name not in self.tools:
                raise DomainError(
                    "UNKNOWN_TOOL",
                    "The plan requested a tool outside the inherited catalog.",
                )
            params = step.get("parameters", {})
            if not isinstance(params, dict) or len(json.dumps(params)) > 24000:
                raise DomainError("INVALID_TOOL_PARAMETERS")
            if dependencies:
                for previous in re.findall(r"\$\{step\.(\d+)\}", json.dumps(params)):
                    if int(previous) >= index:
                        raise DomainError(
                            "INVALID_STEP_DEPENDENCY",
                            "A step may refer only to an earlier result.",
                        )
            schema = self.tools[name].get("parameters", {})
            missing = [k for k in schema.get("required", []) if k not in params]
            if missing:
                raise DomainError(
                    "MISSING_TOOL_PARAMETERS", "Missing: " + ", ".join(missing)
                )
            if len(str(step.get("purpose", ""))) > 300:
                raise DomainError("PURPOSE_TOO_LONG")

    def for_actor(self, actor: Principal):
        return [v for k, v in self.tools.items() if actor.permits("tool:" + k)]


def step_hash(step: dict) -> str:
    return hashlib.sha256(
        json.dumps(
            step, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode()
    ).hexdigest()


class ActionPolicy:
    # These original tools can invoke arbitrary code or control protected host resources.
    PRIVILEGED = {
        "agent_task",
        "dev_agent",
        "computer_control",
        "system_manager",
        "background_monitor",
        "desktop_control",
        "unlock_device",
        "shutdown_brahma",
        "clipboard_processor",
        "check_instagram_messages",
        "instagram_reply",
        "file_processor",
    }
    NO_CONFIRM = {
        "web_search",
        "weather_report",
        "flight_finder",
        "connect_list_devices",
        "connect_get_device",
        "connect_get_capabilities",
        "save_memory",
    }
    FILE_TOOLS = {
        "file_controller",
        "word_document",
        "pdf_document",
        "spreadsheet_builder",
        "presentation_builder",
    }
    PATH_KEYS = {
        "path",
        "file_path",
        "output_path",
        "source",
        "destination",
        "folder",
        "directory",
        "workspace_path",
    }
    PROTECTED_NAMES = {
        "api_keys.json",
        "workspace_store.sqlite3",
        "smart_home.sqlite3",
        ".env",
        "credentials",
        "credentials.json",
    }

    def __init__(self, root: Path, catalog: Catalog):
        self.root, self.catalog = Path(root).resolve(), catalog

    def workspace(self, actor: Principal) -> Path:
        path = (self.root / "user_workspaces" / actor.user_id).resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    def prepare(self, actor: Principal, step: dict) -> dict:
        self.catalog.validate([step], dependencies=False)
        name, args = step["tool"], dict(step.get("parameters", {}))
        actor.require("memory" if name == "save_memory" else "tool:" + name)
        if name in self.PRIVILEGED and actor.role != "OWNER":
            raise DomainError("OWNER_TOOL_REQUIRED", status=403)
        args.pop(
            "confirmed", None
        )  # Client/model confirmation flags are never authority.
        workspace = self.workspace(actor)
        android_target = name == "file_controller" and str(
            args.get("target") or ""
        ).strip().lower() not in {"", "pc", "computer", "local"}
        if android_target:
            actor.require("tool:connect_execute")
        for key, value in list(args.items()):
            if isinstance(value, str):
                value = value.replace("${workspace}", str(workspace))
                args[key] = value
            if key in self.PATH_KEYS and isinstance(value, str) and value:
                parts = re.split(r"[\\/]", value.casefold())
                if (
                    any(
                        p in self.PROTECTED_NAMES or p.endswith(".sealed")
                        for p in parts
                    )
                    or "private" in parts
                ):
                    raise DomainError(
                        "PROTECTED_PATH",
                        "Credentials and backend private state cannot be accessed through tools.",
                        403,
                    )
                if (
                    actor.role != "OWNER"
                    and name in self.FILE_TOOLS
                    and not android_target
                ):
                    path = Path(value).expanduser().resolve()
                    if not path.is_relative_to(workspace):
                        raise DomainError(
                            "WORKSPACE_SCOPE_REQUIRED",
                            "This account can use file tools only inside its own workspace.",
                            403,
                        )
        if actor.role != "OWNER" and name in self.FILE_TOOLS and not android_target:
            if name == "file_controller" and args.get("action") not in {
                "list",
                "read",
                "find",
                "info",
                "disk_usage",
                "largest",
                "create_file",
                "create_folder",
                "write",
                "delete",
                "move",
                "copy",
                "rename",
                "organize_folder",
            }:
                raise DomainError(
                    "OWNER_TOOL_ACTION_REQUIRED",
                    "This file action can operate beyond the user's workspace.",
                    403,
                )
            for filename_key in ("name", "new_name", "filename"):
                filename = args.get(filename_key)
                if isinstance(filename, str) and (
                    "/" in filename or "\\" in filename or filename in {".", ".."}
                ):
                    raise DomainError("WORKSPACE_SCOPE_REQUIRED", status=403)
            if name == "file_controller" and "path" not in args:
                args["path"] = str(workspace)
            elif name != "file_controller" and "output_path" not in args:
                suffix = {
                    "word_document": ".docx",
                    "pdf_document": ".pdf",
                    "spreadsheet_builder": ".xlsx",
                    "presentation_builder": ".pptx",
                }[name]
                args["output_path"] = str(workspace / ("document" + suffix))
            args["auto_open"] = False
        return {
            "tool": name,
            "parameters": args,
            "purpose": str(step.get("purpose", "")),
        }

    def consequential(self, step: dict) -> bool:
        name, args = step["tool"], step["parameters"]
        if name in self.NO_CONFIRM:
            return False
        if name == "file_controller" and args.get("action") in {
            "read",
            "list",
            "find",
            "info",
            "disk_usage",
        }:
            return False
        # Fail closed for natural-language, unknown and effectful tool actions.
        return True


# Portable paths delegate to the actual inherited action functions, not replacement generators.
PORTABLE = {
    "word_document": ("actions.docx_tools", "word_document"),
    "pdf_document": ("actions.pdf_tools", "create_pdf"),
    "spreadsheet_builder": ("actions.office_builder", "create_spreadsheet"),
    "presentation_builder": ("actions.office_builder", "create_presentation"),
    "web_search": ("actions.web_search", "web_search"),
    "weather_report": ("actions.weather_report", "weather_action"),
    "flight_finder": ("actions.flight_finder", "flight_finder"),
}


class BrahmaActions:
    def __init__(self, legacy_dispatch: Callable | None = None):
        self.legacy_dispatch = legacy_dispatch
        self._host_lock = asyncio.Lock()
        self._overrides: dict[str, Callable] = {}

    def register(self, name: str, handler: Callable):
        self._overrides[name] = handler

    async def execute(
        self, actor: Principal, step: dict, *, confirmed=False, before_dispatch=None
    ) -> ToolResult:
        name, parameters = step["tool"], dict(step["parameters"])
        if confirmed:
            parameters["confirmed"] = "yes"
        before = self._fingerprint(parameters.get("output_path"))
        async with self._host_lock:
            # A request may wait behind another host action. Revalidate AFTER the
            # lock is acquired so revocation/cancellation during that wait wins.
            if before_dispatch is not None:
                actor = await before_dispatch()
            if name in self._overrides:
                result = self._overrides[name](actor, parameters)
                if inspect.isawaitable(result):
                    result = await result
            elif self.legacy_dispatch:
                result = await self.legacy_dispatch(actor, name, parameters)
            elif name in PORTABLE:
                module, function = PORTABLE[name]
                handler = getattr(importlib.import_module(module), function)
                result = await asyncio.to_thread(
                    handler, parameters=parameters, player=None
                )
            else:
                raise DomainError(
                    "WINDOWS_RUNTIME_REQUIRED",
                    "This preserved tool requires the native Windows HUD/runtime.",
                    503,
                )
        if isinstance(result, ToolResult):
            return result
        if isinstance(result, dict) and result.get("success") is False:
            raise DomainError(
                "TOOL_FAILED", "The inherited tool reported failure.", 502
            )
        text = str(result)
        if re.match(
            r"(?i)^(error\b|failed\b|could not\b|unable to\b|unsupported\b|unknown action\b|tool .* failed:)",
            text,
        ):
            raise DomainError(
                "TOOL_FAILED", "The inherited tool reported failure.", 502
            )
        path = parameters.get("output_path")
        after = self._fingerprint(path)
        if after and before != after:
            file = Path(path)
            if file.suffix.lower() in {".docx", ".xlsx", ".pptx"}:
                with zipfile.ZipFile(file) as archive:
                    if archive.testzip() is not None:
                        raise DomainError("ARTIFACT_INVALID", status=502)
            elif file.suffix.lower() == ".pdf" and not file.read_bytes().startswith(
                b"%PDF-"
            ):
                raise DomainError("ARTIFACT_INVALID", status=502)
            return ToolResult(
                result,
                Status.VERIFIED,
                "A changed, non-empty output artifact was independently inspected; Office visual rendering is not implied.",
            )
        return ToolResult(result)

    @staticmethod
    def _fingerprint(path):
        try:
            p = Path(path)
            if p.is_file() and 0 < p.stat().st_size <= 64 * 1024 * 1024:
                return hashlib.sha256(p.read_bytes()).hexdigest()
        except (OSError, TypeError, ValueError):
            pass
        return None
