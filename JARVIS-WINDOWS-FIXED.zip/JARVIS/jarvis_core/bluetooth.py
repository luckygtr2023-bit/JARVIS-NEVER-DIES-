from __future__ import annotations

import asyncio
import sys
from dataclasses import dataclass
from .types import DomainError


@dataclass(frozen=True)
class Bond:
    id: str
    name: str


class WindowsBluetooth:
    """Authoritative Windows OS bond state, queried afresh. No client assertions.

    Native adapter is IMPLEMENTED; physical acceptance requires a real Windows
    Bluetooth radio and consenting paired phone. There is no assume-paired mode.
    """

    live = True

    def _api(self):
        if sys.platform != "win32":
            raise DomainError(
                "BLUETOOTH_NOT_VERIFIED",
                "Windows pairing state cannot be verified on this host. Control denied.",
                403,
            )
        try:
            from winrt.windows.devices.bluetooth import BluetoothDevice
            from winrt.windows.devices.enumeration import DeviceInformation

            return BluetoothDevice, DeviceInformation
        except ImportError:
            raise DomainError(
                "BLUETOOTH_NOT_VERIFIED",
                "Windows Bluetooth dependencies are unavailable. Control denied.",
                403,
            )

    async def list_bonds(self) -> list[Bond]:
        bluetooth, information = self._api()
        try:
            selector = bluetooth.get_device_selector_from_pairing_state(True)
            entries = await asyncio.wait_for(information.find_all_async(selector), 8)
            return [Bond(e.id, e.name) for e in entries if e.pairing.is_paired]
        except DomainError:
            raise
        except Exception:
            raise DomainError(
                "BLUETOOTH_NOT_VERIFIED",
                "OS Bluetooth query failed. Control denied.",
                403,
            )

    async def is_paired(self, bond_id: str) -> bool:
        _, information = self._api()
        if not bond_id:
            return False
        try:
            device = await asyncio.wait_for(
                information.create_from_id_async(bond_id), 5
            )
            return bool(device and device.pairing.is_paired)
        except Exception:
            # OS errors are not evidence of pairing.
            raise DomainError(
                "BLUETOOTH_NOT_VERIFIED",
                "Fresh OS pairing verification failed. Control denied.",
                403,
            )
