from __future__ import annotations

import base64
import ctypes
import json
import os
import re
import secrets
import sys
import threading
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .types import DomainError


class SecretGuard:
    """Conservative DLP, not a claim that arbitrary unlabeled secrets are detectable.

    Memory is explicit/opt-in; no automatic transcript ingestion. Known provider
    secrets are additionally rejected. Credential-shaped imports fail atomically.
    """

    LABEL = re.compile(
        r"(?i)(password|passwd|passphrase|pin|otp|recovery[ _-]?code|secret|api[ _-]?key|access[ _-]?token|refresh[ _-]?token|client[ _-]?secret|authorization|private[ _-]?key|credential)\s*(?:[:=]|\bis\b)\s*\S+"
    )
    PATTERNS = [
        re.compile(p)
        for p in (
            r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
            r"\bAIza[0-9A-Za-z_-]{30,}\b",
            r"\bsk-(?:or-v1-)?[A-Za-z0-9_-]{12,}\b",
            r"\b(?:ghp|github_pat|xox[baprs])-?[A-Za-z0-9_-]{16,}\b",
            r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b",
            r"(?i)\bBearer\s+[A-Za-z0-9._~+/-]{8,}",
            r"(?i)https?://[^\s/:]+:[^\s/@]+@",
        )
    ]
    FORBIDDEN_KEYS = {
        "password",
        "passwd",
        "passphrase",
        "apikey",
        "token",
        "accesstoken",
        "refreshtoken",
        "clientsecret",
        "privatekey",
        "authorization",
        "credential",
        "credentials",
        "devicesecret",
        "pin",
        "otp",
        "recoverycode",
        "secret",
        "secretkey",
    }

    def __init__(self):
        self._known: set[str] = set()

    def register(self, value: str):
        if value and len(value) >= 8:
            self._known.add(value)

    def check(self, value):
        if isinstance(value, dict):
            for key, child in value.items():
                normalized = re.sub(r"[^a-z]", "", str(key).lower())
                if normalized in self.FORBIDDEN_KEYS or normalized.endswith(
                    ("password", "apikey", "accesstoken", "privatekey")
                ):
                    raise DomainError(
                        "SECRET_REJECTED",
                        "Credentials must not enter memory, plans or Combos.",
                    )
                self.check(str(key))
                self.check(child)
        elif isinstance(value, (list, tuple)):
            for child in value:
                self.check(child)
        elif isinstance(value, str):
            if (
                self.LABEL.search(value)
                or any(p.search(value) for p in self.PATTERNS)
                or any(s in value for s in self._known)
            ):
                raise DomainError(
                    "SECRET_REJECTED",
                    "Credential-shaped content was rejected; use the protected provider settings.",
                )

    def redact(self, value: str) -> str:
        text = str(value)
        try:
            self.check(text)
            # Tool results can be JSON strings; inspect keys as well as text.
            if text.lstrip().startswith(("{", "[")):
                try:
                    self.check(json.loads(text))
                except (ValueError, TypeError):
                    pass
        except DomainError:
            # Do not retain fragments of a PEM key or multi-word passphrase.
            return "[REDACTED: credential-shaped or known-secret content]"
        return text


def _dpapi(data: bytes, decrypt: bool = False) -> bytes:
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [
            ("cbData", wintypes.DWORD),
            ("pbData", ctypes.POINTER(ctypes.c_byte)),
        ]

    buf = ctypes.create_string_buffer(data)
    incoming = Blob(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
    outgoing = Blob()
    function = (
        ctypes.windll.crypt32.CryptUnprotectData
        if decrypt
        else ctypes.windll.crypt32.CryptProtectData
    )
    description = None if decrypt else ctypes.c_wchar_p("JARVIS current-user secrets")
    if not function(
        ctypes.byref(incoming), description, None, None, None, 1, ctypes.byref(outgoing)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(outgoing.pbData, outgoing.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(outgoing.pbData)


class SecretStore:
    """Credentials outside memory/SQLite: current-user DPAPI on Windows.

    Non-Windows is for development: permission-restricted files, NOT DPAPI or a
    hardware vault. Never represent that mode as Windows security verification.
    """

    def __init__(self, directory: Path, guard: SecretGuard):
        self.directory, self.guard = Path(directory), guard
        self.directory.mkdir(parents=True, exist_ok=True)
        self.directory.chmod(0o700)
        self._lock = threading.RLock()
        self.mode = (
            "Windows current-user DPAPI"
            if sys.platform == "win32"
            else "development filesystem permissions (NOT DPAPI)"
        )

    def _path(self, name: str) -> Path:
        if not re.fullmatch(r"[a-z0-9_.-]{1,64}", name):
            raise DomainError("INVALID_SECRET_REFERENCE")
        return self.directory / (name + ".sealed")

    def get(self, name: str) -> str:
        with self._lock:
            path = self._path(name)
            if not path.exists():
                return ""
            value = path.read_bytes()
            if value.startswith(b"DPAPI1:"):
                if sys.platform != "win32":
                    raise DomainError("WINDOWS_SECRET_STORE_REQUIRED", status=503)
                value = _dpapi(value[7:], decrypt=True)
            elif value.startswith(b"DEV1:") and sys.platform != "win32":
                value = value[5:]
            else:
                raise DomainError("SECRET_STORE_MODE_MISMATCH", status=503)
            result = value.decode("utf-8")
            self.guard.register(result)
            return result

    def set(self, name: str, value: str):
        with self._lock:
            path = self._path(name)
            data = value.encode("utf-8")
            data = (
                b"DPAPI1:" + _dpapi(data)
                if sys.platform == "win32"
                else b"DEV1:" + data
            )
            temporary = path.with_suffix(".tmp")
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
            os.replace(temporary, path)
            path.chmod(0o600)
            self.guard.register(value)

    def get_or_create(self, name: str) -> str:
        with self._lock:
            value = self.get(name)
            if not value:
                value = secrets.token_urlsafe(32)
                self.set(name, value)
            return value


class ContentCipher:
    def __init__(self, key: bytes):
        if len(key) != 32:
            raise ValueError("AES-256 key required")
        self._cipher = AESGCM(key)

    @classmethod
    def from_store(cls, store: SecretStore):
        raw = store.get("content_key")
        if not raw:
            raw = base64.b64encode(os.urandom(32)).decode()
            store.set("content_key", raw)
        return cls(base64.b64decode(raw))

    def seal(self, user_id: str, resource_id: str, value) -> bytes:
        nonce = os.urandom(12)
        aad = f"jarvis.v1:{user_id}:{resource_id}".encode()
        return nonce + self._cipher.encrypt(
            nonce, json.dumps(value, ensure_ascii=False).encode(), aad
        )

    def open(self, user_id: str, resource_id: str, data: bytes):
        aad = f"jarvis.v1:{user_id}:{resource_id}".encode()
        return json.loads(self._cipher.decrypt(data[:12], data[12:], aad))
