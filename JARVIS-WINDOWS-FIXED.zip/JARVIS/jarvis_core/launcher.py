"""Local launcher IPC/preflight. Never prints authentication material."""

from __future__ import annotations
import argparse
import importlib
import json
import os
import sys
from pathlib import Path
import urllib.request

from .runtime import network_config, local_url
from .secrets import SecretStore, SecretGuard

ROOT = Path(__file__).resolve().parents[1]


def health():
    cfg = network_config(ROOT)
    import ssl

    context = None
    if cfg["tls"]:
        cert = Path(cfg["tls_cert"])
        if not cert.is_absolute():
            cert = ROOT / cert
        context = ssl.create_default_context(cafile=str(cert))
    with urllib.request.urlopen(
        local_url(cfg) + "/v1/health", timeout=3, context=context
    ) as response:
        data = json.load(response)
    if data.get("application") != "JARVIS" or not data.get("ok"):
        raise RuntimeError("Unexpected service on configured backend port")
    return data


def show():
    cfg = network_config(ROOT)
    secret = SecretStore(ROOT / "config/private", SecretGuard()).get("local_process")
    if not secret:
        raise RuntimeError("Backend local proof is not available")
    request = urllib.request.Request(
        local_url(cfg) + "/v1/internal/hud/show",
        data=b"{}",
        headers={"Content-Type": "application/json", "X-Jarvis-Local": secret},
        method="POST",
    )
    import ssl

    context = None
    if cfg["tls"]:
        cert = Path(cfg["tls_cert"])
        context = ssl.create_default_context(
            cafile=str(cert if cert.is_absolute() else ROOT / cert)
        )
    with urllib.request.urlopen(request, timeout=5, context=context) as response:
        if response.status != 200:
            raise RuntimeError("HUD activation failed")


def preflight():
    if sys.platform != "win32":
        raise RuntimeError("Native launcher requires Windows")
    if sys.version_info[:2] not in {(3, 11), (3, 12)}:
        raise RuntimeError("Python 3.11/3.12 required")
    for name in (
        "winreg",
        "PyQt6.QtWidgets",
        "PyQt6.QtWebEngineWidgets",
        "fastapi",
        "uvicorn",
        "cryptography",
        "google.genai",
        "cv2",
        "numpy",
        "sounddevice",
        "pyaudio",
        "playwright.async_api",
        "docx",
        "openpyxl",
        "pptx",
        "reportlab",
        "winrt.windows.devices.bluetooth",
        "winrt.windows.devices.enumeration",
        "jarvis_core.api",
        "main",
    ):
        importlib.import_module(name)
        print("Import OK:", name)
    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        if not Path(playwright.chromium.executable_path).is_file():
            raise RuntimeError("Chromium missing")
    # Presence is not physical verification or a provider success.
    import shutil

    for name in ("git", "node", "ffmpeg", "ollama"):
        print(
            "External dependency",
            name,
            ":",
            "FOUND"
            if shutil.which(name)
            else "NOT FOUND (related optional path needs setup)",
        )
    print(
        "Bluetooth hardware, live providers, voice and physical Android: NOT VERIFIED by preflight."
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["health", "show", "preflight"])
    args = parser.parse_args()
    try:
        if args.operation == "preflight":
            preflight()
        elif args.operation == "show":
            show()
            print("HUD show requested")
        else:
            result = health()
            print(
                "Backend health OK; native HUD:", result.get("native_hud_ready", False)
            )
        return 0
    except Exception as error:
        print("JARVIS", args.operation, "failed:", type(error).__name__)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
